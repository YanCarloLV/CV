// Generado por tools/build.js a partir del canal de Roku. No editar a mano.
$defineComponent({"name":"CategoryItem","extends":"Group","fields":[{"id":"itemContent","type":"node","onChange":"showItem"},{"id":"width","type":"float","onChange":"layoutItem"},{"id":"height","type":"float"},{"id":"focusPercent","type":"float","onChange":"showFocus"}],"children":[{"type":"Poster","attrs":{"id":"icon","translation":"[18,14]","width":"26","height":"26","loadWidth":"52","loadHeight":"52","loadDisplayMode":"scaleToFit","blendColor":"0xC8CCD2FF"},"children":[]},{"type":"Label","attrs":{"id":"name","translation":"[58,15]","width":"214","color":"0xE6E8ECFF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-SemiBold.ttf","size":"17"},"children":[]}]},{"type":"Label","attrs":{"id":"count","translation":"[250,17]","width":"70","horizAlign":"right","color":"0x8A8F98FF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Regular.ttf","size":"14"},"children":[]}]}]}, function (m) {
// ---- components/categoryitem.brs ----
function init() {
  m.icon = m.top.$findnode("icon");
  m.name = m.top.$findnode("name");
  m.count = m.top.$findnode("count");
}

function layoutitem() {
  let w;
  w = m.top.width;
  if ((w < 200)) {
    w = 340;
  }
  m.name.width = ((w - 58) - 80);
  m.count.translation = [(w - 90), 17];
}

function showitem() {
  let item, title, nm, cnt, p;
  item = m.top.itemcontent;
  if ((item == null)) {
    return;
  }
  title = item.title;
  if ((title == null)) {
    title = "";
  }
  nm = title;
  cnt = "";
  p = $instr(1, title, "  (");
  if ((p > 0)) {
    nm = $left(title, (p - 1));
    cnt = $mid(title, (p + 3));
    cnt = cnt.$replace(")", "");
  }
  m.name.text = tx(cleanglyphs(nm));
  m.count.text = cnt;
  m.icon.uri = (("pkg:/images/cat_" + caticonname(nm)) + ".png");
}

function caticonname(nm) {
  let s;
  s = $lcase(nm);
  if ((((($instr(1, s, "deport") > 0) || ($instr(1, s, "sport") > 0)) || ($instr(1, s, "futbol") > 0)) || ($instr(1, s, "esporte") > 0))) {
    return "sport";
  }
  if (((((($instr(1, s, "notic") > 0) || ($instr(1, s, "news") > 0)) || ($instr(1, s, "actualit") > 0)) || ($instr(1, s, "nachricht") > 0)) || ($instr(1, s, "notizie") > 0))) {
    return "news";
  }
  if (((((($instr(1, s, "entreten") > 0) || ($instr(1, s, "entertain") > 0)) || ($instr(1, s, "divertiss") > 0)) || ($instr(1, s, "unterhalt") > 0)) || ($instr(1, s, "intratten") > 0))) {
    return "star";
  }
  if ((((($instr(1, s, "cine") > 0) || ($instr(1, s, "pel") > 0)) || ($instr(1, s, "movie") > 0)) || ($instr(1, s, "film") > 0))) {
    return "film";
  }
  if ((($instr(1, s, "serie") > 0) || ($instr(1, s, "séries") > 0))) {
    return "series";
  }
  if ((((((($instr(1, s, "infantil") > 0) || ($instr(1, s, "kids") > 0)) || ($instr(1, s, "ni") === 1)) || ($instr(1, s, "enfant") > 0)) || ($instr(1, s, "kinder") > 0)) || ($instr(1, s, "bambini") > 0))) {
    return "kids";
  }
  if ((((($instr(1, s, "music") > 0) || ($instr(1, s, "radio") > 0)) || ($instr(1, nm, "Música") > 0)) || ($instr(1, s, "musi") > 0))) {
    return "music";
  }
  if ((($instr(1, s, "document") > 0) || ($instr(1, s, "dokument") > 0))) {
    return "doc";
  }
  if ((($instr(1, s, "adult") > 0) || ($instr(1, s, "erwachsen") > 0))) {
    return "adult";
  }
  if ((((((($instr(1, s, "otros") > 0) || ($instr(1, s, "other") > 0)) || ($instr(1, s, "outros") > 0)) || ($instr(1, s, "autres") > 0)) || ($instr(1, s, "andere") > 0)) || ($instr(1, s, "altri") > 0))) {
    return "other";
  }
  return "tv";
}

function showfocus() {
  if ((m.top.focuspercent > 0.5)) {
    m.name.color = "0xFFFFFFFF";
    m.icon.blendcolor = "0xFF8A24FF";
  } else {
    m.name.color = "0xE6E8ECFF";
    m.icon.blendcolor = "0xC8CCD2FF";
  }
}
// ---- components/i18n.brs ----
function i18nlangs() {
  return [{__proto__: $AAP, "code": "es", "name": "Español", "flag": "pkg:/images/flag_es.png"}, {__proto__: $AAP, "code": "en", "name": "English", "flag": "pkg:/images/flag_en.png"}, {__proto__: $AAP, "code": "pt", "name": "Português", "flag": "pkg:/images/flag_pt.png"}, {__proto__: $AAP, "code": "fr", "name": "Français", "flag": "pkg:/images/flag_fr.png"}, {__proto__: $AAP, "code": "de", "name": "Deutsch", "flag": "pkg:/images/flag_de.png"}, {__proto__: $AAP, "code": "it", "name": "Italiano", "flag": "pkg:/images/flag_it.png"}];
}

function i18nvalid(code) {
  let l;
  for (l of $iter(i18nlangs())) {
    if ((l.code === code)) {
      return true;
    }
  }
  return false;
}

function i18ndetect() {
  let code, di, loc, c;
  code = "en";
  di = $createobject("roDeviceInfo");
  if ((di != null)) {
    loc = di.$getcurrentlocale();
    if (((loc != null) && ($len(loc) >= 2))) {
      c = $lcase($left(loc, 2));
      if (i18nvalid(c)) {
        code = c;
      }
    }
  }
  return code;
}

function i18nload(lang) {
  let d, txt, arr, p;
  d = $createobject("roAssociativeArray");
  d.$setmodecasesensitive();
  txt = $readasciifile((("pkg:/locale/" + lang) + ".json"));
  if (((txt != null) && (txt !== ""))) {
    arr = $parsejson(txt);
    if ((arr != null)) {
      for (p of $iter(arr)) {
        $six(d, $ix(p, 0), $ix(p, 1));
      }
    }
  }
  m.i18nd = d;
  m.i18nlang = lang;
}

function tx(s) {
  let lang, v;
  lang = m.global.lang;
  if ((lang == null)) {
    return s;
  }
  if ((lang === "es")) {
    return s;
  }
  if ((m.i18nlang == null)) {
    i18nload(lang);
  } else if ((m.i18nlang !== lang)) {
    i18nload(lang);
  }
  v = m.i18nd.$lookup(s);
  if ((v == null)) {
    return s;
  }
  return v;
}

function i18nlang() {
  let l;
  l = m.global.lang;
  if ((l == null)) {
    return "es";
  }
  return l;
}

function i18n24h() {
  let l;
  l = i18nlang();
  return (((l !== "es") && (l !== "en")));
}

function i18ndow3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  }
  if ((l === "pt")) {
    return ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
  }
  if ((l === "fr")) {
    return ["dim.", "lun.", "mar.", "mer.", "jeu.", "ven.", "sam."];
  }
  if ((l === "de")) {
    return ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
  }
  if ((l === "it")) {
    return ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
  }
  return ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
}

function i18nmon3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  }
  if ((l === "pt")) {
    return ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
  }
  if ((l === "fr")) {
    return ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
  }
  if ((l === "de")) {
    return ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];
  }
  if ((l === "it")) {
    return ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"];
  }
  return ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
}

function i18ndowfull() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  }
  if ((l === "pt")) {
    return ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
  }
  if ((l === "fr")) {
    return ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  }
  if ((l === "de")) {
    return ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
  }
  if ((l === "it")) {
    return ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"];
  }
  return ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
}

function i18ncompass() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  }
  if ((l === "pt")) {
    return ["N", "NE", "L", "SE", "S", "SO", "O", "NO"];
  }
  if ((l === "de")) {
    return ["N", "NO", "O", "SO", "S", "SW", "W", "NW"];
  }
  if ((l === "it")) {
    return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
  }
  return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
}

function i18nhm(h, mm, longfmt) {
  let hs, h12, l, suf;
  if (i18n24h()) {
    hs = h.$tostr();
    if ((h < 10)) {
      hs = ("0" + hs);
    }
    return ((hs + ":") + mm);
  }
  h12 = (h % 12);
  if ((h12 === 0)) {
    h12 = 12;
  }
  l = i18nlang();
  if ((l === "en")) {
    suf = " AM";
    if ((h >= 12)) {
      suf = " PM";
    }
    if ((!longfmt)) {
      suf = "a";
      if ((h >= 12)) {
        suf = "p";
      }
    }
    return (((h12.$tostr() + ":") + mm) + suf);
  }
  if (longfmt) {
    suf = " a. m.";
    if ((h >= 12)) {
      suf = " p. m.";
    }
  } else {
    suf = "a";
    if ((h >= 12)) {
      suf = "p";
    }
  }
  return (((h12.$tostr() + ":") + mm) + suf);
}
// ---- components/glyphs.brs ----
function cleanglyphs(s) {
  let n, out, changed, i, $e0, ch, a, keep, sx;
  if ((s == null)) {
    return "";
  }
  n = $len(s);
  if ((n === 0)) {
    return "";
  }
  out = "";
  changed = false;
  for (i = 1, $e0 = n; i <= $e0; i++) {
    ch = $mid(s, i, 1);
    a = $asc(ch);
    if ((a < 128)) {
      out = (out + ch);
    } else {
      keep = true;
      if (((a >= 8192) && (a <= 11263))) {
        keep = ((((((((((a === 8211) || (a === 8212)) || (a === 8216)) || (a === 8217)) || (a === 8220)) || (a === 8221)) || (a === 8226)) || (a === 8230)) || (a === 8364)));
      } else if (((a >= 7424) && (a <= 7615))) {
        sx = $instr(1, "ᴬᴮᴰᴱᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾᴿᵀᵁᵂ", ch);
        if ((sx > 0)) {
          ch = $mid("ABDEGHIJKLMNOPRTUW", sx, 1);
        } else {
          keep = false;
        }
      } else if (((a >= 65024) && (a <= 65039))) {
        keep = false;
      } else if (((a >= 57344) && (a <= 63743))) {
        keep = false;
      } else if (((a >= 65536) || (((a >= 55296) && (a <= 57343))))) {
        keep = false;
      }
      if (keep) {
        if ((a === 477)) {
          ch = "e";
        }
        if ((a === 592)) {
          ch = "a";
        }
        if ((a === 633)) {
          ch = "r";
        }
        if ((a === 647)) {
          ch = "t";
        }
        if ((a === 623)) {
          ch = "m";
        }
        if ((a === 654)) {
          ch = "y";
        }
        if ((a === 613)) {
          ch = "h";
        }
        if ((a === 596)) {
          ch = "o";
        }
        out = (out + ch);
      }
      changed = true;
    }
  }
  if ((!changed)) {
    return s;
  }
  out = out.$trim();
  while ((($len(out) > 0) && ($instr(1, "|-·:._*", $left(out, 1)) > 0))) {
    out = $mid(out, 2).$trim();
  }
  while (($instr(1, out, "  ") > 0)) {
    out = out.$replace("  ", " ");
  }
  if ((out === "")) {
    return s;
  }
  return out;
}
return {"init": init, "layoutitem": layoutitem, "showitem": showitem, "caticonname": caticonname, "showfocus": showfocus, "i18nlangs": i18nlangs, "i18nvalid": i18nvalid, "i18ndetect": i18ndetect, "i18nload": i18nload, "tx": tx, "i18nlang": i18nlang, "i18n24h": i18n24h, "i18ndow3": i18ndow3, "i18nmon3": i18nmon3, "i18ndowfull": i18ndowfull, "i18ncompass": i18ncompass, "i18nhm": i18nhm, "cleanglyphs": cleanglyphs};
});

$defineComponent({"name":"ChannelItem","extends":"Group","fields":[{"id":"itemContent","type":"node","onChange":"showItem"},{"id":"width","type":"float","onChange":"layoutItem"},{"id":"height","type":"float","onChange":"layoutItem"},{"id":"focusPercent","type":"float","onChange":"showFocus"}],"children":[{"type":"Poster","attrs":{"id":"logoBg","translation":"[30,15]","width":"32","height":"32","loadWidth":"32","loadHeight":"32","uri":"pkg:/images/ic_live.png","blendColor":"0x8A8F98FF","opacity":"0.4"},"children":[]},{"type":"Poster","attrs":{"id":"logo","translation":"[12,10]","width":"68","height":"42","loadWidth":"136","loadHeight":"84","loadDisplayMode":"scaleToFit"},"children":[]},{"type":"Label","attrs":{"id":"title","translation":"[94,8]","width":"330","color":"0xFFFFFFFF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-SemiBold.ttf","size":"18"},"children":[]}]},{"type":"Rectangle","attrs":{"id":"barBg","translation":"[94,40]","width":"34","height":"3","color":"0xFFFFFF30"},"children":[]},{"type":"Rectangle","attrs":{"id":"barFg","translation":"[94,40]","width":"0","height":"3","color":"0xFF8A24FF"},"children":[]},{"type":"Label","attrs":{"id":"sub","translation":"[136,33]","width":"290","color":"0x9AA0A8FF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Regular.ttf","size":"14"},"children":[]}]},{"type":"Poster","attrs":{"id":"heart","translation":"[430,21]","width":"20","height":"20","loadWidth":"40","loadHeight":"40","loadDisplayMode":"scaleToFit","uri":"pkg:/images/heart_on.png","visible":"false"},"children":[]}]}, function (m) {
// ---- components/channelitem.brs ----
function init() {
  m.logo = m.top.$findnode("logo");
  m.logobg = m.top.$findnode("logoBg");
  m.title = m.top.$findnode("title");
  m.sub = m.top.$findnode("sub");
  m.barbg = m.top.$findnode("barBg");
  m.barfg = m.top.$findnode("barFg");
  m.heart = m.top.$findnode("heart");
  m.node = null;
  m.w = 460;
}

function layoutitem() {
  let w;
  w = m.top.width;
  if ((w < 200)) {
    w = 460;
  }
  m.w = w;
  m.title.width = ((w - 94) - 40);
  m.sub.width = ((w - 136) - 40);
  m.heart.translation = [(w - 32), 21];
}

function showitem() {
  let item;
  item = m.top.itemcontent;
  if ((item == null)) {
    return;
  }
  if ((m.node != null)) {
    m.node.$unobservefieldscoped("starRating");
    m.node.$unobservefieldscoped("releaseDate");
    m.node.$unobservefieldscoped("hdPosterUrl");
    m.node.$unobservefieldscoped("playStart");
  }
  m.node = item;
  item.$observefieldscoped("starRating", "refreshItem");
  item.$observefieldscoped("releaseDate", "refreshItem");
  item.$observefieldscoped("hdPosterUrl", "refreshItem");
  item.$observefieldscoped("playStart", "refreshItem");
  refreshitem();
}

function refreshitem() {
  let item, num, nm, uri, line2, src, hasnow, pct, showbar;
  item = m.node;
  if ((item == null)) {
    return;
  }
  num = item.shortdescriptionline1;
  if ((num == null)) {
    num = "";
  }
  nm = cleanglyphs(item.title);
  if ((num !== "")) {
    m.title.text = ((num + "   ") + nm);
  } else {
    m.title.text = nm;
  }
  uri = item.hdposterurl;
  if ((uri == null)) {
    uri = "";
  }
  m.logo.uri = uri;
  m.logo.visible = ((uri !== ""));
  m.logobg.visible = ((uri === ""));
  line2 = item.releasedate;
  if ((line2 == null)) {
    line2 = "";
  }
  src = item.rating;
  if ((($type(src) === "roString") || ($type(src) === "String"))) {
    if (((src !== "") && (line2 === ""))) {
      line2 = src;
    }
  }
  hasnow = ((line2 !== ""));
  m.sub.text = line2;
  m.sub.visible = hasnow;
  pct = item.playstart;
  if ((pct == null)) {
    pct = 0;
  }
  showbar = ((hasnow && (pct > 0)));
  m.barbg.visible = showbar;
  m.barfg.visible = showbar;
  if (showbar) {
    if ((pct > 100)) {
      pct = 100;
    }
    m.barfg.width = $int(((34 * pct) / 100));
    m.sub.translation = [136, 33];
  } else {
    m.sub.translation = [94, 33];
  }
  if (hasnow) {
    m.title.translation = [94, 8];
  } else {
    m.title.translation = [94, 20];
  }
  m.heart.visible = ((item.starrating === 100));
}

function showfocus() {
  if ((m.top.focuspercent > 0.5)) {
    m.sub.color = "0xD8DCE2FF";
  } else {
    m.sub.color = "0x9AA0A8FF";
  }
}
// ---- components/glyphs.brs ----
function cleanglyphs(s) {
  let n, out, changed, i, $e0, ch, a, keep, sx;
  if ((s == null)) {
    return "";
  }
  n = $len(s);
  if ((n === 0)) {
    return "";
  }
  out = "";
  changed = false;
  for (i = 1, $e0 = n; i <= $e0; i++) {
    ch = $mid(s, i, 1);
    a = $asc(ch);
    if ((a < 128)) {
      out = (out + ch);
    } else {
      keep = true;
      if (((a >= 8192) && (a <= 11263))) {
        keep = ((((((((((a === 8211) || (a === 8212)) || (a === 8216)) || (a === 8217)) || (a === 8220)) || (a === 8221)) || (a === 8226)) || (a === 8230)) || (a === 8364)));
      } else if (((a >= 7424) && (a <= 7615))) {
        sx = $instr(1, "ᴬᴮᴰᴱᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾᴿᵀᵁᵂ", ch);
        if ((sx > 0)) {
          ch = $mid("ABDEGHIJKLMNOPRTUW", sx, 1);
        } else {
          keep = false;
        }
      } else if (((a >= 65024) && (a <= 65039))) {
        keep = false;
      } else if (((a >= 57344) && (a <= 63743))) {
        keep = false;
      } else if (((a >= 65536) || (((a >= 55296) && (a <= 57343))))) {
        keep = false;
      }
      if (keep) {
        if ((a === 477)) {
          ch = "e";
        }
        if ((a === 592)) {
          ch = "a";
        }
        if ((a === 633)) {
          ch = "r";
        }
        if ((a === 647)) {
          ch = "t";
        }
        if ((a === 623)) {
          ch = "m";
        }
        if ((a === 654)) {
          ch = "y";
        }
        if ((a === 613)) {
          ch = "h";
        }
        if ((a === 596)) {
          ch = "o";
        }
        out = (out + ch);
      }
      changed = true;
    }
  }
  if ((!changed)) {
    return s;
  }
  out = out.$trim();
  while ((($len(out) > 0) && ($instr(1, "|-·:._*", $left(out, 1)) > 0))) {
    out = $mid(out, 2).$trim();
  }
  while (($instr(1, out, "  ") > 0)) {
    out = out.$replace("  ", " ");
  }
  if ((out === "")) {
    return s;
  }
  return out;
}
return {"init": init, "layoutitem": layoutitem, "showitem": showitem, "refreshitem": refreshitem, "showfocus": showfocus, "cleanglyphs": cleanglyphs};
});

$defineComponent({"name":"ContentReader","extends":"Task","fields":[{"id":"contenturi","type":"string"},{"id":"content","type":"node"},{"id":"movies","type":"node"},{"id":"series","type":"node"},{"id":"adult","type":"node"},{"id":"wanted","type":"assocarray"},{"id":"epgurl","type":"string"},{"id":"listepg","type":"string"},{"id":"favs","type":"assocarray"},{"id":"direct","type":"boolean","value":"false"},{"id":"progress","type":"integer","value":"0"}],"children":[]}, function (m) {
// ---- components/contentreader.brs ----
function init() {
  m.top.functionname = "getcontent";
}

function getcontent() {
  let rootnode, url, fs, path, filesize, code, st, usefile, alllines, m3utext, rules, groups, appearance, moviegroups, movieorder, epgurl, curtitle, curgroup, curid, curlogo, curchno, grpvod, serdata, serorder, pending, pendingorder, adultgroups, adultorder, offset, more, chunksize, lastpct, lines, n, islast, ba, used, grow, i, text, pct, rawline, line, commaat, grp, bar, entry, both, agname, lu, ep, kind, gname, sg, arr, vodn, p, ordered, standard, movieroot, seriesroot, seen, favs, epgforitems;
  rootnode = $createobject("roSGNode", "ContentNode");
  url = m.top.contenturi;
  if (((url == null) || (url === ""))) {
    m.top.content = rootnode;
    return;
  }
  fs = $createobject("roFileSystem");
  path = "cachefs:/iptv_list.m3u";
  if (fs.$exists(path)) {
    fs.$delete(path);
  }
  filesize = 0;
  code = newhttp(url).$gettofile(path);
  if ((code === 200)) {
    st = fs.$stat(path);
    if ((st != null)) {
      filesize = st.size;
    }
  }
  usefile = ((filesize > 0));
  alllines = [];
  if ((!usefile)) {
    if (fs.$exists(path)) {
      fs.$delete(path);
    }
    m3utext = newhttp(url).$gettostring();
    if (((m3utext == null) || (m3utext === ""))) {
      m.top.content = rootnode;
      return;
    }
    m3utext = m3utext.$replace($chr(13), "");
    alllines = m3utext.$split($chr(10));
    m3utext = "";
  }
  rules = buildrules();
  groups = {__proto__: $AAP};
  appearance = [];
  moviegroups = {__proto__: $AAP};
  movieorder = [];
  epgurl = "";
  curtitle = tx("Canal sin nombre");
  curgroup = "";
  curid = "";
  curlogo = "";
  curchno = "";
  grpvod = {__proto__: $AAP};
  serdata = {__proto__: $AAP};
  serorder = [];
  pending = {__proto__: $AAP};
  pendingorder = [];
  adultgroups = {__proto__: $AAP};
  adultorder = [];
  offset = 0;
  more = true;
  chunksize = 262144;
  lastpct = (-1);
  while (more) {
    lines = alllines;
    more = false;
    if (usefile) {
      n = chunksize;
      islast = (((offset + n) >= filesize));
      if (islast) {
        n = (filesize - offset);
      }
      lines = [];
      ba = $createobject("roByteArray");
      if ((((n > 0) && ba.$readfile(path, offset, n)) && (ba.$count() > 0))) {
        used = ba.$count();
        grow = false;
        if ((!islast)) {
          i = (used - 1);
          while (((i >= 0) && ($ix(ba, i) !== 10))) {
            i = (i - 1);
          }
          if (((i >= 0) && ((i + 1) < used))) {
            used = (i + 1);
            ba = $createobject("roByteArray");
            ba.$readfile(path, offset, used);
          } else if ((i < 0)) {
            grow = true;
          }
        }
        if (grow) {
          chunksize = (chunksize * 2);
          more = true;
        } else {
          text = ba.$toasciistring();
          offset = (offset + used);
          text = text.$replace($chr(13), "");
          lines = text.$split($chr(10));
          if ((offset < filesize)) {
            more = true;
          }
          pct = $int(((offset / filesize) * 100));
          if ((pct > 99)) {
            pct = 99;
          }
          if ((pct !== lastpct)) {
            lastpct = pct;
            m.top.progress = pct;
          }
        }
      }
    }
    for (rawline of $iter(lines)) {
      line = rawline.$trim();
      if (($asc($left(line, 1)) === 65279)) {
        line = $mid(line, 2);
      }
      if (($left(line, 7) === "#EXTM3U")) {
        epgurl = firsturl(getattr(line, "url-tvg"));
        if ((epgurl === "")) {
          epgurl = firsturl(getattr(line, "x-tvg-url"));
        }
        if ((epgurl === "")) {
          epgurl = firsturl(getattr(line, "tvg-url"));
        }
      } else if (($left(line, 8) === "#EXTINF:")) {
        curtitle = "";
        commaat = titlecommapos(line);
        if ((commaat > 0)) {
          curtitle = $mid(line, (commaat + 1)).$trim();
        }
        if ((curtitle === "")) {
          curtitle = getattr(line, "tvg-name");
        }
        if ((curtitle === "")) {
          curtitle = tx("Canal sin nombre");
        }
        curgroup = getattr(line, "group-title");
        curid = $lcase(getattr(line, "tvg-id"));
        curlogo = cleanlogo(decodeentities(getattr(line, "tvg-logo")));
        if ((curlogo === "")) {
          curlogo = cleanlogo(decodeentities(getattr(line, "logo")));
        }
        curchno = getattr(line, "tvg-chno").$trim();
      } else if (($left(line, 8) === "#EXTGRP:")) {
        grp = $mid(line, 9).$trim();
        if ((grp !== "")) {
          curgroup = grp;
        }
      } else if ((($left(line, 4) === "http") || ($left(line, 4) === "rtmp"))) {
        bar = $instr(1, line, "|");
        if (((bar > 0) && ($instr(bar, line, "=") > 0))) {
          line = $left(line, (bar - 1)).$trim();
        }
        entry = {__proto__: $AAP, "t": curtitle, "u": line, "i": curid, "f": detectformat(line), "l": curlogo, "n": curchno};
        both = (($lcase(curgroup) + " | ") + $lcase(curtitle));
        if ((($instr(1, both, "adult swim") === 0) && matchany(both, rules.adult))) {
          agname = curgroup.$trim();
          if ((agname === "")) {
            agname = "Adultos";
          }
          lu = $lcase(line);
          entry.d = "live";
          if ((((($instr(1, lu, "/movie/") > 0) || ($instr(1, lu, "/series/") > 0)) || (entry.f === "mp4")) || (entry.f === "mkv"))) {
            entry.d = "movie";
          }
          addtogroup(adultgroups, adultorder, agname, entry);
        } else {
          ep = seriesof(curgroup, curtitle, line);
          kind = "live";
          if ((ep == null)) {
            kind = vodkind(curgroup, curtitle, line, curid);
          }
          gname = curgroup.$trim();
          if ((gname === "")) {
            gname = "Peliculas";
          }
          if ((ep != null)) {
            sg = gname;
            if ((sg === "")) {
              sg = "Series";
            }
            if ((ep.name === "")) {
              ep.name = sg;
            }
            seradd(serdata, serorder, sg, ep, entry);
          } else if ((kind === "vod")) {
            addtogroup(moviegroups, movieorder, gname, entry);
            if (grpvod.$doesexist(gname)) {
              $six(grpvod, gname, ($ix(grpvod, gname) + 1));
            } else {
              $six(grpvod, gname, 1);
            }
          } else if ((kind === "maybe")) {
            if ((!pending.$doesexist(gname))) {
              $six(pending, gname, []);
              pendingorder.$push(gname);
            }
            $ix(pending, gname).$push({__proto__: $AAP, "e": entry, "g": curgroup, "t": curtitle});
          } else {
            addtogroup(groups, appearance, classify(curgroup, curtitle, rules), entry);
          }
        }
        curtitle = tx("Canal sin nombre");
        curgroup = "";
        curid = "";
        curlogo = "";
        curchno = "";
      }
    }
  }
  if ((usefile && fs.$exists(path))) {
    fs.$delete(path);
  }
  for (gname of $iter(pendingorder)) {
    arr = $ix(pending, gname);
    vodn = 0;
    if (grpvod.$doesexist(gname)) {
      vodn = $ix(grpvod, gname);
    }
    for (p of $iter(arr)) {
      if ((vodn >= arr.$count())) {
        addtogroup(moviegroups, movieorder, gname, p.e);
      } else {
        addtogroup(groups, appearance, classify(p.g, p.t, rules), p.e);
      }
    }
  }
  ordered = [];
  standard = ["Deportes", "Noticias", "Entretenimiento", "Cine", "Series", "Infantil", "Música", "Documentales"];
  for (n of $iter(standard)) {
    if (groups.$doesexist(n)) {
      ordered.$push(n);
    }
  }
  for (n of $iter(appearance)) {
    if ((((!isin(ordered, n)) && (n !== "Otros")) && (n !== "Adultos"))) {
      ordered.$push(n);
    }
  }
  if (groups.$doesexist("Otros")) {
    ordered.$push("Otros");
  }
  if (groups.$doesexist("Adultos")) {
    ordered.$push("Adultos");
  }
  movieroot = $createobject("roSGNode", "ContentNode");
  seriesroot = $createobject("roSGNode", "ContentNode");
  if ((m.top.direct === true)) {
    seen = {__proto__: $AAP};
    favs = m.top.favs;
    if ((favs == null)) {
      favs = {__proto__: $AAP};
    }
    epgforitems = m.top.listepg;
    if ((epgforitems === "")) {
      epgforitems = epgurl;
    }
    filltreedirect(rootnode, groups, ordered, "live", seen, favs, epgforitems);
    filltreedirect(movieroot, moviegroups, movieorder, "movie", seen, favs, epgforitems);
    serfilldirect(seriesroot, serdata, serorder, seen, favs);
  } else {
    filltree(rootnode, groups, ordered, "live");
    filltree(movieroot, moviegroups, movieorder, "movie");
    serfill(seriesroot, serdata, serorder);
  }
  m.top.series = seriesroot;
  m.top.adult = buildadult(adultgroups, adultorder);
  m.top.movies = movieroot;
  m.top.epgurl = epgurl;
  m.top.wanted = epgwantedof(rootnode);
  m.top.content = rootnode;
}

function buildadult(ag, order) {
  let root, n, arr, cat, e, item;
  root = $createobject("roSGNode", "ContentNode");
  for (n of $iter(order)) {
    arr = $ix(ag, n);
    ag.$delete(n);
    if (((arr != null) && (arr.$count() > 0))) {
      cat = root.$createchild("ContentNode");
      cat.id = n;
      for (e of $iter(arr)) {
        item = cat.$createchild("ContentNode");
        item.$setfields({__proto__: $AAP, "title": e.t, "url": e.u, "id": e.i, "streamformat": e.f, "hdposterurl": e.l, "description": e.d});
      }
      cat.title = (((n + "  (") + cat.$getchildcount().$tostr()) + ")");
    }
  }
  return root;
}

function addtogroup(groups, appearance, name, entry) {
  if ((!groups.$doesexist(name))) {
    $six(groups, name, []);
    appearance.$push(name);
  }
  $ix(groups, name).$push(entry);
}

function newhttp(url) {
  let http;
  http = $createobject("roUrlTransfer");
  http.$setcertificatesfile("common:/certs/ca-bundle.crt");
  http.$initclientcertificates();
  http.$enableencodings(true);
  http.$seturl(url);
  return http;
}

function filltreedirect(rootnode, groups, ordered, kind, seen, favs, epg) {
  let n, arr, ch, catnode, u, sr, item;
  for (n of $iter(ordered)) {
    arr = $ix(groups, n);
    groups.$delete(n);
    if (((arr == null) || ($lcase(n) === "adultos"))) {
      continue;
    }
    if ((kind === "movie")) {
      for (ch of $iter(arr)) {
        ch.k = sortkey(ch.t);
      }
      arr.$sortby("k");
    }
    catnode = null;
    for (ch of $iter(arr)) {
      u = ch.u;
      if (((u === "") || (!seen.$doesexist(u)))) {
        if ((u !== "")) {
          $six(seen, u, true);
        }
        if ((catnode == null)) {
          catnode = rootnode.$createchild("ContentNode");
          catnode.id = n;
        }
        sr = 0;
        if (((u !== "") && favs.$doesexist(u))) {
          sr = 100;
        }
        item = catnode.$createchild("ContentNode");
        item.$setfields({__proto__: $AAP, "title": ch.t, "url": u, "id": ch.i, "streamformat": ch.f, "hdposterurl": ch.l, "shortdescriptionline1": ch.n, "shortdescriptionline2": epg, "description": kind, "starrating": sr});
      }
    }
    if ((catnode != null)) {
      catnode.title = (((n + "  (") + catnode.$getchildcount().$tostr()) + ")");
    }
  }
}

function filltree(rootnode, groups, ordered, kind) {
  let n, arr, ch, catnode, item;
  for (n of $iter(ordered)) {
    arr = $ix(groups, n);
    if ((kind === "movie")) {
      for (ch of $iter(arr)) {
        ch.k = sortkey(ch.t);
      }
      arr.$sortby("k");
    }
    catnode = rootnode.$createchild("ContentNode");
    catnode.id = n;
    catnode.title = (((n + "  (") + arr.$count().$tostr()) + ")");
    for (ch of $iter(arr)) {
      item = catnode.$createchild("ContentNode");
      item.title = ch.t;
      item.url = ch.u;
      item.id = ch.i;
      item.streamformat = ch.f;
      item.hdposterurl = ch.l;
      item.shortdescriptionline1 = ch.n;
      item.description = kind;
    }
  }
}

function vodkind(group, name, url, id) {
  let u, fmt, g;
  u = $lcase(url);
  if (($instr(1, u, "/live/") > 0)) {
    return "live";
  }
  if (($instr(1, u, "/movie/") > 0)) {
    return "vod";
  }
  if (($instr(1, u, "/series/") > 0)) {
    return "vod";
  }
  if (($instr(1, u, "/vod/") > 0)) {
    return "vod";
  }
  if (($instr(1, u, "type=movie") > 0)) {
    return "vod";
  }
  if (($instr(1, u, "type=series") > 0)) {
    return "vod";
  }
  fmt = detectformat(url);
  if (((fmt === "mp4") || (fmt === "mkv"))) {
    return "vod";
  }
  g = $lcase(group);
  if ((g === "")) {
    return "live";
  }
  if (matchany(g, ["deport", "noticia", "news", "infantil", "kids", "musica", ($chr(109) + "úsica"), "radio"])) {
    return "live";
  }
  if ((!matchany(g, ["pelic", "movie", "vod", "estreno", "halloween", "4k", "cine", "film", " fps", "castellano", "latino", "subtit"]))) {
    return "live";
  }
  if ((id !== "")) {
    return "live";
  }
  if (ischannelname($lcase(name))) {
    return "live";
  }
  if (hasyear(name)) {
    return "vod";
  }
  return "maybe";
}

function ischannelname(n) {
  return matchany(n, ["24/7", "24-7", "24h", "24 h", "en vivo", " tv", "tv ", "canal", "channel", "hbo", "cinemax", "cinecanal", "cinelatino", "studio universal", "tcm", "golden", "starz", "showtime", "paramount", "amc", "axn", "sony", "warner", "cine mexicano", "cine de oro", "cine clasico", "pasiones", "telehit"]);
}

function hasyear(t) {
  let n, i, $e0, c, okl, okr, alldigits, k, $e1, d;
  n = $len(t);
  if ((n < 4)) {
    return false;
  }
  for (i = 1, $e0 = (n - 3); i <= $e0; i++) {
    c = $mid(t, i, 4);
    if ((((($left(c, 2) === "19") || ($left(c, 2) === "20"))) && ($val(c) > 1929))) {
      okl = ((i === 1));
      if ((!okl)) {
        okl = ((($asc($mid(t, (i - 1), 1)) < 48) || ($asc($mid(t, (i - 1), 1)) > 57)));
      }
      okr = (((i + 3) === n));
      if ((!okr)) {
        okr = ((($asc($mid(t, (i + 4), 1)) < 48) || ($asc($mid(t, (i + 4), 1)) > 57)));
      }
      if (((okl && okr) && ($right($left(c, 4), 1) >= "0"))) {
        alldigits = true;
        for (k = 1, $e1 = 4; k <= $e1; k++) {
          d = $asc($mid(c, k, 1));
          if (((d < 48) || (d > 57))) {
            alldigits = false;
          }
        }
        if (alldigits) {
          return true;
        }
      }
    }
  }
  return false;
}

function classify(group, name, rules) {
  let g, n, both, r, gt, lg;
  g = $lcase(group);
  n = $lcase(name);
  both = ((g + " | ") + n);
  if (($instr(1, both, "adult swim") === 0)) {
    if (matchany(both, rules.adult)) {
      return "Adultos";
    }
  }
  if ((g !== "")) {
    for (r of $iter(rules.list)) {
      if (matchany(g, r.words)) {
        return r.name;
      }
    }
  }
  for (r of $iter(rules.list)) {
    if (matchany(n, r.words)) {
      return r.name;
    }
  }
  gt = group.$trim();
  lg = $lcase(gt);
  if (((((((((gt !== "") && (lg !== "general")) && (lg !== "undefined")) && (lg !== "other")) && (lg !== "otros")) && (lg !== "sin categoria")) && (lg !== "uncategorized")) && (lg !== "unknown"))) {
    return gt;
  }
  return "Otros";
}

function matchany(text, words) {
  let w;
  for (w of $iter(words)) {
    if (($instr(1, text, w) > 0)) {
      return true;
    }
  }
  return false;
}

function isin(arr, value) {
  let v;
  for (v of $iter(arr)) {
    if ((v === value)) {
      return true;
    }
  }
  return false;
}

function buildrules() {
  let rules;
  rules = {__proto__: $AAP};
  rules.adult = ["xxx", "adult", "porn", "erotic", "erotico", "erót", "erÓt", "playboy", "sexy", "18+", "hustler", "brazzers", "penthouse", "sextreme", "redlight", "dorcel"];
  rules.list = [{__proto__: $AAP, "name": "Infantil", "words": ["infantil", "kids", "niños", "niÑos", "ninos", "cartoon", "disney", "nickelodeon", "nick jr", "nick ", "boomerang", "baby", "tooncast", "dibujos", "animaci", "anime", "junior", "peppa", "paw patrol"]}, {__proto__: $AAP, "name": "Deportes", "words": ["deport", "sport", "futbol", "fútbol", "fÚtbol", "soccer", "nba", "nfl", "mlb", "nhl", "ufc", "espn", "tudn", "dazn", "bein", "eurosport", "golf", "tenis", "tennis", "boxeo", "boxing", "wwe", "lucha libre", "motogp", "formula 1", "formula1", "nascar", "racing", "olimp", "laliga", "premier league", "champions", "bundesliga", "gol tv", "caliente tv"]}, {__proto__: $AAP, "name": "Noticias", "words": ["noticia", "news", "informa", "cnn", "bbc", "euronews", "jazeera", "france 24", "france24", "telesur", "milenio", "foro tv", "adn 40", "nmas", "hispantv", "bloomberg", "cnbc", "ntn24", "dw español", "dw news", "rt news", "24 horas", "cgtn", "nhk world", "wion", "noticiero", "reuters"]}, {__proto__: $AAP, "name": "Música", "words": ["musica", "música", "mÚsica", "music", "mtv", "vevo", "radio", "hits", "reggaeton", "salsa", "cumbia", "norteñ", "norteÑ", "concert", "karaoke", "ritmoson", "telehit", "vh1", "stingray", "bachata", "mariachi", "corridos", "ranchero", "rock"]}, {__proto__: $AAP, "name": "Series", "words": ["serie", "novela", "drama", "sitcom"]}, {__proto__: $AAP, "name": "Cine", "words": ["pelic", "pelí", "pelÍ", "cine", "movie", "film", "hbo", "cinemax", "tcm", "paramount", "golden", "starz", "showtime", "estreno", "amc", "axn", "studio universal"]}, {__proto__: $AAP, "name": "Documentales", "words": ["document", "discovery", "history", "historia", "nat geo", "national geographic", "animal planet", "a&e", "ngc", "viajes", "travel", "ciencia", "science", "smithsonian", "planeta", "naturaleza", "nature", "investigation", "dmax", "explora"]}, {__proto__: $AAP, "name": "Entretenimiento", "words": ["entreten", "entertain", "variedad", "comedia", "comedy", "reality", "show", "adult swim", "lifestyle", "cocina", "food", "tlc", "telemundo", "televisa", "azteca", "estrellas", "univision", "unimas", "nu9ve", "canal 5", "lifetime", "fox", "tbs", "tnt", "hgtv", "hogar", "sony", "universal", "warner", "antena 3", "telecinco", "cuatro", "bravo", "multimedios"]}];
  return rules;
}

function titlecommapos(s) {
  let inq, i, $e2, c;
  inq = false;
  for (i = 1, $e2 = $len(s); i <= $e2; i++) {
    c = $mid(s, i, 1);
    if ((c === $chr(34))) {
      inq = (!inq);
    } else if (((c === ",") && (!inq))) {
      return i;
    }
  }
  return 0;
}

function lastpos(s, ch) {
  let result, i, $e3;
  result = 0;
  for (i = 1, $e3 = $len(s); i <= $e3; i++) {
    if (($mid(s, i, 1) === ch)) {
      result = i;
    }
  }
  return result;
}

function firsturl(s) {
  let commaat;
  s = s.$trim();
  commaat = $instr(1, s, ",");
  if ((commaat > 0)) {
    s = $left(s, (commaat - 1));
  }
  return s.$trim();
}

function detectformat(url) {
  let u, qpos;
  u = $lcase(url);
  qpos = $instr(1, u, "?");
  if ((qpos > 0)) {
    u = $left(u, (qpos - 1));
  }
  if (($right(u, 4) === ".mp4")) {
    return "mp4";
  }
  if (($right(u, 4) === ".mkv")) {
    return "mkv";
  }
  if (($right(u, 3) === ".ts")) {
    return "ts";
  }
  return "hls";
}

function seriesof(group, title, url) {
  let u, fmt, vodfmt, gl, sergroup, serurl, ep, nm;
  u = $lcase(url);
  if (($instr(1, u, "/live/") > 0)) {
    return null;
  }
  fmt = detectformat(url);
  vodfmt = (((fmt === "mp4") || (fmt === "mkv")));
  gl = $lcase(group);
  sergroup = (((($instr(1, gl, "serie") > 0) || ($instr(1, gl, "season") > 0)) || ($instr(1, gl, "temporada") > 0)));
  serurl = ((($instr(1, u, "/series/") > 0) || ($instr(1, u, "type=series") > 0)));
  ep = epparse(title);
  if ((ep != null)) {
    if ((((ep.strong || sergroup) || serurl) || vodfmt)) {
      return ep;
    }
    return null;
  }
  if ((((serurl || ((sergroup && vodfmt)))) && (!ischannelname($lcase(title))))) {
    nm = group.$trim();
    if ((nm === "")) {
      nm = "Series";
    }
    return {__proto__: $AAP, "name": nm, "s": 1, "e": 0, "t": title, "strong": false};
  }
  return null;
}
// ---- components/utils.brs ----
function getattr(s, key) {
  let pat, p, okp, vstart, q, e, total, c;
  pat = (key + "=");
  p = $instr(1, s, pat);
  while ((p > 0)) {
    okp = false;
    if ((p === 1)) {
      okp = true;
    } else {
      okp = (($mid(s, (p - 1), 1) === " "));
    }
    if (okp) {
      break;
    }
    p = $instr((p + 1), s, pat);
  }
  if ((p === 0)) {
    return "";
  }
  vstart = (p + $len(pat));
  q = $mid(s, vstart, 1);
  if (((q === $chr(34)) || (q === "'"))) {
    e = $instr((vstart + 1), s, q);
    if ((e === 0)) {
      return "";
    }
    return $mid(s, (vstart + 1), ((e - vstart) - 1));
  }
  total = $len(s);
  e = vstart;
  while ((e <= total)) {
    c = $mid(s, e, 1);
    if (((c === " ") || (c === ","))) {
      break;
    }
    e = (e + 1);
  }
  return $mid(s, vstart, (e - vstart));
}

function normname(s) {
  let out, i, $e0, c, a;
  s = $lcase(s);
  out = "";
  for (i = 1, $e0 = $len(s); i <= $e0; i++) {
    c = $mid(s, i, 1);
    a = $asc(c);
    if (((((a >= 97) && (a <= 122))) || (((a >= 48) && (a <= 57))))) {
      out = (out + c);
    }
  }
  return out;
}

function decodeentities(s) {
  let p, semi, numstr, code, repl;
  p = $instr(1, s, "&#");
  while ((p > 0)) {
    semi = $instr(p, s, ";");
    if (((semi === 0) || ((semi - p) > 8))) {
      break;
    }
    numstr = $mid(s, (p + 2), ((semi - p) - 2));
    code = 0;
    if ((($left(numstr, 1) === "x") || ($left(numstr, 1) === "X"))) {
      code = $val($mid(numstr, 2), 16);
    } else {
      code = $val(numstr, 10);
    }
    repl = "";
    if ((code > 0)) {
      repl = $chr(code);
    }
    s = (($left(s, (p - 1)) + repl) + $mid(s, (semi + 1)));
    p = $instr((p + 1), s, "&#");
  }
  s = s.$replace("&lt;", "<");
  s = s.$replace("&gt;", ">");
  s = s.$replace("&quot;", $chr(34));
  s = s.$replace("&apos;", "'");
  s = s.$replace("&#39;", "'");
  s = s.$replace("&amp;", "&");
  return s;
}

function pad2(n) {
  if ((n < 10)) {
    return ("0" + n.$tostr());
  }
  return n.$tostr();
}

function fmttime(secs) {
  let dt;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  return i18nhm(dt.$gethours(), pad2(dt.$getminutes()), false);
}

function fmttimelong(secs) {
  let dt;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  return i18nhm(dt.$gethours(), pad2(dt.$getminutes()), true);
}

function fmtday(secs) {
  let dt, days, months;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  days = i18ndow3();
  months = i18nmon3();
  return (((($ix(days, dt.$getdayofweek()) + " ") + dt.$getdayofmonth().$tostr()) + " ") + $ix(months, (dt.$getmonth() - 1)));
}

function cleanlogo(u) {
  let low, base, q;
  u = u.$trim();
  if (((u === "") || ($len(u) > 2000))) {
    return "";
  }
  low = $lcase(u);
  if (($left(low, 4) !== "http")) {
    return "";
  }
  base = low;
  q = $instr(1, low, "?");
  if ((q > 0)) {
    base = $left(low, (q - 1));
  }
  if (($right(base, 4) === ".svg")) {
    return "";
  }
  return u;
}

function epgwantedof(root) {
  let wanted, i, $e1, cat, j, $e2, ch, cid, nk;
  wanted = {__proto__: $AAP};
  if ((root == null)) {
    return wanted;
  }
  for (i = 0, $e1 = (root.$getchildcount() - 1); i <= $e1; i++) {
    cat = root.$getchild(i);
    for (j = 0, $e2 = (cat.$getchildcount() - 1); j <= $e2; j++) {
      ch = cat.$getchild(j);
      cid = ch.id;
      if (((cid != null) && (cid !== ""))) {
        $six(wanted, $lcase(cid), true);
      }
      nk = normname(ch.title);
      if ((nk !== "")) {
        $six(wanted, nk, true);
      }
    }
  }
  return wanted;
}
// ---- components/series.brs ----
function epregexes() {
  let b;
  if ((m.eprx == null)) {
    b = "(?:^|[\\s\\.\\-_\\[\\(])";
    m.eprx = [{__proto__: $AAP, "rx": $createobject("roRegex", (b + "S(\\d{1,2})[\\s\\.\\-_]*E(\\d{1,3})(?!\\d)"), "i"), "strong": true}, {__proto__: $AAP, "rx": $createobject("roRegex", (b + "(?:(?:Season|Temporada|Temp)\\.?\\s*|T)(\\d{1,2})[\\s\\.\\-_,]*(?:Episode|Episodio|Cap\\w*|Ep|E)\\.?\\s*(\\d{1,3})(?!\\d)"), "i"), "strong": true}, {__proto__: $AAP, "rx": $createobject("roRegex", (b + "(\\d{1,2})x(\\d{1,3})(?![\\dp])"), "i"), "strong": false}];
  }
  return m.eprx;
}

function epparse(title) {
  let p, r, full, at, nm, rest;
  for (p of $iter(epregexes())) {
    r = p.rx.$match(title);
    if ((r.$count() >= 3)) {
      full = $ix(r, 0);
      at = $instr(1, title, full);
      if ((at > 0)) {
        nm = eptrim($left(title, (at - 1)));
        rest = eptrim($mid(title, (at + $len(full))));
        return {__proto__: $AAP, "name": nm, "s": $val($ix(r, 1)), "e": $val($ix(r, 2)), "t": rest, "strong": p.strong};
      }
    }
  }
  return null;
}

function eptrim(s) {
  let seps;
  s = s.$trim();
  seps = "-:|.,([_ ";
  while ((($len(s) > 0) && ($instr(1, seps, $left(s, 1)) > 0))) {
    s = $mid(s, 2).$trim();
  }
  while ((($len(s) > 0) && ($instr(1, seps, $right(s, 1)) > 0))) {
    s = $left(s, ($len(s) - 1)).$trim();
  }
  return s;
}

function sortkey(t) {
  let s, ff, tt, i, $e0, a;
  s = $lcase(t);
  ff = ["á", "é", "í", "ó", "ú", "ü", "ñ", "Á", "É", "Í", "Ó", "Ú", "Ü", "Ñ"];
  tt = ["a", "e", "i", "o", "u", "u", "n", "a", "e", "i", "o", "u", "u", "n"];
  for (i = 0, $e0 = (ff.$count() - 1); i <= $e0; i++) {
    s = s.$replace($ix(ff, i), $ix(tt, i));
  }
  while (($len(s) > 1)) {
    a = $asc($left(s, 1));
    if (((((a >= 48) && (a <= 57))) || (((a >= 97) && (a <= 122))))) {
      break;
    }
    s = $mid(s, 2);
  }
  return s;
}

function seradd(sd, order, gname, ep, entry) {
  let g, key, rec, sk, num;
  if ((!sd.$doesexist(gname))) {
    $six(sd, gname, {__proto__: $AAP, "order": [], "map": {__proto__: $AAP}});
    order.$push(gname);
  }
  g = $ix(sd, gname);
  key = $lcase(ep.name);
  if ((!g.map.$doesexist(key))) {
    $six(g.map, key, {__proto__: $AAP, "name": ep.name, "poster": "", "seasons": {__proto__: $AAP}, "snums": []});
    g.order.$push(key);
  }
  rec = $ix(g.map, key);
  if (((rec.poster === "") && (entry.l !== ""))) {
    rec.poster = entry.l;
  }
  sk = ep.s.$tostr();
  if ((!rec.seasons.$doesexist(sk))) {
    $six(rec.seasons, sk, []);
    rec.snums.$push(ep.s);
  }
  num = ep.e;
  if ((num <= 0)) {
    num = ($ix(rec.seasons, sk).$count() + 1);
  }
  $ix(rec.seasons, sk).$push({__proto__: $AAP, "e": num, "t": ep.t, "u": entry.u, "f": entry.f, "l": entry.l});
}

function serfill(root, sd, order) {
  let gname, g, arr, key, rec, cat, a, sn, s, season, eps, ep, item;
  for (gname of $iter(order)) {
    g = $ix(sd, gname);
    arr = [];
    for (key of $iter(g.order)) {
      rec = $ix(g.map, key);
      arr.$push({__proto__: $AAP, "k": sortkey(rec.name), "r": rec});
    }
    arr.$sortby("k");
    cat = root.$createchild("ContentNode");
    cat.id = gname;
    cat.title = (((gname + "  (") + arr.$count().$tostr()) + ")");
    for (a of $iter(arr)) {
      rec = a.r;
      sn = cat.$createchild("ContentNode");
      sn.title = rec.name;
      sn.id = $lcase(rec.name);
      sn.hdposterurl = rec.poster;
      sn.description = "series";
      rec.snums.$sort();
      for (s of $iter(rec.snums)) {
        season = sn.$createchild("ContentNode");
        season.id = s.$tostr();
        season.title = (tx("Temporada ") + s.$tostr());
        eps = $ix(rec.seasons, s.$tostr());
        eps.$sortby("e");
        for (ep of $iter(eps)) {
          item = season.$createchild("ContentNode");
          item.title = sereptitle(rec.name, s, ep);
          item.shortdescriptionline2 = ep.t;
          item.url = ep.u;
          item.streamformat = ep.f;
          item.hdposterurl = ep.l;
          item.shortdescriptionline1 = ep.e.$tostr();
          item.description = "movie";
        }
      }
    }
  }
}

function serfilldirect(root, sd, order, seen, favs) {
  let gname, g, arr, key, rec, cat, a, sn, s, eps, season, ep, u, sr, item;
  for (gname of $iter(order)) {
    g = $ix(sd, gname);
    sd.$delete(gname);
    if (((g == null) || ($lcase(gname) === "adultos"))) {
      continue;
    }
    arr = [];
    for (key of $iter(g.order)) {
      rec = $ix(g.map, key);
      arr.$push({__proto__: $AAP, "k": sortkey(rec.name), "r": rec});
    }
    arr.$sortby("k");
    cat = null;
    for (a of $iter(arr)) {
      rec = a.r;
      sn = null;
      rec.snums.$sort();
      for (s of $iter(rec.snums)) {
        eps = $ix(rec.seasons, s.$tostr());
        eps.$sortby("e");
        season = null;
        for (ep of $iter(eps)) {
          u = ep.u;
          if (((u !== "") && (!seen.$doesexist(u)))) {
            $six(seen, u, true);
            if ((cat == null)) {
              cat = root.$createchild("ContentNode");
              cat.id = gname;
            }
            if ((sn == null)) {
              sn = cat.$createchild("ContentNode");
              sn.$setfields({__proto__: $AAP, "title": rec.name, "id": $lcase(rec.name), "hdposterurl": rec.poster, "description": "series"});
            }
            if ((season == null)) {
              season = sn.$createchild("ContentNode");
              season.id = s.$tostr();
              season.title = (tx("Temporada ") + s.$tostr());
            }
            sr = 0;
            if (favs.$doesexist(u)) {
              sr = 100;
            }
            item = season.$createchild("ContentNode");
            item.$setfields({__proto__: $AAP, "title": sereptitle(rec.name, s, ep), "shortdescriptionline2": ep.t, "url": u, "streamformat": ep.f, "hdposterurl": ep.l, "shortdescriptionline1": ep.e.$tostr(), "description": "movie", "starrating": sr});
          }
        }
      }
    }
    if ((cat != null)) {
      cat.title = (((gname + "  (") + cat.$getchildcount().$tostr()) + ")");
    }
  }
}

function sereptitle(name, s, ep) {
  let t;
  t = ((((name + "  T") + s.$tostr()) + " E") + ep.e.$tostr());
  if ((ep.t !== "")) {
    t = ((t + " - ") + ep.t);
  }
  return t;
}
// ---- components/i18n.brs ----
function i18nlangs() {
  return [{__proto__: $AAP, "code": "es", "name": "Español", "flag": "pkg:/images/flag_es.png"}, {__proto__: $AAP, "code": "en", "name": "English", "flag": "pkg:/images/flag_en.png"}, {__proto__: $AAP, "code": "pt", "name": "Português", "flag": "pkg:/images/flag_pt.png"}, {__proto__: $AAP, "code": "fr", "name": "Français", "flag": "pkg:/images/flag_fr.png"}, {__proto__: $AAP, "code": "de", "name": "Deutsch", "flag": "pkg:/images/flag_de.png"}, {__proto__: $AAP, "code": "it", "name": "Italiano", "flag": "pkg:/images/flag_it.png"}];
}

function i18nvalid(code) {
  let l;
  for (l of $iter(i18nlangs())) {
    if ((l.code === code)) {
      return true;
    }
  }
  return false;
}

function i18ndetect() {
  let code, di, loc, c;
  code = "en";
  di = $createobject("roDeviceInfo");
  if ((di != null)) {
    loc = di.$getcurrentlocale();
    if (((loc != null) && ($len(loc) >= 2))) {
      c = $lcase($left(loc, 2));
      if (i18nvalid(c)) {
        code = c;
      }
    }
  }
  return code;
}

function i18nload(lang) {
  let d, txt, arr, p;
  d = $createobject("roAssociativeArray");
  d.$setmodecasesensitive();
  txt = $readasciifile((("pkg:/locale/" + lang) + ".json"));
  if (((txt != null) && (txt !== ""))) {
    arr = $parsejson(txt);
    if ((arr != null)) {
      for (p of $iter(arr)) {
        $six(d, $ix(p, 0), $ix(p, 1));
      }
    }
  }
  m.i18nd = d;
  m.i18nlang = lang;
}

function tx(s) {
  let lang, v;
  lang = m.global.lang;
  if ((lang == null)) {
    return s;
  }
  if ((lang === "es")) {
    return s;
  }
  if ((m.i18nlang == null)) {
    i18nload(lang);
  } else if ((m.i18nlang !== lang)) {
    i18nload(lang);
  }
  v = m.i18nd.$lookup(s);
  if ((v == null)) {
    return s;
  }
  return v;
}

function i18nlang() {
  let l;
  l = m.global.lang;
  if ((l == null)) {
    return "es";
  }
  return l;
}

function i18n24h() {
  let l;
  l = i18nlang();
  return (((l !== "es") && (l !== "en")));
}

function i18ndow3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  }
  if ((l === "pt")) {
    return ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
  }
  if ((l === "fr")) {
    return ["dim.", "lun.", "mar.", "mer.", "jeu.", "ven.", "sam."];
  }
  if ((l === "de")) {
    return ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
  }
  if ((l === "it")) {
    return ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
  }
  return ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
}

function i18nmon3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  }
  if ((l === "pt")) {
    return ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
  }
  if ((l === "fr")) {
    return ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
  }
  if ((l === "de")) {
    return ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];
  }
  if ((l === "it")) {
    return ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"];
  }
  return ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
}

function i18ndowfull() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  }
  if ((l === "pt")) {
    return ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
  }
  if ((l === "fr")) {
    return ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  }
  if ((l === "de")) {
    return ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
  }
  if ((l === "it")) {
    return ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"];
  }
  return ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
}

function i18ncompass() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  }
  if ((l === "pt")) {
    return ["N", "NE", "L", "SE", "S", "SO", "O", "NO"];
  }
  if ((l === "de")) {
    return ["N", "NO", "O", "SO", "S", "SW", "W", "NW"];
  }
  if ((l === "it")) {
    return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
  }
  return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
}

function i18nhm(h, mm, longfmt) {
  let hs, h12, l, suf;
  if (i18n24h()) {
    hs = h.$tostr();
    if ((h < 10)) {
      hs = ("0" + hs);
    }
    return ((hs + ":") + mm);
  }
  h12 = (h % 12);
  if ((h12 === 0)) {
    h12 = 12;
  }
  l = i18nlang();
  if ((l === "en")) {
    suf = " AM";
    if ((h >= 12)) {
      suf = " PM";
    }
    if ((!longfmt)) {
      suf = "a";
      if ((h >= 12)) {
        suf = "p";
      }
    }
    return (((h12.$tostr() + ":") + mm) + suf);
  }
  if (longfmt) {
    suf = " a. m.";
    if ((h >= 12)) {
      suf = " p. m.";
    }
  } else {
    suf = "a";
    if ((h >= 12)) {
      suf = "p";
    }
  }
  return (((h12.$tostr() + ":") + mm) + suf);
}
return {"init": init, "getcontent": getcontent, "buildadult": buildadult, "addtogroup": addtogroup, "newhttp": newhttp, "filltreedirect": filltreedirect, "filltree": filltree, "vodkind": vodkind, "ischannelname": ischannelname, "hasyear": hasyear, "classify": classify, "matchany": matchany, "isin": isin, "buildrules": buildrules, "titlecommapos": titlecommapos, "lastpos": lastpos, "firsturl": firsturl, "detectformat": detectformat, "seriesof": seriesof, "getattr": getattr, "normname": normname, "decodeentities": decodeentities, "pad2": pad2, "fmttime": fmttime, "fmttimelong": fmttimelong, "fmtday": fmtday, "cleanlogo": cleanlogo, "epgwantedof": epgwantedof, "epregexes": epregexes, "epparse": epparse, "eptrim": eptrim, "sortkey": sortkey, "seradd": seradd, "serfill": serfill, "serfilldirect": serfilldirect, "sereptitle": sereptitle, "i18nlangs": i18nlangs, "i18nvalid": i18nvalid, "i18ndetect": i18ndetect, "i18nload": i18nload, "tx": tx, "i18nlang": i18nlang, "i18n24h": i18n24h, "i18ndow3": i18ndow3, "i18nmon3": i18nmon3, "i18ndowfull": i18ndowfull, "i18ncompass": i18ncompass, "i18nhm": i18nhm};
});

$defineComponent({"name":"EpgReader","extends":"Task","fields":[{"id":"epgurl","type":"string"},{"id":"wanted","type":"assocarray"},{"id":"status","type":"string"},{"id":"result","type":"assocarray"}],"children":[]}, function (m) {
// ---- components/epgreader.brs ----
function init() {
  m.top.functionname = "readGuide";
}

function readguide() {
  let result, url, nowcache, cachepath, sig, hit, path, fs, http, code, stat, size, ba, kind, parts, msg, nowsecs, chunksize, carry, partpath, psize, offset, n, chunk, text, resume, total, key, arr;
  result = {__proto__: $AAP, "ok": false, "message": "", "programs": {__proto__: $AAP}, "names": {__proto__: $AAP}, "icons": {__proto__: $AAP}, "count": 0, "updated": 0};
  url = m.top.epgurl;
  if (((url == null) || (url === ""))) {
    result.message = tx("esta lista no trae URL de guia");
    m.top.result = result;
    return;
  }
  nowcache = $createobject("roDateTime").$asseconds();
  cachepath = epgcachepath(url);
  sig = "0";
  if ((m.top.wanted != null)) {
    sig = m.top.wanted.$count().$tostr();
  }
  hit = epgcacheload(cachepath, sig, nowcache);
  if ((hit != null)) {
    m.top.status = tx("Guia: lista (cargada desde la memoria)");
    m.top.result = hit;
    return;
  }
  path = "tmp:/epg_guide.xml";
  fs = $createobject("roFileSystem");
  if (fs.$exists(path)) {
    fs.$delete(path);
  }
  http = $createobject("roUrlTransfer");
  http.$setcertificatesfile("common:/certs/ca-bundle.crt");
  http.$initclientcertificates();
  http.$enableencodings(true);
  http.$seturl(url);
  code = http.$gettofile(path);
  if ((code !== 200)) {
    result.message = ((tx("no se pudo descargar (codigo ") + code.$tostr()) + ")");
    m.top.result = result;
    return;
  }
  stat = fs.$stat(path);
  if ((stat == null)) {
    result.message = tx("no se pudo leer el archivo descargado");
    m.top.result = result;
    return;
  }
  size = stat.size;
  ba = $createobject("roByteArray");
  kind = filekind(path);
  parts = null;
  if ((kind === "gzip")) {
    parts = gunziptoparts(path);
    fs.$delete(path);
    if ((parts == null)) {
      msg = tx("no se pudo descomprimir la guia .gz");
      if (((m.gzerr != null) && (m.gzerr !== ""))) {
        msg = m.gzerr;
      }
      result.message = msg;
      m.top.result = result;
      return;
    }
  } else if ((kind !== "xml")) {
    fs.$delete(path);
    result.message = tx("el archivo de guia no parece un XML");
    m.top.result = result;
    return;
  } else {
    if ((size > 60000000)) {
      fs.$delete(path);
      result.message = tx("el archivo de guia es demasiado grande");
      m.top.result = result;
      return;
    }
    parts = [];
    parts.$push(path);
  }
  m.dt = $createobject("roDateTime");
  nowsecs = m.dt.$asseconds();
  m.minend = (nowsecs - 1800);
  m.maxstart = (nowsecs + 129600);
  m.wanted = m.top.wanted;
  if ((m.wanted == null)) {
    m.wanted = {__proto__: $AAP};
  }
  m.interest = {__proto__: $AAP};
  m.names = {__proto__: $AAP};
  m.programs = {__proto__: $AAP};
  m.icons = {__proto__: $AAP};
  m.top.status = tx("Guia: leyendo programacion...");
  chunksize = 262144;
  carry = "";
  for (partpath of $iter(parts)) {
    stat = fs.$stat(partpath);
    if ((stat == null)) {
      break;
    }
    psize = stat.size;
    offset = 0;
    while ((offset < psize)) {
      n = chunksize;
      if (((offset + n) > psize)) {
        n = (psize - offset);
      }
      chunk = $createobject("roByteArray");
      if ((!chunk.$readfile(partpath, offset, n))) {
        break;
      }
      offset = (offset + n);
      text = (carry + chunk.$toasciistring());
      resume = processtext(text);
      carry = $mid(text, resume);
    }
    fs.$delete(partpath);
  }
  total = 0;
  for (key of $iter(m.programs)) {
    arr = $ix(m.programs, key);
    arr.$sortby("s");
    total = (total + arr.$count());
  }
  if ((total === 0)) {
    result.message = tx("la guia no trae programacion para los canales de tu lista (revisa los tvg-id)");
    m.top.result = result;
    return;
  }
  result.ok = true;
  result.programs = m.programs;
  result.names = m.names;
  result.icons = m.icons;
  result.count = m.programs.$count();
  result.updated = nowsecs;
  epgcachesave(cachepath, sig, nowsecs, total, m.programs, m.names, m.icons);
  m.top.result = result;
}

function epgcachepath(url) {
  let ba, dg;
  ba = $createobject("roByteArray");
  ba.$fromasciistring(url);
  dg = $createobject("roEVPDigest");
  dg.$setup("md5");
  return (("cachefs:/epg_" + dg.$process(ba)) + ".json");
}

function epgcacheload(path, sig, nowsecs) {
  let fs, st, txt, d, age, names, icons;
  fs = $createobject("roFileSystem");
  if ((!fs.$exists(path))) {
    return null;
  }
  st = fs.$stat(path);
  if ((st == null)) {
    return null;
  }
  if (((st.size < 30) || (st.size > 16000000))) {
    fs.$delete(path);
    return null;
  }
  txt = $readasciifile(path);
  if (((txt == null) || (txt === ""))) {
    return null;
  }
  d = $parsejson(txt);
  txt = null;
  if (((d == null) || ($type(d) !== "roAssociativeArray"))) {
    return null;
  }
  if ((((!d.$doesexist("sig")) || (!d.$doesexist("updated"))) || (!d.$doesexist("programs")))) {
    return null;
  }
  if ((d.sig !== sig)) {
    return null;
  }
  age = (nowsecs - d.updated);
  if (((age < (-300)) || (age > 21600))) {
    return null;
  }
  if ((($type(d.programs) !== "roAssociativeArray") || (d.programs.$count() === 0))) {
    return null;
  }
  names = {__proto__: $AAP};
  icons = {__proto__: $AAP};
  if ((d.$doesexist("names") && ($type(d.names) === "roAssociativeArray"))) {
    names = d.names;
  }
  if ((d.$doesexist("icons") && ($type(d.icons) === "roAssociativeArray"))) {
    icons = d.icons;
  }
  return {__proto__: $AAP, "ok": true, "message": "", "programs": d.programs, "names": names, "icons": icons, "count": d.programs.$count(), "updated": d.updated};
}

function epgcachesave(path, sig, nowsecs, total, programs, names, icons) {
  let js;
  if ((total > 45000)) {
    return;
  }
  js = $formatjson({__proto__: $AAP, "v": 1, "sig": sig, "updated": nowsecs, "programs": programs, "names": names, "icons": icons});
  if (((js === "") || ($len(js) > 15000000))) {
    return;
  }
  $writeasciifile(path, js);
}

function processtext(text) {
  let p, cpos, gpos, ischannel, closepos;
  p = 1;
  while (true) {
    cpos = $instr(p, text, "<channel ");
    gpos = $instr(p, text, "<programme ");
    if (((cpos === 0) && (gpos === 0))) {
      break;
    }
    ischannel = false;
    if (((cpos > 0) && (((gpos === 0) || (cpos < gpos))))) {
      ischannel = true;
    }
    if (ischannel) {
      closepos = $instr(cpos, text, "</channel>");
      if ((closepos === 0)) {
        return cpos;
      }
      handlechannel($mid(text, cpos, ((closepos - cpos) + 10)));
      p = (closepos + 10);
    } else {
      closepos = $instr(gpos, text, "</programme>");
      if ((closepos === 0)) {
        return gpos;
      }
      handleprogramme($mid(text, gpos, ((closepos - gpos) + 12)));
      p = (closepos + 12);
    }
  }
  return p;
}

function handlechannel(block) {
  let gt, head, id, iswanted, namekeys, p, a, g, b, raw, nm, nk, icon;
  gt = $instr(1, block, ">");
  if ((gt === 0)) {
    return;
  }
  head = $left(block, gt);
  id = $lcase(getattr(head, "id"));
  if ((id === "")) {
    return;
  }
  iswanted = m.wanted.$doesexist(id);
  namekeys = [];
  p = 1;
  while (true) {
    a = $instr(p, block, "<display-name");
    if ((a === 0)) {
      break;
    }
    g = $instr(a, block, ">");
    if ((g === 0)) {
      break;
    }
    b = $instr(g, block, "</display-name>");
    if ((b === 0)) {
      break;
    }
    raw = $mid(block, (g + 1), ((b - g) - 1));
    nm = decodeentities(raw.$trim());
    nk = normname(nm);
    if ((nk !== "")) {
      namekeys.$push(nk);
      if (m.wanted.$doesexist(nk)) {
        iswanted = true;
      }
    }
    p = (b + 15);
  }
  if (iswanted) {
    $six(m.interest, id, true);
    icon = channelicon(block);
    if ((icon !== "")) {
      $six(m.icons, id, icon);
    }
    for (nk of $iter(namekeys)) {
      $six(m.names, nk, id);
    }
  }
}

function channelicon(block) {
  let ip, close;
  ip = $instr(1, block, "<icon");
  if ((ip === 0)) {
    return "";
  }
  close = $instr(ip, block, ">");
  if ((close === 0)) {
    return "";
  }
  return cleanlogo(decodeentities(getattr($mid(block, ip, ((close - ip) + 1)), "src")));
}

function handleprogramme(block) {
  let gt, head, chan, s, e, t, d;
  gt = $instr(1, block, ">");
  if ((gt === 0)) {
    return;
  }
  head = $left(block, gt);
  chan = $lcase(getattr(head, "channel"));
  if ((chan === "")) {
    return;
  }
  if ((!m.interest.$doesexist(chan))) {
    return;
  }
  s = parsexmltvtime(getattr(head, "start"));
  e = parsexmltvtime(getattr(head, "stop"));
  if ((s === 0)) {
    return;
  }
  if ((e === 0)) {
    e = (s + 1800);
  }
  if (((e < m.minend) || (s > m.maxstart))) {
    return;
  }
  t = tagtext(block, "title");
  if ((t === "")) {
    t = tx("Sin titulo");
  }
  d = tagtext(block, "desc");
  if (($len(d) > 260)) {
    d = ($left(d, 257) + "...");
  }
  if ((!m.programs.$doesexist(chan))) {
    $six(m.programs, chan, []);
  }
  $ix(m.programs, chan).$push({__proto__: $AAP, "s": s, "e": e, "t": t, "d": d});
}

function tagtext(block, tag) {
  let p, gt, closepos, txt;
  p = $instr(1, block, ("<" + tag));
  if ((p === 0)) {
    return "";
  }
  gt = $instr(p, block, ">");
  if ((gt === 0)) {
    return "";
  }
  closepos = $instr(gt, block, (("</" + tag) + ">"));
  if ((closepos === 0)) {
    return "";
  }
  txt = $mid(block, (gt + 1), ((closepos - gt) - 1));
  return decodeentities(txt.$trim());
}

function parsexmltvtime(str) {
  let base, offstr, sp, rest, sec, iso, secs, sign, hh, mm, off;
  if ((str === "")) {
    return 0;
  }
  base = str;
  offstr = "";
  sp = $instr(1, str, " ");
  if ((sp > 0)) {
    base = $left(str, (sp - 1));
    rest = $mid(str, (sp + 1));
    offstr = rest.$trim();
  }
  if (($len(base) < 12)) {
    return 0;
  }
  sec = "00";
  if (($len(base) >= 14)) {
    sec = $mid(base, 13, 2);
  }
  iso = ((((((((((($left(base, 4) + "-") + $mid(base, 5, 2)) + "-") + $mid(base, 7, 2)) + "T") + $mid(base, 9, 2)) + ":") + $mid(base, 11, 2)) + ":") + sec) + "Z");
  m.dt.$fromiso8601string(iso);
  secs = m.dt.$asseconds();
  if (($len(offstr) >= 5)) {
    sign = $left(offstr, 1);
    hh = $val($mid(offstr, 2, 2), 10);
    mm = $val($mid(offstr, 4, 2), 10);
    off = ((hh * 3600) + (mm * 60));
    if ((sign === "-")) {
      secs = (secs + off);
    } else if ((sign === "+")) {
      secs = (secs - off);
    }
  }
  return secs;
}
// ---- components/gunzip.brs ----
function filekind(path) {
  let ba, n, i, c;
  ba = $createobject("roByteArray");
  if ($not(ba.$readfile(path, 0, 80))) {
    return "other";
  }
  n = ba.$count();
  if ($and($and((n >= 2), ($ix(ba, 0) === 31)), ($ix(ba, 1) === 139))) {
    return "gzip";
  }
  i = 0;
  while ((i < n)) {
    c = $ix(ba, i);
    if ($and($and($and((c !== 32), (c !== 9)), (c !== 10)), (c !== 13))) {
      break;
    }
    i = (i + 1);
  }
  if ($and($and($and(((i + 2) < n), ($ix(ba, i) === 239)), ($ix(ba, (i + 1)) === 187)), ($ix(ba, (i + 2)) === 191))) {
    i = (i + 3);
  }
  if ($and((i < n), ($ix(ba, i) === 60))) {
    return "xml";
  }
  return "other";
}

function gunziptoparts(srcpath) {
  let fs, stat, i, $e0, oldp, $e1;
  m.gzerr = "";
  m.gzpath = srcpath;
  fs = $createobject("roFileSystem");
  stat = fs.$stat(srcpath);
  if ((stat == null)) {
    m.gzerr = "no se pudo leer la guia comprimida";
    return null;
  }
  m.gzsize = stat.size;
  if ((m.gzsize < 10)) {
    m.gzerr = "el archivo .gz esta vacio o incompleto";
    return null;
  }
  if ((m.gzsize > 25000000)) {
    m.gzerr = "la guia comprimida es demasiado grande";
    return null;
  }
  for (i = 0, $e0 = 250; i <= $e0; i++) {
    oldp = ("tmp:/epgp" + i.$tostr());
    if (fs.$exists(oldp)) {
      fs.$delete(oldp);
    }
  }
  m.gzpos = 0;
  m.gzcachepos = 0;
  m.gzcachelen = 0;
  m.gzcache = $createobject("roByteArray");
  m.gzbuf = 0;
  m.gzn = 0;
  m.winpos = 0;
  m.totalout = 0;
  m.outcount = 0;
  m.out = $createobject("roByteArray");
  m.partseq = 0;
  m.partpaths = [];
  m.win = $createobject("roByteArray");
  for (i = 0, $e1 = 32767; i <= $e1; i++) {
    m.win.$push(0);
  }
  gzinittables();
  m.top.status = "Guia: descomprimiendo .gz...";
  if ($not(gzheader())) {
    return gzfail();
  }
  if ($not(gzblocks())) {
    return gzfail();
  }
  if ($not(gzflush())) {
    return gzfail();
  }
  if ((m.gzerr !== "")) {
    return gzfail();
  }
  if ((m.totalout === 0)) {
    m.gzerr = "la guia comprimida no traia datos";
    return gzfail();
  }
  return m.partpaths;
}

function gzfail() {
  let fs, p;
  fs = $createobject("roFileSystem");
  if ((m.partpaths != null)) {
    for (p of $iter(m.partpaths)) {
      if (fs.$exists(p)) {
        fs.$delete(p);
      }
    }
  }
  return null;
}

function gzinittables() {
  m.lenbase = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
  m.lenextra = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
  m.distbase = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
  m.distextra = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];
  m.clorder = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];
}

function gzpull() {
  let n, b;
  if ((m.gzcachepos >= m.gzcachelen)) {
    if ((m.gzpos >= m.gzsize)) {
      return (-1);
    }
    n = 8192;
    if (((m.gzpos + n) > m.gzsize)) {
      n = (m.gzsize - m.gzpos);
    }
    m.gzcache = $createobject("roByteArray");
    if ($not(m.gzcache.$readfile(m.gzpath, m.gzpos, n))) {
      return (-1);
    }
    m.gzpos = (m.gzpos + n);
    m.gzcachelen = n;
    m.gzcachepos = 0;
  }
  b = $ix(m.gzcache, m.gzcachepos);
  m.gzcachepos = (m.gzcachepos + 1);
  return b;
}

function gzbits(n) {
  let b, mask, v;
  if ((m.gzerr !== "")) {
    return (-1);
  }
  while ((m.gzn < n)) {
    b = gzpull();
    if ((b < 0)) {
      m.gzerr = "la guia .gz esta cortada";
      return (-1);
    }
    m.gzbuf = (m.gzbuf + ((b << m.gzn)));
    m.gzn = (m.gzn + 8);
  }
  if ((n === 0)) {
    return 0;
  }
  mask = (((1 << n)) - 1);
  v = $and(m.gzbuf, mask);
  m.gzbuf = (m.gzbuf >> n);
  m.gzn = (m.gzn - n);
  return v;
}

function gzpeek(n) {
  let b, mask;
  if ((m.gzerr !== "")) {
    return (-1);
  }
  while ((m.gzn < n)) {
    b = gzpull();
    if ((b < 0)) {
      m.gzerr = "la guia .gz esta cortada";
      return (-1);
    }
    m.gzbuf = (m.gzbuf + ((b << m.gzn)));
    m.gzn = (m.gzn + 8);
  }
  mask = (((1 << n)) - 1);
  return $and(m.gzbuf, mask);
}

function gzalign() {
  m.gzbuf = 0;
  m.gzn = 0;
}

function gzemit(b) {
  $six(m.win, m.winpos, b);
  m.winpos = (m.winpos + 1);
  if ((m.winpos === 32768)) {
    m.winpos = 0;
  }
  $six(m.out, m.outcount, b);
  m.outcount = (m.outcount + 1);
  m.totalout = (m.totalout + 1);
  if ((m.totalout > 60000000)) {
    m.gzerr = "la guia descomprimida es demasiado grande";
    return false;
  }
  if ((m.outcount >= 262144)) {
    return gzflush();
  }
  return true;
}

function gzflush() {
  let path, mb;
  if ((m.outcount <= 0)) {
    return true;
  }
  path = ("tmp:/epgp" + m.partseq.$tostr());
  m.partseq = (m.partseq + 1);
  if ($not(m.out.$writefile(path))) {
    m.gzerr = "no hubo espacio para descomprimir la guia";
    return false;
  }
  m.partpaths.$push(path);
  m.out = $createobject("roByteArray");
  m.outcount = 0;
  mb = $idiv(m.totalout, 1000000);
  m.top.status = (("Guia: descomprimiendo .gz (" + mb.$tostr()) + " MB)...");
  return true;
}

function gzwinbyte(dist) {
  let idx;
  idx = (m.winpos - dist);
  while ((idx < 0)) {
    idx = (idx + 32768);
  }
  return $ix(m.win, idx);
}

function gznewtree() {
  let t;
  t = {__proto__: $AAP};
  t.l = [(-1)];
  t.r = [(-1)];
  t.s = [(-1)];
  return t;
}

function gzaddnode(t) {
  t.l.$push((-1));
  t.r.$push((-1));
  t.s.$push((-1));
  return (t.s.$count() - 1);
}

function gzbuildtree(lengths) {
  let bl, i, $e2, $e3, l, nextc, $e4, code, b, $e5, t, sym, $e6, c, idx, bit, $e7, bb, leaf, fast, $e8, ok, consumed, bitpos, $e9;
  bl = [];
  for (i = 0, $e2 = 15; i <= $e2; i++) {
    bl.$push(0);
  }
  for (i = 0, $e3 = (lengths.$count() - 1); i <= $e3; i++) {
    l = $ix(lengths, i);
    if ((l > 0)) {
      $six(bl, l, ($ix(bl, l) + 1));
    }
  }
  nextc = [];
  for (i = 0, $e4 = 15; i <= $e4; i++) {
    nextc.$push(0);
  }
  code = 0;
  $six(bl, 0, 0);
  for (b = 1, $e5 = 15; b <= $e5; b++) {
    code = (((code + $ix(bl, (b - 1)))) << 1);
    $six(nextc, b, code);
  }
  t = gznewtree();
  for (sym = 0, $e6 = (lengths.$count() - 1); sym <= $e6; sym++) {
    l = $ix(lengths, sym);
    if ((l > 0)) {
      c = $ix(nextc, l);
      $six(nextc, l, (c + 1));
      idx = 0;
      for (bit = (l - 1), $e7 = 0; bit >= $e7; bit--) {
        bb = $and(((c >> bit)), 1);
        if ((bit === 0)) {
          if ((bb === 0)) {
            if (($ix(t.l, idx) < 0)) {
              $six(t.l, idx, gzaddnode(t));
            }
            leaf = $ix(t.l, idx);
          } else {
            if (($ix(t.r, idx) < 0)) {
              $six(t.r, idx, gzaddnode(t));
            }
            leaf = $ix(t.r, idx);
          }
          $six(t.s, leaf, sym);
        } else {
          if ((bb === 0)) {
            if (($ix(t.l, idx) < 0)) {
              $six(t.l, idx, gzaddnode(t));
            }
            idx = $ix(t.l, idx);
          } else {
            if (($ix(t.r, idx) < 0)) {
              $six(t.r, idx, gzaddnode(t));
            }
            idx = $ix(t.r, idx);
          }
        }
      }
    }
  }
  fast = [];
  for (i = 0, $e8 = 4095; i <= $e8; i++) {
    idx = 0;
    ok = true;
    consumed = 0;
    for (bitpos = 0, $e9 = 11; bitpos <= $e9; bitpos++) {
      if (($ix(t.s, idx) >= 0)) {
        break;
      }
      bb = $and(((i >> bitpos)), 1);
      if ((bb === 0)) {
        idx = $ix(t.l, idx);
      } else {
        idx = $ix(t.r, idx);
      }
      consumed = (bitpos + 1);
      if ((idx < 0)) {
        ok = false;
        break;
      }
    }
    if ($and($and(ok, (idx >= 0)), ($ix(t.s, idx) >= 0))) {
      fast.$push(((consumed * 65536) + $ix(t.s, idx)));
    } else {
      fast.$push((-1));
    }
  }
  t.f = fast;
  return t;
}

function gzdecode(t) {
  let p, e, nbits, idx, guard, $e10, b;
  p = gzpeek(12);
  if ((p < 0)) {
    return (-1);
  }
  e = $ix(t.f, p);
  if ((e >= 0)) {
    nbits = $idiv(e, 65536);
    if ($and((gzbits(nbits) < 0), (nbits > 0))) {
      return (-1);
    }
    return (e % 65536);
  }
  idx = 0;
  for (guard = 1, $e10 = 16; guard <= $e10; guard++) {
    if (($ix(t.s, idx) >= 0)) {
      return $ix(t.s, idx);
    }
    b = gzbits(1);
    if ((b < 0)) {
      return (-1);
    }
    if ((b === 0)) {
      idx = $ix(t.l, idx);
    } else {
      idx = $ix(t.r, idx);
    }
    if ((idx < 0)) {
      m.gzerr = "no se pudo descomprimir la guia .gz";
      return (-1);
    }
  }
  m.gzerr = "no se pudo descomprimir la guia .gz";
  return (-1);
}

function gzfixedlit() {
  let a, i, $e11, $e12, $e13, $e14;
  a = [];
  for (i = 0, $e11 = 143; i <= $e11; i++) {
    a.$push(8);
  }
  for (i = 144, $e12 = 255; i <= $e12; i++) {
    a.$push(9);
  }
  for (i = 256, $e13 = 279; i <= $e13; i++) {
    a.$push(7);
  }
  for (i = 280, $e14 = 287; i <= $e14; i++) {
    a.$push(8);
  }
  return a;
}

function gzfixeddist() {
  let a, i, $e15;
  a = [];
  for (i = 0, $e15 = 31; i <= $e15; i++) {
    a.$push(5);
  }
  return a;
}

function gzblock(lit, dist) {
  let sym, li, extra, length, ds, dex, d, i, $e16;
  while ((m.gzerr === "")) {
    sym = gzdecode(lit);
    if ((sym < 0)) {
      return false;
    }
    if ((sym < 256)) {
      if ($not(gzemit(sym))) {
        return false;
      }
    } else if ((sym === 256)) {
      return true;
    } else {
      if ($or((sym < 257), (sym > 285))) {
        m.gzerr = "no se pudo descomprimir la guia .gz";
        return false;
      }
      li = (sym - 257);
      extra = gzbits($ix(m.lenextra, li));
      if ((extra < 0)) {
        return false;
      }
      length = ($ix(m.lenbase, li) + extra);
      ds = gzdecode(dist);
      if ($or((ds < 0), (ds > 29))) {
        m.gzerr = "no se pudo descomprimir la guia .gz";
        return false;
      }
      dex = gzbits($ix(m.distextra, ds));
      if ((dex < 0)) {
        return false;
      }
      d = ($ix(m.distbase, ds) + dex);
      for (i = 1, $e16 = length; i <= $e16; i++) {
        if ($not(gzemit(gzwinbyte(d)))) {
          return false;
        }
      }
    }
  }
  return false;
}

function gzheader() {
  let flg, i, $e17, xlen, xlen2, $e18, c;
  if ($or((gzbits(8) !== 31), (gzbits(8) !== 139))) {
    m.gzerr = "el archivo no es un .gz valido";
    return false;
  }
  if ((gzbits(8) !== 8)) {
    m.gzerr = "ese .gz usa un metodo que la TV no puede abrir";
    return false;
  }
  flg = gzbits(8);
  if ((flg < 0)) {
    return false;
  }
  for (i = 1, $e17 = 6; i <= $e17; i++) {
    if ((gzbits(8) < 0)) {
      return false;
    }
  }
  if ((($and(flg, 4)) !== 0)) {
    xlen = gzbits(8);
    xlen2 = gzbits(8);
    if ($or((xlen < 0), (xlen2 < 0))) {
      return false;
    }
    xlen = (xlen + (xlen2 * 256));
    for (i = 1, $e18 = xlen; i <= $e18; i++) {
      if ((gzbits(8) < 0)) {
        return false;
      }
    }
  }
  if ((($and(flg, 8)) !== 0)) {
    c = gzbits(8);
    if ((c < 0)) {
      return false;
    }
    while ((c > 0)) {
      c = gzbits(8);
      if ((c < 0)) {
        return false;
      }
    }
  }
  if ((($and(flg, 16)) !== 0)) {
    c = gzbits(8);
    if ((c < 0)) {
      return false;
    }
    while ((c > 0)) {
      c = gzbits(8);
      if ((c < 0)) {
        return false;
      }
    }
  }
  if ((($and(flg, 2)) !== 0)) {
    if ($or((gzbits(8) < 0), (gzbits(8) < 0))) {
      return false;
    }
  }
  return (m.gzerr === "");
}

function gzblocks() {
  let bfinal, btype, ln, ln2, i, $e19, by, hlit, hdist, hclen, cl, $e20, $e21, v, clt, total, lens, $e22, filled, prev, s, rep, k, $e23, $e24, $e25, litlens, $e26, distlens, $e27;
  while ((m.gzerr === "")) {
    bfinal = gzbits(1);
    btype = gzbits(2);
    if ($or((bfinal < 0), (btype < 0))) {
      return false;
    }
    if ((btype === 0)) {
      gzalign();
      ln = gzbits(8);
      ln2 = gzbits(8);
      if ($or($or($or((ln < 0), (ln2 < 0)), (gzbits(8) < 0)), (gzbits(8) < 0))) {
        return false;
      }
      ln = (ln + (ln2 * 256));
      for (i = 1, $e19 = ln; i <= $e19; i++) {
        by = gzbits(8);
        if ((by < 0)) {
          return false;
        }
        if ($not(gzemit(by))) {
          return false;
        }
      }
    } else if ((btype === 1)) {
      if ((m.fixedlittree == null)) {
        m.fixedlittree = gzbuildtree(gzfixedlit());
        m.fixeddisttree = gzbuildtree(gzfixeddist());
      }
      if ($not(gzblock(m.fixedlittree, m.fixeddisttree))) {
        return false;
      }
    } else if ((btype === 2)) {
      hlit = (gzbits(5) + 257);
      hdist = (gzbits(5) + 1);
      hclen = (gzbits(4) + 4);
      if ((m.gzerr !== "")) {
        return false;
      }
      cl = [];
      for (i = 0, $e20 = 18; i <= $e20; i++) {
        cl.$push(0);
      }
      for (i = 0, $e21 = (hclen - 1); i <= $e21; i++) {
        v = gzbits(3);
        if ((v < 0)) {
          return false;
        }
        $six(cl, $ix(m.clorder, i), v);
      }
      clt = gzbuildtree(cl);
      total = (hlit + hdist);
      lens = [];
      for (i = 0, $e22 = (total - 1); i <= $e22; i++) {
        lens.$push(0);
      }
      filled = 0;
      prev = 0;
      while ((filled < total)) {
        s = gzdecode(clt);
        if ((s < 0)) {
          return false;
        }
        if ((s < 16)) {
          $six(lens, filled, s);
          prev = s;
          filled = (filled + 1);
        } else if ((s === 16)) {
          rep = (gzbits(2) + 3);
          if ((rep < 3)) {
            return false;
          }
          if (((filled + rep) > total)) {
            m.gzerr = "no se pudo descomprimir la guia .gz";
            return false;
          }
          for (k = 1, $e23 = rep; k <= $e23; k++) {
            $six(lens, filled, prev);
            filled = (filled + 1);
          }
        } else if ((s === 17)) {
          rep = (gzbits(3) + 3);
          if ((rep < 3)) {
            return false;
          }
          if (((filled + rep) > total)) {
            m.gzerr = "no se pudo descomprimir la guia .gz";
            return false;
          }
          for (k = 1, $e24 = rep; k <= $e24; k++) {
            $six(lens, filled, 0);
            filled = (filled + 1);
          }
        } else if ((s === 18)) {
          rep = (gzbits(7) + 11);
          if ((rep < 11)) {
            return false;
          }
          if (((filled + rep) > total)) {
            m.gzerr = "no se pudo descomprimir la guia .gz";
            return false;
          }
          for (k = 1, $e25 = rep; k <= $e25; k++) {
            $six(lens, filled, 0);
            filled = (filled + 1);
          }
        } else {
          m.gzerr = "no se pudo descomprimir la guia .gz";
          return false;
        }
      }
      litlens = [];
      for (i = 0, $e26 = (hlit - 1); i <= $e26; i++) {
        litlens.$push($ix(lens, i));
      }
      distlens = [];
      for (i = 0, $e27 = (hdist - 1); i <= $e27; i++) {
        distlens.$push($ix(lens, (hlit + i)));
      }
      if ($not(gzblock(gzbuildtree(litlens), gzbuildtree(distlens)))) {
        return false;
      }
    } else {
      m.gzerr = "no se pudo descomprimir la guia .gz";
      return false;
    }
    if ((bfinal === 1)) {
      return true;
    }
  }
  return false;
}
// ---- components/utils.brs ----
function getattr(s, key) {
  let pat, p, okp, vstart, q, e, total, c;
  pat = (key + "=");
  p = $instr(1, s, pat);
  while ((p > 0)) {
    okp = false;
    if ((p === 1)) {
      okp = true;
    } else {
      okp = (($mid(s, (p - 1), 1) === " "));
    }
    if (okp) {
      break;
    }
    p = $instr((p + 1), s, pat);
  }
  if ((p === 0)) {
    return "";
  }
  vstart = (p + $len(pat));
  q = $mid(s, vstart, 1);
  if (((q === $chr(34)) || (q === "'"))) {
    e = $instr((vstart + 1), s, q);
    if ((e === 0)) {
      return "";
    }
    return $mid(s, (vstart + 1), ((e - vstart) - 1));
  }
  total = $len(s);
  e = vstart;
  while ((e <= total)) {
    c = $mid(s, e, 1);
    if (((c === " ") || (c === ","))) {
      break;
    }
    e = (e + 1);
  }
  return $mid(s, vstart, (e - vstart));
}

function normname(s) {
  let out, i, $e0, c, a;
  s = $lcase(s);
  out = "";
  for (i = 1, $e0 = $len(s); i <= $e0; i++) {
    c = $mid(s, i, 1);
    a = $asc(c);
    if (((((a >= 97) && (a <= 122))) || (((a >= 48) && (a <= 57))))) {
      out = (out + c);
    }
  }
  return out;
}

function decodeentities(s) {
  let p, semi, numstr, code, repl;
  p = $instr(1, s, "&#");
  while ((p > 0)) {
    semi = $instr(p, s, ";");
    if (((semi === 0) || ((semi - p) > 8))) {
      break;
    }
    numstr = $mid(s, (p + 2), ((semi - p) - 2));
    code = 0;
    if ((($left(numstr, 1) === "x") || ($left(numstr, 1) === "X"))) {
      code = $val($mid(numstr, 2), 16);
    } else {
      code = $val(numstr, 10);
    }
    repl = "";
    if ((code > 0)) {
      repl = $chr(code);
    }
    s = (($left(s, (p - 1)) + repl) + $mid(s, (semi + 1)));
    p = $instr((p + 1), s, "&#");
  }
  s = s.$replace("&lt;", "<");
  s = s.$replace("&gt;", ">");
  s = s.$replace("&quot;", $chr(34));
  s = s.$replace("&apos;", "'");
  s = s.$replace("&#39;", "'");
  s = s.$replace("&amp;", "&");
  return s;
}

function pad2(n) {
  if ((n < 10)) {
    return ("0" + n.$tostr());
  }
  return n.$tostr();
}

function fmttime(secs) {
  let dt;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  return i18nhm(dt.$gethours(), pad2(dt.$getminutes()), false);
}

function fmttimelong(secs) {
  let dt;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  return i18nhm(dt.$gethours(), pad2(dt.$getminutes()), true);
}

function fmtday(secs) {
  let dt, days, months;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  days = i18ndow3();
  months = i18nmon3();
  return (((($ix(days, dt.$getdayofweek()) + " ") + dt.$getdayofmonth().$tostr()) + " ") + $ix(months, (dt.$getmonth() - 1)));
}

function cleanlogo(u) {
  let low, base, q;
  u = u.$trim();
  if (((u === "") || ($len(u) > 2000))) {
    return "";
  }
  low = $lcase(u);
  if (($left(low, 4) !== "http")) {
    return "";
  }
  base = low;
  q = $instr(1, low, "?");
  if ((q > 0)) {
    base = $left(low, (q - 1));
  }
  if (($right(base, 4) === ".svg")) {
    return "";
  }
  return u;
}

function epgwantedof(root) {
  let wanted, i, $e1, cat, j, $e2, ch, cid, nk;
  wanted = {__proto__: $AAP};
  if ((root == null)) {
    return wanted;
  }
  for (i = 0, $e1 = (root.$getchildcount() - 1); i <= $e1; i++) {
    cat = root.$getchild(i);
    for (j = 0, $e2 = (cat.$getchildcount() - 1); j <= $e2; j++) {
      ch = cat.$getchild(j);
      cid = ch.id;
      if (((cid != null) && (cid !== ""))) {
        $six(wanted, $lcase(cid), true);
      }
      nk = normname(ch.title);
      if ((nk !== "")) {
        $six(wanted, nk, true);
      }
    }
  }
  return wanted;
}
// ---- components/i18n.brs ----
function i18nlangs() {
  return [{__proto__: $AAP, "code": "es", "name": "Español", "flag": "pkg:/images/flag_es.png"}, {__proto__: $AAP, "code": "en", "name": "English", "flag": "pkg:/images/flag_en.png"}, {__proto__: $AAP, "code": "pt", "name": "Português", "flag": "pkg:/images/flag_pt.png"}, {__proto__: $AAP, "code": "fr", "name": "Français", "flag": "pkg:/images/flag_fr.png"}, {__proto__: $AAP, "code": "de", "name": "Deutsch", "flag": "pkg:/images/flag_de.png"}, {__proto__: $AAP, "code": "it", "name": "Italiano", "flag": "pkg:/images/flag_it.png"}];
}

function i18nvalid(code) {
  let l;
  for (l of $iter(i18nlangs())) {
    if ((l.code === code)) {
      return true;
    }
  }
  return false;
}

function i18ndetect() {
  let code, di, loc, c;
  code = "en";
  di = $createobject("roDeviceInfo");
  if ((di != null)) {
    loc = di.$getcurrentlocale();
    if (((loc != null) && ($len(loc) >= 2))) {
      c = $lcase($left(loc, 2));
      if (i18nvalid(c)) {
        code = c;
      }
    }
  }
  return code;
}

function i18nload(lang) {
  let d, txt, arr, p;
  d = $createobject("roAssociativeArray");
  d.$setmodecasesensitive();
  txt = $readasciifile((("pkg:/locale/" + lang) + ".json"));
  if (((txt != null) && (txt !== ""))) {
    arr = $parsejson(txt);
    if ((arr != null)) {
      for (p of $iter(arr)) {
        $six(d, $ix(p, 0), $ix(p, 1));
      }
    }
  }
  m.i18nd = d;
  m.i18nlang = lang;
}

function tx(s) {
  let lang, v;
  lang = m.global.lang;
  if ((lang == null)) {
    return s;
  }
  if ((lang === "es")) {
    return s;
  }
  if ((m.i18nlang == null)) {
    i18nload(lang);
  } else if ((m.i18nlang !== lang)) {
    i18nload(lang);
  }
  v = m.i18nd.$lookup(s);
  if ((v == null)) {
    return s;
  }
  return v;
}

function i18nlang() {
  let l;
  l = m.global.lang;
  if ((l == null)) {
    return "es";
  }
  return l;
}

function i18n24h() {
  let l;
  l = i18nlang();
  return (((l !== "es") && (l !== "en")));
}

function i18ndow3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  }
  if ((l === "pt")) {
    return ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
  }
  if ((l === "fr")) {
    return ["dim.", "lun.", "mar.", "mer.", "jeu.", "ven.", "sam."];
  }
  if ((l === "de")) {
    return ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
  }
  if ((l === "it")) {
    return ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
  }
  return ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
}

function i18nmon3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  }
  if ((l === "pt")) {
    return ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
  }
  if ((l === "fr")) {
    return ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
  }
  if ((l === "de")) {
    return ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];
  }
  if ((l === "it")) {
    return ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"];
  }
  return ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
}

function i18ndowfull() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  }
  if ((l === "pt")) {
    return ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
  }
  if ((l === "fr")) {
    return ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  }
  if ((l === "de")) {
    return ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
  }
  if ((l === "it")) {
    return ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"];
  }
  return ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
}

function i18ncompass() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  }
  if ((l === "pt")) {
    return ["N", "NE", "L", "SE", "S", "SO", "O", "NO"];
  }
  if ((l === "de")) {
    return ["N", "NO", "O", "SO", "S", "SW", "W", "NW"];
  }
  if ((l === "it")) {
    return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
  }
  return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
}

function i18nhm(h, mm, longfmt) {
  let hs, h12, l, suf;
  if (i18n24h()) {
    hs = h.$tostr();
    if ((h < 10)) {
      hs = ("0" + hs);
    }
    return ((hs + ":") + mm);
  }
  h12 = (h % 12);
  if ((h12 === 0)) {
    h12 = 12;
  }
  l = i18nlang();
  if ((l === "en")) {
    suf = " AM";
    if ((h >= 12)) {
      suf = " PM";
    }
    if ((!longfmt)) {
      suf = "a";
      if ((h >= 12)) {
        suf = "p";
      }
    }
    return (((h12.$tostr() + ":") + mm) + suf);
  }
  if (longfmt) {
    suf = " a. m.";
    if ((h >= 12)) {
      suf = " p. m.";
    }
  } else {
    suf = "a";
    if ((h >= 12)) {
      suf = "p";
    }
  }
  return (((h12.$tostr() + ":") + mm) + suf);
}
// ---- override gunzip.js ----
// La descompresion .gz la hace la app nativa (mucho mas rapido que en BrightScript)
function gunziptoparts(srcpath) {
  const dst = srcpath + '.xml';
  const r = $xhr('GET', '/fs/gunzip?p=' + encodeURIComponent(srcpath) + '&o=' + encodeURIComponent(dst));
  if (r.status !== 200) { m.gzerr = r.text || ''; return null; }
  return [dst];
}

return {"init": init, "readguide": readguide, "epgcachepath": epgcachepath, "epgcacheload": epgcacheload, "epgcachesave": epgcachesave, "processtext": processtext, "handlechannel": handlechannel, "channelicon": channelicon, "handleprogramme": handleprogramme, "tagtext": tagtext, "parsexmltvtime": parsexmltvtime, "filekind": filekind, "gunziptoparts": gunziptoparts, "gzfail": gzfail, "gzinittables": gzinittables, "gzpull": gzpull, "gzbits": gzbits, "gzpeek": gzpeek, "gzalign": gzalign, "gzemit": gzemit, "gzflush": gzflush, "gzwinbyte": gzwinbyte, "gznewtree": gznewtree, "gzaddnode": gzaddnode, "gzbuildtree": gzbuildtree, "gzdecode": gzdecode, "gzfixedlit": gzfixedlit, "gzfixeddist": gzfixeddist, "gzblock": gzblock, "gzheader": gzheader, "gzblocks": gzblocks, "getattr": getattr, "normname": normname, "decodeentities": decodeentities, "pad2": pad2, "fmttime": fmttime, "fmttimelong": fmttimelong, "fmtday": fmtday, "cleanlogo": cleanlogo, "epgwantedof": epgwantedof, "i18nlangs": i18nlangs, "i18nvalid": i18nvalid, "i18ndetect": i18ndetect, "i18nload": i18nload, "tx": tx, "i18nlang": i18nlang, "i18n24h": i18n24h, "i18ndow3": i18ndow3, "i18nmon3": i18nmon3, "i18ndowfull": i18ndowfull, "i18ncompass": i18ncompass, "i18nhm": i18nhm};
});

$defineComponent({"name":"LibraryItem","extends":"Group","fields":[{"id":"itemContent","type":"node","onChange":"showItem"},{"id":"width","type":"float"},{"id":"height","type":"float"},{"id":"focusPercent","type":"float","onChange":"showFocus"}],"children":[{"type":"Poster","attrs":{"id":"dot","translation":"[20,22]","width":"16","height":"16","loadWidth":"16","loadHeight":"16","loadDisplayMode":"scaleToFit"},"children":[]},{"type":"Label","attrs":{"id":"name","translation":"[52,14]","width":"480","font":"font:MediumBoldSystemFont","color":"0xFFFFFFFF"},"children":[]},{"type":"Label","attrs":{"id":"tag","translation":"[540,18]","width":"140","horizAlign":"right","font":"font:SmallBoldSystemFont","color":"0x50E68CFF"},"children":[]}]}, function (m) {
// ---- components/libraryitem.brs ----
function init() {
  m.dot = m.top.$findnode("dot");
  m.name = m.top.$findnode("name");
  m.tag = m.top.$findnode("tag");
}

function showitem() {
  let item, t;
  item = m.top.itemcontent;
  if ((item == null)) {
    return;
  }
  m.name.text = item.title;
  t = item.shortdescriptionline1;
  if ((t == null)) {
    t = "";
  }
  m.tag.text = t;
  if ((t !== "")) {
    m.dot.uri = "pkg:/images/dot_on.png";
    m.dot.visible = true;
  } else {
    m.dot.visible = false;
  }
  m.base = "0xFFFFFFFF";
  if ((item.starrating === 1)) {
    m.base = "0xFF8A24FF";
  }
  m.name.color = m.base;
}

function showfocus() {
  if ((m.top.focuspercent > 0.5)) {
    m.name.color = "0xFF8A24FF";
  } else if ((m.base != null)) {
    m.name.color = m.base;
  }
}
return {"init": init, "showitem": showitem, "showfocus": showfocus};
});

$defineComponent({"name":"MatchesTask","extends":"Task","fields":[{"id":"items","type":"array"},{"id":"result","type":"array"},{"id":"espnOk","type":"boolean","value":"false"},{"id":"only","type":"array"},{"id":"okLeagues","type":"array"}],"children":[]}, function (m) {
// ---- components/matchestask.brs ----
function init() {
  m.top.functionname = "mtRun";
}

function mtrun() {
  try {
    mtruninner();
  } catch (e) {
    console.log("[MT] error: ", e.message);
    m.top.result = [];
  }
}

function mtruninner() {
  let items, now, nowu, loc, tzoff, locsecs, midlocal, midutc, parsed, it, p, lgs, only, want, id, sel, lg, evs, today, ev, ls, lab, out;
  items = m.top.items;
  if ((items == null)) {
    items = [];
  }
  now = $createobject("roDateTime");
  nowu = now.$asseconds();
  loc = $createobject("roDateTime");
  loc.$tolocaltime();
  tzoff = (loc.$asseconds() - nowu);
  locsecs = (nowu + tzoff);
  midlocal = (locsecs - ((locsecs % 86400)));
  midutc = (midlocal - tzoff);
  m.mtmon = loc.$getmonth();
  m.mtday = loc.$getdayofmonth();
  parsed = [];
  for (it of $iter(items)) {
    p = null;
    try {
      p = mtparse(mts(it.t), mts(it.g));
    } catch (e) {
      p = null;
    }
    if ((p == null)) {
      p = {__proto__: $AAP, "mins": (-1), "mon": 0, "day": 0, "league": "", "rest": mts(it.t), "chan": "", "sport": "soccer", "home": "", "away": "", "pair": ""};
    }
    if ((p != null)) {
      p.it = it;
      p.w = mtdeleet(mtnorm(mts(it.t), true)).$split(" ");
      p.t = p.w.$join("");
      parsed.$push(p);
    }
  }
  lgs = mtleagues();
  only = m.top.only;
  if (((only != null) && (only.$count() > 0))) {
    want = {__proto__: $AAP};
    for (id of $iter(only)) {
      $six(want, id, true);
    }
    sel = [];
    for (lg of $iter(lgs)) {
      if (want.$doesexist(lg.id)) {
        sel.$push(lg);
      }
    }
    if ((sel.$count() > 0)) {
      lgs = sel;
    }
  }
  m.oknames = [];
  evs = mtfetchleagues(lgs, mtymd((midlocal + 43200)));
  m.top.okleagues = m.oknames;
  m.top.espnok = ((evs.$count() > 0));
  if ((evs.$count() === 0)) {
    m.top.result = mtlistmode(parsed, tzoff, midutc);
    return;
  }
  today = [];
  for (ev of $iter(evs)) {
    ls = (ev.start + tzoff);
    if (((ev.state === "in") || (((ls >= midlocal) && (ls < (midlocal + 86400)))))) {
      ev.ch = [];
      today.$push(ev);
    }
  }
  for (p of $iter(parsed)) {
    ev = mtfind(p, today);
    if ((ev != null)) {
      lab = p.chan;
      if ((lab === "")) {
        lab = p.it.g;
      }
      ev.ch.$push({__proto__: $AAP, "t": p.it.t, "u": p.it.u, "f": p.it.f, "l": p.it.l, "lab": lab});
    }
  }
  out = [];
  for (ev of $iter(today)) {
    out.$push({__proto__: $AAP, "k": ("e" + ev.id), "start": ev.start, "est": false, "sport": "soccer", "league": ev.league, "lglogo": ev.lglogo, "prio": ev.prio, "lid": ev.lid, "h": ev.h, "a": ev.a, "hl": ev.hl, "al": ev.al, "hsc": ev.hsc, "asc": ev.asc, "state": ev.state, "detail": ev.detail, "full": ((ev.h + " vs ") + ev.a), "ch": ev.ch});
  }
  console.log("[MT] hoy: ", out.$count(), " partidos oficiales");
  m.top.result = out;
}

function mtprio(id) {
  let lgs, i, $e0;
  lgs = mtleagues();
  for (i = 0, $e0 = (lgs.$count() - 1); i <= $e0; i++) {
    if (($ix(lgs, i).id === id)) {
      return (i + 1);
    }
  }
  return 99;
}

function mtleagues() {
  return [{__proto__: $AAP, "id": "mex.1", "n": "Liga MX"}, {__proto__: $AAP, "id": "uefa.champions", "n": "Champions League"}, {__proto__: $AAP, "id": "eng.1", "n": "Premier League"}, {__proto__: $AAP, "id": "esp.1", "n": "LaLiga"}, {__proto__: $AAP, "id": "ita.1", "n": "Serie A"}, {__proto__: $AAP, "id": "ger.1", "n": "Bundesliga"}, {__proto__: $AAP, "id": "fra.1", "n": "Ligue 1"}, {__proto__: $AAP, "id": "ned.1", "n": "Eredivisie"}, {__proto__: $AAP, "id": "por.1", "n": "Liga Portugal"}, {__proto__: $AAP, "id": "uefa.europa", "n": "Europa League"}, {__proto__: $AAP, "id": "uefa.europa.conf", "n": "Conference League"}, {__proto__: $AAP, "id": "usa.1", "n": "MLS"}, {__proto__: $AAP, "id": "concacaf.champions", "n": "Concacaf Champions Cup"}, {__proto__: $AAP, "id": "concacaf.leagues.cup", "n": "Leagues Cup"}, {__proto__: $AAP, "id": "conmebol.libertadores", "n": "Copa Libertadores"}, {__proto__: $AAP, "id": "conmebol.sudamericana", "n": "Copa Sudamericana"}, {__proto__: $AAP, "id": "arg.1", "n": "Liga Argentina"}, {__proto__: $AAP, "id": "bra.1", "n": "Brasileirão"}, {__proto__: $AAP, "id": "mex.2", "n": "Liga de Expansión MX"}, {__proto__: $AAP, "id": "mex.w.1", "n": "Liga MX Femenil"}, {__proto__: $AAP, "id": "eng.2", "n": "Championship"}, {__proto__: $AAP, "id": "esp.copa_del_rey", "n": "Copa del Rey"}, {__proto__: $AAP, "id": "eng.fa", "n": "FA Cup"}, {__proto__: $AAP, "id": "fifa.world", "n": "Mundial 2026"}, {__proto__: $AAP, "id": "fifa.worldq.concacaf", "n": "Eliminatorias Concacaf"}, {__proto__: $AAP, "id": "fifa.worldq.conmebol", "n": "Eliminatorias Conmebol"}, {__proto__: $AAP, "id": "fifa.worldq.uefa", "n": "Eliminatorias UEFA"}, {__proto__: $AAP, "id": "uefa.nations", "n": "Nations League"}, {__proto__: $AAP, "id": "concacaf.nations.league", "n": "Nations League Concacaf"}, {__proto__: $AAP, "id": "fifa.friendly", "n": "Amistosos"}];
}

function mtfetchleagues(leagues, ymd) {
  let evs, seen, base, i, okn, port, reqs, n, lg, h, pending, clock, msg, rq, js, logo, l0, lg0, rl, before, k, $e1, id;
  evs = [];
  seen = {__proto__: $AAP};
  base = "https://site.api.espn.com/apis/site/v2/sports/soccer/";
  i = 0;
  okn = 0;
  while ((i < leagues.$count())) {
    port = $createobject("roMessagePort");
    reqs = {__proto__: $AAP};
    n = 0;
    while (((i < leagues.$count()) && (n < 8))) {
      lg = $ix(leagues, i);
      h = $createobject("roUrlTransfer");
      h.$setcertificatesfile("common:/certs/ca-bundle.crt");
      h.$initclientcertificates();
      h.$enableencodings(true);
      h.$setmessageport(port);
      h.$seturl((((base + lg.id) + "/scoreboard?dates=") + ymd));
      if (h.$asyncgettostring()) {
        $six(reqs, h.$getidentity().$tostr(), {__proto__: $AAP, "h": h, "lg": lg, "p": mtprio(lg.id), "done": false});
        n = (n + 1);
      }
      i = (i + 1);
    }
    pending = n;
    clock = $createobject("roTimespan");
    while (((pending > 0) && (clock.$totalmilliseconds() < 20000))) {
      msg = $wait(1000, port);
      if (($type(msg) === "roUrlEvent")) {
        rq = $ix(reqs, msg.$getsourceidentity().$tostr());
        if (((rq != null) && (!rq.done))) {
          rq.done = true;
          pending = (pending - 1);
          if ((msg.$getresponsecode() === 200)) {
            js = null;
            try {
              js = $parsejson(msg.$getstring());
            } catch (e) {
              js = null;
            }
            if (((js != null) && ($type(js) === "roAssociativeArray"))) {
              okn = (okn + 1);
              m.oknames.$push(rq.lg.n);
              logo = "";
              if ((($type(js.leagues) === "roArray") && (js.leagues.$count() > 0))) {
                l0 = $ix(js.leagues, 0);
                if (((($type(l0) === "roAssociativeArray") && ($type(l0.logos) === "roArray")) && (l0.logos.$count() > 0))) {
                  for (lg0 of $iter(l0.logos)) {
                    if (($type(lg0) === "roAssociativeArray")) {
                      if ((logo === "")) {
                        logo = mts(lg0.href);
                      }
                      if (($type(lg0.rel) === "roArray")) {
                        for (rl of $iter(lg0.rel)) {
                          if ((mts(rl) === "dark")) {
                            logo = mts(lg0.href);
                          }
                        }
                      }
                    }
                  }
                }
              }
              if (($type(js.events) === "roArray")) {
                before = evs.$count();
                mtaddevents(js.events, evs, seen);
                for (k = before, $e1 = (evs.$count() - 1); k <= $e1; k++) {
                  $ix(evs, k).league = rq.lg.n;
                  $ix(evs, k).lglogo = logo;
                  $ix(evs, k).prio = rq.p;
                  $ix(evs, k).lid = rq.lg.id;
                }
              }
            }
          }
        }
      }
    }
    for (id of $iter(reqs)) {
      if ((!$ix(reqs, id).done)) {
        $ix(reqs, id).h.$asynccancel();
      }
    }
  }
  console.log("[MT] ESPN: ", okn, " ligas respondieron, ", evs.$count(), " partidos");
  return evs;
}

function mtlistmode(parsed, tzoff, midutc) {
  let defoff, bykey, order, p, lm, start, key, lab, chitem, lgn, out, k;
  defoff = $int((tzoff / 60));
  bykey = {__proto__: $AAP};
  order = [];
  for (p of $iter(parsed)) {
    if (((p.sport !== "soccer") || (p.mins < 0))) {
      continue;
    }
    if (((p.mon > 0) && (!(((p.mon === m.mtmon) && (p.day === m.mtday)))))) {
      continue;
    }
    lm = p.mins;
    start = (midutc + (lm * 60));
    key = ("t" + p.pair);
    if ((p.pair === "")) {
      key = ("x" + p.t);
    }
    lab = p.chan;
    if ((lab === "")) {
      lab = p.it.g;
    }
    chitem = {__proto__: $AAP, "t": p.it.t, "u": p.it.u, "f": p.it.f, "l": p.it.l, "lab": lab};
    if (bykey.$doesexist(key)) {
      $ix(bykey, key).ch.$push(chitem);
    } else {
      lgn = p.league;
      if ((lgn === "")) {
        lgn = "De tu lista";
      }
      $six(bykey, key, {__proto__: $AAP, "k": key, "start": start, "est": true, "sport": "soccer", "league": lgn, "lglogo": "", "prio": 99, "lid": "", "h": p.home, "a": p.away, "hl": "", "al": "", "hsc": "", "asc": "", "state": "", "detail": "", "full": p.rest, "ch": [chitem]});
      order.$push(key);
    }
  }
  out = [];
  for (k of $iter(order)) {
    out.$push($ix(bykey, k));
  }
  return out;
}

function mtrx() {
  if ((m.rx == null)) {
    m.rx = {__proto__: $AAP, "c": $createobject("roRegex", "^(\\d{1,2})/(\\d{1,2})\\s+(\\S+)\\s+(\\d{1,2}):(\\d{2})\\s*([AaPp][Mm])\\s+(.+?)\\s*=\\s*(.+)$", ""), "b": $createobject("roRegex", "^(.+?)\\s*\\|\\s*(\\d{1,2}):(\\d{2})\\s*([AaPp][Mm])?\\s*\\|\\s*(.+)$", ""), "a": $createobject("roRegex", "^(\\d{1,2})[:\\.](\\d{2})\\s*([AaPp][Mm])?\\s*[-|:]?\\s*(.+)$", ""), "any": $createobject("roRegex", "(\\d{1,2}):(\\d{2})\\s*([AaPp][Mm])?", ""), "vs": $createobject("roRegex", "^(.*\\S)\\s+(?:vs\\.?|v\\.|x)\\s+(\\S.*)$", "i"), "dash": $createobject("roRegex", "^(.*\\S)\\s+-\\s+(\\S.*)$", "")};
  }
  return m.rx;
}

function mtminutes(h, mi, ap) {
  let hh, mm, a;
  if (((h == null) || (mi == null))) {
    return (-1);
  }
  hh = $val(h);
  mm = $val(mi);
  if (((hh > 23) || (mm > 59))) {
    return (-1);
  }
  a = "";
  if ((ap != null)) {
    a = $lcase(ap);
  }
  if (((a === "pm") && (hh < 12))) {
    hh = (hh + 12);
  }
  if (((a === "am") && (hh === 12))) {
    hh = 0;
  }
  return ((hh * 60) + mm);
}

function mtparse(t, grp) {
  let rx, p, r, sp3, ll, txt, w, hw, aw, hk, ak;
  rx = mtrx();
  p = {__proto__: $AAP, "mins": (-1), "mon": 0, "day": 0, "league": "", "rest": "", "chan": "", "sport": "soccer", "home": "", "away": "", "pair": ""};
  r = rx.c.$match(t);
  if ((r.$count() >= 9)) {
    p.mon = $val($ix(r, 1));
    p.day = $val($ix(r, 2));
    p.league = mts($ix(r, 3));
    p.mins = mtminutes($ix(r, 4), $ix(r, 5), $ix(r, 6));
    p.rest = mts($ix(r, 7));
    p.chan = mts($ix(r, 8)).$replace("*", "").$trim();
    sp3 = $lcase(p.league);
    if ((((sp3 !== "soccer") && (sp3 !== "futbol")) && (sp3 !== "football"))) {
      p.sport = "other";
    }
  } else {
    r = rx.b.$match(t);
    if ((r.$count() >= 6)) {
      p.league = mts($ix(r, 1)).$trim();
      p.mins = mtminutes($ix(r, 2), $ix(r, 3), $ix(r, 4));
      p.rest = mts($ix(r, 5));
    } else {
      r = rx.a.$match(t);
      if ((r.$count() >= 5)) {
        p.mins = mtminutes($ix(r, 1), $ix(r, 2), $ix(r, 3));
        p.rest = mts($ix(r, 4));
      } else {
        r = rx.any.$match(t);
        if ((r.$count() < 3)) {
          return null;
        }
        p.mins = mtminutes($ix(r, 1), $ix(r, 2), $ix(r, 3));
        p.rest = t.$replace(mts($ix(r, 0)), " ").$trim();
      }
    }
  }
  if ((p.mins < 0)) {
    return null;
  }
  ll = $lcase(p.league);
  if ((ll === "epl")) {
    p.league = "Premier League";
  }
  if ((ll === "les")) {
    p.league = "LaLiga";
  }
  if ((ll === "arg")) {
    p.league = "Liga Argentina";
  }
  txt = $lcase(((((p.league + " ") + p.rest) + " | ") + grp));
  for (w of $iter(["basket", "nba", "wnba", "nfl", "cfl", "americano", "nhl", "hockey", "mlb", "beisbol", "béisbol", "baseball", "tenis", "tennis", "atp ", "wta", "ufc", "boxing", "boxeo", "box ", "f1 ", "formula", "fórmula", "motogp", "nascar", "golf", "freestyle", "balonmano", "handball", "volei", "voley", "volley", "rugby", "artística", "artistica", "pesaje", "matchroom", "wwe", "horse", "ciclismo", "baloncesto", "bkfc", "nascar", "ncaa", "lmp", "lmb"])) {
    if (($instr(1, txt, w) > 0)) {
      p.sport = "other";
      break;
    }
  }
  r = rx.vs.$match(p.rest);
  if ((r.$count() < 3)) {
    r = rx.dash.$match(p.rest);
  }
  if ((r.$count() >= 3)) {
    p.home = mts($ix(r, 1)).$trim();
    p.away = mts($ix(r, 2)).$trim();
    hw = mtnorm(p.home, true).$split(" ");
    aw = mtnorm(p.away, true).$split(" ");
    hk = mtsig(hw, (hw.$count() - 2), (hw.$count() - 1));
    ak = mtsig(aw, 0, 1);
    if (((hk !== "") && (ak !== ""))) {
      if ((hk < ak)) {
        p.pair = ((hk + "|") + ak);
      } else {
        p.pair = ((ak + "|") + hk);
      }
    }
  }
  return p;
}

function mtsig(w, i0, i1) {
  let x, best, anyw, i, $e2;
  if ((m.stopp == null)) {
    m.stopp = {__proto__: $AAP};
    for (x of $iter(["club", "real", "sporting", "atletico", "deportivo", "athletic", "sport", "sports", "football", "futbol", "calcio", "olympique", "borussia", "racing", "union", "town", "rovers", "wanderers", "county", "women", "femenino", "under", "esporte", "clube", "the", "city", "united", "u17", "u19", "u20", "u21", "u22", "u23", "sub17"])) {
      $six(m.stopp, x, true);
    }
  }
  if ((i0 < 0)) {
    i0 = 0;
  }
  if ((i1 > (w.$count() - 1))) {
    i1 = (w.$count() - 1);
  }
  best = "";
  anyw = "";
  for (i = i0, $e2 = i1; i <= $e2; i++) {
    x = $ix(w, i);
    if (($len(x) > $len(anyw))) {
      anyw = x;
    }
    if (((($len(x) >= 4) && (!m.stopp.$doesexist(x))) && ($len(x) > $len(best)))) {
      best = x;
    }
  }
  if ((best === "")) {
    best = anyw;
  }
  return best;
}

function mtlastwords(s, n) {
  let w, out, c, i;
  w = mtnorm(s, true).$split(" ");
  out = "";
  c = 0;
  i = (w.$count() - 1);
  while (((i >= 0) && (c < n))) {
    if (($ix(w, i) !== "")) {
      out = (($ix(w, i) + " ") + out);
      c = (c + 1);
    }
    i = (i - 1);
  }
  return out.$trim();
}

function mtlongest(s) {
  let best, w;
  best = "";
  for (w of $iter(mtnorm(s, true).$split(" "))) {
    if (($len(w) > $len(best))) {
      best = w;
    }
  }
  return best;
}

function mtnorm(s, spaces) {
  let t, out, lastsp, n, i, $e3, ch, a, k;
  if ((m.acca == null)) {
    m.acca = "áàäâãåéèëêíìïîóòöôõøúùüûñçýÁÀÄÂÃÅÉÈËÊÍÌÏÎÓÒÖÔÕØÚÙÜÛÑÇÝłŁšŠžŽćĆčČęĘąĄńŃśŚźŹżŻğĞıİşŞ";
    m.accb = "aaaaaaeeeeiiiioooooouuuuncyaaaaaaeeeeiiiioooooouuuuncyllsszzcccceeaannsszzzzggiiss";
  }
  t = $lcase(s);
  out = "";
  lastsp = true;
  n = $len(t);
  for (i = 1, $e3 = n; i <= $e3; i++) {
    ch = $mid(t, i, 1);
    a = $asc(ch);
    if (((((a >= 97) && (a <= 122))) || (((a >= 48) && (a <= 57))))) {
      out = (out + ch);
      lastsp = false;
    } else if ((a >= 128)) {
      k = $instr(1, m.acca, ch);
      if ((k > 0)) {
        out = (out + $mid(m.accb, k, 1));
        lastsp = false;
      } else if ((spaces && (!lastsp))) {
        out = (out + " ");
        lastsp = true;
      }
    } else if ((spaces && (!lastsp))) {
      out = (out + " ");
      lastsp = true;
    }
  }
  return out.$trim();
}

function mtwords(name) {
  let w, out, got, full, compact, k;
  if ((m.stopw == null)) {
    m.stopw = {__proto__: $AAP};
    for (w of $iter(["club", "real", "sporting", "atletico", "deportivo", "athletic", "sport", "sports", "football", "futbol", "calcio", "olympique", "borussia", "racing", "union", "town", "rovers", "wanderers", "county", "women", "femenino", "fem", "under", "esporte", "clube", "associazione", "societa", "amateur", "reserves", "the"])) {
      $six(m.stopw, w, true);
    }
  }
  out = [];
  got = {__proto__: $AAP};
  for (w of $iter(mtnorm(name, true).$split(" "))) {
    if (((($len(w) >= 4) && (!m.stopw.$doesexist(w))) && (!got.$doesexist(w)))) {
      $six(got, w, true);
      out.$push(w);
    }
  }
  if ((out.$count() === 0)) {
    full = mtnorm(name, false);
    if (($len(full) >= 3)) {
      out.$push(full);
    }
  }
  if ((m.alias == null)) {
    m.alias = {__proto__: $AAP, "guadalajara": ["chivas"], "monterrey": ["rayados"], "unam": ["pumas"], "uanl": ["tigres"], "america": ["aguilas"], "toluca": ["diablos"], "manchesterunited": ["manutd", "manunited"], "manchestercity": ["mancity"], "parissaintgermain": ["psg"], "parissg": ["psg"], "borussiadortmund": ["dortmund", "bvb"], "bayernmunich": ["bayern"], "internazionale": ["inter"], "intermilan": ["inter"], "atleticomadrid": ["atleticomadrid", "atleticodemadrid", "atleti"], "atleticodemadrid": ["atleticomadrid", "atleticodemadrid", "atleti"], "realmadrid": ["realmadrid"], "realsociedad": ["sociedad"], "realbetis": ["betis"], "tottenhamhotspur": ["tottenham", "spurs"], "wolverhamptonwanderers": ["wolves"], "nottinghamforest": ["nottingham", "forest"], "athleticclub": ["athletic", "bilbao"], "sportingcp": ["sporting"], "rbleipzig": ["leipzig"], "bayerleverkusen": ["leverkusen"], "barcelona": ["barca"], "juventus": ["juve"], "napoli": ["napoles"], "acmilan": ["milan"], "olympiquemarseille": ["marsella", "marseille"], "olympiquelyonnais": ["lyon"], "bayernmunchen": ["bayern"], "unitedstates": ["estadosunidos", "usa", "eeuu"], "spain": ["espana"], "germany": ["alemania"], "france": ["francia"], "brazil": ["brasil"], "england": ["inglaterra"], "netherlands": ["paisesbajos", "holanda"], "japan": ["japon"], "italy": ["italia"], "belgium": ["belgica"], "croatia": ["croacia"], "morocco": ["marruecos"], "southkorea": ["corea"], "korearepublic": ["corea"], "switzerland": ["suiza"], "poland": ["polonia"], "turkey": ["turquia"], "turkiye": ["turquia"], "saudiarabia": ["arabia"], "egypt": ["egipto"], "scotland": ["escocia"], "wales": ["gales"], "ireland": ["irlanda"], "norway": ["noruega"], "sweden": ["suecia"], "denmark": ["dinamarca"], "czechia": ["chequia"], "czechrepublic": ["chequia"], "newzealand": ["nuevazelanda"], "southafrica": ["sudafrica"], "cameroon": ["camerun"], "ivorycoast": ["costademarfil"], "algeria": ["argelia"], "tunisia": ["tunez"], "ivorycoast2": ["costademarfil"]};
  }
  compact = mtnorm(name, false);
  for (k of $iter(m.alias)) {
    if (($instr(1, compact, k) > 0)) {
      for (w of $iter($ix(m.alias, k))) {
        if ((!got.$doesexist(w))) {
          $six(got, w, true);
          out.$push(w);
        }
      }
    }
  }
  return out;
}

function mtfind(p, evs) {
  let best, bestscore, ev, sh, sa;
  best = null;
  bestscore = 0;
  for (ev of $iter(evs)) {
    sh = mtteamscore(ev.hw, p);
    if ((sh > 0)) {
      sa = mtteamscore(ev.aw, p);
      if (((sa > 0) && ((sh + sa) > bestscore))) {
        bestscore = (sh + sa);
        best = ev;
      }
    }
  }
  return best;
}

function mtteamscore(words, p) {
  let sc, w, tk;
  sc = 0;
  for (w of $iter(words)) {
    if (($instr(1, p.t, w) > 0)) {
      sc = (sc + 1);
    }
  }
  if ((sc > 0)) {
    return sc;
  }
  for (w of $iter(words)) {
    if (($len(w) >= 5)) {
      for (tk of $iter(p.w)) {
        if (mtnear(w, tk)) {
          sc = (sc + 1);
          break;
        }
      }
    }
  }
  return sc;
}

function mtnear(a, b) {
  let la, lb, i, j, ed;
  la = $len(a);
  lb = $len(b);
  if (((((la - lb) > 1) || ((lb - la) > 1)) || (lb < 4))) {
    return false;
  }
  if (($left(a, 1) !== $left(b, 1))) {
    return false;
  }
  i = 1;
  j = 1;
  ed = 0;
  while (((i <= la) && (j <= lb))) {
    if (($mid(a, i, 1) === $mid(b, j, 1))) {
      i = (i + 1);
      j = (j + 1);
    } else {
      ed = (ed + 1);
      if ((ed > 1)) {
        return false;
      }
      if ((la > lb)) {
        i = (i + 1);
      } else if ((lb > la)) {
        j = (j + 1);
      } else {
        i = (i + 1);
        j = (j + 1);
      }
    }
  }
  ed = ((ed + (((la - i) + 1))) + (((lb - j) + 1)));
  return (ed <= 1);
}

function mtdeleet(s) {
  let toks, out, tk, n, hasl, hasd, nd, i, $e4, a;
  toks = s.$split(" ");
  out = [];
  for (tk of $iter(toks)) {
    n = $len(tk);
    hasl = false;
    hasd = false;
    nd = 0;
    for (i = 1, $e4 = n; i <= $e4; i++) {
      a = $asc($mid(tk, i, 1));
      if (((a >= 97) && (a <= 122))) {
        hasl = true;
      }
      if (((a >= 48) && (a <= 57))) {
        hasd = true;
        nd = (nd + 1);
      }
    }
    if ((((hasl && hasd) && (n >= 4)) && ((nd * 2) <= n))) {
      tk = tk.$replace("0", "o").$replace("1", "i").$replace("3", "e").$replace("4", "a").$replace("5", "s").$replace("7", "t").$replace("8", "b");
    }
    out.$push(tk);
  }
  return out.$join(" ");
}

function mtymd(secs) {
  let d, y, mo, dd, ms, ds;
  d = $createobject("roDateTime");
  d.$fromseconds(secs);
  y = d.$getyear().$tostr();
  mo = d.$getmonth();
  dd = d.$getdayofmonth();
  ms = mo.$tostr();
  if ((mo < 10)) {
    ms = ("0" + ms);
  }
  ds = dd.$tostr();
  if ((dd < 10)) {
    ds = ("0" + ds);
  }
  return ((y + ms) + ds);
}

function mtespn(midlocal) {
  let base, dy, dt, dm, evs, seen, js, d;
  base = "https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard?dates=";
  dy = mtymd((midlocal - 43200));
  dt = mtymd((midlocal + 43200));
  dm = mtymd(((midlocal + 86400) + 43200));
  evs = [];
  seen = {__proto__: $AAP};
  js = mtget((((base + dy) + "-") + dm));
  if ((((js != null) && ($type(js.events) === "roArray")) && (js.events.$count() > 0))) {
    mtaddevents(js.events, evs, seen);
  } else {
    for (d of $iter([dy, dt, dm])) {
      js = mtget((base + d));
      if (((js != null) && ($type(js.events) === "roArray"))) {
        mtaddevents(js.events, evs, seen);
      }
      js = null;
    }
  }
  console.log("[MT] ESPN: ", evs.$count(), " partidos");
  return evs;
}

function mtget(url) {
  let fs, path, http, port, msg, txt;
  fs = $createobject("roFileSystem");
  path = "cachefs:/mt_espn.json";
  if (fs.$exists(path)) {
    fs.$delete(path);
  }
  http = $createobject("roUrlTransfer");
  http.$setcertificatesfile("common:/certs/ca-bundle.crt");
  http.$initclientcertificates();
  http.$enableencodings(true);
  http.$seturl(url);
  port = $createobject("roMessagePort");
  http.$setmessageport(port);
  if ((!http.$asyncgettofile(path))) {
    return null;
  }
  msg = $wait(30000, port);
  if (($type(msg) !== "roUrlEvent")) {
    http.$asynccancel();
    console.log("[MT] ESPN sin respuesta");
    return null;
  }
  if ((msg.$getresponsecode() !== 200)) {
    console.log("[MT] ESPN codigo ", msg.$getresponsecode());
    if (fs.$exists(path)) {
      fs.$delete(path);
    }
    return null;
  }
  txt = $readasciifile(path);
  fs.$delete(path);
  if (((txt == null) || (txt === ""))) {
    return null;
  }
  return $parsejson(txt);
}

function mts(v) {
  let t;
  if ((v == null)) {
    return "";
  }
  t = $type(v);
  if (((t === "roString") || (t === "String"))) {
    return v;
  }
  if (((((((t === "roInteger") || (t === "Integer")) || (t === "roFloat")) || (t === "Float")) || (t === "LongInteger")) || (t === "Double"))) {
    return v.$tostr();
  }
  return "";
}

function mtiso(s) {
  let iso, d;
  if (($len(s) < 16)) {
    return 0;
  }
  iso = ($left(s, 16) + ":00Z");
  d = $createobject("roDateTime");
  d.$fromiso8601string(iso);
  return d.$asseconds();
}

function mtleaguename(e) {
  let n, mp, k;
  n = mtleagueraw(e);
  mp = {__proto__: $AAP, "english premier league": "Premier League", "spanish laliga": "LaLiga", "laliga": "LaLiga", "spanish la liga": "LaLiga", "italian serie a": "Serie A", "german bundesliga": "Bundesliga", "french ligue 1": "Ligue 1", "mexican liga bbva mx": "Liga MX", "liga bbva mx": "Liga MX", "mexican liga mx": "Liga MX", "uefa champions league": "Champions League", "uefa europa league": "Europa League", "english league championship": "Championship", "portuguese primeira liga": "Liga Portugal", "dutch eredivisie": "Eredivisie", "saudi pro league": "Liga Saudí", "argentine liga profesional de fútbol": "Liga Argentina", "brazilian serie a": "Brasileirão", "major league soccer": "MLS"};
  k = $lcase(n);
  if (mp.$doesexist(k)) {
    return $ix(mp, k);
  }
  return n;
}

function mtleagueraw(e) {
  let comp, n, sl, parts, out, w;
  comp = null;
  if ((($type(e.competitions) === "roArray") && (e.competitions.$count() > 0))) {
    comp = $ix(e.competitions, 0);
  }
  if ((comp != null)) {
    n = mts(comp.altgamenote);
    if ((n !== "")) {
      return n;
    }
  }
  if (($type(e.season) === "roAssociativeArray")) {
    sl = mts(e.season.slug);
    if ((sl !== "")) {
      parts = sl.$split("-");
      out = "";
      for (w of $iter(parts)) {
        if ((((w !== "") && ($val(w) === 0)) && (w !== "00"))) {
          out = (((out + $ucase($left(w, 1))) + $mid(w, 2)) + " ");
        }
      }
      return out.$trim();
    }
  }
  return "";
}

function mtaddevents(arr, evs, seen) {
  let e, id, comp, h, a, c, st, det, hn, an, hw, aw;
  for (e of $iter(arr)) {
    if (($type(e) === "roAssociativeArray")) {
      id = mts(e.id);
      if (((((id !== "") && (!seen.$doesexist(id))) && ($type(e.competitions) === "roArray")) && (e.competitions.$count() > 0))) {
        $six(seen, id, true);
        comp = $ix(e.competitions, 0);
        h = null;
        a = null;
        if (($type(comp.competitors) === "roArray")) {
          for (c of $iter(comp.competitors)) {
            if (($type(c) === "roAssociativeArray")) {
              if ((mts(c.homeaway) === "home")) {
                h = c;
              } else {
                a = c;
              }
            }
          }
        }
        if (((((h != null) && (a != null)) && ($type(h.team) === "roAssociativeArray")) && ($type(a.team) === "roAssociativeArray"))) {
          st = "";
          det = "";
          if ((($type(e.status) === "roAssociativeArray") && ($type(e.status.type) === "roAssociativeArray"))) {
            st = mts(e.status.type.state);
            det = mts(e.status.type.shortdetail);
          }
          hn = mts(h.team.shortdisplayname);
          if ((hn === "")) {
            hn = mts(h.team.displayname);
          }
          an = mts(a.team.shortdisplayname);
          if ((an === "")) {
            an = mts(a.team.displayname);
          }
          hw = mtwords(((mts(h.team.displayname) + " ") + mts(h.team.shortdisplayname)));
          aw = mtwords(((mts(a.team.displayname) + " ") + mts(a.team.shortdisplayname)));
          evs.$push({__proto__: $AAP, "id": id, "start": mtiso(mts(e.date)), "league": mtleaguename(e), "h": hn, "a": an, "hl": mts(h.team.logo), "al": mts(a.team.logo), "hsc": mts(h.score), "asc": mts(a.score), "state": st, "detail": det, "hw": hw, "aw": aw});
        }
      }
    }
  }
}
return {"init": init, "mtrun": mtrun, "mtruninner": mtruninner, "mtprio": mtprio, "mtleagues": mtleagues, "mtfetchleagues": mtfetchleagues, "mtlistmode": mtlistmode, "mtrx": mtrx, "mtminutes": mtminutes, "mtparse": mtparse, "mtsig": mtsig, "mtlastwords": mtlastwords, "mtlongest": mtlongest, "mtnorm": mtnorm, "mtwords": mtwords, "mtfind": mtfind, "mtteamscore": mtteamscore, "mtnear": mtnear, "mtdeleet": mtdeleet, "mtymd": mtymd, "mtespn": mtespn, "mtget": mtget, "mts": mts, "mtiso": mtiso, "mtleaguename": mtleaguename, "mtleagueraw": mtleagueraw, "mtaddevents": mtaddevents};
});

$defineComponent({"name":"QrServer","extends":"Task","fields":[{"id":"port","type":"integer","value":"8088"},{"id":"received","type":"assocarray"},{"id":"status","type":"string"}],"children":[]}, function (m) {
// ---- components/qrserver.brs ----
function init() {
  m.top.functionname = "serve";
}

function serve() {
  let mp, srv, bound, ports, pt, reuse, $e0, variant, $e1, cand, addr, okaddr, clients, clock, counter, msg, sid, c, k, cl, sock, s, now, old, key;
  mp = $createobject("roMessagePort");
  srv = null;
  bound = 0;
  ports = [m.top.port, 8090, 8099, 8123];
  for (pt of $iter(ports)) {
    for (reuse = 0, $e0 = 1; reuse <= $e0; reuse++) {
      for (variant = 0, $e1 = 2; variant <= $e1; variant++) {
        if ((srv == null)) {
          cand = $createobject("roStreamSocket");
          addr = $createobject("roSocketAddress");
          if ((variant === 0)) {
            addr.$setaddress(("0.0.0.0:" + pt.$tostr()));
          } else if ((variant === 1)) {
            addr.$sethostname("0.0.0.0");
            addr.$setport(pt);
          } else {
            addr.$setport(pt);
          }
          if ((reuse === 0)) {
            cand.$setreuseaddr(true);
          }
          okaddr = cand.$setaddress(addr);
          if (okaddr) {
            cand.$setmessageport(mp);
            cand.$notifyreadable(true);
            if (cand.$listen(5)) {
              srv = cand;
              bound = pt;
            }
          }
        }
      }
    }
  }
  if ((srv == null)) {
    m.top.status = ("error:" + tx("No se pudo abrir el servidor en la TV (puertos ocupados o bloqueados)"));
    return;
  }
  m.top.status = ("listo:" + bound.$tostr());
  clients = {__proto__: $AAP};
  clock = $createobject("roTimespan");
  counter = 0;
  while (true) {
    msg = $wait(1000, mp);
    if (($type(msg) === "roSocketEvent")) {
      sid = msg.$getsocketid();
      if ((sid === srv.$getid())) {
        if (srv.$isreadable()) {
          c = srv.$accept();
          if ((c != null)) {
            c.$setmessageport(mp);
            c.$notifyreadable(true);
            $six(clients, c.$getid().$tostr(), {__proto__: $AAP, "sock": c, "buf": "", "t": clock.$totalmilliseconds()});
          }
        }
      } else {
        k = sid.$tostr();
        cl = $ix(clients, k);
        if ((cl != null)) {
          sock = cl.sock;
          if (sock.$isreadable()) {
            s = sock.$receivestr(4096);
            if (((s == null) || (s === ""))) {
              sock.$close();
              clients.$delete(k);
            } else {
              cl.buf = (cl.buf + s);
              if ((($instr(1, cl.buf, ((($chr(13) + $chr(10)) + $chr(13)) + $chr(10))) > 0) || ($len(cl.buf) > 40000))) {
                counter = (counter + 1);
                handlerequest(sock, cl.buf, counter);
                sock.$close();
                clients.$delete(k);
              }
            }
          }
        }
      }
    }
    now = clock.$totalmilliseconds();
    old = [];
    for (key of $iter(clients)) {
      if (((now - $ix(clients, key).t) > 15000)) {
        old.$push(key);
      }
    }
    for (key of $iter(old)) {
      $ix(clients, key).sock.$close();
      clients.$delete(key);
    }
  }
}

function handlerequest(sock, req, counter) {
  let eol, line, sp1, rest, sp2, target, path, query, q, p, host, user, pass, full, err, it, items, total, i, $e2, url, epg, nm, lbl;
  eol = $instr(1, req, $chr(13));
  if ((eol === 0)) {
    eol = $instr(1, req, $chr(10));
  }
  if ((eol === 0)) {
    eol = ($len(req) + 1);
  }
  line = $left(req, (eol - 1));
  sp1 = $instr(1, line, " ");
  if ((sp1 === 0)) {
    sendpage(sock, "400 Bad Request", "Bad request");
    return;
  }
  rest = $mid(line, (sp1 + 1));
  sp2 = $instr(1, rest, " ");
  target = rest;
  if ((sp2 > 0)) {
    target = $left(rest, (sp2 - 1));
  }
  path = target;
  query = "";
  q = $instr(1, target, "?");
  if ((q > 0)) {
    path = $left(target, (q - 1));
    query = $mid(target, (q + 1));
  }
  if ((path === "/")) {
    sendpage(sock, "200 OK", noticepage());
  } else if ((path === "/form")) {
    p = parsequery(query);
    if ((p.ok === "1")) {
      sendpage(sock, "200 OK", formpage(""));
    } else {
      sendpage(sock, "200 OK", noticepage());
    }
  } else if ((path === "/xt")) {
    p = parsext(query);
    if ((p.ok === "1")) {
      sendpage(sock, "200 OK", xtformpage(""));
    } else {
      sendpage(sock, "200 OK", noticepage());
    }
  } else if ((path === "/addxt")) {
    p = parsext(query);
    if ((p.ok !== "1")) {
      sendpage(sock, "200 OK", noticepage());
      return;
    }
    host = p.host.$trim();
    user = p.user.$trim();
    pass = p.pass.$trim();
    full = xtfromurl(host);
    if ((full != null)) {
      host = full.host;
      user = full.user;
      pass = full.pass;
    }
    err = "";
    if ((host === "")) {
      err = tx("Escribe el servidor.");
    } else if ((user === "")) {
      err = tx("Falta el usuario.");
    } else if ((pass === "")) {
      err = tx("Falta la contraseña.");
    }
    if ((err !== "")) {
      sendpage(sock, "200 OK", xtformpage(err));
    } else {
      it = {__proto__: $AAP, "name": p.name.$trim(), "url": "", "epg": "", "xt": {__proto__: $AAP, "host": host, "user": user, "pass": pass}};
      m.top.received = {__proto__: $AAP, "id": counter, "items": [it]};
      sendpage(sock, "200 OK", donepage([it]));
    }
  } else if ((path === "/add")) {
    p = parsemulti(query);
    if ((p.ok !== "1")) {
      sendpage(sock, "200 OK", noticepage());
      return;
    }
    items = [];
    err = "";
    total = p.url.$count();
    if ((total > 10)) {
      err = tx("Solo puedes enviar hasta 10 listas a la vez.");
    }
    for (i = 0, $e2 = (total - 1); i <= $e2; i++) {
      url = $ix(p.url, i).$trim();
      epg = $ix(p.epg, i).$trim();
      nm = "";
      if ((i < p.name.$count())) {
        nm = $ix(p.name, i).$trim();
      }
      if (((url !== "") || (epg !== ""))) {
        lbl = "";
        if ((total > 1)) {
          lbl = ((tx("Lista ") + ((i + 1)).$tostr()) + ": ");
        }
        if (((url !== "") && ($lcase($left(url, 4)) !== "http"))) {
          err = (lbl + tx("el link de la lista debe empezar con http:// o https://"));
        } else if (((epg !== "") && ($lcase($left(epg, 4)) !== "http"))) {
          err = (lbl + tx("el link de la guía debe empezar con http:// o https://"));
        }
        items.$push({__proto__: $AAP, "name": nm, "url": url, "epg": epg});
      }
    }
    if (((err === "") && (items.$count() === 0))) {
      err = tx("Escribe el link de la lista M3U o el de la guía.");
    }
    if ((err !== "")) {
      sendpage(sock, "200 OK", formpage(err));
    } else {
      m.top.received = {__proto__: $AAP, "id": counter, "items": items};
      sendpage(sock, "200 OK", donepage(items));
    }
  } else {
    sendpage(sock, "404 Not Found", "Not found");
  }
}

function parsequery(q) {
  let res, xfer, p, total, amp, pair, eq, key, val;
  res = {__proto__: $AAP, "name": "", "url": "", "epg": "", "ok": ""};
  if ((q === "")) {
    return res;
  }
  xfer = $createobject("roUrlTransfer");
  p = 1;
  total = $len(q);
  while ((p <= total)) {
    amp = $instr(p, q, "&");
    if ((amp === 0)) {
      amp = (total + 1);
    }
    pair = $mid(q, p, (amp - p));
    eq = $instr(1, pair, "=");
    if ((eq > 0)) {
      key = $left(pair, (eq - 1));
      val = $mid(pair, (eq + 1));
      val = val.$replace("+", " ");
      val = xfer.$unescape(val);
      if (res.$doesexist(key)) {
        $six(res, key, val);
      }
    }
    p = (amp + 1);
  }
  return res;
}

function parsext(q) {
  let res, xfer, p, total, amp, pair, eq, key, val;
  res = {__proto__: $AAP, "name": "", "host": "", "user": "", "pass": "", "ok": ""};
  if ((q === "")) {
    return res;
  }
  xfer = $createobject("roUrlTransfer");
  p = 1;
  total = $len(q);
  while ((p <= total)) {
    amp = $instr(p, q, "&");
    if ((amp === 0)) {
      amp = (total + 1);
    }
    pair = $mid(q, p, (amp - p));
    eq = $instr(1, pair, "=");
    if ((eq > 0)) {
      key = $left(pair, (eq - 1));
      val = $mid(pair, (eq + 1));
      val = val.$replace("+", " ");
      val = xfer.$unescape(val);
      if (res.$doesexist(key)) {
        $six(res, key, val);
      }
    }
    p = (amp + 1);
  }
  return res;
}

function parsemulti(q) {
  let res, xfer, p, total, amp, pair, eq, key, val;
  res = {__proto__: $AAP, "name": [], "url": [], "epg": [], "ok": ""};
  if ((q === "")) {
    return res;
  }
  xfer = $createobject("roUrlTransfer");
  p = 1;
  total = $len(q);
  while ((p <= total)) {
    amp = $instr(p, q, "&");
    if ((amp === 0)) {
      amp = (total + 1);
    }
    pair = $mid(q, p, (amp - p));
    eq = $instr(1, pair, "=");
    if ((eq > 0)) {
      key = $left(pair, (eq - 1));
      val = $mid(pair, (eq + 1));
      val = val.$replace("+", " ");
      val = xfer.$unescape(val);
      if ((key === "ok")) {
        res.ok = val;
      } else if ((((key === "name") || (key === "url")) || (key === "epg"))) {
        $ix(res, key).$push(val);
      }
    }
    p = (amp + 1);
  }
  while ((res.name.$count() < res.url.$count())) {
    res.name.$push("");
  }
  while ((res.epg.$count() < res.url.$count())) {
    res.epg.$push("");
  }
  return res;
}

function htmlesc(s) {
  let out, i, $e3, c, a;
  out = "";
  for (i = 1, $e3 = $len(s); i <= $e3; i++) {
    c = $mid(s, i, 1);
    a = $asc(c);
    if ((c === "&")) {
      out = (out + "&amp;");
    } else if ((c === "<")) {
      out = (out + "&lt;");
    } else if ((c === ">")) {
      out = (out + "&gt;");
    } else if ((c === $chr(34))) {
      out = (out + "&quot;");
    } else if (((a > 126) || (a < 32))) {
      out = (((out + "&#") + a.$tostr()) + ";");
    } else {
      out = (out + c);
    }
  }
  return out;
}

function sendpage(sock, status, body) {
  let text, tries, n;
  text = ((("HTTP/1.1 " + status) + $chr(13)) + $chr(10));
  text = (((text + "Content-Type: text/html; charset=utf-8") + $chr(13)) + $chr(10));
  text = (((text + "Cache-Control: no-store") + $chr(13)) + $chr(10));
  text = (((((text + "Connection: close") + $chr(13)) + $chr(10)) + $chr(13)) + $chr(10));
  text = (text + body);
  tries = 0;
  while (((text !== "") && (tries < 300))) {
    n = sock.$sendstr(text);
    if ((n > 0)) {
      text = $mid(text, (n + 1));
    } else {
      tries = (tries + 1);
      $sleep(20);
    }
  }
}

function hx(t) {
  let o, i, $e4, c, a;
  o = "";
  for (i = 1, $e4 = $len(t); i <= $e4; i++) {
    c = $mid(t, i, 1);
    a = $asc(c);
    if (((((((a > 126) || (c === "'")) || (c === $chr(34))) || (c === "<")) || (c === ">")) || (c === "&"))) {
      o = (((o + "&#") + a.$tostr()) + ";");
    } else {
      o = (o + c);
    }
  }
  return o;
}

function jq(t) {
  let o, i, $e5, c, a, h;
  o = "";
  for (i = 1, $e5 = $len(t); i <= $e5; i++) {
    c = $mid(t, i, 1);
    a = $asc(c);
    if ((((((((a > 126) || (c === "'")) || (c === "\\")) || (c === $chr(34))) || (c === "<")) || (c === ">")) || (a < 32))) {
      h = $stri(a, 16);
      while (($len(h) < 4)) {
        h = ("0" + h);
      }
      o = ((o + "\\u") + h);
    } else {
      o = (o + c);
    }
  }
  return o;
}

function noticepage() {
  let s;
  s = "";
  s = (s + "<!DOCTYPE html><html lang='");
  s = (s + i18nlang());
  s = (s + "'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'><meta name='theme-color' content='#07070a'><title>Smart IPTV MX<");
  s = (s + "/title><style>*{box-sizing:border-box}html{-webkit-text-size-adjust:100%;background:#07070a}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,'SF Pro Text','Segoe UI',Robo");
  s = (s + "to,sans-serif;background:#07070a;color:#fff;min-height:100vh;background-image:radial-gradient(120% 60% at 10% -10%,rgba(255,122,26,.28),transparent 60%),radial-gradient(80% 50% at ");
  s = (s + "100% 0%,rgba(255,61,42,.12),transparent 60%)}.wrap{max-width:520px;margin:0 auto;padding:22px 18px 40px}.brand{display:flex;align-items:center;gap:12px;margin-bottom:22px}.logo{wid");
  s = (s + "th:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#ff9a3c,#ff5a1f);display:flex;align-items:center;justify-content:center;box-shadow:0 8px 24px rgba(255,106,");
  s = (s + "0,.35)}.bname{font-weight:800;letter-spacing:.3px;font-size:17px}.bsub{color:#8a8f98;font-size:13px;margin-top:2px}.steps{display:flex;gap:6px;margin:0 0 20px}.st{flex:1;height:4px");
  s = (s + ";border-radius:4px;background:rgba(255,255,255,.12)}.st.on{background:#ff8a24}.kick{color:#ff8a24;font-weight:800;font-size:12px;letter-spacing:1.2px;text-transform:uppercase;margi");
  s = (s + "n:0 0 6px}h1{font-size:28px;line-height:1.15;margin:0 0 8px;font-weight:800}.lead{color:#a8adb5;margin:0 0 20px;font-size:15px;line-height:1.5}.tabs{display:flex;background:rgba(25");
  s = (s + "5,255,255,.06);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:4px;margin-bottom:18px}.tab{flex:1;text-align:center;padding:11px 8px;border-radius:10px;color:#c8c");
  s = (s + "cd2;text-decoration:none;font-weight:700;font-size:15px}.tab.on{background:#fff;color:#0a0a0f}.card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-r");
  s = (s + "adius:18px;padding:18px;margin-bottom:14px}.card p{color:#d0d4da;font-size:15px;line-height:1.55;margin:0 0 10px}.card p:last-child{margin:0}label.f{display:block;font-weight:700;f");
  s = (s + "ont-size:14px;margin:14px 0 7px;color:#e6e8eb}label.f:first-child{margin-top:0}.opt{color:#7e838c;font-weight:500}.inp{position:relative}input.t{width:100%;padding:15px 14px;border");
  s = (s + "-radius:13px;border:1.5px solid rgba(255,255,255,.12);background:rgba(0,0,0,.35);color:#fff;font-size:16px;outline:none;transition:border-color .2s,box-shadow .2s}input.t:focus{bor");
  s = (s + "der-color:#ff8a24;box-shadow:0 0 0 4px rgba(255,138,36,.18)}input.t.bad{border-color:#ff5a4f}input.t.good{border-color:#34c759}.help{color:#7e838c;font-size:13px;margin-top:6px;lin");
  s = (s + "e-height:1.4}.msg{font-size:13px;margin-top:6px;font-weight:600}.msg.e{color:#ff6b61}.msg.o{color:#34c759}.eye{position:absolute;right:8px;top:50%;transform:translateY(-50%);backgr");
  s = (s + "ound:rgba(255,255,255,.08);border:0;color:#c8ccd2;border-radius:9px;padding:8px 10px;font-size:13px;font-weight:700}.btn{display:flex;align-items:center;justify-content:center;gap:");
  s = (s + "10px;width:100%;margin-top:18px;padding:17px;border:0;border-radius:15px;background:linear-gradient(135deg,#ff9a3c,#ff6a00);color:#0a0a0f;font-size:17px;font-weight:800;box-shadow:");
  s = (s + "0 10px 28px rgba(255,106,0,.3);text-decoration:none}.btn:disabled{opacity:.4;box-shadow:none}.btn.sec{background:rgba(255,255,255,.07);color:#fff;border:1px solid rgba(255,255,255,");
  s = (s + ".12);box-shadow:none;font-weight:700;font-size:15px;padding:14px}.btn.rm{background:transparent;border:1px solid rgba(255,255,255,.12);color:#a8adb5;box-shadow:none;font-size:14px;");
  s = (s + "padding:11px;margin-top:12px}.spin{width:18px;height:18px;border:3px solid rgba(0,0,0,.25);border-top-color:#0a0a0f;border-radius:50%;animation:sp .8s linear infinite;display:none}");
  s = (s + ".busy .spin{display:inline-block}@keyframes sp{to{transform:rotate(360deg)}}.err{background:rgba(255,90,79,.12);border:1px solid rgba(255,90,79,.35);color:#ffd2ce;border-radius:14p");
  s = (s + "x;padding:13px 14px;margin-bottom:14px;font-size:14px;font-weight:600}.chk{display:flex;align-items:flex-start;gap:12px;color:#fff;font-weight:700;font-size:15px;line-height:1.4}.c");
  s = (s + "hk input{width:24px;height:24px;flex:none;margin:0;accent-color:#ff8a24}.bt{font-weight:800;font-size:15px;margin-bottom:4px;display:flex;align-items:center;gap:8px}.num{background");
  s = (s + ":#ff8a24;color:#0a0a0f;border-radius:8px;padding:2px 8px;font-size:13px}.hid{display:none!important}.small{color:#7e838c;font-size:13px;line-height:1.5}a.lnk{color:#ff8a24;font-wei");
  s = (s + "ght:700;text-decoration:none}.det{background:rgba(52,199,89,.12);border:1px solid rgba(52,199,89,.35);color:#b8f5c8;border-radius:12px;padding:10px 12px;font-size:13px;font-weight:");
  s = (s + "700;margin-top:10px}.done{text-align:center;padding-top:20px}.ring{width:120px;height:120px;margin:10px auto 18px}.ring circle{stroke:#34c759;stroke-width:6;fill:none;stroke-dashar");
  s = (s + "ray:340;stroke-dashoffset:340;animation:dr .7s ease-out forwards}.ring path{stroke:#34c759;stroke-width:7;fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:80;s");
  s = (s + "troke-dashoffset:80;animation:dr .4s .55s ease-out forwards}@keyframes dr{to{stroke-dashoffset:0}}.item{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);bord");
  s = (s + "er-radius:14px;padding:12px 14px;margin:8px 0;text-align:left;font-size:14px;color:#d0d4da;word-break:break-all}</style></head><body><div class='wrap'><div class='brand'><div class");
  s = (s + "='logo'><svg width='24' height='24' viewBox='0 0 24 24'><path d='M8 5v14l11-7z' fill='#0a0a0f'/></svg></div><div><div class='bname'>SMART IPTV MX</div><div class='bsub'>");
  s = (s + hx(tx("Conectado a tu TV")));
  s = (s + "</div></div></div><div class='steps'><div class='st on'></div><div class='st'></div><div class='st'></div></div><div class='kick'>");
  s = (s + hx(tx("Paso 1 de 3")));
  s = (s + "</div><h1>");
  s = (s + hx(tx("Antes de continuar")));
  s = (s + "</h1><p class='lead'>");
  s = (s + hx(tx("Aviso de responsabilidad")));
  s = (s + "</p><div class='card'><p><b>");
  s = (s + hx(tx("Smart IPTV MX es solo un reproductor.")));
  s = (s + "</b> ");
  s = (s + hx(tx("No incluye, no distribuye ni vende canales, películas ni listas de reproducción.")));
  s = (s + "</p><p>");
  s = (s + hx(tx("Para usarla tienes que cargar tus propias listas. Tú eres la única persona responsable de que ese contenido sea legal y de contar con la suscripción o el permiso para verlo.")));
  s = (s + "</p><p>");
  s = (s + hx(tx("Los creadores de la app no controlan ni respaldan lo que contengan tus listas, y no responden por el uso que se les dé.")));
  s = (s + "</p><p>");
  s = (s + hx(tx("Las listas que envíes se guardan en tu televisor.")));
  s = (s + "</p></div><form action='/form' method='get'><input type='hidden' name='ok' value='1'><div class='card'><label class='chk'><input type='checkbox' id='agree' required> <span>");
  s = (s + hx(tx("He leído este aviso y estoy de acuerdo")));
  s = (s + "</span></label></div><button class='btn' id='go' type='submit' disabled>");
  s = (s + hx(tx("Estoy de acuerdo, continuar")));
  s = (s + "</button></form><script>var a=document.getElementById('agree'),g=document.getElementById('go');a.onchange=function(){g.disabled=!a.checked;};</script></div></body></html>");
  return s;
}

function formpage(err) {
  let s;
  s = "";
  s = (s + "<!DOCTYPE html><html lang='");
  s = (s + i18nlang());
  s = (s + "'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'><meta name='theme-color' content='#07070a'><title>Smart IPTV MX<");
  s = (s + "/title><style>*{box-sizing:border-box}html{-webkit-text-size-adjust:100%;background:#07070a}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,'SF Pro Text','Segoe UI',Robo");
  s = (s + "to,sans-serif;background:#07070a;color:#fff;min-height:100vh;background-image:radial-gradient(120% 60% at 10% -10%,rgba(255,122,26,.28),transparent 60%),radial-gradient(80% 50% at ");
  s = (s + "100% 0%,rgba(255,61,42,.12),transparent 60%)}.wrap{max-width:520px;margin:0 auto;padding:22px 18px 40px}.brand{display:flex;align-items:center;gap:12px;margin-bottom:22px}.logo{wid");
  s = (s + "th:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#ff9a3c,#ff5a1f);display:flex;align-items:center;justify-content:center;box-shadow:0 8px 24px rgba(255,106,");
  s = (s + "0,.35)}.bname{font-weight:800;letter-spacing:.3px;font-size:17px}.bsub{color:#8a8f98;font-size:13px;margin-top:2px}.steps{display:flex;gap:6px;margin:0 0 20px}.st{flex:1;height:4px");
  s = (s + ";border-radius:4px;background:rgba(255,255,255,.12)}.st.on{background:#ff8a24}.kick{color:#ff8a24;font-weight:800;font-size:12px;letter-spacing:1.2px;text-transform:uppercase;margi");
  s = (s + "n:0 0 6px}h1{font-size:28px;line-height:1.15;margin:0 0 8px;font-weight:800}.lead{color:#a8adb5;margin:0 0 20px;font-size:15px;line-height:1.5}.tabs{display:flex;background:rgba(25");
  s = (s + "5,255,255,.06);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:4px;margin-bottom:18px}.tab{flex:1;text-align:center;padding:11px 8px;border-radius:10px;color:#c8c");
  s = (s + "cd2;text-decoration:none;font-weight:700;font-size:15px}.tab.on{background:#fff;color:#0a0a0f}.card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-r");
  s = (s + "adius:18px;padding:18px;margin-bottom:14px}.card p{color:#d0d4da;font-size:15px;line-height:1.55;margin:0 0 10px}.card p:last-child{margin:0}label.f{display:block;font-weight:700;f");
  s = (s + "ont-size:14px;margin:14px 0 7px;color:#e6e8eb}label.f:first-child{margin-top:0}.opt{color:#7e838c;font-weight:500}.inp{position:relative}input.t{width:100%;padding:15px 14px;border");
  s = (s + "-radius:13px;border:1.5px solid rgba(255,255,255,.12);background:rgba(0,0,0,.35);color:#fff;font-size:16px;outline:none;transition:border-color .2s,box-shadow .2s}input.t:focus{bor");
  s = (s + "der-color:#ff8a24;box-shadow:0 0 0 4px rgba(255,138,36,.18)}input.t.bad{border-color:#ff5a4f}input.t.good{border-color:#34c759}.help{color:#7e838c;font-size:13px;margin-top:6px;lin");
  s = (s + "e-height:1.4}.msg{font-size:13px;margin-top:6px;font-weight:600}.msg.e{color:#ff6b61}.msg.o{color:#34c759}.eye{position:absolute;right:8px;top:50%;transform:translateY(-50%);backgr");
  s = (s + "ound:rgba(255,255,255,.08);border:0;color:#c8ccd2;border-radius:9px;padding:8px 10px;font-size:13px;font-weight:700}.btn{display:flex;align-items:center;justify-content:center;gap:");
  s = (s + "10px;width:100%;margin-top:18px;padding:17px;border:0;border-radius:15px;background:linear-gradient(135deg,#ff9a3c,#ff6a00);color:#0a0a0f;font-size:17px;font-weight:800;box-shadow:");
  s = (s + "0 10px 28px rgba(255,106,0,.3);text-decoration:none}.btn:disabled{opacity:.4;box-shadow:none}.btn.sec{background:rgba(255,255,255,.07);color:#fff;border:1px solid rgba(255,255,255,");
  s = (s + ".12);box-shadow:none;font-weight:700;font-size:15px;padding:14px}.btn.rm{background:transparent;border:1px solid rgba(255,255,255,.12);color:#a8adb5;box-shadow:none;font-size:14px;");
  s = (s + "padding:11px;margin-top:12px}.spin{width:18px;height:18px;border:3px solid rgba(0,0,0,.25);border-top-color:#0a0a0f;border-radius:50%;animation:sp .8s linear infinite;display:none}");
  s = (s + ".busy .spin{display:inline-block}@keyframes sp{to{transform:rotate(360deg)}}.err{background:rgba(255,90,79,.12);border:1px solid rgba(255,90,79,.35);color:#ffd2ce;border-radius:14p");
  s = (s + "x;padding:13px 14px;margin-bottom:14px;font-size:14px;font-weight:600}.chk{display:flex;align-items:flex-start;gap:12px;color:#fff;font-weight:700;font-size:15px;line-height:1.4}.c");
  s = (s + "hk input{width:24px;height:24px;flex:none;margin:0;accent-color:#ff8a24}.bt{font-weight:800;font-size:15px;margin-bottom:4px;display:flex;align-items:center;gap:8px}.num{background");
  s = (s + ":#ff8a24;color:#0a0a0f;border-radius:8px;padding:2px 8px;font-size:13px}.hid{display:none!important}.small{color:#7e838c;font-size:13px;line-height:1.5}a.lnk{color:#ff8a24;font-wei");
  s = (s + "ght:700;text-decoration:none}.det{background:rgba(52,199,89,.12);border:1px solid rgba(52,199,89,.35);color:#b8f5c8;border-radius:12px;padding:10px 12px;font-size:13px;font-weight:");
  s = (s + "700;margin-top:10px}.done{text-align:center;padding-top:20px}.ring{width:120px;height:120px;margin:10px auto 18px}.ring circle{stroke:#34c759;stroke-width:6;fill:none;stroke-dashar");
  s = (s + "ray:340;stroke-dashoffset:340;animation:dr .7s ease-out forwards}.ring path{stroke:#34c759;stroke-width:7;fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:80;s");
  s = (s + "troke-dashoffset:80;animation:dr .4s .55s ease-out forwards}@keyframes dr{to{stroke-dashoffset:0}}.item{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);bord");
  s = (s + "er-radius:14px;padding:12px 14px;margin:8px 0;text-align:left;font-size:14px;color:#d0d4da;word-break:break-all}</style></head><body><div class='wrap'><div class='brand'><div class");
  s = (s + "='logo'><svg width='24' height='24' viewBox='0 0 24 24'><path d='M8 5v14l11-7z' fill='#0a0a0f'/></svg></div><div><div class='bname'>SMART IPTV MX</div><div class='bsub'>");
  s = (s + hx(tx("Conectado a tu TV")));
  s = (s + "</div></div></div><div class='steps'><div class='st on'></div><div class='st on'></div><div class='st'></div></div><div class='kick'>");
  s = (s + hx(tx("Paso 2 de 3")));
  s = (s + "</div><h1>");
  s = (s + hx(tx("Envía tu lista a la TV")));
  s = (s + "</h1><p class='lead'>");
  s = (s + hx(tx("Pega el link de tu lista M3U. La guía es opcional.")));
  s = (s + "</p><div class='tabs'><a class='tab on' href='/form?ok=1'>");
  s = (s + hx(tx("Lista M3U")));
  s = (s + "</a><a class='tab ' href='/xt?ok=1'>");
  s = (s + hx(tx("Cuenta Xtream")));
  s = (s + "</a></div>");
  s = (s + errbox(err));
  s = (s + "<form action='/add' method='get' id='frm'><input type='hidden' name='ok' value='1'><div class='card'><label class='chk'><input type='checkbox' id='multi'> <span>");
  s = (s + hx(tx("Agregar varias listas (hasta 10)")));
  s = (s + "</span></label></div><div id='blocks'></div><button type='button' class='btn sec hid' id='more'>");
  s = (s + hx(tx("+ Agregar otra lista")));
  s = (s + "</button><p class='small hid' id='cnt' style='margin:8px 0 0'></p><button type='submit' class='btn' id='send' disabled><span class='spin'></span><span id='sendt'>");
  s = (s + hx(tx("Enviar a la TV")));
  s = (s + "</span></button></form><p class='small' style='margin-top:16px'>");
  s = (s + hx(tx("Si dejas la lista vacía y pones solo la guía, se agrega a la primera lista activa.")));
  s = (s + "</p><template id='tpl'><div class='card blk'><div class='bt'><span class='num'>1</span><span>");
  s = (s + hx(tx("Lista ")));
  s = (s + "</span></div><label class='f'>");
  s = (s + hx(tx("Nombre")));
  s = (s + " <span class='opt'>(");
  s = (s + hx(tx("opcional")));
  s = (s + ")</span></label><input class='t' name='name' autocomplete='off' placeholder='");
  s = (s + hx(tx("Mi lista")));
  s = (s + "'><label class='f'>");
  s = (s + hx(tx("Link de la lista M3U")));
  s = (s + "</label><input class='t u' name='url' type='url' inputmode='url' autocapitalize='off' autocorrect='off' spellcheck='false' placeholder='http://...'><div class='msg'></div><label cl");
  s = (s + "ass='f'>");
  s = (s + hx(tx("Link de la guía XMLTV")));
  s = (s + " <span class='opt'>(");
  s = (s + hx(tx("opcional")));
  s = (s + ")</span></label><input class='t g' name='epg' type='url' inputmode='url' autocapitalize='off' autocorrect='off' spellcheck='false' placeholder='http://...  (.xml / .xml.gz)'><div c");
  s = (s + "lass='msg'></div><button type='button' class='btn rm hid'>");
  s = (s + hx(tx("Quitar esta lista")));
  s = (s + "</button></div></template><script>var TOF='");
  s = (s + jq(tx("de")));
  s = (s + "',TLI='");
  s = (s + jq(tx("listas")));
  s = (s + "',TS1='");
  s = (s + jq(tx("Enviar a la TV")));
  s = (s + "',TSN='");
  s = (s + jq(tx("Enviar {n} listas a la TV")));
  s = (s + "',TBAD='");
  s = (s + jq(tx("Debe empezar con http:// o https://")));
  s = (s + "',TOK='");
  s = (s + jq(tx("Link válido")));
  s = (s + "',TSEND='");
  s = (s + jq(tx("Enviando a tu TV...")));
  s = (s + "';var MAX=10,box=document.getElementById('blocks'),tpl=document.getElementById('tpl'),chk=document.getElementById('multi'),more=document.getElementById('more'),cnt=document.getElem");
  s = (s + "entById('cnt'),send=document.getElementById('send'),sendt=document.getElementById('sendt');function okUrl(v){return /^https?:\\/\\/\\S+\\.\\S+/i.test(v);}function check(){var any=false,");
  s = (s + "bad=false;var bl=box.children;for(var i=0;i<bl.length;i++){var u=bl[i].querySelector('.u'),g=bl[i].querySelector('.g');[u,g].forEach(function(el){var m=el.nextElementSibling,v=el.v");
  s = (s + "alue.trim();el.classList.remove('bad','good');m.className='msg';m.textContent='';if(v){if(okUrl(v)){el.classList.add('good');if(el===u){m.className='msg o';m.textContent=TOK;}}else");
  s = (s + "{el.classList.add('bad');m.className='msg e';m.textContent=TBAD;bad=true;}any=true;}});}send.disabled=!any||bad;}function renum(){var b=box.children;for(var i=0;i<b.length;i++){b[i");
  s = (s + "].querySelector('.num').textContent=i+1;b[i].querySelector('.bt').style.display=chk.checked?'flex':'none';b[i].querySelector('.rm').classList.toggle('hid',!(chk.checked&&b.length>1");
  s = (s + "));}more.classList.toggle('hid',!(chk.checked&&b.length<MAX));cnt.classList.toggle('hid',!chk.checked);cnt.textContent=b.length+' '+TOF+' '+MAX+' '+TLI;sendt.textContent=chk.checke");
  s = (s + "d&&b.length>1?TSN.replace('{n}',b.length):TS1;check();}function add(){if(box.children.length>=MAX)return;var n=tpl.content.cloneNode(true);var el=n.firstElementChild;el.querySelect");
  s = (s + "or('.rm').onclick=function(){box.removeChild(el);renum();};el.querySelectorAll('input').forEach(function(i){i.addEventListener('input',check);});box.appendChild(n);renum();return e");
  s = (s + "l;}chk.onchange=function(){if(!chk.checked){while(box.children.length>1)box.removeChild(box.lastChild);}renum();};more.onclick=function(){var el=add();if(el){el.scrollIntoView({beh");
  s = (s + "avior:'smooth',block:'center'});}};document.getElementById('frm').onsubmit=function(){send.classList.add('busy');sendt.textContent=TSEND;setTimeout(function(){send.disabled=true;},");
  s = (s + "10);};add();</script></div></body></html>");
  return s;
}

function xtformpage(err) {
  let s;
  s = "";
  s = (s + "<!DOCTYPE html><html lang='");
  s = (s + i18nlang());
  s = (s + "'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'><meta name='theme-color' content='#07070a'><title>Smart IPTV MX<");
  s = (s + "/title><style>*{box-sizing:border-box}html{-webkit-text-size-adjust:100%;background:#07070a}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,'SF Pro Text','Segoe UI',Robo");
  s = (s + "to,sans-serif;background:#07070a;color:#fff;min-height:100vh;background-image:radial-gradient(120% 60% at 10% -10%,rgba(255,122,26,.28),transparent 60%),radial-gradient(80% 50% at ");
  s = (s + "100% 0%,rgba(255,61,42,.12),transparent 60%)}.wrap{max-width:520px;margin:0 auto;padding:22px 18px 40px}.brand{display:flex;align-items:center;gap:12px;margin-bottom:22px}.logo{wid");
  s = (s + "th:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#ff9a3c,#ff5a1f);display:flex;align-items:center;justify-content:center;box-shadow:0 8px 24px rgba(255,106,");
  s = (s + "0,.35)}.bname{font-weight:800;letter-spacing:.3px;font-size:17px}.bsub{color:#8a8f98;font-size:13px;margin-top:2px}.steps{display:flex;gap:6px;margin:0 0 20px}.st{flex:1;height:4px");
  s = (s + ";border-radius:4px;background:rgba(255,255,255,.12)}.st.on{background:#ff8a24}.kick{color:#ff8a24;font-weight:800;font-size:12px;letter-spacing:1.2px;text-transform:uppercase;margi");
  s = (s + "n:0 0 6px}h1{font-size:28px;line-height:1.15;margin:0 0 8px;font-weight:800}.lead{color:#a8adb5;margin:0 0 20px;font-size:15px;line-height:1.5}.tabs{display:flex;background:rgba(25");
  s = (s + "5,255,255,.06);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:4px;margin-bottom:18px}.tab{flex:1;text-align:center;padding:11px 8px;border-radius:10px;color:#c8c");
  s = (s + "cd2;text-decoration:none;font-weight:700;font-size:15px}.tab.on{background:#fff;color:#0a0a0f}.card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-r");
  s = (s + "adius:18px;padding:18px;margin-bottom:14px}.card p{color:#d0d4da;font-size:15px;line-height:1.55;margin:0 0 10px}.card p:last-child{margin:0}label.f{display:block;font-weight:700;f");
  s = (s + "ont-size:14px;margin:14px 0 7px;color:#e6e8eb}label.f:first-child{margin-top:0}.opt{color:#7e838c;font-weight:500}.inp{position:relative}input.t{width:100%;padding:15px 14px;border");
  s = (s + "-radius:13px;border:1.5px solid rgba(255,255,255,.12);background:rgba(0,0,0,.35);color:#fff;font-size:16px;outline:none;transition:border-color .2s,box-shadow .2s}input.t:focus{bor");
  s = (s + "der-color:#ff8a24;box-shadow:0 0 0 4px rgba(255,138,36,.18)}input.t.bad{border-color:#ff5a4f}input.t.good{border-color:#34c759}.help{color:#7e838c;font-size:13px;margin-top:6px;lin");
  s = (s + "e-height:1.4}.msg{font-size:13px;margin-top:6px;font-weight:600}.msg.e{color:#ff6b61}.msg.o{color:#34c759}.eye{position:absolute;right:8px;top:50%;transform:translateY(-50%);backgr");
  s = (s + "ound:rgba(255,255,255,.08);border:0;color:#c8ccd2;border-radius:9px;padding:8px 10px;font-size:13px;font-weight:700}.btn{display:flex;align-items:center;justify-content:center;gap:");
  s = (s + "10px;width:100%;margin-top:18px;padding:17px;border:0;border-radius:15px;background:linear-gradient(135deg,#ff9a3c,#ff6a00);color:#0a0a0f;font-size:17px;font-weight:800;box-shadow:");
  s = (s + "0 10px 28px rgba(255,106,0,.3);text-decoration:none}.btn:disabled{opacity:.4;box-shadow:none}.btn.sec{background:rgba(255,255,255,.07);color:#fff;border:1px solid rgba(255,255,255,");
  s = (s + ".12);box-shadow:none;font-weight:700;font-size:15px;padding:14px}.btn.rm{background:transparent;border:1px solid rgba(255,255,255,.12);color:#a8adb5;box-shadow:none;font-size:14px;");
  s = (s + "padding:11px;margin-top:12px}.spin{width:18px;height:18px;border:3px solid rgba(0,0,0,.25);border-top-color:#0a0a0f;border-radius:50%;animation:sp .8s linear infinite;display:none}");
  s = (s + ".busy .spin{display:inline-block}@keyframes sp{to{transform:rotate(360deg)}}.err{background:rgba(255,90,79,.12);border:1px solid rgba(255,90,79,.35);color:#ffd2ce;border-radius:14p");
  s = (s + "x;padding:13px 14px;margin-bottom:14px;font-size:14px;font-weight:600}.chk{display:flex;align-items:flex-start;gap:12px;color:#fff;font-weight:700;font-size:15px;line-height:1.4}.c");
  s = (s + "hk input{width:24px;height:24px;flex:none;margin:0;accent-color:#ff8a24}.bt{font-weight:800;font-size:15px;margin-bottom:4px;display:flex;align-items:center;gap:8px}.num{background");
  s = (s + ":#ff8a24;color:#0a0a0f;border-radius:8px;padding:2px 8px;font-size:13px}.hid{display:none!important}.small{color:#7e838c;font-size:13px;line-height:1.5}a.lnk{color:#ff8a24;font-wei");
  s = (s + "ght:700;text-decoration:none}.det{background:rgba(52,199,89,.12);border:1px solid rgba(52,199,89,.35);color:#b8f5c8;border-radius:12px;padding:10px 12px;font-size:13px;font-weight:");
  s = (s + "700;margin-top:10px}.done{text-align:center;padding-top:20px}.ring{width:120px;height:120px;margin:10px auto 18px}.ring circle{stroke:#34c759;stroke-width:6;fill:none;stroke-dashar");
  s = (s + "ray:340;stroke-dashoffset:340;animation:dr .7s ease-out forwards}.ring path{stroke:#34c759;stroke-width:7;fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:80;s");
  s = (s + "troke-dashoffset:80;animation:dr .4s .55s ease-out forwards}@keyframes dr{to{stroke-dashoffset:0}}.item{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);bord");
  s = (s + "er-radius:14px;padding:12px 14px;margin:8px 0;text-align:left;font-size:14px;color:#d0d4da;word-break:break-all}</style></head><body><div class='wrap'><div class='brand'><div class");
  s = (s + "='logo'><svg width='24' height='24' viewBox='0 0 24 24'><path d='M8 5v14l11-7z' fill='#0a0a0f'/></svg></div><div><div class='bname'>SMART IPTV MX</div><div class='bsub'>");
  s = (s + hx(tx("Conectado a tu TV")));
  s = (s + "</div></div></div><div class='steps'><div class='st on'></div><div class='st on'></div><div class='st'></div></div><div class='kick'>");
  s = (s + hx(tx("Paso 2 de 3")));
  s = (s + "</div><h1>");
  s = (s + hx(tx("Agrega tu cuenta Xtream")));
  s = (s + "</h1><p class='lead'>");
  s = (s + hx(tx("Escribe los 3 datos que te dio tu proveedor, o pega tu link completo y se llenan solos.")));
  s = (s + "</p><div class='tabs'><a class='tab ' href='/form?ok=1'>");
  s = (s + hx(tx("Lista M3U")));
  s = (s + "</a><a class='tab on' href='/xt?ok=1'>");
  s = (s + hx(tx("Cuenta Xtream")));
  s = (s + "</a></div>");
  s = (s + errbox(err));
  s = (s + "<form action='/addxt' method='get' id='frm'><input type='hidden' name='ok' value='1'><div class='card'><label class='f'>");
  s = (s + hx(tx("¿Tienes un link completo?")));
  s = (s + " <span class='opt'>(");
  s = (s + hx(tx("opcional")));
  s = (s + ")</span></label><input class='t' id='full' type='url' inputmode='url' autocapitalize='off' autocorrect='off' spellcheck='false' placeholder='http://servidor.com:8080/get.php?userna");
  s = (s + "me=...'><div class='help'>");
  s = (s + hx(tx("Pega un link que tenga username y password: separamos los datos por ti.")));
  s = (s + "</div><div id='det' class='det hid'></div></div><div class='card'><label class='f'>");
  s = (s + hx(tx("Servidor")));
  s = (s + "</label><input class='t' name='host' id='host' type='url' inputmode='url' autocapitalize='off' autocorrect='off' spellcheck='false' placeholder='http://servidor.com:8080'><div clas");
  s = (s + "s='msg' id='hm'></div><label class='f'>");
  s = (s + hx(tx("Usuario")));
  s = (s + "</label><input class='t' name='user' id='user' type='text' autocapitalize='off' autocorrect='off' spellcheck='false' autocomplete='off'><label class='f'>");
  s = (s + hx(tx("Contraseña")));
  s = (s + "</label><div class='inp'><input class='t' name='pass' id='pass' type='password' autocapitalize='off' autocorrect='off' spellcheck='false' autocomplete='off' style='padding-right:84");
  s = (s + "px'><button type='button' class='eye' id='eye'>");
  s = (s + hx(tx("Ver")));
  s = (s + "</button></div><label class='f'>");
  s = (s + hx(tx("Nombre")));
  s = (s + " <span class='opt'>(");
  s = (s + hx(tx("opcional")));
  s = (s + ")</span></label><input class='t' name='name' autocomplete='off' placeholder='Xtream'></div><button type='submit' class='btn' id='send' disabled><span class='spin'></span><span id='");
  s = (s + "sendt'>");
  s = (s + hx(tx("Enviar a la TV")));
  s = (s + "</span></button></form><script>var TDET='");
  s = (s + jq(tx("Datos detectados: servidor, usuario y contraseña")));
  s = (s + "',TBAD='");
  s = (s + jq(tx("Debe empezar con http:// o https://")));
  s = (s + "',TSEND='");
  s = (s + jq(tx("Enviando a tu TV...")));
  s = (s + "',TV='");
  s = (s + jq(tx("Ver")));
  s = (s + "',TH='");
  s = (s + jq(tx("Ocultar")));
  s = (s + "';var f=document.getElementById('full'),h=document.getElementById('host'),u=document.getElementById('user'),p=document.getElementById('pass'),s=document.getElementById('send'),d=do");
  s = (s + "cument.getElementById('det'),hm=document.getElementById('hm'),e=document.getElementById('eye');function v(){var hv=h.value.trim();h.classList.remove('bad','good');hm.textContent=''");
  s = (s + ";hm.className='msg';if(hv){if(/^https?:\\/\\/[^\\s\\/]+/i.test(hv)){h.classList.add('good');}else{h.classList.add('bad');hm.className='msg e';hm.textContent=TBAD;}}s.disabled=!(/^https");
  s = (s + "?:\\/\\/[^\\s\\/]+/i.test(hv)&&u.value.trim()&&p.value.trim());}f.addEventListener('input',function(){var t=f.value.trim();d.classList.add('hid');try{var x=new URL(t);var us=x.searchPa");
  s = (s + "rams.get('username'),pw=x.searchParams.get('password');if(!us){var m=x.pathname.match(/^\\/(?:live|movie|series)\\/([^\\/]+)\\/([^\\/]+)\\//);if(m){us=decodeURIComponent(m[1]);pw=decodeU");
  s = (s + "RIComponent(m[2]);}}if(us&&pw){h.value=x.protocol+'//'+x.host;u.value=us;p.value=pw;d.textContent='\\u2713 '+TDET;d.classList.remove('hid');v();}}catch(err){}});h.addEventListener('");
  s = (s + "blur',function(){var hv=h.value.trim();if(hv&&!/^https?:\\/\\//i.test(hv)){h.value='http://'+hv;}v();});[h,u,p].forEach(function(i){i.addEventListener('input',v);});e.onclick=functio");
  s = (s + "n(){var sh=p.type==='password';p.type=sh?'text':'password';e.textContent=sh?TH:TV;};document.getElementById('frm').onsubmit=function(){s.classList.add('busy');document.getElementBy");
  s = (s + "Id('sendt').textContent=TSEND;};v();</script></div></body></html>");
  return s;
}

function donepage(items) {
  let s;
  s = "";
  s = (s + "<!DOCTYPE html><html lang='");
  s = (s + i18nlang());
  s = (s + "'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'><meta name='theme-color' content='#07070a'><title>Smart IPTV MX<");
  s = (s + "/title><style>*{box-sizing:border-box}html{-webkit-text-size-adjust:100%;background:#07070a}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,'SF Pro Text','Segoe UI',Robo");
  s = (s + "to,sans-serif;background:#07070a;color:#fff;min-height:100vh;background-image:radial-gradient(120% 60% at 10% -10%,rgba(255,122,26,.28),transparent 60%),radial-gradient(80% 50% at ");
  s = (s + "100% 0%,rgba(255,61,42,.12),transparent 60%)}.wrap{max-width:520px;margin:0 auto;padding:22px 18px 40px}.brand{display:flex;align-items:center;gap:12px;margin-bottom:22px}.logo{wid");
  s = (s + "th:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#ff9a3c,#ff5a1f);display:flex;align-items:center;justify-content:center;box-shadow:0 8px 24px rgba(255,106,");
  s = (s + "0,.35)}.bname{font-weight:800;letter-spacing:.3px;font-size:17px}.bsub{color:#8a8f98;font-size:13px;margin-top:2px}.steps{display:flex;gap:6px;margin:0 0 20px}.st{flex:1;height:4px");
  s = (s + ";border-radius:4px;background:rgba(255,255,255,.12)}.st.on{background:#ff8a24}.kick{color:#ff8a24;font-weight:800;font-size:12px;letter-spacing:1.2px;text-transform:uppercase;margi");
  s = (s + "n:0 0 6px}h1{font-size:28px;line-height:1.15;margin:0 0 8px;font-weight:800}.lead{color:#a8adb5;margin:0 0 20px;font-size:15px;line-height:1.5}.tabs{display:flex;background:rgba(25");
  s = (s + "5,255,255,.06);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:4px;margin-bottom:18px}.tab{flex:1;text-align:center;padding:11px 8px;border-radius:10px;color:#c8c");
  s = (s + "cd2;text-decoration:none;font-weight:700;font-size:15px}.tab.on{background:#fff;color:#0a0a0f}.card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-r");
  s = (s + "adius:18px;padding:18px;margin-bottom:14px}.card p{color:#d0d4da;font-size:15px;line-height:1.55;margin:0 0 10px}.card p:last-child{margin:0}label.f{display:block;font-weight:700;f");
  s = (s + "ont-size:14px;margin:14px 0 7px;color:#e6e8eb}label.f:first-child{margin-top:0}.opt{color:#7e838c;font-weight:500}.inp{position:relative}input.t{width:100%;padding:15px 14px;border");
  s = (s + "-radius:13px;border:1.5px solid rgba(255,255,255,.12);background:rgba(0,0,0,.35);color:#fff;font-size:16px;outline:none;transition:border-color .2s,box-shadow .2s}input.t:focus{bor");
  s = (s + "der-color:#ff8a24;box-shadow:0 0 0 4px rgba(255,138,36,.18)}input.t.bad{border-color:#ff5a4f}input.t.good{border-color:#34c759}.help{color:#7e838c;font-size:13px;margin-top:6px;lin");
  s = (s + "e-height:1.4}.msg{font-size:13px;margin-top:6px;font-weight:600}.msg.e{color:#ff6b61}.msg.o{color:#34c759}.eye{position:absolute;right:8px;top:50%;transform:translateY(-50%);backgr");
  s = (s + "ound:rgba(255,255,255,.08);border:0;color:#c8ccd2;border-radius:9px;padding:8px 10px;font-size:13px;font-weight:700}.btn{display:flex;align-items:center;justify-content:center;gap:");
  s = (s + "10px;width:100%;margin-top:18px;padding:17px;border:0;border-radius:15px;background:linear-gradient(135deg,#ff9a3c,#ff6a00);color:#0a0a0f;font-size:17px;font-weight:800;box-shadow:");
  s = (s + "0 10px 28px rgba(255,106,0,.3);text-decoration:none}.btn:disabled{opacity:.4;box-shadow:none}.btn.sec{background:rgba(255,255,255,.07);color:#fff;border:1px solid rgba(255,255,255,");
  s = (s + ".12);box-shadow:none;font-weight:700;font-size:15px;padding:14px}.btn.rm{background:transparent;border:1px solid rgba(255,255,255,.12);color:#a8adb5;box-shadow:none;font-size:14px;");
  s = (s + "padding:11px;margin-top:12px}.spin{width:18px;height:18px;border:3px solid rgba(0,0,0,.25);border-top-color:#0a0a0f;border-radius:50%;animation:sp .8s linear infinite;display:none}");
  s = (s + ".busy .spin{display:inline-block}@keyframes sp{to{transform:rotate(360deg)}}.err{background:rgba(255,90,79,.12);border:1px solid rgba(255,90,79,.35);color:#ffd2ce;border-radius:14p");
  s = (s + "x;padding:13px 14px;margin-bottom:14px;font-size:14px;font-weight:600}.chk{display:flex;align-items:flex-start;gap:12px;color:#fff;font-weight:700;font-size:15px;line-height:1.4}.c");
  s = (s + "hk input{width:24px;height:24px;flex:none;margin:0;accent-color:#ff8a24}.bt{font-weight:800;font-size:15px;margin-bottom:4px;display:flex;align-items:center;gap:8px}.num{background");
  s = (s + ":#ff8a24;color:#0a0a0f;border-radius:8px;padding:2px 8px;font-size:13px}.hid{display:none!important}.small{color:#7e838c;font-size:13px;line-height:1.5}a.lnk{color:#ff8a24;font-wei");
  s = (s + "ght:700;text-decoration:none}.det{background:rgba(52,199,89,.12);border:1px solid rgba(52,199,89,.35);color:#b8f5c8;border-radius:12px;padding:10px 12px;font-size:13px;font-weight:");
  s = (s + "700;margin-top:10px}.done{text-align:center;padding-top:20px}.ring{width:120px;height:120px;margin:10px auto 18px}.ring circle{stroke:#34c759;stroke-width:6;fill:none;stroke-dashar");
  s = (s + "ray:340;stroke-dashoffset:340;animation:dr .7s ease-out forwards}.ring path{stroke:#34c759;stroke-width:7;fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:80;s");
  s = (s + "troke-dashoffset:80;animation:dr .4s .55s ease-out forwards}@keyframes dr{to{stroke-dashoffset:0}}.item{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);bord");
  s = (s + "er-radius:14px;padding:12px 14px;margin:8px 0;text-align:left;font-size:14px;color:#d0d4da;word-break:break-all}</style></head><body><div class='wrap'><div class='brand'><div class");
  s = (s + "='logo'><svg width='24' height='24' viewBox='0 0 24 24'><path d='M8 5v14l11-7z' fill='#0a0a0f'/></svg></div><div><div class='bname'>SMART IPTV MX</div><div class='bsub'>");
  s = (s + hx(tx("Conectado a tu TV")));
  s = (s + "</div></div></div><div class='steps'><div class='st on'></div><div class='st on'></div><div class='st on'></div></div><div class='done'><svg class='ring' viewBox='0 0 120 120'><cir");
  s = (s + "cle cx='60' cy='60' r='54'/><path d='M36 62 l16 16 l32 -34'/></svg><h1>");
  s = (s + donetitle(items));
  s = (s + "</h1><p class='lead'>");
  s = (s + hx(tx("Mira tu televisión: ya se está cargando.")));
  s = (s + "</p>");
  s = (s + doneitems(items));
  s = (s + "<a class='btn' href='/form?ok=1' style='margin-top:22px'>");
  s = (s + hx(tx("Enviar otra lista")));
  s = (s + "</a><a class='btn sec' href='/xt?ok=1'>");
  s = (s + hx(tx("Agregar cuenta Xtream")));
  s = (s + "</a></div></div></body></html>");
  return s;
}

function errbox(err) {
  if ((err === "")) {
    return "";
  }
  return (("<div class='err'>" + hx(err)) + "</div>");
}

function donetitle(items) {
  if ((items.$count() === 1)) {
    return hx(tx("¡Listo! Ya está en tu TV"));
  }
  return hx(tx("¡{n} listas recibidas en tu TV!").$replace("{n}", items.$count().$tostr()));
}

function doneitems(items) {
  let s, it, shown;
  s = "";
  for (it of $iter(items)) {
    shown = it.name;
    if ((shown === "")) {
      shown = it.url;
    }
    if ((shown === "")) {
      shown = it.epg;
    }
    if (((shown === "") && it.$doesexist("xt"))) {
      shown = it.xt.host;
    }
    s = (((s + "<div class='item'>") + htmlesc(shown)) + "</div>");
  }
  return s;
}
// ---- components/i18n.brs ----
function i18nlangs() {
  return [{__proto__: $AAP, "code": "es", "name": "Español", "flag": "pkg:/images/flag_es.png"}, {__proto__: $AAP, "code": "en", "name": "English", "flag": "pkg:/images/flag_en.png"}, {__proto__: $AAP, "code": "pt", "name": "Português", "flag": "pkg:/images/flag_pt.png"}, {__proto__: $AAP, "code": "fr", "name": "Français", "flag": "pkg:/images/flag_fr.png"}, {__proto__: $AAP, "code": "de", "name": "Deutsch", "flag": "pkg:/images/flag_de.png"}, {__proto__: $AAP, "code": "it", "name": "Italiano", "flag": "pkg:/images/flag_it.png"}];
}

function i18nvalid(code) {
  let l;
  for (l of $iter(i18nlangs())) {
    if ((l.code === code)) {
      return true;
    }
  }
  return false;
}

function i18ndetect() {
  let code, di, loc, c;
  code = "en";
  di = $createobject("roDeviceInfo");
  if ((di != null)) {
    loc = di.$getcurrentlocale();
    if (((loc != null) && ($len(loc) >= 2))) {
      c = $lcase($left(loc, 2));
      if (i18nvalid(c)) {
        code = c;
      }
    }
  }
  return code;
}

function i18nload(lang) {
  let d, txt, arr, p;
  d = $createobject("roAssociativeArray");
  d.$setmodecasesensitive();
  txt = $readasciifile((("pkg:/locale/" + lang) + ".json"));
  if (((txt != null) && (txt !== ""))) {
    arr = $parsejson(txt);
    if ((arr != null)) {
      for (p of $iter(arr)) {
        $six(d, $ix(p, 0), $ix(p, 1));
      }
    }
  }
  m.i18nd = d;
  m.i18nlang = lang;
}

function tx(s) {
  let lang, v;
  lang = m.global.lang;
  if ((lang == null)) {
    return s;
  }
  if ((lang === "es")) {
    return s;
  }
  if ((m.i18nlang == null)) {
    i18nload(lang);
  } else if ((m.i18nlang !== lang)) {
    i18nload(lang);
  }
  v = m.i18nd.$lookup(s);
  if ((v == null)) {
    return s;
  }
  return v;
}

function i18nlang() {
  let l;
  l = m.global.lang;
  if ((l == null)) {
    return "es";
  }
  return l;
}

function i18n24h() {
  let l;
  l = i18nlang();
  return (((l !== "es") && (l !== "en")));
}

function i18ndow3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  }
  if ((l === "pt")) {
    return ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
  }
  if ((l === "fr")) {
    return ["dim.", "lun.", "mar.", "mer.", "jeu.", "ven.", "sam."];
  }
  if ((l === "de")) {
    return ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
  }
  if ((l === "it")) {
    return ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
  }
  return ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
}

function i18nmon3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  }
  if ((l === "pt")) {
    return ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
  }
  if ((l === "fr")) {
    return ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
  }
  if ((l === "de")) {
    return ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];
  }
  if ((l === "it")) {
    return ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"];
  }
  return ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
}

function i18ndowfull() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  }
  if ((l === "pt")) {
    return ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
  }
  if ((l === "fr")) {
    return ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  }
  if ((l === "de")) {
    return ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
  }
  if ((l === "it")) {
    return ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"];
  }
  return ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
}

function i18ncompass() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  }
  if ((l === "pt")) {
    return ["N", "NE", "L", "SE", "S", "SO", "O", "NO"];
  }
  if ((l === "de")) {
    return ["N", "NO", "O", "SO", "S", "SW", "W", "NW"];
  }
  if ((l === "it")) {
    return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
  }
  return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
}

function i18nhm(h, mm, longfmt) {
  let hs, h12, l, suf;
  if (i18n24h()) {
    hs = h.$tostr();
    if ((h < 10)) {
      hs = ("0" + hs);
    }
    return ((hs + ":") + mm);
  }
  h12 = (h % 12);
  if ((h12 === 0)) {
    h12 = 12;
  }
  l = i18nlang();
  if ((l === "en")) {
    suf = " AM";
    if ((h >= 12)) {
      suf = " PM";
    }
    if ((!longfmt)) {
      suf = "a";
      if ((h >= 12)) {
        suf = "p";
      }
    }
    return (((h12.$tostr() + ":") + mm) + suf);
  }
  if (longfmt) {
    suf = " a. m.";
    if ((h >= 12)) {
      suf = " p. m.";
    }
  } else {
    suf = "a";
    if ((h >= 12)) {
      suf = "p";
    }
  }
  return (((h12.$tostr() + ":") + mm) + suf);
}
// ---- components/xtcommon.brs ----
function dstr(v) {
  let t;
  t = $type(v);
  if (((t === "roString") || (t === "String"))) {
    return v;
  }
  if (((((((((((t === "roInt") || (t === "Integer")) || (t === "roLongInteger")) || (t === "LongInteger")) || (t === "roFloat")) || (t === "Float")) || (t === "roDouble")) || (t === "Double")) || (t === "roBoolean")) || (t === "Boolean"))) {
    return v.$tostr();
  }
  return "";
}

function xtesc(s) {
  let ba, hex, out, i, $e0, b;
  ba = $createobject("roByteArray");
  ba.$fromasciistring(s);
  hex = "0123456789ABCDEF";
  out = "";
  for (i = 0, $e0 = (ba.$count() - 1); i <= $e0; i++) {
    b = $ix(ba, i);
    if ((((((((((b >= 48) && (b <= 57))) || (((b >= 65) && (b <= 90)))) || (((b >= 97) && (b <= 122)))) || (b === 45)) || (b === 46)) || (b === 95)) || (b === 126))) {
      out = (out + $chr(b));
    } else {
      out = (((out + "%") + $mid(hex, (($idiv(b, 16)) + 1), 1)) + $mid(hex, (((b % 16)) + 1), 1));
    }
  }
  return out;
}

function xthexval(c) {
  if (((c >= 48) && (c <= 57))) {
    return (c - 48);
  }
  if (((c >= 65) && (c <= 70))) {
    return (c - 55);
  }
  if (((c >= 97) && (c <= 102))) {
    return (c - 87);
  }
  return (-1);
}

function xtunesc(s) {
  let src, dst, n, i, b, used, hi, lo;
  src = $createobject("roByteArray");
  src.$fromasciistring(s);
  dst = $createobject("roByteArray");
  n = src.$count();
  i = 0;
  while ((i < n)) {
    b = $ix(src, i);
    used = false;
    if ((b === 37)) {
      if (((i + 2) < n)) {
        hi = xthexval($ix(src, (i + 1)));
        lo = xthexval($ix(src, (i + 2)));
        if (((hi >= 0) && (lo >= 0))) {
          dst.$push(((hi * 16) + lo));
          i = (i + 3);
          used = true;
        }
      }
    }
    if ((!used)) {
      dst.$push(b);
      i = (i + 1);
    }
  }
  return dst.$toasciistring();
}

function xtbase(h) {
  let s, low, q, done, tail;
  s = h.$trim();
  if ((s === "")) {
    return "";
  }
  low = $lcase(s);
  if ((($left(low, 7) !== "http://") && ($left(low, 8) !== "https://"))) {
    s = ("http://" + s);
  }
  q = $instr(1, s, "?");
  if ((q > 0)) {
    s = $left(s, (q - 1));
  }
  done = false;
  while ((!done)) {
    done = true;
    while ((($right(s, 1) === "/") && ($len(s) > 8))) {
      s = $left(s, ($len(s) - 1));
      done = false;
    }
    for (tail of $iter(["/player_api.php", "/get.php", "/xmltv.php", "/panel_api.php", "/c"])) {
      if (((($len(s) - $len(tail)) > 8) && ($lcase($right(s, $len(tail))) === tail))) {
        s = $left(s, ($len(s) - $len(tail)));
        done = false;
      }
    }
  }
  return s;
}

function xtparam(s, key) {
  let low, sep, p, st, en;
  low = $lcase(s);
  for (sep of $iter(["?", "&"])) {
    p = $instr(1, low, ((sep + $lcase(key)) + "="));
    if ((p > 0)) {
      st = ((p + $len(key)) + 2);
      en = $instr(st, s, "&");
      if ((en === 0)) {
        en = ($len(s) + 1);
      }
      return xtunesc($mid(s, st, (en - st)));
    }
  }
  return "";
}

function xtfromurl(s) {
  let u, p;
  u = xtparam(s, "username");
  p = xtparam(s, "password");
  if (((u === "") || (p === ""))) {
    return null;
  }
  return {__proto__: $AAP, "host": xtbase(s), "user": u, "pass": p};
}
return {"init": init, "serve": serve, "handlerequest": handlerequest, "parsequery": parsequery, "parsext": parsext, "parsemulti": parsemulti, "htmlesc": htmlesc, "sendpage": sendpage, "hx": hx, "jq": jq, "noticepage": noticepage, "formpage": formpage, "xtformpage": xtformpage, "donepage": donepage, "errbox": errbox, "donetitle": donetitle, "doneitems": doneitems, "i18nlangs": i18nlangs, "i18nvalid": i18nvalid, "i18ndetect": i18ndetect, "i18nload": i18nload, "tx": tx, "i18nlang": i18nlang, "i18n24h": i18n24h, "i18ndow3": i18ndow3, "i18nmon3": i18nmon3, "i18ndowfull": i18ndowfull, "i18ncompass": i18ncompass, "i18nhm": i18nhm, "dstr": dstr, "xtesc": xtesc, "xthexval": xthexval, "xtunesc": xtunesc, "xtbase": xtbase, "xtparam": xtparam, "xtfromurl": xtfromurl};
});

$defineComponent({"name":"VideoListScene","extends":"Scene","fields":[{"id":"exitRequested","type":"boolean","alwaysNotify":"true"}],"children":[{"type":"Rectangle","attrs":{"id":"background","width":"1280","height":"720","color":"0x07070AFF"},"children":[]},{"type":"Group","attrs":{"id":"bgFx"},"children":[{"type":"Poster","attrs":{"id":"glowA","translation":"[-300,-340]","width":"1040","height":"1040","opacity":"0.30","blendColor":"0xFF7A1AFF","uri":"pkg:/images/glow.png"},"children":[]},{"type":"Poster","attrs":{"id":"glowB","translation":"[720,240]","width":"920","height":"920","opacity":"0.16","blendColor":"0xFF3D2AFF","uri":"pkg:/images/glow.png"},"children":[]},{"type":"Poster","attrs":{"id":"glowC","translation":"[260,430]","width":"780","height":"780","opacity":"0.10","blendColor":"0xFFB347FF","uri":"pkg:/images/glow.png"},"children":[]},{"type":"Poster","attrs":{"id":"bgVignette","width":"1280","height":"720","uri":"pkg:/images/vignette.png"},"children":[]}]},{"type":"Group","attrs":{"id":"homePanel","visible":"true"},"children":[{"type":"Group","attrs":{"id":"heroImgs"},"children":[{"type":"Poster","attrs":{"id":"heroA","width":"1280","height":"720","loadWidth":"1280","loadHeight":"720","loadDisplayMode":"scaleToZoom","opacity":"0"},"children":[]},{"type":"Poster","attrs":{"id":"heroB","width":"1280","height":"720","loadWidth":"1280","loadHeight":"720","loadDisplayMode":"scaleToZoom","opacity":"0"},"children":[]}]},{"type":"Poster","attrs":{"id":"heroGradL","width":"1280","height":"720","uri":"pkg:/images/grad_left.png"},"children":[]},{"type":"Poster","attrs":{"id":"heroGradB","width":"1280","height":"720","uri":"pkg:/images/grad_bottom.png"},"children":[]},{"type":"Group","attrs":{"id":"heroText"},"children":[]},{"type":"Group","attrs":{"id":"heroBtns"},"children":[]},{"type":"Group","attrs":{"id":"homeBody"},"children":[]},{"type":"Label","attrs":{"id":"homeStatus","text":"","translation":"[64,676]","width":"1152","color":"0x7E838CFF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Regular.ttf","size":"15"},"children":[]}]}]},{"type":"Group","attrs":{"id":"topBar","visible":"true"},"children":[{"type":"Poster","attrs":{"width":"1280","height":"150","uri":"pkg:/images/grad_top.png"},"children":[]},{"type":"Poster","attrs":{"translation":"[56,22]","width":"54","height":"34","loadWidth":"54","loadHeight":"34","loadDisplayMode":"scaleToFit","uri":"pkg:/images/logo_small.png"},"children":[]},{"type":"Label","attrs":{"id":"topTitle","text":"SMART IPTV MX","translation":"[120,28]","width":"290","color":"0xFFFFFFFF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Bold.ttf","size":"21"},"children":[]}]},{"type":"Poster","attrs":{"translation":"[418,35]","width":"10","height":"10","uri":"pkg:/images/dot_on.png"},"children":[]},{"type":"Label","attrs":{"id":"activeName","text":"Sin lista","translation":"[436,30]","width":"330","color":"0x9A9FA8FF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Regular.ttf","size":"16"},"children":[]}]},{"type":"Group","attrs":{"id":"wxFocus","visible":"false"},"children":[{"type":"Poster","attrs":{"translation":"[786,20]","width":"128","height":"40","uri":"pkg:/images/rr_fill.9.png","blendColor":"0xFF8A24FF","opacity":"0.35"},"children":[]}]},{"type":"Poster","attrs":{"id":"wxIcon","translation":"[798,26]","width":"28","height":"28","loadWidth":"28","loadHeight":"28","loadDisplayMode":"scaleToFit","uri":"pkg:/images/wx_pcloud_d.png"},"children":[]},{"type":"Label","attrs":{"id":"wxTemp","text":"Clima","translation":"[832,29]","width":"80","color":"0xFFFFFFFF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-SemiBold.ttf","size":"19"},"children":[]}]},{"type":"Label","attrs":{"id":"topDate","text":"","translation":"[912,31]","width":"160","horizAlign":"right","color":"0x9A9FA8FF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Regular.ttf","size":"16"},"children":[]}]},{"type":"Label","attrs":{"id":"topClock","text":"","translation":"[1076,27]","width":"150","horizAlign":"right","color":"0xFFFFFFFF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-SemiBold.ttf","size":"22"},"children":[]}]}]},{"type":"Group","attrs":{"id":"wxPanel","visible":"false","translation":"[38,22]","scale":"[0.95,0.95]"},"children":[{"type":"Group","attrs":{"id":"wxBody","translation":"[0,44]"},"children":[]},{"type":"Label","attrs":{"id":"wxHint","text":"","translation":"[0,640]","width":"1240","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]}]},{"type":"Group","attrs":{"id":"langPanel","visible":"false"},"children":[{"type":"Label","attrs":{"id":"langHead","text":"","translation":"[0,40]","width":"1240","horizAlign":"center","font":"font:MediumBoldSystemFont","color":"0xFF8A24FF"},"children":[]},{"type":"Group","attrs":{"id":"langBody"},"children":[]},{"type":"Label","attrs":{"id":"langHint","text":"","translation":"[0,652]","width":"1240","horizAlign":"center","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]}]},{"type":"Group","attrs":{"id":"aboutPanel","visible":"false"},"children":[{"type":"Group","attrs":{"id":"aboutMenu","translation":"[56,100]"},"children":[]},{"type":"Group","attrs":{"id":"aboutBody","translation":"[400,96]"},"children":[]},{"type":"Label","attrs":{"id":"aboutHint","text":"Arriba/Abajo: elegir sección     OK: abrir     Atrás: volver","translation":"[56,676]","width":"1100","color":"0x7E838CFF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Regular.ttf","size":"15"},"children":[]}]}]},{"type":"Group","attrs":{"id":"tutPanel","visible":"false"},"children":[{"type":"Group","attrs":{"id":"tutBody"},"children":[]}]},{"type":"Group","attrs":{"id":"libraryPanel","visible":"false","translation":"[38,22]","scale":"[0.95,0.95]"},"children":[{"type":"MarkupList","attrs":{"id":"libraryList","translation":"[290,90]","itemSize":"[700,60]","itemSpacing":"[0,4]","numRows":"7","itemComponentName":"LibraryItem","focusBitmapUri":"pkg:/images/fb_lib.png","focusFootprintBitmapUri":"pkg:/images/blank.png"},"children":[]},{"type":"Label","attrs":{"id":"statusLabel","text":"","translation":"[140,590]","width":"1000","horizAlign":"center","wrap":"true","font":"font:SmallSystemFont","color":"0xFF8A24FF"},"children":[]},{"type":"Label","attrs":{"id":"hintLabel","text":"OK: opciones de la lista     Atrás: inicio","translation":"[140,650]","width":"1000","horizAlign":"center","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]},{"type":"Label","attrs":{"id":"xtHint","visible":"false","text":"OK: opciones de la cuenta     Atrás: inicio","translation":"[140,650]","width":"1000","horizAlign":"center","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]}]},{"type":"Group","attrs":{"id":"listsPanel","visible":"false","translation":"[38,22]","scale":"[0.95,0.95]"},"children":[{"type":"Rectangle","attrs":{"id":"pipFrame","visible":"false","translation":"[867,72]","width":"386","height":"220","color":"0xFF8A24FF"},"children":[]},{"type":"Label","attrs":{"id":"pipTag","visible":"false","text":"VIENDO AHORA","translation":"[871,300]","width":"378","font":"font:SmallBoldSystemFont","color":"0xFF8A24FF"},"children":[]},{"type":"Label","attrs":{"id":"pipName","visible":"false","text":"","translation":"[871,326]","width":"378","wrap":"true","numLines":"2","font":"font:MediumBoldSystemFont","color":"0xFFFFFFFF"},"children":[]},{"type":"Label","attrs":{"id":"pipHint","visible":"false","text":"OK en el canal: pantalla completa","translation":"[871,404]","width":"378","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]},{"type":"Group","attrs":{"id":"matchBtn","translation":"[28,72]"},"children":[]},{"type":"MarkupList","attrs":{"id":"categoryList","translation":"[28,136]","itemSize":"[340,54]","numRows":"9","vertFocusAnimationStyle":"floatingFocus","itemComponentName":"CategoryItem","focusBitmapUri":"pkg:/images/rr_fill.9.png","focusBitmapBlendColor":"0xFF8A2459","focusFootprintBitmapUri":"pkg:/images/rr_fill.9.png","focusFootprintBlendColor":"0xFFFFFF14"},"children":[]},{"type":"MarkupList","attrs":{"id":"channelList","translation":"[392,76]","itemSize":"[460,62]","numRows":"9","itemSpacing":"[0,2]","vertFocusAnimationStyle":"floatingFocus","itemComponentName":"ChannelItem","focusBitmapUri":"pkg:/images/rr_fill.9.png","focusBitmapBlendColor":"0xFF8A2459","focusFootprintBitmapUri":"pkg:/images/blank.png"},"children":[]},{"type":"Group","attrs":{"id":"chInfo"},"children":[]},{"type":"Label","attrs":{"id":"epgListStatus","text":"","translation":"[898,604]","width":"312","wrap":"false","maxLines":"1","color":"0x7E838CFF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Regular.ttf","size":"13"},"children":[]}]},{"type":"Poster","attrs":{"translation":"[28,672]","width":"28","height":"28","loadWidth":"28","loadHeight":"28","uri":"pkg:/images/heart_on.png"},"children":[]},{"type":"Label","attrs":{"id":"liveHint","text":"OK: ver canal     Play o *: favorito     Izq/Der: categorías y canales     Atrás: inicio","translation":"[66,674]","width":"1190","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]}]},{"type":"Group","attrs":{"id":"moviePanel","visible":"false","translation":"[38,22]","scale":"[0.95,0.95]"},"children":[{"type":"Group","attrs":{"id":"cwRow","visible":"false"},"children":[]},{"type":"Group","attrs":{"id":"movieWrap"},"children":[{"type":"Group","attrs":{"id":"movieCats","translation":"[16,74]"},"children":[]},{"type":"Group","attrs":{"id":"movieBar","translation":"[300,64]"},"children":[]},{"type":"Group","attrs":{"id":"movieGrid","translation":"[300,112]"},"children":[]}]},{"type":"Animation","attrs":{"id":"cwSlide","duration":"0.22","easeFunction":"outQuad","repeat":"false"},"children":[{"type":"Vector2DFieldInterpolator","attrs":{"id":"cwSlideI","key":"[0.0, 1.0]","keyValue":"[[0,0],[0,0]]","fieldToInterp":"movieWrap.translation"},"children":[]}]},{"type":"Poster","attrs":{"translation":"[28,672]","width":"28","height":"28","loadWidth":"28","loadHeight":"28","uri":"pkg:/images/heart_on.png"},"children":[]},{"type":"Label","attrs":{"id":"movieHint","text":"","translation":"[66,674]","width":"1190","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]},{"type":"Group","attrs":{"id":"movieOverlay"},"children":[]}]},{"type":"Group","attrs":{"id":"detailPanel","visible":"false"},"children":[{"type":"Group","attrs":{"id":"detailBody"},"children":[]}]},{"type":"Group","attrs":{"id":"favPanel","visible":"false","translation":"[38,22]","scale":"[0.95,0.95]"},"children":[{"type":"Label","attrs":{"id":"favTabLive","text":"CANALES","translation":"[28,74]","font":"font:MediumBoldSystemFont","color":"0xFF8A24FF"},"children":[]},{"type":"Label","attrs":{"id":"favTabMovie","text":"PELICULAS","translation":"[280,74]","font":"font:MediumBoldSystemFont","color":"0xA8ADB5FF"},"children":[]},{"type":"Group","attrs":{"id":"favBody","translation":"[16,120]"},"children":[]},{"type":"Poster","attrs":{"translation":"[28,672]","width":"28","height":"28","loadWidth":"28","loadHeight":"28","uri":"pkg:/images/heart_on.png"},"children":[]},{"type":"Label","attrs":{"id":"favHint","text":"","translation":"[66,674]","width":"1190","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]}]},{"type":"Group","attrs":{"id":"searchPanel","visible":"false","translation":"[38,22]","scale":"[0.95,0.95]"},"children":[{"type":"Label","attrs":{"id":"searchTitle","text":"","translation":"[72,70]","width":"1136","font":"font:MediumBoldSystemFont","color":"0xFFFFFFFF"},"children":[]},{"type":"MarkupList","attrs":{"id":"searchList","translation":"[72,112]","itemSize":"[1136,60]","numRows":"9","itemComponentName":"ChannelItem","focusBitmapUri":"pkg:/images/fb_wide.png","focusFootprintBitmapUri":"pkg:/images/blank.png"},"children":[]},{"type":"Poster","attrs":{"translation":"[28,672]","width":"28","height":"28","loadWidth":"28","loadHeight":"28","uri":"pkg:/images/heart_on.png"},"children":[]},{"type":"Label","attrs":{"id":"searchHint","text":"OK: ver     Play o *: favorito     Izquierda: nueva búsqueda     Atrás: inicio","translation":"[66,674]","width":"1190","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]}]},{"type":"Group","attrs":{"id":"qrPanel","visible":"false"},"children":[{"type":"Poster","attrs":{"translation":"[88,104]","width":"340","height":"340","uri":"pkg:/images/rr_fill.9.png"},"children":[]},{"type":"Group","attrs":{"id":"qrCode","translation":"[113,129]"},"children":[]},{"type":"Poster","attrs":{"id":"qrLogo","translation":"[225,241]","width":"66","height":"66","uri":"pkg:/images/qr_logo.png","visible":"false"},"children":[]},{"type":"Label","attrs":{"id":"qrUrl","text":"","translation":"[88,462]","width":"340","color":"0xFF8A24FF","horizAlign":"center"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-SemiBold.ttf","size":"19"},"children":[]}]},{"type":"Label","attrs":{"text":"Si no puedes escanear, escribe esta dirección en el navegador del celular.","translation":"[98,494]","width":"320","color":"0x7E838CFF","horizAlign":"center","wrap":"true","maxLines":"2"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Regular.ttf","size":"14"},"children":[]}]},{"type":"Label","attrs":{"text":"CARGAR DESDE EL CELULAR","translation":"[500,104]","width":"700","color":"0xFF8A24FF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Bold.ttf","size":"15"},"children":[]}]},{"type":"Label","attrs":{"text":"Envía tu lista o tu cuenta Xtream","translation":"[500,128]","width":"716","color":"0xFFFFFFFF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Bold.ttf","size":"36"},"children":[]}]},{"type":"Poster","attrs":{"translation":"[500,196]","width":"36","height":"36","uri":"pkg:/images/rr_fill.9.png","blendColor":"0xFF8A24FF"},"children":[]},{"type":"Label","attrs":{"text":"1","translation":"[500,204]","width":"36","color":"0x0A0A0FFF","horizAlign":"center"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Bold.ttf","size":"17"},"children":[]}]},{"type":"Label","attrs":{"text":"Conecta el celular al mismo Wi-Fi que la TV","translation":"[552,203]","width":"664","color":"0xE6E8EBFF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Regular.ttf","size":"19"},"children":[]}]},{"type":"Poster","attrs":{"translation":"[500,252]","width":"36","height":"36","uri":"pkg:/images/rr_fill.9.png","blendColor":"0xFF8A24FF"},"children":[]},{"type":"Label","attrs":{"text":"2","translation":"[500,260]","width":"36","color":"0x0A0A0FFF","horizAlign":"center"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Bold.ttf","size":"17"},"children":[]}]},{"type":"Label","attrs":{"text":"Escanea el código con la cámara","translation":"[552,259]","width":"664","color":"0xE6E8EBFF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Regular.ttf","size":"19"},"children":[]}]},{"type":"Poster","attrs":{"translation":"[500,308]","width":"36","height":"36","uri":"pkg:/images/rr_fill.9.png","blendColor":"0xFF8A24FF"},"children":[]},{"type":"Label","attrs":{"text":"3","translation":"[500,316]","width":"36","color":"0x0A0A0FFF","horizAlign":"center"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Bold.ttf","size":"17"},"children":[]}]},{"type":"Label","attrs":{"text":"Elige Lista M3U o Xtream, llena los datos y toca Enviar","translation":"[552,315]","width":"664","color":"0xE6E8EBFF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Regular.ttf","size":"19"},"children":[]}]},{"type":"Poster","attrs":{"translation":"[500,372]","width":"350","height":"64","uri":"pkg:/images/rr_fill.9.png","blendColor":"0xFFFFFFFF","opacity":"0.07"},"children":[]},{"type":"Poster","attrs":{"translation":"[518,392]","width":"24","height":"24","blendColor":"0xFF8A24FF","uri":"pkg:/images/ic_list.png"},"children":[]},{"type":"Label","attrs":{"text":"Lista M3U","translation":"[556,384]","width":"280","color":"0xFFFFFFFF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-SemiBold.ttf","size":"17"},"children":[]}]},{"type":"Label","attrs":{"text":"Un link que empieza con http","translation":"[556,408]","width":"280","color":"0x9A9FA8FF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Regular.ttf","size":"13"},"children":[]}]},{"type":"Poster","attrs":{"translation":"[866,372]","width":"350","height":"64","uri":"pkg:/images/rr_fill.9.png","blendColor":"0xFFFFFFFF","opacity":"0.07"},"children":[]},{"type":"Poster","attrs":{"translation":"[884,392]","width":"24","height":"24","blendColor":"0xFF8A24FF","uri":"pkg:/images/ic_xtream.png"},"children":[]},{"type":"Label","attrs":{"text":"Cuenta Xtream","translation":"[922,384]","width":"280","color":"0xFFFFFFFF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-SemiBold.ttf","size":"17"},"children":[]}]},{"type":"Label","attrs":{"text":"Servidor, usuario y contraseña","translation":"[922,408]","width":"280","color":"0x9A9FA8FF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Regular.ttf","size":"13"},"children":[]}]},{"type":"Poster","attrs":{"translation":"[500,462]","width":"716","height":"70","uri":"pkg:/images/rr_fill.9.png","blendColor":"0x34C759FF","opacity":"0.10"},"children":[]},{"type":"Poster","attrs":{"id":"qrDot","translation":"[522,489]","width":"16","height":"16","uri":"pkg:/images/dot_on.png"},"children":[]},{"type":"Label","attrs":{"id":"qrStatus","text":"","translation":"[552,475]","width":"650","color":"0x50E68CFF","wrap":"true","maxLines":"2"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-SemiBold.ttf","size":"18"},"children":[]}]},{"type":"Label","attrs":{"text":"Atrás: volver","translation":"[88,676]","width":"1100","color":"0x7E838CFF"},"children":[{"type":"Font","attrs":{"role":"font","uri":"pkg:/fonts/Inter-Regular.ttf","size":"15"},"children":[]}]}]},{"type":"Group","attrs":{"id":"supportPanel","visible":"false"},"children":[]},{"type":"Group","attrs":{"id":"matchesPanel","visible":"false"},"children":[{"type":"Group","attrs":{"id":"mtBody"},"children":[]}]},{"type":"Group","attrs":{"id":"pinPanel","visible":"false"},"children":[{"type":"Group","attrs":{"id":"pinBody"},"children":[]}]},{"type":"Group","attrs":{"id":"welcomePanel","visible":"false"},"children":[{"type":"Poster","attrs":{"id":"wLogo","visible":"false","width":"1","height":"1"},"children":[]},{"type":"Group","attrs":{"id":"wContent"},"children":[{"type":"Group","attrs":{"id":"wGroup"},"children":[]}]}]},{"type":"Rectangle","attrs":{"id":"guideBg","visible":"false","width":"1280","height":"720","color":"0x090A0CFF"},"children":[]},{"type":"Video","attrs":{"id":"videoPlayer","visible":"false","translation":"[0,0]","width":"1280","height":"720","enableTrickPlay":"false"},"children":[]},{"type":"Group","attrs":{"id":"guidePanel","visible":"false","translation":"[38,22]","scale":"[0.95,0.95]"},"children":[{"type":"Label","attrs":{"id":"guideCatLabel","text":"","translation":"[530,12]","width":"500","font":"font:SmallSystemFont","color":"0xFF8A24FF"},"children":[]},{"type":"Poster","attrs":{"id":"guideLogo","translation":"[530,40]","width":"72","height":"48","loadWidth":"72","loadHeight":"48","loadDisplayMode":"scaleToFit"},"children":[]},{"type":"Label","attrs":{"id":"guideChannelName","text":"","translation":"[612,46]","width":"640","font":"font:MediumBoldSystemFont","color":"0xFFFFFFFF"},"children":[]},{"type":"Label","attrs":{"id":"guideNow","text":"","translation":"[530,96]","width":"720","wrap":"true","numLines":"2","font":"font:LargeBoldSystemFont","color":"0xFFFFFFFF"},"children":[]},{"type":"Rectangle","attrs":{"id":"progTrack","translation":"[530,162]","width":"300","height":"8","color":"0xFFFFFF2A"},"children":[]},{"type":"Rectangle","attrs":{"id":"progFill","translation":"[530,162]","width":"0","height":"8","color":"0xFF8A24FF"},"children":[]},{"type":"Rectangle","attrs":{"id":"progHead","translation":"[530,159]","width":"3","height":"14","color":"0xFFE2B8FF","visible":"false"},"children":[]},{"type":"Label","attrs":{"id":"progInfo","text":"","translation":"[842,151]","width":"180","font":"font:SmallBoldSystemFont","color":"0xFF8A24FF"},"children":[]},{"type":"Label","attrs":{"id":"guideWhen","text":"","translation":"[960,154]","width":"290","horizAlign":"right","font":"font:SmallSystemFont","color":"0xFFFFFFFF"},"children":[]},{"type":"Label","attrs":{"id":"guideDesc","text":"","translation":"[530,182]","width":"720","height":"78","wrap":"true","numLines":"3","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]},{"type":"Label","attrs":{"id":"guideClock","text":"","translation":"[980,12]","width":"270","horizAlign":"right","font":"font:MediumBoldSystemFont","color":"0xFFFFFFFF"},"children":[]},{"type":"Rectangle","attrs":{"id":"videoHintBg","translation":"[24,250]","width":"480","height":"36","color":"0x000000B0"},"children":[]},{"type":"Label","attrs":{"id":"videoHint","text":"Play: pantalla completa     Atrás: cerrar guía","translation":"[32,258]","width":"460","font":"font:SmallSystemFont","color":"0xFFFFFFFF"},"children":[]},{"type":"Label","attrs":{"id":"guideHint","text":"Izq/Der: horario    Arriba/Abajo: canal    « »: categorías    OK: ver    Play: pantalla completa","translation":"[16,302]","width":"1248","font":"font:SmallSystemFont","color":"0xFFFFFFFF"},"children":[]},{"type":"Label","attrs":{"id":"guideDay","text":"","translation":"[12,338]","width":"196","font":"font:SmallBoldSystemFont","color":"0xFF8A24FF"},"children":[]},{"type":"Group","attrs":{"id":"guideGrid"},"children":[]},{"type":"Label","attrs":{"id":"guideStatus","text":"","translation":"[16,688]","width":"1248","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]}]},{"type":"Group","attrs":{"id":"zapBanner","visible":"false"},"children":[{"type":"Rectangle","attrs":{"width":"1280","height":"156","translation":"[0,564]","color":"0x000000C8"},"children":[]},{"type":"Poster","attrs":{"id":"zapLogo","translation":"[64,596]","width":"96","height":"64","loadWidth":"96","loadHeight":"64","loadDisplayMode":"scaleToFit"},"children":[]},{"type":"Poster","attrs":{"id":"zapHeart","translation":"[1168,596]","width":"40","height":"40","loadWidth":"40","loadHeight":"40","loadDisplayMode":"scaleToFit","uri":"pkg:/images/heart_off.png"},"children":[]},{"type":"Label","attrs":{"id":"zapChannel","text":"","translation":"[176,582]","width":"980","font":"font:LargeBoldSystemFont","color":"0xFFFFFFFF"},"children":[]},{"type":"Label","attrs":{"id":"zapNow","text":"","translation":"[176,634]","width":"1040","font":"font:MediumSystemFont","color":"0xFFFFFFFF"},"children":[]},{"type":"Label","attrs":{"id":"zapNext","text":"","translation":"[176,676]","width":"1040","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]}]},{"type":"Group","attrs":{"id":"ctlBar","visible":"false"},"children":[{"type":"Rectangle","attrs":{"width":"1280","height":"210","translation":"[0,510]","color":"0x090A0CE6"},"children":[]},{"type":"Rectangle","attrs":{"width":"1280","height":"4","translation":"[0,510]","color":"0xFF8A24FF"},"children":[]},{"type":"Label","attrs":{"id":"ctlTitle","text":"","translation":"[64,522]","width":"900","font":"font:MediumBoldSystemFont","color":"0xFFFFFFFF"},"children":[]},{"type":"Label","attrs":{"id":"ctlBadge","text":"","translation":"[1016,526]","width":"200","horizAlign":"right","font":"font:SmallBoldSystemFont","color":"0xFF8A24FF"},"children":[]},{"type":"Label","attrs":{"id":"ctlPos","text":"0:00","translation":"[40,568]","width":"100","horizAlign":"right","font":"font:SmallSystemFont","color":"0xFFFFFFFF"},"children":[]},{"type":"Rectangle","attrs":{"id":"ctlTrack","translation":"[160,578]","width":"960","height":"8","color":"0xFFFFFF33"},"children":[]},{"type":"Rectangle","attrs":{"id":"ctlFill","translation":"[160,578]","width":"0","height":"8","color":"0xFF8A24FF"},"children":[]},{"type":"Poster","attrs":{"id":"ctlKnob","translation":"[152,572]","width":"20","height":"20","uri":"pkg:/images/knob.png"},"children":[]},{"type":"Label","attrs":{"id":"ctlDur","text":"","translation":"[1140,568]","width":"100","font":"font:SmallSystemFont","color":"0xFFFFFFFF"},"children":[]},{"type":"Poster","attrs":{"id":"ctlFocus0","translation":"[384,624]","width":"72","height":"56","loadDisplayMode":"scaleToFit","visible":"false","uri":"pkg:/images/ctl_focus.png"},"children":[]},{"type":"Poster","attrs":{"id":"ctlIcon0","translation":"[400,632]","width":"40","height":"40","loadDisplayMode":"scaleToFit","uri":"pkg:/images/ctl_rew.png"},"children":[]},{"type":"Poster","attrs":{"id":"ctlFocus1","translation":"[472,624]","width":"72","height":"56","loadDisplayMode":"scaleToFit","visible":"false","uri":"pkg:/images/ctl_focus.png"},"children":[]},{"type":"Poster","attrs":{"id":"ctlIcon1","translation":"[488,632]","width":"40","height":"40","loadDisplayMode":"scaleToFit","uri":"pkg:/images/ctl_play.png"},"children":[]},{"type":"Poster","attrs":{"id":"ctlFocus2","translation":"[560,624]","width":"72","height":"56","loadDisplayMode":"scaleToFit","visible":"false","uri":"pkg:/images/ctl_focus.png"},"children":[]},{"type":"Poster","attrs":{"id":"ctlIcon2","translation":"[576,632]","width":"40","height":"40","loadDisplayMode":"scaleToFit","uri":"pkg:/images/ctl_fwd.png"},"children":[]},{"type":"Poster","attrs":{"id":"ctlFocus3","translation":"[648,624]","width":"72","height":"56","loadDisplayMode":"scaleToFit","visible":"false","uri":"pkg:/images/ctl_focus.png"},"children":[]},{"type":"Poster","attrs":{"id":"ctlIcon3","translation":"[664,632]","width":"40","height":"40","loadDisplayMode":"scaleToFit","uri":"pkg:/images/ctl_cc.png"},"children":[]},{"type":"Poster","attrs":{"id":"ctlFocus4","translation":"[736,624]","width":"72","height":"56","loadDisplayMode":"scaleToFit","visible":"false","uri":"pkg:/images/ctl_focus.png"},"children":[]},{"type":"Poster","attrs":{"id":"ctlIcon4","translation":"[752,632]","width":"40","height":"40","loadDisplayMode":"scaleToFit","uri":"pkg:/images/ctl_audio.png"},"children":[]},{"type":"Poster","attrs":{"id":"ctlFocus5","translation":"[824,624]","width":"72","height":"56","loadDisplayMode":"scaleToFit","visible":"false","uri":"pkg:/images/ctl_focus.png"},"children":[]},{"type":"Poster","attrs":{"id":"ctlIcon5","translation":"[840,632]","width":"40","height":"40","loadDisplayMode":"scaleToFit","uri":"pkg:/images/ctl_heart.png"},"children":[]},{"type":"Label","attrs":{"id":"ctlMsg","text":"","translation":"[64,692]","width":"1152","horizAlign":"center","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]},{"type":"Label","attrs":{"id":"ctlVol","text":"Volumen: botones + / - del control de tu TV","translation":"[64,644]","width":"330","wrap":"true","numLines":"2","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]}]},{"type":"Group","attrs":{"id":"trackPanel","visible":"false"},"children":[{"type":"Rectangle","attrs":{"width":"1280","height":"720","color":"0x000000A0"},"children":[]},{"type":"Rectangle","attrs":{"width":"440","height":"400","translation":"[420,150]","color":"0x17191DFF"},"children":[]},{"type":"Rectangle","attrs":{"width":"440","height":"4","translation":"[420,150]","color":"0xFF8A24FF"},"children":[]},{"type":"Label","attrs":{"id":"trackTitle","text":"","translation":"[440,166]","width":"400","horizAlign":"center","font":"font:MediumBoldSystemFont","color":"0xFF8A24FF"},"children":[]},{"type":"LabelList","attrs":{"id":"trackList","translation":"[450,216]","itemSize":"[380,44]","numRows":"6"},"children":[]},{"type":"Label","attrs":{"text":"OK: elegir     Atrás: cerrar","translation":"[440,510]","width":"400","horizAlign":"center","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]}]},{"type":"Animation","attrs":{"id":"wAnim","duration":"0.4","easeFunction":"outQuad"},"children":[{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"wContent.opacity","key":"[0.0, 1.0]","keyValue":"[0.0, 1.0]"},"children":[]},{"type":"Vector2DFieldInterpolator","attrs":{"fieldToInterp":"wContent.translation","key":"[0.0, 1.0]","keyValue":"[[0.0, 24.0], [0.0, 0.0]]"},"children":[]}]},{"type":"Animation","attrs":{"id":"wLogoAnim","duration":"2.6","repeat":"true","easeFunction":"inOutQuad"},"children":[{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"wLogo.opacity","key":"[0.0, 0.5, 1.0]","keyValue":"[0.7, 1.0, 0.7]"},"children":[]}]},{"type":"Timer","attrs":{"id":"bmTimer","duration":"20","repeat":"true"},"children":[]},{"type":"Timer","attrs":{"id":"ctlHideTimer","duration":"7","repeat":"false"},"children":[]},{"type":"Timer","attrs":{"id":"ctlTickTimer","duration":"1","repeat":"true"},"children":[]},{"type":"Group","attrs":{"id":"toast","visible":"false"},"children":[{"type":"Rectangle","attrs":{"width":"1280","height":"720","color":"0x000000B3"},"children":[]},{"type":"Group","attrs":{"id":"toastBox","translation":"[360,170]"},"children":[{"type":"Poster","attrs":{"width":"560","height":"380","uri":"pkg:/images/toast_card.png"},"children":[]},{"type":"Poster","attrs":{"id":"toastRing","translation":"[216,44]","width":"128","height":"128","scaleRotateCenter":"[64,64]","opacity":"0","uri":"pkg:/images/check_ring.png"},"children":[]},{"type":"Poster","attrs":{"id":"toastCheck","translation":"[216,44]","width":"128","height":"128","scaleRotateCenter":"[64,64]","opacity":"0","uri":"pkg:/images/check_circle.png"},"children":[]},{"type":"Label","attrs":{"id":"toastTitle","text":"","translation":"[0,196]","width":"560","horizAlign":"center","font":"font:LargeBoldSystemFont","color":"0xFFFFFFFF"},"children":[]},{"type":"Label","attrs":{"id":"toastSub","text":"","translation":"[40,250]","width":"480","height":"64","horizAlign":"center","wrap":"true","numLines":"2","font":"font:MediumBoldSystemFont","color":"0xFF8A24FF"},"children":[]},{"type":"Label","attrs":{"id":"toastHint","text":"","translation":"[20,330]","width":"520","horizAlign":"center","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]}]}]},{"type":"Group","attrs":{"id":"overlay","visible":"false"},"children":[{"type":"Rectangle","attrs":{"id":"ovBg","width":"1280","height":"720","color":"0x090A0CD8"},"children":[]},{"type":"Poster","attrs":{"id":"ovLogo","translation":"[450,30]","width":"380","height":"351","loadDisplayMode":"scaleToFit","uri":"pkg:/images/logo_full.png"},"children":[]},{"type":"Label","attrs":{"id":"ovTitle","text":"","translation":"[140,404]","width":"1000","horizAlign":"center","font":"font:LargeBoldSystemFont","color":"0xFFFFFFFF"},"children":[]},{"type":"Label","attrs":{"id":"ovSub","text":"","translation":"[190,458]","width":"900","height":"64","horizAlign":"center","wrap":"true","numLines":"2","font":"font:MediumSystemFont","color":"0xA8ADB5FF"},"children":[]},{"type":"Group","attrs":{"id":"ovBar","translation":"[510,540]","clippingRect":"[0,0,260,6]"},"children":[{"type":"Rectangle","attrs":{"width":"260","height":"6","color":"0xFFFFFF22"},"children":[]},{"type":"Rectangle","attrs":{"id":"ovBarFill","translation":"[-120,0]","width":"120","height":"6","color":"0xFF8A24FF"},"children":[]}]},{"type":"Label","attrs":{"id":"ovHint","text":"","translation":"[140,628]","width":"1000","horizAlign":"center","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]}]},{"type":"Animation","attrs":{"id":"pulseAnim","duration":"1.4","repeat":"true","easeFunction":"inOutQuad"},"children":[{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"ovLogo.opacity","key":"[0.0, 0.5, 1.0]","keyValue":"[0.45, 1.0, 0.45]"},"children":[]}]},{"type":"Animation","attrs":{"id":"barAnim","duration":"1.1","repeat":"true","easeFunction":"linear"},"children":[{"type":"Vector2DFieldInterpolator","attrs":{"fieldToInterp":"ovBarFill.translation","key":"[0.0, 1.0]","keyValue":"[[-120.0, 0.0], [260.0, 0.0]]"},"children":[]}]},{"type":"Group","attrs":{"id":"catPicker","visible":"false"},"children":[{"type":"Rectangle","attrs":{"width":"1280","height":"720","color":"0x000000B0"},"children":[]},{"type":"Rectangle","attrs":{"width":"480","height":"620","translation":"[400,50]","color":"0x17191DFF"},"children":[]},{"type":"Label","attrs":{"text":"Categorías","translation":"[420,68]","width":"440","horizAlign":"center","font":"font:MediumBoldSystemFont","color":"0xFF8A24FF"},"children":[]},{"type":"Group","attrs":{"id":"catPickerGrid","translation":"[430,120]"},"children":[]},{"type":"Label","attrs":{"text":"OK: elegir     Atrás: cerrar","translation":"[420,600]","width":"440","horizAlign":"center","font":"font:SmallSystemFont","color":"0xA8ADB5FF"},"children":[]}]},{"type":"Timer","attrs":{"id":"zapTimer","duration":"4","repeat":"false"},"children":[]},{"type":"Animation","attrs":{"id":"animBg0","duration":"52.0","repeat":"true","easeFunction":"inOutQuad"},"children":[{"type":"Vector2DFieldInterpolator","attrs":{"fieldToInterp":"glowA.translation","key":"[0.0, 0.33, 0.66, 1.0]","keyValue":"[[-300.0, -340.0], [-150.0, -250.0], [-330.0, -190.0], [-300.0, -340.0]]"},"children":[]}]},{"type":"Animation","attrs":{"id":"animBg1","duration":"14.0","repeat":"true","easeFunction":"inOutQuad"},"children":[{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"glowA.opacity","key":"[0.0, 0.5, 1.0]","keyValue":"[0.24, 0.38, 0.24]"},"children":[]}]},{"type":"Animation","attrs":{"id":"animBg2","duration":"64.0","repeat":"true","easeFunction":"inOutQuad"},"children":[{"type":"Vector2DFieldInterpolator","attrs":{"fieldToInterp":"glowB.translation","key":"[0.0, 0.5, 1.0]","keyValue":"[[720.0, 240.0], [560.0, 300.0], [720.0, 240.0]]"},"children":[]},{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"glowB.opacity","key":"[0.0, 0.5, 1.0]","keyValue":"[0.12, 0.22, 0.12]"},"children":[]}]},{"type":"Animation","attrs":{"id":"animBg3","duration":"44.0","repeat":"true","easeFunction":"inOutQuad"},"children":[{"type":"Vector2DFieldInterpolator","attrs":{"fieldToInterp":"glowC.translation","key":"[0.0, 0.5, 1.0]","keyValue":"[[260.0, 430.0], [420.0, 380.0], [260.0, 430.0]]"},"children":[]},{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"glowC.opacity","key":"[0.0, 0.5, 1.0]","keyValue":"[0.06, 0.14, 0.06]"},"children":[]}]},{"type":"Timer","attrs":{"id":"featTimer","duration":"9","repeat":"true"},"children":[]},{"type":"Animation","attrs":{"id":"qrPulse","duration":"1.4","repeat":"true","easeFunction":"inOutQuad"},"children":[{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"qrDot.opacity","key":"[0.0, 0.5, 1.0]","keyValue":"[1.0, 0.25, 1.0]"},"children":[]}]},{"type":"Animation","attrs":{"id":"heroFade","duration":"0.9","easeFunction":"inOutQuad"},"children":[{"type":"FloatFieldInterpolator","attrs":{"id":"heroFadeIn","fieldToInterp":"heroA.opacity","key":"[0.0, 1.0]","keyValue":"[0.0, 1.0]"},"children":[]},{"type":"FloatFieldInterpolator","attrs":{"id":"heroFadeOut","fieldToInterp":"heroB.opacity","key":"[0.0, 1.0]","keyValue":"[1.0, 0.0]"},"children":[]}]},{"type":"Animation","attrs":{"id":"heroTextFade","duration":"0.55","easeFunction":"outQuad"},"children":[{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"heroText.opacity","key":"[0.0, 1.0]","keyValue":"[0.0, 1.0]"},"children":[]},{"type":"Vector2DFieldInterpolator","attrs":{"fieldToInterp":"heroText.translation","key":"[0.0, 1.0]","keyValue":"[[0.0, 14.0], [0.0, 0.0]]"},"children":[]}]},{"type":"Animation","attrs":{"id":"toastBoxAnim","duration":"0.3","easeFunction":"outQuad"},"children":[{"type":"Vector2DFieldInterpolator","attrs":{"fieldToInterp":"toastBox.translation","key":"[0.0, 1.0]","keyValue":"[[360.0, 200.0], [360.0, 170.0]]"},"children":[]},{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"toastBox.opacity","key":"[0.0, 1.0]","keyValue":"[0.0, 1.0]"},"children":[]}]},{"type":"Animation","attrs":{"id":"toastPop","duration":"0.5","delay":"0.15","easeFunction":"outQuad"},"children":[{"type":"Vector2DFieldInterpolator","attrs":{"fieldToInterp":"toastCheck.scale","key":"[0.0, 0.6, 1.0]","keyValue":"[[0.2, 0.2], [1.15, 1.15], [1.0, 1.0]]"},"children":[]},{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"toastCheck.opacity","key":"[0.0, 0.35, 1.0]","keyValue":"[0.0, 1.0, 1.0]"},"children":[]}]},{"type":"Animation","attrs":{"id":"toastRipple","duration":"1.0","delay":"0.45","easeFunction":"outQuad"},"children":[{"type":"Vector2DFieldInterpolator","attrs":{"fieldToInterp":"toastRing.scale","key":"[0.0, 1.0]","keyValue":"[[1.0, 1.0], [2.1, 2.1]]"},"children":[]},{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"toastRing.opacity","key":"[0.0, 0.2, 1.0]","keyValue":"[0.0, 0.8, 0.0]"},"children":[]}]},{"type":"Audio","attrs":{"id":"bgm"},"children":[]},{"type":"Audio","attrs":{"id":"sfx"},"children":[]},{"type":"Timer","attrs":{"id":"toastTimer","duration":"4.5","repeat":"false"},"children":[]},{"type":"Timer","attrs":{"id":"tuneTimer","duration":"25","repeat":"false"},"children":[]},{"type":"Timer","attrs":{"id":"clockTimer","duration":"5","repeat":"true"},"children":[]},{"type":"Timer","attrs":{"id":"wxTimer","duration":"1800","repeat":"true"},"children":[]},{"type":"Timer","attrs":{"id":"vsTimer","duration":"0.03","repeat":"true"},"children":[]},{"type":"Group","attrs":{"id":"uiLayer","visible":"false"},"children":[]},{"type":"Group","attrs":{"id":"introPanel","visible":"false"},"children":[{"type":"Rectangle","attrs":{"width":"1280","height":"720","color":"0x07070AFF"},"children":[]},{"type":"Poster","attrs":{"id":"inGlowA","translation":"[-260,-200]","width":"1000","height":"1000","opacity":"0","blendColor":"0xFF7A1AFF","uri":"pkg:/images/glow.png"},"children":[]},{"type":"Poster","attrs":{"id":"inGlowB","translation":"[620,160]","width":"900","height":"900","opacity":"0","blendColor":"0xFF3D6AFF","uri":"pkg:/images/glow.png"},"children":[]},{"type":"Poster","attrs":{"id":"inGlowC","translation":"[180,380]","width":"820","height":"820","opacity":"0","blendColor":"0xFFB347FF","uri":"pkg:/images/glow.png"},"children":[]},{"type":"Poster","attrs":{"id":"inStarsA","width":"1280","height":"720","opacity":"0","uri":"pkg:/images/stars_a.png"},"children":[]},{"type":"Poster","attrs":{"id":"inStarsB","width":"1280","height":"720","opacity":"0","uri":"pkg:/images/stars_b.png"},"children":[]},{"type":"Poster","attrs":{"id":"inVig","width":"1280","height":"720","uri":"pkg:/images/vignette.png"},"children":[]},{"type":"Poster","attrs":{"id":"inHalo","translation":"[440,150]","width":"400","height":"280","opacity":"0","scaleRotateCenter":"[200,140]","blendColor":"0xFF8A24FF","uri":"pkg:/images/glow.png"},"children":[]},{"type":"Poster","attrs":{"id":"inMark","translation":"[520,214]","width":"240","height":"152","scaleRotateCenter":"[120,76]","uri":"pkg:/images/logo_mark.png"},"children":[]},{"type":"Poster","attrs":{"id":"inWord","translation":"[419,408]","width":"443","height":"29","opacity":"0","uri":"pkg:/images/wordmark.png"},"children":[]},{"type":"Poster","attrs":{"translation":"[550,476]","width":"180","height":"4","opacity":"0.14","uri":"pkg:/images/rr_pill.9.png"},"children":[]},{"type":"Group","attrs":{"id":"inBarG","translation":"[550,476]","scale":"[0,1]"},"children":[{"type":"Poster","attrs":{"width":"180","height":"4","blendColor":"0xFF8A24FF","uri":"pkg:/images/rr_pill.9.png"},"children":[]}]},{"type":"Audio","attrs":{"id":"introSfx"},"children":[]}]},{"type":"ParallelAnimation","attrs":{"id":"introAnim"},"children":[{"type":"Animation","attrs":{"duration":"1.8","easeFunction":"outQuad"},"children":[{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"inGlowA.opacity","key":"[0.0, 1.0]","keyValue":"[0.0, 0.34]"},"children":[]},{"type":"Vector2DFieldInterpolator","attrs":{"fieldToInterp":"inGlowA.translation","key":"[0.0, 1.0]","keyValue":"[[-260.0, -200.0], [-200.0, -260.0]]"},"children":[]}]},{"type":"Animation","attrs":{"duration":"2.2","delay":"0.3","easeFunction":"outQuad"},"children":[{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"inGlowB.opacity","key":"[0.0, 1.0]","keyValue":"[0.0, 0.20]"},"children":[]},{"type":"Vector2DFieldInterpolator","attrs":{"fieldToInterp":"inGlowB.translation","key":"[0.0, 1.0]","keyValue":"[[620.0, 160.0], [560.0, 200.0]]"},"children":[]}]},{"type":"Animation","attrs":{"duration":"2.4","delay":"0.5","easeFunction":"outQuad"},"children":[{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"inGlowC.opacity","key":"[0.0, 1.0]","keyValue":"[0.0, 0.14]"},"children":[]}]},{"type":"Animation","attrs":{"duration":"3.4","easeFunction":"linear"},"children":[{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"inStarsA.opacity","key":"[0.0, 0.3, 0.55, 0.8, 1.0]","keyValue":"[0.0, 0.8, 0.45, 0.9, 0.6]"},"children":[]},{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"inStarsB.opacity","key":"[0.0, 0.25, 0.5, 0.75, 1.0]","keyValue":"[0.0, 0.35, 0.9, 0.4, 0.85]"},"children":[]}]},{"type":"Animation","attrs":{"duration":"1.2","delay":"0.15","easeFunction":"outQuad"},"children":[{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"inHalo.opacity","key":"[0.0, 0.5, 1.0]","keyValue":"[0.0, 0.55, 0.32]"},"children":[]},{"type":"Vector2DFieldInterpolator","attrs":{"fieldToInterp":"inHalo.scale","key":"[0.0, 1.0]","keyValue":"[[0.6, 0.6], [1.15, 1.15]]"},"children":[]}]},{"type":"Animation","attrs":{"duration":"0.7","delay":"0.25","easeFunction":"inOutQuad"},"children":[{"type":"Vector2DFieldInterpolator","attrs":{"fieldToInterp":"inMark.scale","key":"[0.0, 0.5, 1.0]","keyValue":"[[1.0, 1.0], [1.07, 1.07], [1.0, 1.0]]"},"children":[]}]},{"type":"Animation","attrs":{"duration":"0.6","delay":"0.75","easeFunction":"outQuad"},"children":[{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"inWord.opacity","key":"[0.0, 1.0]","keyValue":"[0.0, 1.0]"},"children":[]},{"type":"Vector2DFieldInterpolator","attrs":{"fieldToInterp":"inWord.translation","key":"[0.0, 1.0]","keyValue":"[[419.0, 420.0], [419.0, 408.0]]"},"children":[]}]},{"type":"Animation","attrs":{"duration":"2.2","delay":"0.9","easeFunction":"inOutQuad"},"children":[{"type":"Vector2DFieldInterpolator","attrs":{"fieldToInterp":"inBarG.scale","key":"[0.0, 1.0]","keyValue":"[[0.0, 1.0], [1.0, 1.0]]"},"children":[]}]}]},{"type":"Animation","attrs":{"id":"introOut","duration":"0.45","easeFunction":"inQuad"},"children":[{"type":"FloatFieldInterpolator","attrs":{"fieldToInterp":"introPanel.opacity","key":"[0.0, 1.0]","keyValue":"[1.0, 0.0]"},"children":[]}]},{"type":"Timer","attrs":{"id":"introTimer","duration":"3.3","repeat":"false"},"children":[]}]}, function (m) {
// ---- components/videolistscene.brs ----
function init() {
  let i, $e0, bgmcontent, sfxcontent;
  i18ninit();
  m.librarypanel = m.top.$findnode("libraryPanel");
  m.librarylist = m.top.$findnode("libraryList");
  m.statuslabel = m.top.$findnode("statusLabel");
  m.listspanel = m.top.$findnode("listsPanel");
  m.categorylist = m.top.$findnode("categoryList");
  m.channellist = m.top.$findnode("channelList");
  m.epgliststatus = m.top.$findnode("epgListStatus");
  m.videoplayer = m.top.$findnode("videoPlayer");
  m.guidebg = m.top.$findnode("guideBg");
  m.guidepanel = m.top.$findnode("guidePanel");
  m.guidecatlabel = m.top.$findnode("guideCatLabel");
  m.guidelogo = m.top.$findnode("guideLogo");
  m.guidechannelname = m.top.$findnode("guideChannelName");
  m.guidenow = m.top.$findnode("guideNow");
  m.guidewhen = m.top.$findnode("guideWhen");
  m.guidedesc = m.top.$findnode("guideDesc");
  m.guideclock = m.top.$findnode("guideClock");
  m.guideday = m.top.$findnode("guideDay");
  m.guidegrid = m.top.$findnode("guideGrid");
  m.guidestatus = m.top.$findnode("guideStatus");
  m.progtrack = m.top.$findnode("progTrack");
  m.progfill = m.top.$findnode("progFill");
  m.proghead = m.top.$findnode("progHead");
  m.proginfo = m.top.$findnode("progInfo");
  m.progw = 300;
  m.follownow = false;
  m.livestrips = {__proto__: $AAP};
  m.zapbanner = m.top.$findnode("zapBanner");
  m.zaplogo = m.top.$findnode("zapLogo");
  m.zapchannel = m.top.$findnode("zapChannel");
  m.zapnow = m.top.$findnode("zapNow");
  m.zapnext = m.top.$findnode("zapNext");
  m.zaptimer = m.top.$findnode("zapTimer");
  m.clocktimer = m.top.$findnode("clockTimer");
  m.catpicker = m.top.$findnode("catPicker");
  m.catpickergrid = m.top.$findnode("catPickerGrid");
  m.background = m.top.$findnode("background");
  m.homepanel = m.top.$findnode("homePanel");
  m.welcomepanel = m.top.$findnode("welcomePanel");
  m.wtitle = m.top.$findnode("wTitle");
  m.wbody = m.top.$findnode("wBody");
  m.wbtnlabel = m.top.$findnode("wBtnLabel");
  m.whint = m.top.$findnode("wHint");
  m.wdots = [m.top.$findnode("wDot0"), m.top.$findnode("wDot1"), m.top.$findnode("wDot2"), m.top.$findnode("wDot3"), m.top.$findnode("wDot4")];
  m.wgreet = m.top.$findnode("wGreet");
  m.wbtn = m.top.$findnode("wBtn");
  m.wchipsg = m.top.$findnode("wChipsG");
  m.wfing = m.top.$findnode("wFinG");
  m.wchips = [m.top.$findnode("wChip0"), m.top.$findnode("wChip1"), m.top.$findnode("wChip2")];
  m.wfin = [m.top.$findnode("wFin0"), m.top.$findnode("wFin1")];
  m.wfinl1 = m.top.$findnode("wFinL1");
  m.wanim = m.top.$findnode("wAnim");
  m.wlogoanim = m.top.$findnode("wLogoAnim");
  m.wchoice = 2;
  m.wfinsel = 0;
  m.wpage = 0;
  m.welcomefirst = false;
  m.homestatus = m.top.$findnode("homeStatus");
  m.topbar = m.top.$findnode("topBar");
  m.toptitle = m.top.$findnode("topTitle");
  m.activename = m.top.$findnode("activeName");
  m.topdate = m.top.$findnode("topDate");
  m.topclock = m.top.$findnode("topClock");
  m.searchpanel = m.top.$findnode("searchPanel");
  m.searchtitle = m.top.$findnode("searchTitle");
  m.searchlist = m.top.$findnode("searchList");
  m.qrpanel = m.top.$findnode("qrPanel");
  m.qrcode = m.top.$findnode("qrCode");
  m.qrlogo = m.top.$findnode("qrLogo");
  m.qrurl = m.top.$findnode("qrUrl");
  m.qrstatus = m.top.$findnode("qrStatus");
  m.zapheart = m.top.$findnode("zapHeart");
  m.overlay = m.top.$findnode("overlay");
  m.ovbg = m.top.$findnode("ovBg");
  m.ovlogo = m.top.$findnode("ovLogo");
  m.ovtitle = m.top.$findnode("ovTitle");
  m.ovsub = m.top.$findnode("ovSub");
  m.ovbar = m.top.$findnode("ovBar");
  m.ovhint = m.top.$findnode("ovHint");
  m.pulseanim = m.top.$findnode("pulseAnim");
  m.baranim = m.top.$findnode("barAnim");
  m.tunetimer = m.top.$findnode("tuneTimer");
  m.ovstate = "";
  m.bgfx = m.top.$findnode("bgFx");
  m.bganims = [];
  m.bgloops = [];
  for (i = 0, $e0 = 3; i <= $e0; i++) {
    m.bganims.$push(m.top.$findnode(("animBg" + i.$tostr())));
  }
  m.bgon = false;
  m.bgfrozen = false;
  m.toast = m.top.$findnode("toast");
  m.toasttitle = m.top.$findnode("toastTitle");
  m.toastsub = m.top.$findnode("toastSub");
  m.toasthint = m.top.$findnode("toastHint");
  m.toastcheck = m.top.$findnode("toastCheck");
  m.toastring = m.top.$findnode("toastRing");
  m.toastanims = [m.top.$findnode("toastBoxAnim"), m.top.$findnode("toastPop"), m.top.$findnode("toastRipple")];
  m.toasttimer = m.top.$findnode("toastTimer");
  m.toasttimer.$observefield("fire", "hideToast");
  m.lastpop = (-2);
  m.lastquery = "";
  m.activeset = {__proto__: $AAP};
  m.needreload = false;
  m.moviepanel = m.top.$findnode("moviePanel");
  m.moviecats = m.top.$findnode("movieCats");
  m.moviegrid = m.top.$findnode("movieGrid");
  m.moviehint = m.top.$findnode("movieHint");
  m.detailpanel = m.top.$findnode("detailPanel");
  m.detailbody = m.top.$findnode("detailBody");
  m.moviebar = m.top.$findnode("movieBar");
  m.movieoverlay = m.top.$findnode("movieOverlay");
  m.vstimer = m.top.$findnode("vsTimer");
  m.vstimer.$observefield("fire", "onVsTick");
  m.vson = false;
  m.movpick = false;
  m.baridx = 0;
  m.vsquery = "";
  m.vsmode = "";
  m.vsdone = true;
  m.vstotal = 0;
  m.vsqcache = {__proto__: $AAP};
  m.vsresults = [];
  m.favpanel = m.top.$findnode("favPanel");
  m.favbody = m.top.$findnode("favBody");
  m.favtablive = m.top.$findnode("favTabLive");
  m.favtabmovie = m.top.$findnode("favTabMovie");
  m.favhint = m.top.$findnode("favHint");
  m.mode = "home";
  m.homeindex = 6;
  m.catalogready = false;
  m.loadingall = false;
  m.returnmode = "home";
  m.playingitem = null;
  m.movcat = 0;
  m.movidx = 0;
  m.movside = "grid";
  m.favtab = "live";
  m.favidx = 0;
  m.epgurls = [];
  m.librarylist.$observefield("itemSelected", "onLibrarySelected");
  m.categorylist.$observefield("itemFocused", "onCategoryFocused");
  m.categorylist.$observefield("itemSelected", "onCategorySelected");
  m.channellist.$observefield("itemSelected", "onChannelSelected");
  m.channellist.$observefield("itemFocused", "onChannelFocused");
  m.videoplayer.$observefield("state", "onVideoState");
  m.zaptimer.$observefield("fire", "onZapTimer");
  m.clocktimer.$observefield("fire", "onClock");
  m.tunetimer.$observefield("fire", "onTuneTimeout");
  m.searchlist.$observefield("itemSelected", "onSearchSelected");
  m.videoplayer.enabletrickplay = false;
  initcontrols();
  m.sec = $createobject("roRegistrySection", "IPTV_Settings");
  m.wxpanel = m.top.$findnode("wxPanel");
  wxinit();
  m.editindex = (-1);
  m.optionsindex = (-1);
  m.pendingname = "";
  m.pendingurl = "";
  m.curcat = 0;
  m.curchan = 0;
  m.prevcat = (-1);
  m.prevchan = (-1);
  m.hastuned = false;
  m.pip = false;
  m.restorechan = (-1);
  m.restorecat = (-1);
  m.aboutpanel = m.top.$findnode("aboutPanel");
  m.langpanel = m.top.$findnode("langPanel");
  m.langbody = m.top.$findnode("langBody");
  m.langhead = m.top.$findnode("langHead");
  m.langhint = m.top.$findnode("langHint");
  m.langidx = 0;
  m.langfirst = false;
  m.aboutmenu = m.top.$findnode("aboutMenu");
  m.aboutbody = m.top.$findnode("aboutBody");
  m.aboutidx = 0;
  m.pipframe = m.top.$findnode("pipFrame");
  m.piptag = m.top.$findnode("pipTag");
  m.pipname = m.top.$findnode("pipName");
  m.piphint = m.top.$findnode("pipHint");
  m.guidecat = 0;
  m.guiderow = 0;
  m.guidescroll = 0;
  m.guideopen = false;
  m.cursor = 0;
  m.pickindex = 0;
  m.pickscroll = 0;
  m.shownprog = null;
  m.winstart = 0;
  m.winspan = (150 * 60);
  m.gridx = 210;
  m.gridw = 1050;
  m.gridy = 372;
  m.rowh = 50;
  m.visrows = 6;
  m.nowline = null;
  m.rowgroups = [];
  m.fulldraw = true;
  m.drawnscroll = (-1);
  m.drawnrow = (-1);
  m.drawnwin = (-1);
  m.drawncat = (-1);
  m.epg = {__proto__: $AAP, "programs": {__proto__: $AAP}, "names": {__proto__: $AAP}, "icons": {__proto__: $AAP}};
  m.epgstatus = "";
  loadplaylists();
  loadfavs();
  loadactiveset();
  xtinit();
  initbookmarks();
  if ((m.sec.$exists("pref_start") && (m.sec.$read("pref_start") === "movies"))) {
    m.homeindex = 7;
  }
  refreshlibrary();
  updateactivechip();
  xmltranslate();
  m.clocktimer.control = "start";
  m.bgm = m.top.$findnode("bgm");
  m.bgmon = true;
  if ((m.sec.$exists("bgm_off") && (m.sec.$read("bgm_off") === "1"))) {
    m.bgmon = false;
  }
  bgmcontent = $createobject("roSGNode", "ContentNode");
  bgmcontent.url = "pkg:/sounds/ambient.mp3";
  bgmcontent.streamformat = "mp3";
  m.bgm.content = bgmcontent;
  m.bgm.loop = true;
  m.sfx = m.top.$findnode("sfx");
  sfxcontent = $createobject("roSGNode", "ContentNode");
  sfxcontent.url = "pkg:/sounds/chime.mp3";
  sfxcontent.streamformat = "mp3";
  m.sfx.content = sfxcontent;
  m.sfx.$observefield("state", "onSfxState");
  m.videoplayer.$observefield("visible", "onVideoVisible");
  m.adultctx = false;
  m.mtbtnon = false;
  m.mtloading = false;
  m.mtpick = false;
  m.mtchip = 0;
  m.mtfresh = false;
  m.cwshown = false;
  m.cwidx = 0;
  m.cwlist = [];
  startintro();
  opensection("preload");
  m.top.$signalbeacon("AppLaunchComplete");
}

function loadplaylists() {
  let parsed, old;
  m.playlists = [];
  if (m.sec.$exists("playlists")) {
    parsed = $parsejson(m.sec.$read("playlists"));
    if (($type(parsed) === "roArray")) {
      m.playlists = parsed;
    }
  }
  if (((m.playlists.$count() === 0) && m.sec.$exists("saved_url"))) {
    old = m.sec.$read("saved_url");
    if ((old !== "")) {
      m.playlists.$push({__proto__: $AAP, "name": tx("Mi lista"), "url": old, "epg": ""});
      saveplaylists();
    }
  }
  if (m.sec.$exists("saved_url")) {
    m.sec.$delete("saved_url");
    m.sec.$flush();
  }
}

function saveplaylists() {
  m.sec.$write("playlists", $formatjson(m.playlists));
  m.sec.$flush();
}

function epgof(p) {
  if ((p.$doesexist("epg") && ($type(p.epg) === "roString"))) {
    return p.epg;
  }
  return "";
}

function refreshlibrary() {
  let root, p, c;
  root = $createobject("roSGNode", "ContentNode");
  for (p of $iter(m.playlists)) {
    c = root.$createchild("ContentNode");
    c.title = p.name;
    if (isincluded(p.url)) {
      c.shortdescriptionline1 = tx("INCLUIDA");
    }
  }
  c = root.$createchild("ContentNode");
  c.title = tx("+  Agregar lista con el teclado");
  c.starrating = 1;
  c = root.$createchild("ContentNode");
  c.title = tx("+  Agregar lista desde el celular (QR)");
  c.starrating = 1;
  m.librarylist.content = root;
  updatelibrarystatus();
}

function updatelibrarystatus() {
  let ls, names, i, $e1;
  ls = activelists();
  if ((m.playlists.$count() === 0)) {
    m.statuslabel.text = tx("Aun no hay listas. Agrega una.");
  } else if ((ls.$count() === 0)) {
    m.statuslabel.text = tx("Ninguna lista incluida. Elige una y pulsa OK para incluirla.");
  } else {
    names = $ix(ls, 0).name;
    for (i = 1, $e1 = (ls.$count() - 1); i <= $e1; i++) {
      names = ((names + ", ") + $ix(ls, i).name);
    }
    m.statuslabel.text = (tx("En tu catálogo: ") + names);
  }
}

function onlibraryselected() {
  let idx;
  if ((m.mode === "xtlist")) {
    xtselected();
    return;
  }
  idx = m.librarylist.itemselected;
  if ((idx < m.playlists.$count())) {
    showoptions(idx);
  } else if ((idx === m.playlists.$count())) {
    startadd();
  } else {
    showqr();
  }
}

function startepg() {
  let u, url;
  if ((m.epgtask != null)) {
    m.epgtask.control = "STOP";
  }
  m.epg = {__proto__: $AAP, "programs": {__proto__: $AAP}, "names": {__proto__: $AAP}, "icons": {__proto__: $AAP}};
  m.epgqueue = [];
  if (((m.epgurls != null) && (m.epgurls.$count() > 0))) {
    for (u of $iter(m.epgurls)) {
      m.epgqueue.$push(u);
    }
  } else {
    url = "";
    if ((m.loadingplaylist != null)) {
      url = epgof(m.loadingplaylist);
    }
    if ((((url === "") && (m.contenttask != null)) && (m.contenttask.epgurl != null))) {
      url = m.contenttask.epgurl;
    }
    if ((url !== "")) {
      m.epgqueue.$push(url);
    }
  }
  if ((m.epgqueue.$count() === 0)) {
    setepgstatus(tx("Guia: esta lista no trae URL de guia (puedes agregarla al editar la lista)"));
    return;
  }
  loadnextepg();
}

function loadnextepg() {
  let url, wanted, i, $e2, cat, j, $e3, ch, nk;
  if (((m.epgqueue == null) || (m.epgqueue.$count() === 0))) {
    return;
  }
  url = $ix(m.epgqueue, 0);
  m.epgqueue.$delete(0);
  wanted = m.epgwanted;
  if (((((wanted == null) || (wanted.$count() === 0))) && (m.root != null))) {
    wanted = {__proto__: $AAP};
    for (i = 0, $e2 = (m.root.$getchildcount() - 1); i <= $e2; i++) {
      cat = m.root.$getchild(i);
      for (j = 0, $e3 = (cat.$getchildcount() - 1); j <= $e3; j++) {
        ch = cat.$getchild(j);
        if ((ch.id !== "")) {
          $six(wanted, $lcase(ch.id), true);
        }
        nk = normname(ch.title);
        if ((nk !== "")) {
          $six(wanted, nk, true);
        }
      }
    }
  }
  setepgstatus(tx("Guia: cargando (si es .gz puede tardar unos minutos)..."));
  m.epgtask = $createobject("roSGNode", "EpgReader");
  m.epgtask.epgurl = url;
  m.epgtask.wanted = wanted;
  m.epgtask.$observefield("status", "onEpgStatus");
  m.epgtask.$observefield("result", "onEpgLoaded");
  m.epgtask.control = "RUN";
}

function onepgstatus() {
  let text;
  if ((m.epgtask == null)) {
    return;
  }
  text = m.epgtask.status;
  if (((text == null) || (text === ""))) {
    return;
  }
  setepgstatus(text);
}

function onepgloaded() {
  let r, key, msg;
  r = m.epgtask.result;
  if (((r != null) && r.ok)) {
    if ((m.epg == null)) {
      m.epg = {__proto__: $AAP, "programs": {__proto__: $AAP}, "names": {__proto__: $AAP}, "icons": {__proto__: $AAP}};
    }
    if ((r.programs != null)) {
      for (key of $iter(r.programs)) {
        $six(m.epg.programs, key, $ix(r.programs, key));
      }
    }
    if ((r.names != null)) {
      for (key of $iter(r.names)) {
        $six(m.epg.names, key, $ix(r.names, key));
      }
    }
    if ((r.icons != null)) {
      for (key of $iter(r.icons)) {
        $six(m.epg.icons, key, $ix(r.icons, key));
      }
    }
    applyepgicons();
    applynowplaying();
    if (((m.epgqueue != null) && (m.epgqueue.$count() > 0))) {
      loadnextepg();
      return;
    }
    setepgstatus(((tx("Guia actualizada (") + m.epg.programs.$count().$tostr()) + tx(" canales con programacion)")));
  } else {
    if (((m.epgqueue != null) && (m.epgqueue.$count() > 0))) {
      loadnextepg();
      return;
    }
    msg = tx("sin datos");
    if (((r != null) && (r.message != null))) {
      msg = r.message;
    }
    if ((((m.epg != null) && (m.epg.programs != null)) && (m.epg.programs.$count() > 0))) {
      setepgstatus(((tx("Guia parcial (") + m.epg.programs.$count().$tostr()) + tx(" canales)")));
    } else {
      setepgstatus((tx("Guia no disponible: ") + msg));
    }
  }
  m.fulldraw = true;
  if (m.guideopen) {
    buildguide();
  }
}

function setepgstatus(text) {
  m.epgstatus = text;
  m.epgliststatus.text = text;
  m.guidestatus.text = text;
}

function applyepgicons() {
  if (m.listspanel.visible) {
    liveinfosoon();
  }
}

function applyepgiconsall() {
  let changed, i, $e4, cat, j, $e5, ch, cur, u, idx;
  if ((((m.root == null) || (m.epg == null)) || (m.epg.icons == null))) {
    return;
  }
  changed = false;
  for (i = 0, $e4 = (m.root.$getchildcount() - 1); i <= $e4; i++) {
    cat = m.root.$getchild(i);
    for (j = 0, $e5 = (cat.$getchildcount() - 1); j <= $e5; j++) {
      ch = cat.$getchild(j);
      cur = ch.hdposterurl;
      if ((cur == null)) {
        cur = "";
      }
      if ((cur === "")) {
        u = iconfor(ch);
        if ((u !== "")) {
          ch.hdposterurl = u;
          changed = true;
        }
      }
    }
  }
  if ((changed && m.listspanel.visible)) {
    idx = m.categorylist.itemfocused;
    if (((idx >= 0) && (idx < m.root.$getchildcount()))) {
      m.channellist.content = m.root.$getchild(idx);
    }
  }
}

function iconfor(item) {
  let key, nk, k2;
  if ((((item == null) || (m.epg == null)) || (m.epg.icons == null))) {
    return "";
  }
  key = $lcase(item.id);
  if (((key !== "") && m.epg.icons.$doesexist(key))) {
    return $ix(m.epg.icons, key);
  }
  if ((m.epg.names != null)) {
    nk = normname(item.title);
    if (m.epg.names.$doesexist(nk)) {
      k2 = $ix(m.epg.names, nk);
      if (m.epg.icons.$doesexist(k2)) {
        return $ix(m.epg.icons, k2);
      }
    }
  }
  return "";
}

function logoof(item) {
  let u;
  if ((item == null)) {
    return "";
  }
  u = item.hdposterurl;
  if ((u == null)) {
    u = "";
  }
  if ((u !== "")) {
    return u;
  }
  return iconfor(item);
}

function displayname(item) {
  let num;
  if ((item == null)) {
    return "";
  }
  num = item.shortdescriptionline1;
  if ((num == null)) {
    num = "";
  }
  if ((num !== "")) {
    return ((num + "   ") + cleanglyphs(item.title));
  }
  return cleanglyphs(item.title);
}

function getprogs(item) {
  let empty, key, nk, k2;
  empty = [];
  if ((((item == null) || (m.epg == null)) || (m.epg.programs == null))) {
    return empty;
  }
  key = $lcase(item.id);
  if (((key !== "") && m.epg.programs.$doesexist(key))) {
    return $ix(m.epg.programs, key);
  }
  if ((m.epg.names == null)) {
    return empty;
  }
  nk = normname(item.title);
  if (m.epg.names.$doesexist(nk)) {
    k2 = $ix(m.epg.names, nk);
    if (m.epg.programs.$doesexist(k2)) {
      return $ix(m.epg.programs, k2);
    }
  }
  return empty;
}

function getnownext(item) {
  let res, progs, t, i, $e6, p;
  res = {__proto__: $AAP, "cur": null, "nxt": null};
  progs = getprogs(item);
  if ((progs.$count() === 0)) {
    return res;
  }
  t = $createobject("roDateTime").$asseconds();
  for (i = 0, $e6 = (progs.$count() - 1); i <= $e6; i++) {
    p = $ix(progs, i);
    if (((p.s <= t) && (p.e > t))) {
      res.cur = p;
      if (((i + 1) < progs.$count())) {
        res.nxt = $ix(progs, (i + 1));
      }
      break;
    } else if ((p.s > t)) {
      res.nxt = p;
      break;
    }
  }
  return res;
}

function progline(prefix, p) {
  return ((((((prefix + "  ") + fmttime(p.s)) + " - ") + fmttime(p.e)) + "   ") + p.t);
}

function startadd() {
  m.editindex = (-1);
  m.pendingname = "";
  m.pendingurl = "";
  showkeyboard(tx("Nombre de la lista (opcional)"), "", "name");
}

function startedit(index) {
  m.editindex = index;
  m.pendingname = "";
  m.pendingurl = "";
  showkeyboard(tx("Nombre de la lista"), $ix(m.playlists, index).name, "name");
}

function showkeyboard(title, text, stage) {
  let okl;
  okl = tx("Siguiente");
  if (((stage === "search") || (stage === "wxcity"))) {
    okl = tx("Buscar");
  }
  if ((stage === "epg")) {
    okl = tx("Guardar");
  }
  kbopen(title, text, stage, okl);
}

function kbhandle(button, text, stage) {
  let prefill, name, wasactive, entry, oldurl;
  if (($left(stage, 2) === "xt")) {
    xtkeyboarddone(button, text, stage);
    return;
  }
  if ((stage === "wxcity")) {
    if (((button === 0) && (text !== ""))) {
      wxgeo(text);
    } else if ((m.wxlat !== "")) {
      openweather();
    } else {
      showhome();
    }
    return;
  }
  if ((stage === "search")) {
    if (((button === 0) && (text !== ""))) {
      runsearch(text);
    } else {
      showhome();
    }
    return;
  }
  if ((button !== 0)) {
    m.librarylist.$setfocus(true);
    return;
  }
  if ((stage === "name")) {
    m.pendingname = text;
    prefill = "";
    if ((m.editindex >= 0)) {
      prefill = $ix(m.playlists, m.editindex).url;
    }
    showkeyboard(tx("URL de la lista M3U"), prefill, "url");
  } else if ((stage === "url")) {
    if ((text === "")) {
      m.statuslabel.text = tx("La URL no puede estar vacia.");
      m.librarylist.$setfocus(true);
      return;
    }
    m.pendingurl = text;
    prefill = "";
    if ((m.editindex >= 0)) {
      prefill = epgof($ix(m.playlists, m.editindex));
    }
    showkeyboard(tx("URL de guia XMLTV (opcional, vacio = la de tu lista)"), prefill, "epg");
  } else {
    name = m.pendingname;
    wasactive = false;
    entry = null;
    oldurl = "";
    if ((m.editindex >= 0)) {
      oldurl = $ix(m.playlists, m.editindex).url;
    }
    if ((m.editindex >= 0)) {
      if ((name === "")) {
        name = $ix(m.playlists, m.editindex).name;
      }
      wasactive = isincluded($ix(m.playlists, m.editindex).url);
      entry = {__proto__: $AAP, "name": name, "url": m.pendingurl, "epg": text};
      $six(m.playlists, m.editindex, entry);
    } else {
      if ((name === "")) {
        name = (tx("Lista ") + ((m.playlists.$count() + 1)).$tostr());
      }
      entry = {__proto__: $AAP, "name": name, "url": m.pendingurl, "epg": text};
      m.playlists.$push(entry);
    }
    saveplaylists();
    if (((m.editindex >= 0) && m.activeset.$doesexist(oldurl))) {
      m.activeset.$delete(oldurl);
    }
    if (((wasactive || (m.editindex < 0)) || (m.playlists.$count() === 1))) {
      includelist(entry.url);
      opensection("preload");
    }
    refreshlibrary();
    m.statuslabel.text = tx("Lista guardada e incluida en el catálogo.");
    m.librarylist.$setfocus(true);
  }
}

function showoptions(index) {
  let p, dialog;
  m.optionsindex = index;
  p = $ix(m.playlists, index);
  dialog = {__proto__: $AAP, "title": "", "message": [], "buttons": []};
  dialog.title = p.name;
  dialog.message = [p.url];
  if (isincluded(p.url)) {
    dialog.buttons = [tx("Quitar del catálogo"), tx("Usar solo esta"), tx("Editar"), tx("Eliminar"), tx("Cancelar")];
  } else {
    dialog.buttons = [tx("Incluir en el catálogo"), tx("Usar solo esta"), tx("Editar"), tx("Eliminar"), tx("Cancelar")];
  }
  uiask(dialog.title, dialog.message, dialog.buttons, "onOptionsButton");
}

function onoptionsbutton() {
  let button, idx;
  button = m.uibtn;
  idx = m.optionsindex;
  if ((button === 0)) {
    toggleactive(idx);
    refreshlibrary();
    m.librarylist.jumptoitem = idx;
    m.librarylist.$setfocus(true);
  } else if ((button === 1)) {
    setactive($ix(m.playlists, idx));
    showhome();
    m.homestatus.text = ((tx("Cargando ") + $ix(m.playlists, idx).name) + "...");
    opensection("preload");
  } else if ((button === 2)) {
    startedit(idx);
  } else if ((button === 3)) {
    showconfirmdelete(idx);
  } else {
    m.librarylist.$setfocus(true);
  }
}

function showconfirmdelete(index) {
  let dialog;
  dialog = {__proto__: $AAP, "title": "", "message": [], "buttons": []};
  dialog.title = tx("Eliminar esta lista?");
  dialog.message = [$ix(m.playlists, index).name];
  dialog.buttons = [tx("Si, eliminar"), tx("Cancelar")];
  uiask(dialog.title, dialog.message, dialog.buttons, "onDeleteButton");
}

function ondeletebutton() {
  let button, idx, wasactive, delurl;
  button = m.uibtn;
  if ((button === 0)) {
    idx = m.optionsindex;
    if (((idx >= 0) && (idx < m.playlists.$count()))) {
      wasactive = isincluded($ix(m.playlists, idx).url);
      delurl = $ix(m.playlists, idx).url;
      m.playlists.$delete(idx);
      saveplaylists();
      if (m.activeset.$doesexist(delurl)) {
        m.activeset.$delete(delurl);
      }
      if (((m.activeset.$count() === 0) && (m.playlists.$count() > 0))) {
        $six(m.activeset, $ix(m.playlists, 0).url, true);
      }
      saveactiveset();
      if (wasactive) {
        resetcatalog();
        m.needreload = true;
      }
      updateactivechip();
      refreshlibrary();
      m.statuslabel.text = tx("Lista eliminada.");
    }
  }
  m.librarylist.$setfocus(true);
}

function oncategoryfocused() {
  let idx;
  idx = m.categorylist.itemfocused;
  if ((((m.root != null) && (idx >= 0)) && (idx < m.root.$getchildcount()))) {
    m.channellist.content = m.root.$getchild(idx);
    if ((m.restorechan >= 0)) {
      if ((idx === m.restorecat)) {
        m.channellist.jumptoitem = m.restorechan;
      }
      m.restorechan = (-1);
    }
    liveinfosoon();
  }
}

function oncategoryselected() {
  m.channellist.$setfocus(true);
}

function onchannelselected() {
  let idx, catidx, cat, same;
  if ((m.root == null)) {
    return;
  }
  idx = m.channellist.itemselected;
  catidx = m.categorylist.itemfocused;
  cat = m.root.$getchild(catidx);
  if ((((cat != null) && (idx >= 0)) && (idx < cat.$getchildcount()))) {
    same = false;
    if (m.pip) {
      same = ((((catidx === m.curcat) && (idx === m.curchan)) && (m.ovstate !== "fail")));
      leavepiplayout();
    }
    m.playingitem = null;
    m.returnmode = "live";
    m.mode = "video";
    if ((!same)) {
      marktuned(catidx, idx);
    }
    m.listspanel.visible = false;
    m.topbar.visible = false;
    setbganim(false);
    bgmstop();
    m.videoplayer.visible = true;
    capturekeys();
    if ((!same)) {
      tunechannel();
    }
    showbanner("");
  }
}

function currentitem() {
  let cat;
  if ((m.playingitem != null)) {
    return m.playingitem;
  }
  if ((m.root == null)) {
    return null;
  }
  cat = m.root.$getchild(m.curcat);
  if ((cat == null)) {
    return null;
  }
  return cat.$getchild(m.curchan);
}

function marktuned(cat, chan) {
  if (m.hastuned) {
    if (((cat !== m.curcat) || (chan !== m.curchan))) {
      m.prevcat = m.curcat;
      m.prevchan = m.curchan;
    }
  }
  m.curcat = cat;
  m.curchan = chan;
  m.hastuned = true;
}

function tunechannel() {
  let item, video;
  item = currentitem();
  if ((item == null)) {
    return;
  }
  video = $createobject("roSGNode", "ContentNode");
  video.title = displayname(item);
  video.url = item.url;
  video.streamformat = item.streamformat;
  video.live = true;
  m.alttried = false;
  stabreset();
  m.videoplayer.control = "stop";
  m.videoplayer.content = video;
  m.videoplayer.control = "play";
  showoverlay("loading");
}

function zap(delta) {
  let cat, n;
  if ((m.playingitem != null)) {
    return;
  }
  cat = m.root.$getchild(m.curcat);
  if ((cat == null)) {
    return;
  }
  n = cat.$getchildcount();
  if ((n === 0)) {
    return;
  }
  marktuned(m.curcat, ((((m.curchan + delta) + n)) % n));
  tunechannel();
  showbanner("");
}

function replaylast() {
  let cat, pc, ph;
  if ((m.playingitem != null)) {
    return;
  }
  if (((m.prevcat < 0) || (m.root == null))) {
    return;
  }
  cat = m.root.$getchild(m.prevcat);
  if ((cat == null)) {
    return;
  }
  if (((m.prevchan < 0) || (m.prevchan >= cat.$getchildcount()))) {
    return;
  }
  pc = m.curcat;
  ph = m.curchan;
  m.curcat = m.prevcat;
  m.curchan = m.prevchan;
  m.prevcat = pc;
  m.prevchan = ph;
  tunechannel();
  showbanner("");
  if (m.guideopen) {
    m.guidecat = m.curcat;
    m.guiderow = m.curchan;
    m.fulldraw = true;
    buildguide();
  }
}

function showbanner(errormsg) {
  let item, logo, nn, heart;
  item = currentitem();
  if ((item == null)) {
    return;
  }
  m.zapchannel.text = displayname(item);
  logo = logoof(item);
  m.zaplogo.uri = logo;
  m.zaplogo.visible = ((logo !== ""));
  nn = getnownext(item);
  if ((nn.cur != null)) {
    m.zapnow.text = progline(tx("AHORA"), nn.cur);
  } else {
    m.zapnow.text = tx("AHORA  (sin informacion de guia)");
  }
  heart = tx("OK: controles");
  m.zapheart.uri = "pkg:/images/heart_off.png";
  if ((((m.favmap != null) && (item.url != null)) && m.favmap.$doesexist(item.url))) {
    heart = tx("En favoritos  /  OK: controles");
    m.zapheart.uri = "pkg:/images/heart_on.png";
  }
  if ((errormsg !== "")) {
    m.zapnext.text = errormsg;
  } else if ((item.description === "movie")) {
    m.zapnext.text = (heart + tx("     Atras: volver"));
  } else if ((nn.nxt != null)) {
    m.zapnext.text = progline(tx("DESPUES"), nn.nxt);
  } else {
    m.zapnext.text = (heart + tx("     Izquierda: guia     Arriba/Abajo: canal     Atras: volver"));
  }
  m.ctlbar.visible = false;
  m.ctlopen = false;
  m.zapbanner.visible = true;
  m.zaptimer.control = "stop";
  m.zaptimer.control = "start";
}

function bgmstart() {
  let st;
  if (((m.bgm == null) || (!m.bgmon))) {
    return;
  }
  if (m.videoplayer.visible) {
    return;
  }
  st = m.bgm.state;
  if (((st === "playing") || (st === "buffering"))) {
    return;
  }
  m.bgm.control = "play";
}

function bgmstop() {
  if ((m.bgm == null)) {
    return;
  }
  m.bgm.control = "stop";
}

function onvideovisible() {
  if (m.videoplayer.visible) {
    bgmstop();
  } else {
    bgmstart();
  }
}

function togglebgm() {
  m.bgmon = (!m.bgmon);
  if (m.bgmon) {
    m.sec.$write("bgm_off", "0");
    bgmstart();
    m.homestatus.text = tx("Sonido de fondo: activado");
  } else {
    m.sec.$write("bgm_off", "1");
    bgmstop();
    m.homestatus.text = tx("Sonido de fondo: desactivado");
  }
  m.sec.$flush();
}

function onzaptimer() {
  m.zapbanner.visible = false;
}

function onclock() {
  let mn, nowsecs, redraw;
  updatetopclock();
  if (((m.mode === "live") && m.listspanel.visible)) {
    mn = $int(($createobject("roDateTime").$asseconds() / 60));
    if ((mn !== m.livemin)) {
      m.livemin = mn;
      liveinfosoon();
    }
  }
  if ((!m.guideopen)) {
    return;
  }
  updateclock();
  nowsecs = $createobject("roDateTime").$asseconds();
  redraw = false;
  if (m.follownow) {
    m.cursor = nowsecs;
    if ((nowsecs >= ((m.winstart + m.winspan) - 600))) {
      m.winstart = alignhalfhour(nowsecs);
      m.fulldraw = true;
      redraw = true;
    }
    if ((m.shownprog != null)) {
      if ((m.shownprog.e <= nowsecs)) {
        redraw = true;
      }
    }
  }
  if (updatestrips(nowsecs)) {
    m.fulldraw = true;
    redraw = true;
  }
  if (redraw) {
    buildguide();
  } else {
    refreshnowline();
    updateprogress(m.shownprog);
  }
}

function initstability() {
  m.recontimer = $createobject("roSGNode", "Timer");
  m.recontimer.repeat = false;
  m.top.$appendchild(m.recontimer);
  m.recontimer.$observefield("fire", "onReconTimer");
  m.stalltimer = $createobject("roSGNode", "Timer");
  m.stalltimer.repeat = false;
  m.stalltimer.duration = 14;
  m.top.$appendchild(m.stalltimer);
  m.stalltimer.$observefield("fire", "onStallTimer");
  m.stabclock = $createobject("roTimespan");
  m.liveok = false;
  m.recontries = 0;
  m.playstartat = 0;
  m.reconactive = false;
}

function stabreset() {
  if ((m.recontimer == null)) {
    initstability();
  }
  m.liveok = false;
  m.recontries = 0;
  m.reconactive = false;
  m.recontimer.control = "stop";
  m.stalltimer.control = "stop";
}

function stabismovie() {
  return ((m.playingitem != null) && (m.playingitem.description === "movie"));
}

function onvideostate() {
  let state, dur, vpos;
  if ((m.recontimer == null)) {
    initstability();
  }
  state = m.videoplayer.state;
  if ((state === "playing")) {
    m.stalltimer.control = "stop";
    hideoverlay();
    m.liveok = true;
    m.reconactive = false;
    m.playstartat = m.stabclock.$totalmilliseconds();
    bmonplaying();
  } else if ((state === "buffering")) {
    if (m.liveok) {
      m.stalltimer.control = "stop";
      m.stalltimer.control = "start";
    }
  } else if ((state === "error")) {
    if (m.liveok) {
      stabreconnect();
      return;
    }
    if (tryaltformat()) {
      return;
    }
    if (m.reconactive) {
      stabreconnect();
      return;
    }
    showoverlay("fail");
  } else if ((state === "finished")) {
    if (stabismovie()) {
      dur = m.videoplayer.duration;
      vpos = m.videoplayer.position;
      if (((((dur == null) || (dur <= 0)) || (vpos == null)) || (vpos >= (dur - 30)))) {
        stopvideo();
      } else {
        stabreconnect();
      }
    } else if ((m.liveok || m.reconactive)) {
      stabreconnect();
    } else {
      showoverlay("fail");
    }
  }
}

function onstalltimer() {
  if ((m.videoplayer.visible && (m.videoplayer.state === "buffering"))) {
    stabreconnect();
  }
}

function stabreconnect() {
  let vpos, delays, item, nm;
  if ((!m.videoplayer.visible)) {
    return;
  }
  if (((m.playstartat > 0) && ((m.stabclock.$totalmilliseconds() - m.playstartat) > 45000))) {
    m.recontries = 0;
  }
  if ((m.recontries >= 5)) {
    m.reconactive = false;
    showoverlay("fail");
    return;
  }
  m.recontries = (m.recontries + 1);
  m.reconactive = true;
  m.liveok = false;
  m.stalltimer.control = "stop";
  if (stabismovie()) {
    vpos = m.videoplayer.position;
    if (((vpos != null) && (vpos > 5))) {
      m.resumepos = ($int(vpos) - 3);
    }
  }
  delays = [0.4, 1.5, 3.0, 5.0, 8.0];
  m.recontimer.duration = $ix(delays, (m.recontries - 1));
  m.recontimer.control = "stop";
  m.recontimer.control = "start";
  showoverlay("loading");
  m.ovtitle.text = tx("Reconectando...");
  item = currentitem();
  nm = "";
  if ((item != null)) {
    nm = displayname(item);
  }
  m.ovsub.text = ((tx("Recuperando la señal") + "  ·  ") + nm);
  m.tunetimer.control = "stop";
}

function onrecontimer() {
  let c, vid;
  if ((!m.videoplayer.visible)) {
    return;
  }
  c = m.videoplayer.content;
  if ((c == null)) {
    return;
  }
  vid = $createobject("roSGNode", "ContentNode");
  vid.title = c.title;
  vid.url = c.url;
  vid.streamformat = c.streamformat;
  if ((!stabismovie())) {
    vid.live = true;
  }
  m.videoplayer.control = "stop";
  m.videoplayer.content = vid;
  m.videoplayer.control = "play";
  m.tunetimer.control = "stop";
  m.tunetimer.control = "start";
}

function ontunetimeout() {
  if ((m.ovstate === "loading")) {
    if (m.reconactive) {
      stabreconnect();
      return;
    }
    if (tryaltformat()) {
      return;
    }
    showoverlay("fail");
  }
}

function tryaltformat() {
  let c, fmt, alt, url, low, isxtlive, vid;
  if ((m.alttried === true)) {
    return false;
  }
  c = m.videoplayer.content;
  if ((((c == null) || (c.url == null)) || (c.url === ""))) {
    return false;
  }
  fmt = c.streamformat;
  alt = "";
  url = c.url;
  low = $lcase(url);
  isxtlive = (($instr(1, low, "/live/") > 0));
  if ((fmt === "hls")) {
    if (($instr(1, low, ".m3u8") === 0)) {
      alt = "ts";
    } else if ((isxtlive && ($right(low, 5) === ".m3u8"))) {
      alt = "ts";
      url = ($left(url, ($len(url) - 5)) + ".ts");
    }
  } else if ((fmt === "ts")) {
    alt = "hls";
    if ((isxtlive && ($right(low, 3) === ".ts"))) {
      url = ($left(url, ($len(url) - 3)) + ".m3u8");
    }
  }
  if ((alt === "")) {
    return false;
  }
  m.alttried = true;
  vid = $createobject("roSGNode", "ContentNode");
  vid.title = c.title;
  vid.url = url;
  vid.streamformat = alt;
  m.videoplayer.control = "stop";
  m.videoplayer.content = vid;
  m.videoplayer.control = "play";
  showoverlay("loading");
  return true;
}

function showoverlay(state) {
  let name, item;
  m.ovstate = state;
  name = "";
  item = currentitem();
  if ((item != null)) {
    name = displayname(item);
  }
  if ((state === "loading")) {
    m.ovbg.color = "0x090A0CD8";
    m.ovtitle.text = tx("Conectando...");
    m.ovsub.text = name;
    m.ovhint.text = tx("Atrás: volver");
    m.ovbar.visible = true;
    m.pulseanim.control = "start";
    m.baranim.control = "start";
    m.tunetimer.control = "stop";
    m.tunetimer.control = "start";
  } else {
    m.ovbg.color = "0x090A0CF5";
    m.ovtitle.text = tx("Canal no disponible");
    m.ovsub.text = ((tx("No se pudo conectar con ") + name) + tx(". Puede estar fuera de servicio por ahora."));
    m.ovhint.text = tx("OK: reintentar     Arriba/Abajo: otro canal     Atrás: volver");
    if ((m.playingitem != null)) {
      m.ovhint.text = tx("OK: reintentar     Atrás: volver");
    }
    m.pulseanim.control = "stop";
    m.baranim.control = "stop";
    m.ovlogo.opacity = 1.0;
    m.ovbar.visible = false;
    m.tunetimer.control = "stop";
  }
  layoutoverlay();
  m.overlay.visible = true;
}

function hideoverlay() {
  m.ovstate = "";
  m.overlay.visible = false;
  m.pulseanim.control = "stop";
  m.baranim.control = "stop";
  m.tunetimer.control = "stop";
}

function layoutoverlay() {
  if (m.pip) {
    m.overlay.translation = [846, 94];
    m.overlay.scale = [0.2805, 0.2805];
    m.ovsub.visible = false;
    m.ovhint.visible = false;
  } else if (m.guideopen) {
    m.overlay.translation = [61, 37];
    m.overlay.scale = [0.35625, 0.35625];
    m.ovsub.visible = false;
    m.ovhint.visible = false;
  } else {
    m.overlay.translation = [0, 0];
    m.overlay.scale = [1, 1];
    m.ovsub.visible = true;
    m.ovhint.visible = true;
  }
}

function retrycurrent() {
  if ((m.playingitem != null)) {
    playnode(m.playingitem, m.returnmode);
  } else {
    tunechannel();
    showbanner("");
  }
}

function stopvideo() {
  let backto;
  stabreset();
  bmsavenow();
  m.bmtimer.control = "stop";
  hideoverlay();
  hidecontrols();
  m.videoplayer.control = "stop";
  closeguidelayout();
  m.zapbanner.visible = false;
  m.videoplayer.visible = false;
  m.playingitem = null;
  backto = m.returnmode;
  if ((backto === "episodes")) {
    reshowepisodes();
  } else if ((backto === "movies")) {
    showmovies();
  } else if ((backto === "adult")) {
    showadult();
  } else if ((backto === "mosaic")) {
    showmosaic();
  } else if ((backto === "matches")) {
    showmatches();
  } else if ((backto === "cw")) {
    if ((m.cwback === "series")) {
      showserieslist();
    } else {
      showmovies();
    }
  } else if ((backto === "detail")) {
    reshowdetail();
  } else if ((backto === "favs")) {
    showfavs();
  } else if ((backto === "search")) {
    showsearchresults();
  } else if ((backto === "live")) {
    showlive();
  } else {
    showhome();
  }
}

function openguide() {
  let nowsecs;
  if (((m.root == null) || (!m.videoplayer.visible))) {
    return;
  }
  if (((m.returnmode === "adult") || (((m.playingitem != null) && (m.playingitem.description === "movie"))))) {
    showbanner("");
    return;
  }
  m.guideopen = true;
  m.zapbanner.visible = false;
  m.catpicker.visible = false;
  m.videoplayer.translation = [61, 37];
  m.videoplayer.width = 456;
  m.videoplayer.height = 256;
  m.guidebg.visible = true;
  m.guidepanel.visible = true;
  layoutoverlay();
  m.guidecat = m.curcat;
  m.guiderow = m.curchan;
  m.guidescroll = 0;
  m.fulldraw = true;
  nowsecs = $createobject("roDateTime").$asseconds();
  m.cursor = nowsecs;
  m.follownow = true;
  m.winspan = (150 * 60);
  m.winstart = alignhalfhour(nowsecs);
  updateclock();
  buildguide();
  capturekeys();
}

function closeguidelayout() {
  m.guideopen = false;
  m.catpicker.visible = false;
  m.guidebg.visible = false;
  m.guidepanel.visible = false;
  m.nowline = null;
  m.fulldraw = true;
  m.videoplayer.translation = [0, 0];
  m.videoplayer.width = 1280;
  m.videoplayer.height = 720;
  layoutoverlay();
}

function closeguide() {
  closeguidelayout();
  capturekeys();
  showbanner("");
}

function buildguide() {
  let cat, n, item, old;
  if (((!m.guideopen) || (m.root == null))) {
    return;
  }
  cat = m.root.$getchild(m.guidecat);
  if ((cat == null)) {
    return;
  }
  n = cat.$getchildcount();
  if ((n === 0)) {
    return;
  }
  if ((m.guiderow < 0)) {
    m.guiderow = 0;
  }
  if ((m.guiderow >= n)) {
    m.guiderow = (n - 1);
  }
  if ((m.guiderow < m.guidescroll)) {
    m.guidescroll = m.guiderow;
  }
  if ((m.guiderow >= (m.guidescroll + m.visrows))) {
    m.guidescroll = ((m.guiderow - m.visrows) + 1);
  }
  if ((m.guidescroll < 0)) {
    m.guidescroll = 0;
  }
  item = cat.$getchild(m.guiderow);
  updatetopinfo(cat, item);
  if (((((m.fulldraw || (m.guidescroll !== m.drawnscroll)) || (m.winstart !== m.drawnwin)) || (m.guidecat !== m.drawncat)) || (m.rowgroups.$count() === 0))) {
    drawgrid(cat, n);
  } else {
    old = m.drawnrow;
    m.drawnrow = m.guiderow;
    if ((old !== m.guiderow)) {
      redrawrow(old);
    }
    redrawrow(m.guiderow);
  }
}

function updatetopinfo(cat, item) {
  let logo, progs, idx, p, nowsecs, badge;
  m.guidecatlabel.text = cat.title;
  m.guideday.text = fmtday(m.winstart);
  m.guidechannelname.text = displayname(item);
  if (((m.guidecat === m.curcat) && (m.guiderow === m.curchan))) {
    m.guidechannelname.text = (tx("EN VIVO   ") + m.guidechannelname.text);
  }
  logo = logoof(item);
  if ((logo !== "")) {
    m.guidelogo.uri = logo;
    m.guidelogo.visible = true;
    m.guidechannelname.translation = [612, 46];
  } else {
    m.guidelogo.uri = "";
    m.guidelogo.visible = false;
    m.guidechannelname.translation = [530, 46];
  }
  progs = getprogs(item);
  idx = progatcursor(progs);
  p = null;
  if ((idx >= 0)) {
    p = $ix(progs, idx);
  }
  m.shownprog = p;
  if ((p == null)) {
    m.guidenow.text = tx("Sin información de programación");
    m.guidedesc.text = "";
    m.guidewhen.text = "";
    updateprogress(null);
    return;
  }
  nowsecs = $createobject("roDateTime").$asseconds();
  badge = tx("DESPUÉS");
  if (((p.s <= nowsecs) && (p.e > nowsecs))) {
    badge = tx("AHORA");
  } else if ((p.e <= nowsecs)) {
    badge = tx("YA EMITIDO");
  }
  m.guidenow.text = ((badge + "   ") + p.t);
  if (($len(m.guidenow.text) > 38)) {
    m.guidenow.font = "font:MediumBoldSystemFont";
  } else {
    m.guidenow.font = "font:LargeBoldSystemFont";
  }
  m.guidedesc.text = p.d;
  m.guidewhen.text = ((fmttimelong(p.s) + " - ") + fmttimelong(p.e));
  updateprogress(p);
}

function updateprogress(p) {
  let nowsecs, dur, frac, fw, pct;
  m.proghead.visible = false;
  if ((p == null)) {
    m.progfill.width = 0;
    m.proginfo.text = "";
    return;
  }
  nowsecs = $createobject("roDateTime").$asseconds();
  dur = (p.e - p.s);
  if ((((dur > 0) && (nowsecs >= p.s)) && (nowsecs < p.e))) {
    frac = (((nowsecs - p.s)) / dur);
    fw = $int((m.progw * frac));
    if ((fw < 3)) {
      fw = 3;
    }
    if ((fw > m.progw)) {
      fw = m.progw;
    }
    m.progfill.color = "0xFF8A24FF";
    m.progfill.width = fw;
    m.proghead.translation = [((530 + fw) - 2), 159];
    m.proghead.visible = true;
    pct = $int((frac * 100));
    m.proginfo.color = "0xFF8A24FF";
    m.proginfo.text = ((pct.$tostr() + "%  ·  ") + fmtdur((p.e - nowsecs)));
  } else if ((nowsecs < p.s)) {
    m.progfill.width = 0;
    m.proginfo.color = "0xA8ADB5FF";
    m.proginfo.text = (tx("en ") + fmtdur((p.s - nowsecs)));
  } else {
    m.progfill.color = "0x5A5F6AFF";
    m.progfill.width = m.progw;
    m.proginfo.color = "0xA8ADB5FF";
    m.proginfo.text = "emitido";
  }
}

function fmtdur(secs) {
  let mins, h, r;
  if ((secs < 60)) {
    return tx("1 min");
  }
  mins = $int((((secs + 59)) / 60));
  if ((mins < 60)) {
    return (mins.$tostr() + tx(" min"));
  }
  h = $idiv(mins, 60);
  r = (mins - (h * 60));
  if ((r === 0)) {
    return (h.$tostr() + tx(" h"));
  }
  return (((h.$tostr() + tx(" h ")) + r.$tostr()) + tx(" min"));
}

function updatestrips(nowsecs) {
  let ended, key, st, x2, fw;
  ended = false;
  if ((m.livestrips == null)) {
    return false;
  }
  for (key of $iter(m.livestrips)) {
    st = $ix(m.livestrips, key);
    if ((nowsecs >= st.e)) {
      ended = true;
    } else {
      x2 = timetox(nowsecs);
      fw = (x2 - st.x1);
      if ((fw < 0)) {
        fw = 0;
      }
      if ((fw > st.w)) {
        fw = st.w;
      }
      st.rect.width = fw;
    }
  }
  return ended;
}

function updateclock() {
  m.guideclock.text = fmttimelong($createobject("roDateTime").$asseconds());
}

function drawgrid(cat, n) {
  let winend, s, $e7, secs, x, lx, slot, $e8, g, idx, nowsecs;
  clearnode(m.guidegrid);
  m.nowline = null;
  m.livestrips = {__proto__: $AAP};
  m.rowgroups = [];
  winend = (m.winstart + m.winspan);
  addrect(m.guidegrid, 0, m.gridy, 1280, (m.visrows * m.rowh), "0x101015FF");
  addrect(m.guidegrid, m.gridx, 334, m.gridw, 36, "0x00000055");
  for (s = 0, $e7 = 5; s <= $e7; s++) {
    secs = (m.winstart + (s * 1800));
    x = timetox(secs);
    addrect(m.guidegrid, x, 334, 1, (36 + (m.visrows * m.rowh)), "0xFFFFFF18");
    lx = (x + 6);
    if ((s === 5)) {
      lx = (x - 78);
    }
    addlabel(m.guidegrid, lx, 340, 120, fmttime(secs), "0xA8ADB5FF", "font:SmallSystemFont");
  }
  for (slot = 0, $e8 = (m.visrows - 1); slot <= $e8; slot++) {
    g = $createobject("roSGNode", "Group");
    g.translation = [0, (m.gridy + (slot * m.rowh))];
    m.guidegrid.$appendchild(g);
    m.rowgroups.$push(g);
    idx = (m.guidescroll + slot);
    if ((idx < n)) {
      fillrow(g, cat.$getchild(idx), idx);
    }
  }
  nowsecs = $createobject("roDateTime").$asseconds();
  if (((nowsecs >= m.winstart) && (nowsecs <= winend))) {
    m.nowline = addrect(m.guidegrid, timetox(nowsecs), m.gridy, 2, (m.visrows * m.rowh), "0xFF5555FF");
  }
  m.drawnscroll = m.guidescroll;
  m.drawnrow = m.guiderow;
  m.drawnwin = m.winstart;
  m.drawncat = m.guidecat;
  m.fulldraw = false;
}

function fillrow(g, ch, i) {
  let nows, winend, focused, playing, logo, nl, namecolor, progs, sel, drew, pi, $e9, p, a, b, x1, x2, w, color, tcolor, trackcolor, fillcolor, fw, fr;
  clearnode(g);
  if ((m.livestrips != null)) {
    m.livestrips.$delete(i.$tostr());
  }
  if ((ch == null)) {
    return;
  }
  nows = $createobject("roDateTime").$asseconds();
  winend = (m.winstart + m.winspan);
  focused = ((i === m.guiderow));
  playing = (((m.guidecat === m.curcat) && (i === m.curchan)));
  if (focused) {
    addrect(g, 0, 0, 1280, (m.rowh - 2), "0xFFFFFF30");
  }
  if (playing) {
    addrect(g, 0, 0, 5, (m.rowh - 2), "0xFF8A24FF");
  }
  logo = logoof(ch);
  if ((logo !== "")) {
    addposter(g, 14, 6, 64, 36, logo);
  } else {
    nl = addposter(g, 34, 10, 26, 26, "pkg:/images/ic_live.png");
    nl.blendcolor = "0x8A8F98FF";
    nl.opacity = 0.45;
  }
  namecolor = "0xFFFFFFFF";
  if (focused) {
    namecolor = "0xFF8A24FF";
  }
  addlabel(g, 86, 12, 118, fittext(displayname(ch), 118), namecolor, "font:SmallBoldSystemFont");
  progs = getprogs(ch);
  sel = (-1);
  if (focused) {
    sel = progatcursor(progs);
  }
  drew = false;
  for (pi = 0, $e9 = (progs.$count() - 1); pi <= $e9; pi++) {
    p = $ix(progs, pi);
    if (((p.e > m.winstart) && (p.s < winend))) {
      a = p.s;
      if ((a < m.winstart)) {
        a = m.winstart;
      }
      b = p.e;
      if ((b > winend)) {
        b = winend;
      }
      if ((b > a)) {
        x1 = timetox(a);
        x2 = timetox(b);
        w = ((x2 - x1) - 4);
        if ((w >= 2)) {
          drew = true;
          color = "0x25252DFF";
          tcolor = "0xFFFFFFFF";
          if ((focused && (pi === sel))) {
            color = "0xFF8A24FF";
            tcolor = "0x1A1210FF";
          } else if (focused) {
            color = "0x3B3438FF";
          }
          addrect(g, (x1 + 2), 6, w, (m.rowh - 14), color);
          if ((w >= 36)) {
            addlabel(g, (x1 + 8), 12, (w - 12), fittext(p.t, (w - 12)), tcolor, "font:SmallSystemFont");
          }
          if ((((p.s <= nows) && (p.e > nows)) && (w >= 8))) {
            trackcolor = "0xFFFFFF26";
            fillcolor = "0xFF8A24FF";
            if ((focused && (pi === sel))) {
              trackcolor = "0x1A121033";
              fillcolor = "0x1A1210FF";
            }
            addrect(g, (x1 + 2), (m.rowh - 14), w, 4, trackcolor);
            fw = (timetox(nows) - x1);
            if ((fw < 0)) {
              fw = 0;
            }
            if ((fw > w)) {
              fw = w;
            }
            fr = addrect(g, (x1 + 2), (m.rowh - 14), fw, 4, fillcolor);
            if ((m.livestrips != null)) {
              $six(m.livestrips, i.$tostr(), {__proto__: $AAP, "rect": fr, "x1": x1, "w": w, "e": p.e});
            }
          }
        }
      }
    }
  }
  if ((!drew)) {
    addrect(g, (m.gridx + 2), 6, (m.gridw - 4), (m.rowh - 14), "0x1B1B22FF");
    addlabel(g, (m.gridx + 10), 14, 320, tx("Sin programación"), "0xA8ADB5FF", "font:SmallSystemFont");
  }
  addrect(g, 0, (m.rowh - 2), 1280, 1, "0xFFFFFF16");
}

function redrawrow(absidx) {
  let cat, slot;
  cat = m.root.$getchild(m.guidecat);
  if ((cat == null)) {
    return;
  }
  slot = (absidx - m.guidescroll);
  if (((slot < 0) || (slot >= m.visrows))) {
    return;
  }
  if ((slot >= m.rowgroups.$count())) {
    return;
  }
  fillrow($ix(m.rowgroups, slot), cat.$getchild(absidx), absidx);
}

function refreshnowline() {
  let nowsecs, winend;
  if ((m.nowline == null)) {
    return;
  }
  nowsecs = $createobject("roDateTime").$asseconds();
  winend = (m.winstart + m.winspan);
  if (((nowsecs < m.winstart) || (nowsecs > winend))) {
    m.nowline.visible = false;
    return;
  }
  m.nowline.visible = true;
  m.nowline.translation = [timetox(nowsecs), m.gridy];
}

function progatcursor(progs) {
  let n, best, i, $e10, p;
  if ((progs == null)) {
    return (-1);
  }
  n = progs.$count();
  if ((n === 0)) {
    return (-1);
  }
  best = (-1);
  for (i = 0, $e10 = (n - 1); i <= $e10; i++) {
    p = $ix(progs, i);
    if (((p.s <= m.cursor) && (p.e > m.cursor))) {
      return i;
    }
    if ((p.s > m.cursor)) {
      return i;
    }
    best = i;
  }
  return best;
}

function focusedguideitem() {
  let cat;
  if ((m.root == null)) {
    return null;
  }
  cat = m.root.$getchild(m.guidecat);
  if ((cat == null)) {
    return null;
  }
  return cat.$getchild(m.guiderow);
}

function moveguiderow(delta) {
  let cat, n, nxt;
  cat = m.root.$getchild(m.guidecat);
  if ((cat == null)) {
    return;
  }
  n = cat.$getchildcount();
  if ((n === 0)) {
    return;
  }
  nxt = (m.guiderow + delta);
  if (((nxt < 0) || (nxt >= n))) {
    return;
  }
  m.guiderow = nxt;
  buildguide();
}

function moveprog(delta) {
  let item, progs, idx, moved, nidx, p, nowsecs;
  item = focusedguideitem();
  progs = getprogs(item);
  idx = progatcursor(progs);
  moved = false;
  if ((idx >= 0)) {
    nidx = (idx + delta);
    if (((nidx >= 0) && (nidx < progs.$count()))) {
      p = $ix(progs, nidx);
      nowsecs = $createobject("roDateTime").$asseconds();
      if (((p.s <= nowsecs) && (p.e > nowsecs))) {
        m.cursor = nowsecs;
        m.follownow = true;
      } else {
        m.cursor = (p.s + 30);
        m.follownow = false;
      }
      moved = true;
    }
  }
  if ((!moved)) {
    m.cursor = (m.cursor + (delta * 1800));
    m.follownow = false;
  }
  clampcursor();
  ensurecursorvisible();
  buildguide();
}

function clampcursor() {
  let nowsecs, minc, maxc;
  nowsecs = $createobject("roDateTime").$asseconds();
  minc = (nowsecs - (6 * 3600));
  maxc = (nowsecs + (18 * 3600));
  if ((m.cursor < minc)) {
    m.cursor = minc;
  }
  if ((m.cursor > maxc)) {
    m.cursor = maxc;
  }
}

function ensurecursorvisible() {
  if (((m.cursor < m.winstart) || (m.cursor >= (m.winstart + m.winspan)))) {
    m.winstart = alignhalfhour(m.cursor);
  }
  shiftwindow(0);
  if ((m.cursor < m.winstart)) {
    m.cursor = (m.winstart + 30);
  }
  if ((m.cursor >= (m.winstart + m.winspan))) {
    m.cursor = ((m.winstart + m.winspan) - 30);
  }
}

function shiftwindow(delta) {
  let nowsecs, minstart, maxstart;
  nowsecs = $createobject("roDateTime").$asseconds();
  minstart = (alignhalfhour(nowsecs) - (6 * 3600));
  maxstart = (alignhalfhour(nowsecs) + (18 * 3600));
  m.winstart = (m.winstart + delta);
  if ((m.winstart < minstart)) {
    m.winstart = minstart;
  }
  if ((m.winstart > maxstart)) {
    m.winstart = maxstart;
  }
}

function alignhalfhour(secs) {
  let dt, drop;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  drop = ((((dt.$getminutes() % 30)) * 60) + dt.$getseconds());
  return (secs - drop);
}

function timetox(secs) {
  let rel;
  rel = (secs - m.winstart);
  if ((rel < 0)) {
    rel = 0;
  }
  if ((rel > m.winspan)) {
    rel = m.winspan;
  }
  return (m.gridx + $int((((rel / m.winspan)) * m.gridw)));
}

function playhighlighted(gofull) {
  let cat;
  if ((m.root == null)) {
    return;
  }
  cat = m.root.$getchild(m.guidecat);
  if ((cat == null)) {
    return;
  }
  if (((m.guiderow < 0) || (m.guiderow >= cat.$getchildcount()))) {
    return;
  }
  if (((m.guidecat !== m.curcat) || (m.guiderow !== m.curchan))) {
    marktuned(m.guidecat, m.guiderow);
    tunechannel();
  }
  if (gofull) {
    closeguide();
  } else {
    m.fulldraw = true;
    buildguide();
  }
}

function opencatpicker() {
  if (((m.root == null) || (m.root.$getchildcount() === 0))) {
    return;
  }
  m.pickindex = m.guidecat;
  if ((m.pickindex < 0)) {
    m.pickindex = 0;
  }
  m.pickscroll = 0;
  m.catpicker.visible = true;
  drawcatpicker();
  capturekeys();
}

function drawcatpicker() {
  let n, vis, last, row, i, $e11, y, title;
  clearnode(m.catpickergrid);
  n = m.root.$getchildcount();
  if ((n === 0)) {
    return;
  }
  if ((m.pickindex >= n)) {
    m.pickindex = (n - 1);
  }
  vis = 10;
  if ((m.pickindex < m.pickscroll)) {
    m.pickscroll = m.pickindex;
  }
  if ((m.pickindex >= (m.pickscroll + vis))) {
    m.pickscroll = ((m.pickindex - vis) + 1);
  }
  last = ((m.pickscroll + vis) - 1);
  if ((last >= n)) {
    last = (n - 1);
  }
  row = 0;
  for (i = m.pickscroll, $e11 = last; i <= $e11; i++) {
    y = (row * 48);
    title = cleanglyphs(m.root.$getchild(i).title);
    if ((i === m.pickindex)) {
      addrect(m.catpickergrid, 0, y, 420, 44, "0xFF8A24FF");
      addlabel(m.catpickergrid, 16, (y + 8), 390, fittext(title, 390), "0x1A1210FF", "font:MediumBoldSystemFont");
    } else {
      addlabel(m.catpickergrid, 16, (y + 8), 390, fittext(title, 390), "0xFFFFFFFF", "font:MediumSystemFont");
    }
    row = (row + 1);
  }
}

function movepick(delta) {
  let n, nxt;
  if ((m.root == null)) {
    return;
  }
  n = m.root.$getchildcount();
  nxt = (m.pickindex + delta);
  if (((nxt < 0) || (nxt >= n))) {
    return;
  }
  m.pickindex = nxt;
  drawcatpicker();
}

function acceptcategory() {
  m.catpicker.visible = false;
  m.guidecat = m.pickindex;
  m.guiderow = 0;
  m.guidescroll = 0;
  m.fulldraw = true;
  capturekeys();
  buildguide();
}

function capturekeys() {
  m.channellist.$setfocus(false);
  m.categorylist.$setfocus(false);
  m.librarylist.$setfocus(false);
  m.background.$setfocus(true);
  if ((!m.background.$hasfocus())) {
    m.top.$setfocus(true);
  }
}

function clearnode(n) {
  if ((n == null)) {
    return;
  }
  while ((n.$getchildcount() > 0)) {
    n.$removechildindex((n.$getchildcount() - 1));
  }
}

function addrect(parent, x, y, w, h, color) {
  let r;
  r = $createobject("roSGNode", "Rectangle");
  r.translation = [x, y];
  r.width = w;
  r.height = h;
  r.color = color;
  parent.$appendchild(r);
  return r;
}

function addlabel(parent, x, y, w, text, color, font) {
  let l;
  l = $createobject("roSGNode", "Label");
  l.translation = [x, y];
  l.width = w;
  l.height = 28;
  l.text = text;
  l.color = color;
  l.font = font;
  parent.$appendchild(l);
  return l;
}

function addposter(parent, x, y, w, h, uri) {
  let p;
  p = $createobject("roSGNode", "Poster");
  p.translation = [x, y];
  p.width = w;
  p.height = h;
  p.loadwidth = w;
  p.loadheight = h;
  p.loaddisplaymode = "scaleToFit";
  p.uri = uri;
  parent.$appendchild(p);
  return p;
}

function emptycover(kind) {
  let lg;
  lg = "es";
  if ((((m.global != null) && (m.global.lang != null)) && i18nvalid(m.global.lang))) {
    lg = m.global.lang;
  }
  return (((("pkg:/images/cover_" + kind) + "_") + lg) + ".jpg");
}

function coverposter(parent, x, y, w, h, uri) {
  let ph, p;
  ph = emptycover("p");
  if (((uri == null) || (uri === ""))) {
    uri = ph;
  }
  p = $createobject("roSGNode", "Poster");
  p.translation = [x, y];
  p.width = w;
  p.height = h;
  p.loadwidth = w;
  p.loadheight = h;
  p.loaddisplaymode = "scaleToZoom";
  p.failedbitmapuri = ph;
  p.uri = uri;
  parent.$appendchild(p);
  return p;
}

function fittext(text, width) {
  let maxchars;
  if (((text == null) || (width < 16))) {
    return "";
  }
  maxchars = $int((width / 8));
  if ((maxchars < 1)) {
    return "";
  }
  if (($len(text) <= maxchars)) {
    return text;
  }
  if ((maxchars < 4)) {
    return $left(text, maxchars);
  }
  return ($left(text, (maxchars - 3)) + "...");
}

function onkeyevent(key, press) {
  let idx, cat, ch;
  if ((!press)) {
    return false;
  }
  if ((key === "rewind")) {
    key = "rev";
  }
  if ((key === "fastforward")) {
    key = "fwd";
  }
  if ((m.mode === "intro")) {
    return introkey(key);
  }
  if ((m.uiopen === true)) {
    return uikey(key);
  }
  if ((m.mode === "mosaic")) {
    return mosaickey(key);
  }
  if ((m.mode === "welcome")) {
    return welcomekey(key);
  }
  if ((m.mode === "home")) {
    if (((key === "rev") || (key === "fwd"))) {
      if ((key === "rev")) {
        homestepfeature((-1));
      } else {
        homestepfeature(1);
      }
      return true;
    }
    if ((key === "left")) {
      movehome((-1), 0);
    } else if ((key === "right")) {
      movehome(1, 0);
    } else if ((key === "up")) {
      movehome(0, (-1));
    } else if ((key === "down")) {
      movehome(0, 1);
    } else if ((key === "OK")) {
      openhomecard();
    } else if ((key === "options")) {
      showlists();
    } else if ((key === "play")) {
      togglebgm();
    } else if ((key === "back")) {
      return false;
    }
    return true;
  }
  if ((m.mode === "about")) {
    return aboutkey(key);
  }
  if ((m.mode === "tutorial")) {
    return tutkey(key);
  }
  if ((m.mode === "lang")) {
    return langkey(key);
  }
  if (((((m.mode === "weather") || (m.mode === "wxsearch")) || (m.mode === "wxunit")) || (m.mode === "wxmsg"))) {
    return wxkey(key);
  }
  if ((m.mode === "search")) {
    return searchkey(key);
  }
  if ((m.mode === "qr")) {
    if (m.toast.visible) {
      if (((key === "OK") || (key === "back"))) {
        hidetoast();
      }
      return true;
    }
    if ((key === "back")) {
      showhome();
    }
    return true;
  }
  if ((m.mode === "xtlist")) {
    return xtkey(key);
  }
  if ((m.mode === "detail")) {
    return detailkey(key);
  }
  if ((((m.mode === "movies") || (m.mode === "series")) || (m.mode === "adult"))) {
    return movieskey(key);
  }
  if ((m.mode === "pin")) {
    return pinkey(key);
  }
  if ((m.mode === "matches")) {
    return matcheskey(key);
  }
  if ((m.mode === "support")) {
    return supportkey(key);
  }
  if (((m.mode === "live") && m.listspanel.visible)) {
    if (livematchkey(key)) {
      return true;
    }
  }
  if ((m.mode === "episodes")) {
    return episodeskey(key);
  }
  if ((m.mode === "favs")) {
    return favskey(key);
  }
  if ((m.mode === "lists")) {
    if ((key === "back")) {
      showhome();
      if (m.needreload) {
        m.needreload = false;
        opensection("preload");
      }
      return true;
    } else if ((key === "options")) {
      idx = m.librarylist.itemfocused;
      if (((idx >= 0) && (idx < m.playlists.$count()))) {
        showoptions(idx);
        return true;
      }
    }
    return false;
  }
  if (m.guideopen) {
    if (m.catpicker.visible) {
      if (((key === "back") || (key === "options"))) {
        m.catpicker.visible = false;
        capturekeys();
        return true;
      } else if ((key === "up")) {
        movepick((-1));
        return true;
      } else if ((key === "down")) {
        movepick(1);
        return true;
      } else if ((key === "OK")) {
        acceptcategory();
        return true;
      }
      return true;
    }
    if ((key === "back")) {
      closeguide();
      return true;
    } else if ((key === "left")) {
      moveprog((-1));
      return true;
    } else if ((key === "right")) {
      moveprog(1);
      return true;
    } else if ((key === "up")) {
      moveguiderow((-1));
      return true;
    } else if ((key === "down")) {
      moveguiderow(1);
      return true;
    } else if ((key === "OK")) {
      if (((m.guidecat === m.curcat) && (m.guiderow === m.curchan))) {
        if ((m.ovstate === "fail")) {
          retrycurrent();
        } else {
          closeguide();
        }
      } else {
        playhighlighted(false);
      }
      return true;
    } else if ((key === "play")) {
      playhighlighted(true);
      return true;
    } else if (((key === "rev") || (key === "fwd"))) {
      opencatpicker();
      return true;
    } else if ((key === "replay")) {
      replaylast();
      return true;
    }
    return false;
  }
  if ((m.videoplayer.visible && (!m.pip))) {
    if (m.ctlopen) {
      return ctlkey(key);
    }
    if ((key === "back")) {
      if ((((m.returnmode === "live") && (m.playingitem == null)) && (m.root != null))) {
        enterpip();
      } else {
        stopvideo();
      }
      return true;
    } else if (((key === "OK") && (m.ovstate === "fail"))) {
      retrycurrent();
      return true;
    } else if ((key === "OK")) {
      showcontrols();
      return true;
    } else if ((key === "left")) {
      if (ismovieitem()) {
        seekby((-10));
      } else {
        openguide();
      }
      return true;
    } else if ((key === "right")) {
      if (ismovieitem()) {
        seekby(10);
      } else {
        showcontrols();
      }
      return true;
    } else if ((key === "up")) {
      if (ismovieitem()) {
        showcontrols();
      } else {
        zap(1);
      }
      return true;
    } else if ((key === "down")) {
      if (ismovieitem()) {
        showcontrols();
      } else {
        zap((-1));
      }
      return true;
    } else if ((key === "rev")) {
      seekby((-10));
      return true;
    } else if ((key === "fwd")) {
      seekby(10);
      return true;
    } else if ((key === "play")) {
      togglepause();
      return true;
    } else if ((key === "replay")) {
      if (ismovieitem()) {
        quickseek((-15));
      } else {
        replaylast();
      }
      return true;
    }
    return false;
  }
  if ((key === "back")) {
    if (m.listspanel.visible) {
      if (m.channellist.$hasfocus()) {
        m.categorylist.$setfocus(true);
      } else {
        stoppip();
        showhome();
      }
      return true;
    }
  } else if ((((key === "options") && m.listspanel.visible) && m.channellist.$hasfocus())) {
    mosaddfromlive();
    return true;
  } else if ((((key === "play") && m.listspanel.visible) && m.channellist.$hasfocus())) {
    cat = null;
    if ((m.root != null)) {
      cat = m.root.$getchild(m.categorylist.itemfocused);
    }
    if ((cat != null)) {
      ch = cat.$getchild(m.channellist.itemfocused);
      if ((ch != null)) {
        togglefavorite(ch);
      }
    }
    return true;
  } else if ((key === "options")) {
    if ((m.librarypanel.visible && m.librarylist.$hasfocus())) {
      idx = m.librarylist.itemfocused;
      if (((idx >= 0) && (idx < m.playlists.$count()))) {
        showoptions(idx);
        return true;
      }
    }
  } else if (((key === "right") && m.categorylist.$hasfocus())) {
    m.channellist.$setfocus(true);
    return true;
  } else if (((key === "left") && m.channellist.$hasfocus())) {
    m.categorylist.$setfocus(true);
    return true;
  }
  return false;
}

function onbginstate(ev) {
  let id, lp;
  if ((!m.bgon)) {
    return;
  }
  if ((ev.$getdata() !== "stopped")) {
    return;
  }
  id = ev.$getrosgnode().id;
  lp = m.top.$findnode(("bgL" + $mid(id, 4)));
  if ((lp != null)) {
    lp.control = "start";
  }
}

function enterpip() {
  m.pip = true;
  hidecontrols();
  m.zapbanner.visible = false;
  m.zaptimer.control = "stop";
  m.videoplayer.translation = [866, 94];
  m.videoplayer.width = 359;
  m.videoplayer.height = 202;
  layoutoverlay();
  showlive();
}

function leavepiplayout() {
  m.pip = false;
  m.videoplayer.translation = [0, 0];
  m.videoplayer.width = 1280;
  m.videoplayer.height = 720;
  applypiplayout(false);
  layoutoverlay();
}

function stoppip() {
  if ((!m.pip)) {
    return;
  }
  hideoverlay();
  m.videoplayer.control = "stop";
  m.videoplayer.visible = false;
  leavepiplayout();
}

function applypiplayout(on) {
  let item, ci;
  m.pipframe.visible = on;
  m.piptag.visible = on;
  m.pipname.visible = on;
  m.piphint.visible = on;
  if (on) {
    item = currentitem();
    if ((item != null)) {
      m.pipname.text = displayname(item);
    }
  }
  ci = m.top.$findnode("chInfo");
  if ((ci != null)) {
    ci.visible = (!on);
  }
  m.epgliststatus.visible = (!on);
}
// ---- components/screens.brs ----
function showhome() {
  m.mode = "home";
  m.adultctx = false;
  hidepanels();
  settitle("SMART IPTV MX");
  m.homepanel.visible = true;
  homeenter();
  capturekeys();
}

function showlists() {
  m.mode = "lists";
  hidepanels();
  settitle(tx("Mis listas"));
  m.librarypanel.visible = true;
  xthintmode(false);
  refreshlibrary();
  m.librarylist.$setfocus(true);
}

function hidepanels() {
  let sp;
  m.homepanel.visible = false;
  m.welcomepanel.visible = false;
  m.wlogoanim.control = "stop";
  m.librarypanel.visible = false;
  m.listspanel.visible = false;
  m.moviepanel.visible = false;
  if ((m.detailpanel != null)) {
    m.detailpanel.visible = false;
  }
  m.favpanel.visible = false;
  m.searchpanel.visible = false;
  m.qrpanel.visible = false;
  m.aboutpanel.visible = false;
  if ((m.tutpanel != null)) {
    m.tutpanel.visible = false;
  }
  if ((m.langpanel != null)) {
    m.langpanel.visible = false;
  }
  if ((m.pinpanel != null)) {
    m.pinpanel.visible = false;
  }
  if ((m.mtpanel != null)) {
    m.mtpanel.visible = false;
  }
  sp = m.top.$findnode("supportPanel");
  if ((sp != null)) {
    sp.visible = false;
  }
  if ((m.wxpanel != null)) {
    m.wxpanel.visible = false;
  }
  wxstopanims();
  if (m.toast.visible) {
    hidetoast();
  }
  if ((m.feattimer != null)) {
    m.feattimer.control = "stop";
  }
  m.topbar.visible = true;
  setbganim(true);
  setbgfrozen(false);
  stopqr();
  moshide();
}

function setbganim(on) {
  let an, lp;
  if ((on === m.bgon)) {
    return;
  }
  m.bgon = on;
  m.bgfrozen = false;
  m.bgfx.visible = on;
  for (an of $iter(m.bganims)) {
    if (on) {
      an.control = "start";
    } else {
      an.control = "stop";
    }
  }
  if ((!on)) {
    for (lp of $iter(m.bgloops)) {
      lp.control = "stop";
    }
  }
}

function setbgfrozen(frozen) {
  let cmd, an, lp;
  if ((frozen === m.bgfrozen)) {
    return;
  }
  m.bgfrozen = frozen;
  if ((!m.bgon)) {
    return;
  }
  cmd = "resume";
  if (frozen) {
    cmd = "pause";
  }
  for (an of $iter(m.bganims)) {
    an.control = cmd;
  }
  for (lp of $iter(m.bgloops)) {
    lp.control = cmd;
  }
}

function settitle(text) {
  m.toptitle.text = text;
  updatetopclock();
}

function updatetopclock() {
  let t;
  t = $createobject("roDateTime").$asseconds();
  m.topclock.text = fmttimelong(t);
  m.topdate.text = fmtday(t);
}

function updateactivechip() {
  let ls;
  ls = activelists();
  if ((ls.$count() === 0)) {
    m.activename.text = tx("Sin listas activas");
  } else if ((ls.$count() === 1)) {
    m.activename.text = (tx("En uso: ") + $ix(ls, 0).name);
  } else {
    m.activename.text = (ls.$count().$tostr() + tx(" listas activas"));
  }
}

function isincluded(url) {
  return (((m.xtactive == null) && (m.activeset != null)) && m.activeset.$doesexist(url));
}

function activelists() {
  let res, p;
  res = [];
  if ((m.xtactive != null)) {
    res.$push(xtpseudo(m.xtactive));
    return res;
  }
  if (((m.playlists == null) || (m.activeset == null))) {
    return res;
  }
  for (p of $iter(m.playlists)) {
    if (m.activeset.$doesexist(p.url)) {
      res.$push(p);
    }
  }
  return res;
}

function activeplaylist() {
  let ls;
  ls = activelists();
  if ((ls.$count() === 0)) {
    return null;
  }
  return $ix(ls, 0);
}

function loadactiveset() {
  let arr, u, ok, p;
  m.activeset = {__proto__: $AAP};
  if (m.sec.$exists("active_set")) {
    arr = $parsejson(m.sec.$read("active_set"));
    if (($type(arr) === "roArray")) {
      for (u of $iter(arr)) {
        if (($type(u) === "roString")) {
          $six(m.activeset, u, true);
        }
      }
    }
  } else if (m.sec.$exists("active_url")) {
    u = m.sec.$read("active_url");
    if ((u !== "")) {
      $six(m.activeset, u, true);
    }
  }
  for (u of $iter(m.activeset.$keys())) {
    ok = false;
    for (p of $iter(m.playlists)) {
      if (($lcase(p.url) === $lcase(u))) {
        ok = true;
      }
    }
    if ((!ok)) {
      m.activeset.$delete(u);
    }
  }
  if (((m.activeset.$count() === 0) && (m.playlists.$count() > 0))) {
    $six(m.activeset, $ix(m.playlists, 0).url, true);
  }
}

function saveactiveset() {
  let arr, p;
  arr = [];
  for (p of $iter(m.playlists)) {
    if (m.activeset.$doesexist(p.url)) {
      arr.$push(p.url);
    }
  }
  m.sec.$write("active_set", $formatjson(arr));
  m.sec.$delete("active_url");
  m.sec.$flush();
}

function toggleactive(idx) {
  let url;
  if (((idx < 0) || (idx >= m.playlists.$count()))) {
    return;
  }
  xtclear();
  url = $ix(m.playlists, idx).url;
  if (m.activeset.$doesexist(url)) {
    m.activeset.$delete(url);
  } else {
    $six(m.activeset, url, true);
  }
  saveactiveset();
  resetcatalog();
  updateactivechip();
  m.needreload = true;
}

function setactive(p) {
  xtclear();
  m.activeset = {__proto__: $AAP};
  $six(m.activeset, p.url, true);
  saveactiveset();
  resetcatalog();
  updateactivechip();
}

function includelist(url) {
  xtclear();
  $six(m.activeset, url, true);
  saveactiveset();
  resetcatalog();
  updateactivechip();
}

function resetcatalog() {
  if ((m.epgtask != null)) {
    m.epgtask.control = "STOP";
  }
  if ((m.contenttask != null)) {
    m.contenttask.control = "STOP";
  }
  m.loadingall = false;
  m.catalogready = false;
  m.root = null;
  m.movieroot = null;
  m.seriesroot = null;
  m.adultroot = null;
  m.cntadult = 0;
  mtreset();
  gsreset();
  m.hastuned = false;
  m.curcat = 0;
  m.curchan = 0;
  m.prevcat = (-1);
  m.prevchan = (-1);
  m.epg = {__proto__: $AAP, "programs": {__proto__: $AAP}, "names": {__proto__: $AAP}, "icons": {__proto__: $AAP}};
  m.epgurls = [];
  m.epgstatus = "";
  m.epgliststatus.text = "";
  m.categorylist.content = null;
  m.channellist.content = null;
}

function reloadactive() {
  let ls;
  ls = activelists();
  if ((ls.$count() === 0)) {
    m.homestatus.text = tx("Primero agrega una lista (Mis listas o Cargar con QR).");
    return;
  }
  resetcatalog();
  updateactivechip();
  m.homestatus.text = ((tx("Actualizando ") + listslabel(ls)) + "...");
  opensection("preload");
}

function listslabel(ls) {
  if ((ls.$count() === 1)) {
    return $ix(ls, 0).name;
  }
  return (ls.$count().$tostr() + tx(" listas"));
}

function opensection(which) {
  let ls;
  m.pendingsection = which;
  if (m.loadingall) {
    if ((which !== "preload")) {
      m.homestatus.text = tx("Cargando la lista, un momento...");
    }
    return;
  }
  if ((which === "favs")) {
    showfavs();
    return;
  }
  if (m.catalogready) {
    showloadedsection(which);
    return;
  }
  ls = activelists();
  if ((ls.$count() === 0)) {
    if ((which !== "preload")) {
      m.homestatus.text = tx("Primero agrega una lista (Mis listas o Cargar con QR).");
    }
    return;
  }
  m.loadqueue = ls;
  m.loadfails = [];
  m.multisrc = ((ls.$count() > 1));
  m.directload = (!m.multisrc);
  m.xterr = "";
  m.liveacc = $createobject("roSGNode", "ContentNode");
  m.movieacc = $createobject("roSGNode", "ContentNode");
  m.seriesacc = $createobject("roSGNode", "ContentNode");
  m.adultacc = $createobject("roSGNode", "ContentNode");
  m.epgwanted = {__proto__: $AAP};
  m.seridx = {__proto__: $AAP};
  m.seenurls = {__proto__: $AAP};
  m.epgurls = [];
  m.loadingall = true;
  m.homestatus.text = ((tx("Cargando ") + listslabel(ls)) + "...");
  homeonprogress(0);
  loadnextlist();
}

function loadnextlist() {
  let i, $e0, nser, $e1, sc, nlive, $e2, nmov, $e3, p, fv;
  if (((m.loadqueue == null) || (m.loadqueue.$count() === 0))) {
    m.loadingall = false;
    m.catalogready = true;
    m.root = m.liveacc;
    m.movieroot = m.movieacc;
    m.seriesroot = m.seriesacc;
    m.adultroot = m.adultacc;
    pruneempty(m.liveacc);
    pruneempty(m.movieacc);
    pruneempty(m.seriesacc);
    pruneempty(m.adultacc);
    m.cntadult = 0;
    if ((m.adultroot != null)) {
      for (i = 0, $e0 = (m.adultroot.$getchildcount() - 1); i <= $e0; i++) {
        m.cntadult = (m.cntadult + m.adultroot.$getchild(i).$getchildcount());
      }
    }
    nser = 0;
    for (i = 0, $e1 = (m.seriesroot.$getchildcount() - 1); i <= $e1; i++) {
      sc = m.seriesroot.$getchild(i);
      sc.title = (((sc.id + "  (") + sc.$getchildcount().$tostr()) + ")");
      nser = (nser + sc.$getchildcount());
    }
    nlive = 0;
    for (i = 0, $e2 = (m.root.$getchildcount() - 1); i <= $e2; i++) {
      nlive = (nlive + m.root.$getchild(i).$getchildcount());
    }
    nmov = 0;
    for (i = 0, $e3 = (m.movieroot.$getchildcount() - 1); i <= $e3; i++) {
      nmov = (nmov + m.movieroot.$getchild(i).$getchildcount());
    }
    if ((((nlive + nmov) + nser) === 0)) {
      m.catalogready = false;
      m.root = null;
      m.movieroot = null;
      m.seriesroot = null;
      m.homestatus.text = tx("No se pudo leer la lista o está vacía. Revisa el link en Mis listas.");
      if (((m.xterr != null) && (m.xterr !== ""))) {
        m.homestatus.text = m.xterr;
      }
      return;
    }
    m.homestatus.text = ((((tx("Cargado: ") + nlive.$tostr()) + tx(" canales, ")) + nmov.$tostr()) + tx(" películas"));
    if ((nser > 0)) {
      m.homestatus.text = (((m.homestatus.text + ", ") + nser.$tostr()) + tx(" series"));
    }
    if (((m.loadfails != null) && (m.loadfails.$count() > 0))) {
      m.homestatus.text = ((m.homestatus.text + tx("  - no se pudo leer: ")) + $ix(m.loadfails, 0));
    }
    m.cntlive = nlive;
    m.cntmov = nmov;
    m.cntser = nser;
    homeoncatalog();
    gsstart();
    mtstartsoon();
    if (((m.mode === "home") && (m.pendingsection !== "preload"))) {
      showloadedsection(m.pendingsection);
    }
    startepg();
    return;
  }
  p = $ix(m.loadqueue, 0);
  m.loadqueue.$delete(0);
  m.loadingplaylist = p;
  m.homestatus.text = ((tx("Cargando ") + p.name) + "...");
  if ((m.contenttask != null)) {
    m.contenttask.control = "STOP";
  }
  if ((p.xt != null)) {
    m.contenttask = $createobject("roSGNode", "XtreamReader");
    m.contenttask.host = p.xt.host;
    m.contenttask.user = p.xt.user;
    m.contenttask.pass = p.xt.pass;
    m.contenttask.$observefield("status", "onXtStatus");
  } else {
    m.contenttask = $createobject("roSGNode", "ContentReader");
    m.contenttask.contenturi = p.url;
  }
  if ((m.directload === true)) {
    fv = m.favmap;
    if ((fv == null)) {
      fv = {__proto__: $AAP};
    }
    m.contenttask.favs = fv;
    m.contenttask.listepg = epgof(p);
    m.contenttask.direct = true;
  }
  m.contenttask.$observefield("progress", "onContentProgress");
  m.contenttask.$observefield("content", "onContentLoaded");
  m.contenttask.control = "RUN";
}

function oncontentprogress() {
  if ((((!m.loadingall) || (m.contenttask == null)) || (m.loadingplaylist == null))) {
    return;
  }
  m.homestatus.text = ((((tx("Cargando ") + m.loadingplaylist.name) + "... ") + m.contenttask.progress.$tostr()) + "%");
  homeonprogress(m.contenttask.progress);
}

function oncontentloaded(event) {
  let node, ep, c, mv, sr, ad, wt, srcname, i, $e4, acat;
  node = null;
  if (((event != null) && ($type(event) === "roSGNodeEvent"))) {
    node = event.$getrosgnode();
  }
  if (((node != null) && (m.contenttask != null))) {
    if ((!node.$issamenode(m.contenttask))) {
      return;
    }
  }
  if ((!m.loadingall)) {
    return;
  }
  ep = "";
  if ((m.loadingplaylist != null)) {
    ep = epgof(m.loadingplaylist);
  }
  if ((((ep === "") && (m.contenttask != null)) && (m.contenttask.epgurl != null))) {
    ep = m.contenttask.epgurl;
  }
  c = m.contenttask.content;
  mv = m.contenttask.movies;
  sr = m.contenttask.series;
  ad = m.contenttask.adult;
  wt = m.contenttask.wanted;
  if ((wt != null)) {
    if ((m.epgwanted == null)) {
      m.epgwanted = {__proto__: $AAP};
    }
    m.epgwanted.$append(wt);
  }
  if (((((((c == null) || (c.$getchildcount() === 0))) && (((mv == null) || (mv.$getchildcount() === 0)))) && (((sr == null) || (sr.$getchildcount() === 0)))) && (((ad == null) || (ad.$getchildcount() === 0))))) {
    if ((m.loadfails == null)) {
      m.loadfails = [];
    }
    if ((m.loadingplaylist != null)) {
      m.loadfails.$push(m.loadingplaylist.name);
    }
    loadnextlist();
    return;
  }
  srcname = "";
  if (((m.multisrc === true) && (m.loadingplaylist != null))) {
    srcname = m.loadingplaylist.name;
  }
  if ((m.directload === true)) {
    if ((c != null)) {
      m.liveacc = c;
    }
    if ((mv != null)) {
      m.movieacc = mv;
    }
    if ((sr != null)) {
      m.seriesacc = sr;
    }
    if ((ad != null)) {
      m.adultacc = ad;
    }
  } else {
    mergetree(m.liveacc, c, ep, srcname);
    mergetree(m.movieacc, mv, ep, srcname);
    mergeseries(m.seriesacc, sr, srcname);
    if ((ad != null)) {
      for (i = 0, $e4 = (ad.$getchildcount() - 1); i <= $e4; i++) {
        acat = ad.$getchild(i);
        mergecategory(m.adultacc, acat, acat.id, ep, srcname);
      }
    }
    m.contenttask = null;
  }
  if ((ep !== "")) {
    if ((m.epgurls == null)) {
      m.epgurls = [];
    }
    if ((!listhas(m.epgurls, ep))) {
      m.epgurls.$push(ep);
    }
  }
  loadnextlist();
}

function mergecategory(dest, cat, name, epg, srcname) {
  let found, j, $e5, k, $e6, ch, isdup, item;
  found = null;
  for (j = 0, $e5 = (dest.$getchildcount() - 1); j <= $e5; j++) {
    if ((dest.$getchild(j).id === name)) {
      found = dest.$getchild(j);
    }
  }
  if ((found == null)) {
    found = dest.$createchild("ContentNode");
    found.id = name;
  }
  for (k = 0, $e6 = (cat.$getchildcount() - 1); k <= $e6; k++) {
    ch = cat.$getchild(k);
    isdup = false;
    if ((((ch.url != null) && (ch.url !== "")) && m.seenurls.$doesexist(ch.url))) {
      isdup = true;
    }
    if ((!isdup)) {
      if (((ch.url != null) && (ch.url !== ""))) {
        $six(m.seenurls, ch.url, true);
      }
      item = found.$createchild("ContentNode");
      item.title = ch.title;
      item.url = ch.url;
      item.id = ch.id;
      item.streamformat = ch.streamformat;
      item.hdposterurl = ch.hdposterurl;
      item.shortdescriptionline1 = ch.shortdescriptionline1;
      item.shortdescriptionline2 = epg;
      item.description = ch.description;
      if ((srcname !== "")) {
        item.rating = srcname;
      }
      if ((((m.favmap != null) && (ch.url != null)) && m.favmap.$doesexist(ch.url))) {
        item.starrating = 100;
      } else {
        item.starrating = 0;
      }
    }
  }
  found.title = (((name + "  (") + found.$getchildcount().$tostr()) + ")");
}

function pruneempty(node) {
  let i, $e7;
  if ((node == null)) {
    return;
  }
  for (i = (node.$getchildcount() - 1), $e7 = 0; i >= $e7; i--) {
    if ((node.$getchild(i).$getchildcount() === 0)) {
      node.$removechildindex(i);
    }
  }
}

function mergetree(dest, src, epg, srcname) {
  let i, $e8, cat, name;
  if (((dest == null) || (src == null))) {
    return;
  }
  if ((m.seenurls == null)) {
    m.seenurls = {__proto__: $AAP};
  }
  for (i = 0, $e8 = (src.$getchildcount() - 1); i <= $e8; i++) {
    cat = src.$getchild(i);
    name = cat.id;
    if (((name == null) || (name === ""))) {
      name = cat.title;
    }
    if (($lcase(name) !== "adultos")) {
      mergecategory(dest, cat, name, epg, srcname);
    }
  }
}

function listhas(arr, value) {
  let v;
  if ((arr == null)) {
    return false;
  }
  for (v of $iter(arr)) {
    if ((v === value)) {
      return true;
    }
  }
  return false;
}

function showloadedsection(which) {
  if ((which === "movies")) {
    if (((m.movieroot == null) || (m.movieroot.$getchildcount() === 0))) {
      m.homestatus.text = tx("No encontré películas en esta lista. Los canales siguen en En vivo.");
      showhome();
      return;
    }
    m.movcat = 0;
    m.movidx = 0;
    m.movside = "cw";
    m.cwidx = 0;
    m.vson = false;
    m.movpick = false;
    showmovies();
  } else if ((which === "series")) {
    if (((m.seriesroot == null) || (m.seriesroot.$getchildcount() === 0))) {
      m.homestatus.text = tx("No encontré series en esta lista. Las series se detectan por su nombre (ej. S01E04 o 1x04).");
      showhome();
      return;
    }
    m.movcat = 0;
    m.movidx = 0;
    m.movside = "cw";
    m.cwidx = 0;
    m.vson = false;
    m.movpick = false;
    showserieslist();
  } else if ((which === "search")) {
    startsearch();
  } else {
    if (((m.root == null) || (m.root.$getchildcount() === 0))) {
      m.homestatus.text = tx("No hay canales en vivo en esta lista.");
      showhome();
      return;
    }
    showlive();
  }
}

function showlive() {
  let restore, n, ci, cat;
  m.mode = "live";
  m.adultctx = false;
  m.mtbtnon = false;
  mtdrawbtn();
  hidepanels();
  setbgfrozen(true);
  settitle(tx("En vivo"));
  m.listspanel.visible = true;
  m.top.$findnode("liveHint").text = tx("OK: ver canal     Play: favorito     Mantén Atrás: al mosaico     Arriba: Partidos de hoy     Atrás: inicio");
  applypiplayout(m.pip);
  restore = false;
  if ((m.root != null)) {
    n = m.root.$getchildcount();
    m.categorylist.content = m.root;
    ci = m.categorylist.itemfocused;
    if ((ci < 0)) {
      ci = 0;
    }
    if (((m.hastuned && (m.curcat >= 0)) && (m.curcat < n))) {
      ci = m.curcat;
      restore = true;
    }
    if ((ci >= n)) {
      ci = 0;
    }
    m.categorylist.jumptoitem = ci;
    if ((n > 0)) {
      cat = m.root.$getchild(ci);
      m.channellist.content = cat;
      if (((restore && (m.curchan >= 0)) && (m.curchan < cat.$getchildcount()))) {
        m.channellist.jumptoitem = m.curchan;
        m.restorecat = ci;
        m.restorechan = m.curchan;
      } else {
        restore = false;
      }
    }
    applynowplaying();
  }
  if (restore) {
    m.channellist.$setfocus(true);
  } else {
    m.categorylist.$setfocus(true);
  }
}

function applynowplaying() {
  if (m.listspanel.visible) {
    liveinfosoon();
  }
}

function applynowplayingall() {
  let i, $e9, cat, j, $e10, ch, nn;
  if ((((m.root == null) || (m.epg == null)) || (m.epg.programs == null))) {
    return;
  }
  if ((m.epg.programs.$count() === 0)) {
    return;
  }
  for (i = 0, $e9 = (m.root.$getchildcount() - 1); i <= $e9; i++) {
    cat = m.root.$getchild(i);
    for (j = 0, $e10 = (cat.$getchildcount() - 1); j <= $e10; j++) {
      ch = cat.$getchild(j);
      nn = getnownext(ch);
      if ((nn.cur != null)) {
        ch.releasedate = ((fmttime(nn.cur.s) + "  ") + nn.cur.t);
      } else {
        ch.releasedate = "";
      }
    }
  }
}

function showserieslist() {
  m.mode = "series";
  m.adultctx = false;
  m.vodroot = m.seriesroot;
  hidepanels();
  setbgfrozen(true);
  settitle(tx("Series"));
  m.moviepanel.visible = true;
  drawmovies();
  capturekeys();
}

function showmovies() {
  m.mode = "movies";
  m.adultctx = false;
  m.vodroot = m.movieroot;
  hidepanels();
  setbgfrozen(true);
  settitle(tx("Películas"));
  m.moviepanel.visible = true;
  drawmovies();
  capturekeys();
}

function showfavs() {
  m.mode = "favs";
  if (((m.favtab == null) || (m.favtab === ""))) {
    m.favtab = "live";
  }
  if ((m.favidx == null)) {
    m.favidx = 0;
  }
  hidepanels();
  settitle(tx("Favoritos"));
  m.favpanel.visible = true;
  drawfavs();
  capturekeys();
}

function startsearch() {
  m.mode = "search";
  hidepanels();
  settitle(tx("Búsqueda"));
  m.searchpanel.visible = true;
  showkeyboard(tx("Buscar canales y películas"), m.lastquery, "search");
}

function foldtext(s) {
  s = $lcase(s);
  s = s.$replace($chr(225), "a").$replace($chr(233), "e").$replace($chr(237), "i").$replace($chr(243), "o").$replace($chr(250), "u");
  s = s.$replace($chr(241), "n").$replace($chr(252), "u");
  s = s.$replace($chr(193), "a").$replace($chr(201), "e").$replace($chr(205), "i").$replace($chr(211), "o").$replace($chr(218), "u").$replace($chr(209), "n");
  return s;
}

function runsearch(query) {
  let q, tokens, parts, t, results, total, n, k, $e11, hay, ok, ref, pass, rest, i, j, src, cat, $e12, $e13, $e14, ch;
  m.lastquery = query;
  q = foldtext(query.$trim());
  tokens = [];
  parts = q.$split(" ");
  for (t of $iter(parts)) {
    if ((t !== "")) {
      tokens.$push(t);
    }
  }
  results = $createobject("roSGNode", "ContentNode");
  total = 0;
  if ((tokens.$count() > 0)) {
    if (((m.gsdone === true) && (m.gst != null))) {
      n = m.gst.$count();
      for (k = 0, $e11 = (n - 1); k <= $e11; k++) {
        if ((total >= 200)) {
          break;
        }
        hay = $ix(m.gst, k);
        ok = true;
        for (t of $iter(tokens)) {
          if (($instr(1, hay, t) === 0)) {
            ok = false;
            break;
          }
        }
        if (ok) {
          ref = $ix(m.gsr, k);
          pass = $int((ref / 700000000));
          rest = (ref - (pass * 700000000));
          i = $int((rest / 100000));
          j = (rest - (i * 100000));
          src = gssrc(pass);
          if (((src != null) && (i < src.$getchildcount()))) {
            cat = src.$getchild(i);
            if ((j < cat.$getchildcount())) {
              total = (total + 1);
              gsaddresult(results, cat, cat.$getchild(j), pass, i, j);
            }
          }
        }
      }
    } else {
      for (pass = 0, $e12 = 2; pass <= $e12; pass++) {
        src = gssrc(pass);
        if ((src != null)) {
          for (i = 0, $e13 = (src.$getchildcount() - 1); i <= $e13; i++) {
            cat = src.$getchild(i);
            for (j = 0, $e14 = (cat.$getchildcount() - 1); j <= $e14; j++) {
              if ((total >= 200)) {
                break;
              }
              ch = cat.$getchild(j);
              hay = foldtext(ch.title);
              ok = true;
              for (t of $iter(tokens)) {
                if (($instr(1, hay, t) === 0)) {
                  ok = false;
                  break;
                }
              }
              if (ok) {
                total = (total + 1);
                gsaddresult(results, cat, ch, pass, i, j);
              }
            }
          }
        }
      }
    }
  }
  m.searchresults = results;
  showsearchresults();
}

function gssrc(pass) {
  if ((pass === 0)) {
    return m.root;
  }
  if ((pass === 1)) {
    return m.movieroot;
  }
  return m.seriesroot;
}

function gsaddresult(results, cat, ch, pass, i, j) {
  let cname, it, sr, kind;
  cname = cat.id;
  if (((cname == null) || (cname === ""))) {
    cname = cat.title;
  }
  it = results.$createchild("ContentNode");
  it.title = ch.title;
  it.url = ch.url;
  it.id = ch.id;
  it.streamformat = ch.streamformat;
  it.hdposterurl = ch.hdposterurl;
  it.shortdescriptionline1 = ch.shortdescriptionline1;
  it.description = ch.description;
  sr = 0;
  if ((((m.favmap != null) && (ch.url != null)) && m.favmap.$doesexist(ch.url))) {
    sr = 100;
  }
  it.starrating = sr;
  kind = tx("Canal");
  if ((pass === 1)) {
    kind = tx("Película");
  }
  if ((pass === 2)) {
    kind = tx("Serie");
    it.description = "serie";
    it.id = ((i.$tostr() + ":") + j.$tostr());
  }
  it.releasedate = ((kind + "  -  ") + cname);
}

function gsreset() {
  if ((m.gstimer != null)) {
    m.gstimer.control = "stop";
  }
  m.gst = null;
  m.gsr = null;
  m.gsdone = false;
}

function gsstart() {
  let t;
  gsreset();
  if ((m.gstimer == null)) {
    t = $createobject("roSGNode", "Timer");
    t.duration = 0.05;
    t.repeat = true;
    t.$observefield("fire", "onGsTick");
    m.top.$appendchild(t);
    m.gstimer = t;
  }
  m.gst = [];
  m.gsr = [];
  m.gspass = 0;
  m.gsci = 0;
  m.gsji = 0;
  m.gstimer.control = "start";
}

function ongstick() {
  if ((m.gst == null)) {
    m.gstimer.control = "stop";
    return;
  }
  try {
    gstickwork();
  } catch (e) {
    console.log("[GS] error: ", e.message);
    gsreset();
  }
}

function gstickwork() {
  let ts, src, cat, n, lim, j, $e15;
  ts = $createobject("roTimespan");
  while ((ts.$totalmilliseconds() < 15)) {
    if ((m.gspass > 2)) {
      m.gsdone = true;
      m.gstimer.control = "stop";
      return;
    }
    src = gssrc(m.gspass);
    if ((((src == null) || (m.gsci >= src.$getchildcount())) || (m.gsci > 6999))) {
      m.gspass = (m.gspass + 1);
      m.gsci = 0;
      m.gsji = 0;
    } else {
      cat = src.$getchild(m.gsci);
      n = cat.$getchildcount();
      if (((m.gsji >= n) || (m.gsji >= 100000))) {
        m.gsci = (m.gsci + 1);
        m.gsji = 0;
      } else {
        lim = (m.gsji + 40);
        if ((lim > n)) {
          lim = n;
        }
        for (j = m.gsji, $e15 = (lim - 1); j <= $e15; j++) {
          m.gst.$push(foldtext(cat.$getchild(j).title));
          m.gsr.$push((((m.gspass * 700000000) + (m.gsci * 100000)) + j));
        }
        m.gsji = lim;
      }
    }
  }
}

function showsearchresults() {
  let n;
  m.mode = "search";
  hidepanels();
  settitle(tx("Búsqueda"));
  m.searchpanel.visible = true;
  n = 0;
  if ((m.searchresults != null)) {
    n = m.searchresults.$getchildcount();
  }
  if ((n === 0)) {
    m.searchtitle.text = ((tx("Sin resultados para \"") + m.lastquery) + $chr(34));
    m.searchlist.content = null;
    capturekeys();
  } else {
    m.searchtitle.text = (((n.$tostr() + tx(" resultados para \"")) + m.lastquery) + $chr(34));
    m.searchlist.content = m.searchresults;
    m.searchlist.$setfocus(true);
  }
}

function onsearchselected() {
  let idx, it, p, ci, si, sn;
  idx = m.searchlist.itemselected;
  if ((((m.searchresults == null) || (idx < 0)) || (idx >= m.searchresults.$getchildcount()))) {
    return;
  }
  it = m.searchresults.$getchild(idx);
  if ((it.description === "serie")) {
    p = $instr(1, it.id, ":");
    ci = $val($left(it.id, (p - 1)));
    si = $val($mid(it.id, (p + 1)));
    sn = m.seriesroot.$getchild(ci).$getchild(si);
    m.epback = "search";
    showepisodes(sn);
    return;
  }
  playnode(it, "search");
}

function searchkey(key) {
  let it;
  if ((key === "back")) {
    showhome();
    return true;
  } else if (((key === "left") || (key === "options"))) {
    startsearch();
    return true;
  } else if ((key === "play")) {
    if ((m.searchresults != null)) {
      it = m.searchresults.$getchild(m.searchlist.itemfocused);
      if (((it != null) && (it.description !== "serie"))) {
        togglefavorite(it);
      }
    }
    return true;
  }
  return false;
}

function syncstars() {
}

function favsync(item) {
  let u, want;
  if (((item == null) || (m.favmap == null))) {
    return;
  }
  u = item.url;
  if (((u == null) || (u === ""))) {
    return;
  }
  want = 0;
  if (m.favmap.$doesexist(u)) {
    want = 100;
  }
  if ((item.starrating !== want)) {
    item.starrating = want;
  }
}

function localip() {
  let di, ci, addrs, k;
  di = $createobject("roDeviceInfo");
  ci = di.$getconnectioninfo();
  if ((((ci != null) && (ci.ip != null)) && (ci.ip !== ""))) {
    return ci.ip;
  }
  addrs = di.$getipaddrs();
  if ((addrs != null)) {
    for (k of $iter(addrs)) {
      if ((($ix(addrs, k) != null) && ($ix(addrs, k) !== ""))) {
        return $ix(addrs, k);
      }
    }
  }
  return "";
}

function showqr() {
  let qp, ip;
  m.mode = "qr";
  hidepanels();
  settitle(tx("Cargar desde el celular"));
  m.qrpanel.visible = true;
  qp = m.top.$findnode("qrPulse");
  if ((qp != null)) {
    qp.control = "start";
  }
  clearnode(m.qrcode);
  m.qrlogo.visible = false;
  m.qrstatus.text = "";
  m.qrstatus.color = "0x50E68CFF";
  ip = localip();
  if ((ip === "")) {
    m.qrurl.text = "";
    m.qrstatus.color = "0xFF8A24FF";
    m.qrstatus.text = tx("No encontré la red de la TV. Revisa que esté conectada al Wi-Fi o por cable.");
    capturekeys();
    return;
  }
  m.qrip = ip;
  m.qrurl.text = "";
  m.qrtask = $createobject("roSGNode", "QrServer");
  m.qrtask.port = 8088;
  m.qrtask.$observefield("status", "onQrStatus");
  m.qrtask.$observefield("received", "onQrReceived");
  m.qrtask.control = "RUN";
  m.qrstatus.text = tx("Preparando...");
  capturekeys();
}

function drawqr(mat) {
  let px, n, y, $e16, x, x0;
  px = 10;
  n = mat.$count();
  for (y = 0, $e16 = (n - 1); y <= $e16; y++) {
    x = 0;
    while ((x < n)) {
      if (($ix($ix(mat, y), x) === 1)) {
        x0 = x;
        while (((x < n) && ($ix($ix(mat, y), x) === 1))) {
          x = (x + 1);
        }
        addrect(m.qrcode, (x0 * px), (y * px), (((x - x0)) * px), px, "0x000000FF");
      } else {
        x = (x + 1);
      }
    }
  }
}

function stopqr() {
  let qp;
  qp = m.top.$findnode("qrPulse");
  if ((qp != null)) {
    qp.control = "stop";
  }
  if ((m.qrtask != null)) {
    m.qrtask.control = "STOP";
    m.qrtask = null;
  }
}

function onqrstatus() {
  let st, url, mat;
  if ((m.qrtask == null)) {
    return;
  }
  st = m.qrtask.status;
  if ((st == null)) {
    return;
  }
  if (($left(st, 6) === "listo:")) {
    url = ((("http://" + m.qrip) + ":") + $mid(st, 7));
    m.qrurl.text = url;
    clearnode(m.qrcode);
    mat = qrmatrix(url);
    if ((mat != null)) {
      drawqr(mat);
    }
    m.qrlogo.visible = ((mat != null));
    m.qrstatus.color = "0x50E68CFF";
    m.qrstatus.text = tx("Esperando tu celular...");
  } else if (($left(st, 6) === "error:")) {
    m.qrstatus.color = "0xFF8A24FF";
    m.qrstatus.text = $mid(st, 7);
  }
}

function onqrreceived() {
  let r, items, added, addedxt, lastepg, it, xa, url, epg, name, found, i, $e17, entry, ap, $e18;
  if ((m.qrtask == null)) {
    return;
  }
  r = m.qrtask.received;
  if ((r == null)) {
    return;
  }
  items = r.items;
  if (($type(items) !== "roArray")) {
    return;
  }
  added = [];
  addedxt = "";
  lastepg = "";
  for (it of $iter(items)) {
    if ((it.xt != null)) {
      xa = xtaddfromqr(it);
      if ((xa !== "")) {
        addedxt = xa;
      }
      continue;
    }
    url = it.url;
    epg = it.epg;
    name = it.name;
    if ((url !== "")) {
      found = (-1);
      for (i = 0, $e17 = (m.playlists.$count() - 1); i <= $e17; i++) {
        if (($ix(m.playlists, i).url === url)) {
          found = i;
        }
      }
      if (((name === "") && (found >= 0))) {
        name = $ix(m.playlists, found).name;
      }
      if ((name === "")) {
        name = (tx("Lista ") + ((m.playlists.$count() + 1)).$tostr());
      }
      entry = {__proto__: $AAP, "name": name, "url": url, "epg": epg};
      if ((found >= 0)) {
        if ((epg === "")) {
          entry.epg = epgof($ix(m.playlists, found));
        }
        $six(m.playlists, found, entry);
      } else {
        m.playlists.$push(entry);
      }
      includelist(url);
      added.$push(name);
    } else if ((epg !== "")) {
      lastepg = epg;
    }
  }
  if ((addedxt !== "")) {
    m.qrstatus.color = "0x50E68CFF";
    m.qrstatus.text = (tx("Cuenta Xtream agregada: ") + addedxt);
    showtoast(tx("¡Cuenta cargada!"), addedxt, tx("Ya quedó incluida en tu catálogo     OK: continuar"));
    return;
  }
  if ((added.$count() > 0)) {
    saveplaylists();
    opensection("preload");
    refreshlibrary();
    m.qrstatus.color = "0x50E68CFF";
    if ((added.$count() === 1)) {
      m.qrstatus.text = (tx("Lista agregada: ") + $ix(added, 0));
      showtoast(tx("¡Lista cargada!"), $ix(added, 0), tx("Ya quedó incluida en tu catálogo     OK: continuar"));
    } else {
      m.qrstatus.text = (added.$count().$tostr() + tx(" listas agregadas"));
      showtoast((("¡" + added.$count().$tostr()) + tx(" listas cargadas!")), tx("Todas quedaron incluidas en tu catálogo"), tx("OK: continuar"));
    }
  } else if ((lastepg !== "")) {
    ap = activeplaylist();
    if ((ap == null)) {
      m.qrstatus.color = "0xFF8A24FF";
      m.qrstatus.text = tx("Primero envía una lista; la guía se agrega a la primera lista activa.");
      return;
    }
    for (i = 0, $e18 = (m.playlists.$count() - 1); i <= $e18; i++) {
      if (($ix(m.playlists, i).url === ap.url)) {
        $six(m.playlists, i, {__proto__: $AAP, "name": ap.name, "url": ap.url, "epg": lastepg});
      }
    }
    saveplaylists();
    m.catalogready = false;
    m.qrstatus.color = "0x50E68CFF";
    m.qrstatus.text = ((tx("Guía guardada para ") + ap.name) + tx(". Se usará al recargar la lista."));
    showtoast(tx("¡Guía guardada!"), ap.name, tx("Se usará al recargar la lista     OK: continuar"));
  }
}

function loadfavs() {
  let parsed, f;
  m.favs = [];
  m.favmap = {__proto__: $AAP};
  if (m.sec.$exists("favorites")) {
    parsed = $parsejson(m.sec.$read("favorites"));
    if (($type(parsed) === "roArray")) {
      m.favs = parsed;
    }
  }
  for (f of $iter(m.favs)) {
    if (((f.u != null) && (f.u !== ""))) {
      $six(m.favmap, f.u, true);
    }
  }
}

function savefavs() {
  m.sec.$write("favorites", $formatjson(m.favs));
  m.sec.$flush();
}

function togglefavorite(item) {
  let url, kept, f, kind, logo, num, fmt;
  if ((item == null)) {
    return;
  }
  if ((m.adultctx === true)) {
    return;
  }
  url = item.url;
  if (((url == null) || (url === ""))) {
    return;
  }
  if ((m.favmap == null)) {
    loadfavs();
  }
  if (m.favmap.$doesexist(url)) {
    kept = [];
    for (f of $iter(m.favs)) {
      if ((f.u !== url)) {
        kept.$push(f);
      }
    }
    m.favs = kept;
    m.favmap.$delete(url);
    item.starrating = 0;
  } else {
    kind = item.description;
    if ((kind !== "movie")) {
      kind = "live";
    }
    logo = item.hdposterurl;
    if ((logo == null)) {
      logo = "";
    }
    if (($len(logo) > 180)) {
      logo = "";
    }
    num = item.shortdescriptionline1;
    if ((num == null)) {
      num = "";
    }
    fmt = item.streamformat;
    if (((fmt == null) || (fmt === ""))) {
      fmt = "hls";
    }
    m.favs.$push({__proto__: $AAP, "u": url, "t": item.title, "k": kind, "i": item.id, "f": fmt, "n": num, "l": logo});
    $six(m.favmap, url, true);
    item.starrating = 100;
  }
  savefavs();
  if ((m.mode === "search")) {
    syncstars();
  }
  if ((m.mode === "movies")) {
    drawmovies();
  }
  if ((m.mode === "episodes")) {
    drawepisodes();
  }
  if ((m.mode === "favs")) {
    drawfavs();
  }
  if ((m.videoplayer.visible && (!m.pip))) {
    showbanner("");
  }
  if (m.listspanel.visible) {
    liveinfosoon();
  }
}

function favitems(kind) {
  let out, f;
  out = [];
  if ((m.favs == null)) {
    return out;
  }
  for (f of $iter(m.favs)) {
    if ((f.k === kind)) {
      out.$push(f);
    }
  }
  return out;
}

function favtoitem(f) {
  let item;
  item = $createobject("roSGNode", "ContentNode");
  item.title = f.t;
  item.url = f.u;
  item.id = f.i;
  item.streamformat = f.f;
  item.hdposterurl = f.l;
  item.shortdescriptionline1 = f.n;
  item.description = f.k;
  item.starrating = 100;
  return item;
}

function drawmovies() {
  let ncat, first, last, row, i, $e19, cat, label, color, total, page, start, n, $e20, ix, item, col, ry, x, y, focused, border, logo, namecolor, cap, yr;
  if ((m.vodroot == null)) {
    return;
  }
  if (((m.vson === true) && (m.vsmode === m.mode))) {
    cwlayout(false);
    drawsearch();
    return;
  }
  m.vson = false;
  cwupdate();
  clearnode(m.moviecats);
  clearnode(m.moviegrid);
  clearnode(m.movieoverlay);
  m.moviegrid.translation = [300, 112];
  ncat = m.vodroot.$getchildcount();
  if ((ncat === 0)) {
    return;
  }
  if ((m.movcat < 0)) {
    m.movcat = 0;
  }
  if ((m.movcat >= ncat)) {
    m.movcat = (ncat - 1);
  }
  first = (m.movcat - 5);
  if ((first < 0)) {
    first = 0;
  }
  last = (first + 11);
  if ((last >= ncat)) {
    last = (ncat - 1);
  }
  row = 0;
  for (i = first, $e19 = last; i <= $e19; i++) {
    cat = m.vodroot.$getchild(i);
    label = cat.id;
    if (((label == null) || (label === ""))) {
      label = cat.title;
    }
    label = cleancatname(label);
    color = "0xA8ADB5FF";
    if ((i === m.movcat)) {
      if ((m.movside === "cats")) {
        color = "0xFF8A24FF";
      } else {
        color = "0xFFFFFFFF";
      }
      addrect(m.moviecats, 0, (row * 46), 260, 40, "0xFFFFFF18");
    }
    addlabel(m.moviecats, 10, ((row * 46) + 6), 246, fittext(label, 240), color, "font:SmallBoldSystemFont");
    row = (row + 1);
  }
  cat = m.vodroot.$getchild(m.movcat);
  total = cat.$getchildcount();
  if ((m.movidx >= total)) {
    m.movidx = (total - 1);
  }
  if ((m.movidx < 0)) {
    m.movidx = 0;
  }
  page = $idiv(m.movidx, 10);
  start = (page * 10);
  for (n = 0, $e20 = 9; n <= $e20; n++) {
    ix = (start + n);
    if ((ix >= total)) {
      break;
    }
    item = cat.$getchild(ix);
    favsync(item);
    col = (n % 5);
    ry = $idiv(n, 5);
    x = (col * 190);
    y = (ry * 276);
    focused = (((m.movside === "grid") && (ix === m.movidx)));
    border = "0x00000000";
    if (focused) {
      border = "0xFF8A24FF";
    }
    addrect(m.moviegrid, x, y, 176, 270, border);
    addrect(m.moviegrid, (x + 3), (y + 3), 170, 230, "0x1C1C24FF");
    logo = item.hdposterurl;
    if ((logo == null)) {
      logo = "";
    }
    coverposter(m.moviegrid, (x + 3), (y + 3), 170, 230, logo);
    namecolor = "0xFFFFFFFF";
    if (focused) {
      namecolor = "0x101016FF";
    }
    cap = cleantitle(item.title);
    yr = yearof(item.title);
    if (((yr !== "") && (m.mode === "movies"))) {
      cap = ((yr + "  ") + cap);
    }
    if (((m.mode === "movies") && (item.starrating === 100))) {
      addposter(m.moviegrid, (x + 138), (y + 6), 32, 32, "pkg:/images/heart_on.png");
    }
    addlabel(m.moviegrid, (x + 4), (y + 238), 168, fittext(cap, 160), namecolor, "font:SmallSystemFont");
  }
  m.moviehint.text = tx("Flechas: mover     OK: ver     Play: favorito     Atrás: buscar o letra A-Z");
  if ((m.mode === "series")) {
    m.moviehint.text = tx("Flechas: mover     OK: ver temporadas     Atrás: buscar o letra A-Z");
  }
  if ((m.mode === "adult")) {
    m.moviehint.text = tx("Flechas: mover     OK: ver     Atrás: buscar o letra A-Z");
  }
  if ((m.movside === "cw")) {
    m.moviehint.text = tx("OK: continuar     Abajo: catálogo     Play: quitar de Seguir viendo     Atrás: inicio");
  }
  if ((m.movside === "bar")) {
    m.moviehint.text = tx("Izq/Der: elegir     OK: abrir     Abajo: volver a la lista     Atrás: categorías");
  }
  if ((m.movside === "cats")) {
    m.moviehint.text = tx("Arriba/Abajo: categoría     Derecha: entrar     Atrás: inicio");
  }
  drawmoviebar(cat, total);
  if ((m.movpick === true)) {
    drawpicker(cat);
    m.moviehint.text = tx("Flechas: elegir letra     OK: ir     Atrás: cerrar");
  }
}

function yearof(title) {
  let p;
  if ((title == null)) {
    return "";
  }
  p = $instr(1, title, "(19");
  if ((p === 0)) {
    p = $instr(1, title, "(20");
  }
  if (((p === 0) || ((p + 5) > $len(title)))) {
    return "";
  }
  if (($mid(title, (p + 5), 1) !== ")")) {
    return "";
  }
  return $mid(title, (p + 1), 4);
}

function movieskey(key) {
  let ncat, cat, total, d;
  if (((m.vodroot == null) || (m.vodroot.$getchildcount() === 0))) {
    if ((key === "back")) {
      showhome();
    }
    return true;
  }
  if ((m.vson === true)) {
    return vskey(key);
  }
  if ((m.movpick === true)) {
    return pickkey(key);
  }
  if ((m.movside === "cw")) {
    return cwkey(key);
  }
  if ((m.movside === "bar")) {
    return barkey(key);
  }
  ncat = m.vodroot.$getchildcount();
  cat = m.vodroot.$getchild(m.movcat);
  total = 0;
  if ((cat != null)) {
    total = cat.$getchildcount();
  }
  if ((key === "options")) {
    vsopen();
    return true;
  }
  if ((key === "back")) {
    if ((m.movside === "grid")) {
      m.movside = "bar";
      if ((m.baridx == null)) {
        m.baridx = 1;
      }
      drawmovies();
    } else {
      showhome();
    }
    return true;
  } else if ((key === "up")) {
    if ((m.movside === "cats")) {
      if ((m.movcat > 0)) {
        m.movcat = (m.movcat - 1);
        m.movidx = 0;
      } else {
        m.movside = "bar";
        m.baridx = 0;
      }
    } else if ((m.movidx < 5)) {
      m.movside = "bar";
      m.baridx = 0;
    } else {
      m.movidx = (m.movidx - 5);
    }
    drawmovies();
    return true;
  } else if ((key === "down")) {
    if ((m.movside === "cats")) {
      if ((m.movcat < (ncat - 1))) {
        m.movcat = (m.movcat + 1);
        m.movidx = 0;
      }
    } else if (((m.movidx + 5) < total)) {
      m.movidx = (m.movidx + 5);
    }
    drawmovies();
    return true;
  } else if ((key === "left")) {
    if ((m.movside === "grid")) {
      if (((total === 0) || (((m.movidx % 5)) === 0))) {
        m.movside = "cats";
      } else {
        m.movidx = (m.movidx - 1);
      }
      drawmovies();
    }
    return true;
  } else if ((key === "right")) {
    if ((m.movside === "cats")) {
      m.movside = "grid";
    } else if ((m.movidx < (total - 1))) {
      m.movidx = (m.movidx + 1);
    }
    drawmovies();
    return true;
  } else if ((key === "OK")) {
    if ((m.movside === "cats")) {
      m.movside = "grid";
      drawmovies();
    } else if ((((cat != null) && (m.movidx >= 0)) && (m.movidx < total))) {
      vodopen(cat.$getchild(m.movidx));
    }
    return true;
  } else if (((key === "rev") || (key === "fwd"))) {
    if ((((m.movside === "grid") && (cat != null)) && (total > 0))) {
      d = 1;
      if ((key === "rev")) {
        d = (-1);
      }
      m.movidx = letterjump(cat, m.movidx, d);
      drawmovies();
    }
    return true;
  } else if ((key === "play")) {
    if ((((((m.mode === "movies") && (m.movside === "grid")) && (cat != null)) && (m.movidx >= 0)) && (m.movidx < total))) {
      togglefavorite(cat.$getchild(m.movidx));
    }
    return true;
  }
  return true;
}

function drawfavs() {
  let items, page, start, n, $e21, ix, f, col, ry, x, y, focused, border, logo, $e22, bg, color;
  clearnode(m.favbody);
  if ((m.favtab === "movie")) {
    m.favtablive.color = "0xA8ADB5FF";
    m.favtabmovie.color = "0xFF8A24FF";
  } else {
    m.favtab = "live";
    m.favtablive.color = "0xFF8A24FF";
    m.favtabmovie.color = "0xA8ADB5FF";
  }
  items = favitems(m.favtab);
  if ((items.$count() === 0)) {
    addlabel(m.favbody, 12, 40, 900, tx("Aún no hay favoritos. En un canal o película pulsa el botón Play (o * en la lista)."), "0xA8ADB5FF", "font:SmallSystemFont");
    m.favhint.text = tx("Izquierda / Derecha: canales o peliculas     Atras: inicio");
    return;
  }
  if ((m.favidx >= items.$count())) {
    m.favidx = (items.$count() - 1);
  }
  if ((m.favidx < 0)) {
    m.favidx = 0;
  }
  if ((m.favtab === "movie")) {
    page = $idiv(m.favidx, 10);
    start = (page * 10);
    for (n = 0, $e21 = 9; n <= $e21; n++) {
      ix = (start + n);
      if ((ix >= items.$count())) {
        break;
      }
      f = $ix(items, ix);
      col = (n % 5);
      ry = $idiv(n, 5);
      x = ((col * 190) + 280);
      y = (ry * 260);
      focused = ((ix === m.favidx));
      border = "0x00000000";
      if (focused) {
        border = "0xFF8A24FF";
      }
      addrect(m.favbody, x, y, 176, 246, border);
      addrect(m.favbody, (x + 3), (y + 3), 170, 200, "0x1C1C24FF");
      logo = f.l;
      if ((logo == null)) {
        logo = "";
      }
      coverposter(m.favbody, (x + 3), (y + 3), 170, 200, logo);
      addlabel(m.favbody, (x + 4), (y + 210), 168, fittext(cleanglyphs(f.t), 160), "0xFFFFFFFF", "font:SmallSystemFont");
    }
  } else {
    page = $idiv(m.favidx, 8);
    start = (page * 8);
    for (n = 0, $e22 = 7; n <= $e22; n++) {
      ix = (start + n);
      if ((ix >= items.$count())) {
        break;
      }
      f = $ix(items, ix);
      y = (n * 62);
      bg = "0x00000000";
      color = "0xFFFFFFFF";
      if ((ix === m.favidx)) {
        bg = "0xFF8A2433";
        color = "0xFF8A24FF";
      }
      addrect(m.favbody, 0, y, 1100, 56, bg);
      logo = f.l;
      if ((logo == null)) {
        logo = "";
      }
      if ((logo !== "")) {
        addposter(m.favbody, 8, (y + 8), 72, 40, logo);
      }
      addlabel(m.favbody, 96, (y + 14), 900, fittext(cleanglyphs(f.t), 880), color, "font:MediumSystemFont");
      addposter(m.favbody, 1130, (y + 10), 36, 36, "pkg:/images/heart_on.png");
    }
  }
  m.favhint.text = tx("Flechas: mover     OK: ver     Play: quitar de favoritos     Izq/Der: cambiar pestaña     Atrás: inicio");
}

function favskey(key) {
  let items, jump;
  items = favitems(m.favtab);
  if ((key === "back")) {
    showhome();
    return true;
  } else if ((key === "left")) {
    if ((((m.favtab === "movie") && (items.$count() > 0)) && (((m.favidx % 5)) !== 0))) {
      m.favidx = (m.favidx - 1);
    } else {
      m.favtab = "live";
      m.favidx = 0;
    }
    drawfavs();
    return true;
  } else if ((key === "right")) {
    if (((m.favtab === "movie") && (m.favidx < (items.$count() - 1)))) {
      m.favidx = (m.favidx + 1);
    } else if ((m.favtab === "live")) {
      m.favtab = "movie";
      m.favidx = 0;
    }
    drawfavs();
    return true;
  } else if ((key === "up")) {
    jump = 1;
    if ((m.favtab === "movie")) {
      jump = 5;
    }
    if (((m.favidx - jump) >= 0)) {
      m.favidx = (m.favidx - jump);
    }
    drawfavs();
    return true;
  } else if ((key === "down")) {
    jump = 1;
    if ((m.favtab === "movie")) {
      jump = 5;
    }
    if (((m.favidx + jump) < items.$count())) {
      m.favidx = (m.favidx + jump);
    }
    drawfavs();
    return true;
  } else if ((key === "OK")) {
    if (((m.favidx >= 0) && (m.favidx < items.$count()))) {
      playnode(favtoitem($ix(items, m.favidx)), "favs");
    }
    return true;
  } else if ((key === "play")) {
    if (((m.favidx >= 0) && (m.favidx < items.$count()))) {
      togglefavorite(favtoitem($ix(items, m.favidx)));
    }
    return true;
  }
  return true;
}

function vodopen(item) {
  let d;
  if ((item == null)) {
    return;
  }
  if ((m.mode === "adult")) {
    d = item.description;
    if ((d === "series")) {
      m.epback = "adult";
      showepisodes(item);
    } else if ((d === "live")) {
      playnode(item, "adult");
    } else {
      showdetail(item, "adult");
    }
  } else if ((m.mode === "series")) {
    m.epback = "series";
    showepisodes(item);
  } else {
    showdetail(item, "movies");
  }
}

function playnode(item, backto) {
  let video, fmt;
  if ((((item == null) || (item.url == null)) || (item.url === ""))) {
    return;
  }
  m.playingitem = item;
  m.returnmode = backto;
  m.mode = "video";
  hidepanels();
  closeguidelayout();
  m.topbar.visible = false;
  setbganim(false);
  bgmstop();
  m.videoplayer.visible = true;
  m.videoplayer.translation = [0, 0];
  m.videoplayer.width = 1280;
  m.videoplayer.height = 720;
  video = $createobject("roSGNode", "ContentNode");
  video.title = item.title;
  video.url = item.url;
  fmt = item.streamformat;
  if (((fmt == null) || (fmt === ""))) {
    fmt = "hls";
  }
  video.streamformat = fmt;
  if ((item.description !== "movie")) {
    video.live = true;
  }
  m.alttried = false;
  stabreset();
  m.videoplayer.control = "stop";
  m.videoplayer.content = video;
  bmprepare(item);
  cwbegin(item, backto);
  m.videoplayer.control = "play";
  capturekeys();
  showoverlay("loading");
  showbanner("");
}

function showtoast(title, subtitle, hint) {
  let an;
  for (an of $iter(m.toastanims)) {
    an.control = "stop";
  }
  m.toastcheck.scale = [0.2, 0.2];
  m.toastcheck.opacity = 0;
  m.toastring.scale = [1, 1];
  m.toastring.opacity = 0;
  m.toasttitle.text = title;
  m.toastsub.text = subtitle;
  m.toasthint.text = hint;
  m.toast.visible = true;
  playchime();
  for (an of $iter(m.toastanims)) {
    an.control = "start";
  }
  m.toasttimer.control = "stop";
  m.toasttimer.control = "start";
}

function hidetoast() {
  let an;
  m.toast.visible = false;
  m.toasttimer.control = "stop";
  for (an of $iter(m.toastanims)) {
    an.control = "stop";
  }
}

function playchime() {
  if ((m.sfx == null)) {
    return;
  }
  bgmstop();
  m.sfx.control = "stop";
  m.sfx.control = "play";
}

function onsfxstate() {
  let st;
  st = m.sfx.state;
  if (((st === "finished") || (st === "error"))) {
    bgmstart();
  }
}
// ---- components/qr.brs ----
function qrxor(a, b) {
  return ((a + b) - (2 * ($and(a, b))));
}

function qrmul(x, y) {
  let z, i, $e0;
  z = 0;
  for (i = 7, $e0 = 0; i >= $e0; i--) {
    z = qrxor((z << 1), (((z >> 7)) * 285));
    z = qrxor(z, (($and(((y >> i)), 1)) * x));
  }
  return z;
}

function qrmatrix(text) {
  let n, size, bits, i, $e1, total, tl, $e2, data, $e3, v, j, $e4, padbyte, b1, b2, $e5, e1, e2, $e6, $e7, mods, isfn, y, $e8, a, b, x, $e9, $e10, dy, $e11, dx, $e12, dist, idx, right, vert, $e13, $e14, upward, bit, $e15, $e16;
  n = $len(text);
  if ($or((n > 32), (n < 1))) {
    return null;
  }
  size = 29;
  bits = [];
  qrpush(bits, 4, 4);
  qrpush(bits, n, 8);
  for (i = 1, $e1 = n; i <= $e1; i++) {
    qrpush(bits, $and($asc($mid(text, i, 1)), 255), 8);
  }
  total = (34 * 8);
  tl = (total - bits.$count());
  if ((tl > 4)) {
    tl = 4;
  }
  for (i = 1, $e2 = tl; i <= $e2; i++) {
    bits.$push(0);
  }
  while ((((bits.$count() % 8)) !== 0)) {
    bits.$push(0);
  }
  data = [];
  for (i = 0, $e3 = (bits.$count() - 1); i <= $e3; i += 8) {
    v = 0;
    for (j = 0, $e4 = 7; j <= $e4; j++) {
      v = (((v << 1)) + $ix(bits, (i + j)));
    }
    data.$push(v);
  }
  padbyte = 236;
  while ((data.$count() < 34)) {
    data.$push(padbyte);
    if ((padbyte === 236)) {
      padbyte = 17;
    } else {
      padbyte = 236;
    }
  }
  b1 = [];
  b2 = [];
  for (i = 0, $e5 = 16; i <= $e5; i++) {
    b1.$push($ix(data, i));
    b2.$push($ix(data, (17 + i)));
  }
  e1 = qrrs(b1, 18);
  e2 = qrrs(b2, 18);
  data = [];
  for (i = 0, $e6 = 16; i <= $e6; i++) {
    data.$push($ix(b1, i));
    data.$push($ix(b2, i));
  }
  for (i = 0, $e7 = 17; i <= $e7; i++) {
    data.$push($ix(e1, i));
    data.$push($ix(e2, i));
  }
  mods = [];
  isfn = [];
  for (y = 0, $e8 = (size - 1); y <= $e8; y++) {
    a = [];
    b = [];
    for (x = 0, $e9 = (size - 1); x <= $e9; x++) {
      a.$push(0);
      b.$push(false);
    }
    mods.$push(a);
    isfn.$push(b);
  }
  for (i = 0, $e10 = (size - 1); i <= $e10; i++) {
    qrset(mods, isfn, 6, i, (((i + 1)) % 2));
    qrset(mods, isfn, i, 6, (((i + 1)) % 2));
  }
  qrfinder(mods, isfn, 3, 3, size);
  qrfinder(mods, isfn, (size - 4), 3, size);
  qrfinder(mods, isfn, 3, (size - 4), size);
  for (dy = (-2), $e11 = 2; dy <= $e11; dy++) {
    for (dx = (-2), $e12 = 2; dx <= $e12; dx++) {
      dist = $abs(dx);
      if (($abs(dy) > dist)) {
        dist = $abs(dy);
      }
      v = 1;
      if ((dist === 1)) {
        v = 0;
      }
      qrset(mods, isfn, (22 + dx), (22 + dy), v);
    }
  }
  qrformat(mods, isfn, size);
  idx = 0;
  right = (size - 1);
  while ((right >= 1)) {
    if ((right === 6)) {
      right = 5;
    }
    for (vert = 0, $e13 = (size - 1); vert <= $e13; vert++) {
      for (j = 0, $e14 = 1; j <= $e14; j++) {
        x = (right - j);
        upward = (($and(((right + 1)), 2)) === 0);
        if (upward) {
          y = ((size - 1) - vert);
        } else {
          y = vert;
        }
        if ($and($not($ix($ix(isfn, y), x)), (idx < (data.$count() * 8)))) {
          bit = $and((($ix(data, (idx >> 3)) >> ((7 - ($and(idx, 7)))))), 1);
          $six($ix(mods, y), x, bit);
          idx = (idx + 1);
        }
      }
    }
    right = (right - 2);
  }
  for (y = 0, $e15 = (size - 1); y <= $e15; y++) {
    for (x = 0, $e16 = (size - 1); x <= $e16; x++) {
      if ($and($not($ix($ix(isfn, y), x)), (((((x + y)) % 2)) === 0))) {
        $six($ix(mods, y), x, (1 - $ix($ix(mods, y), x)));
      }
    }
  }
  qrformat(mods, isfn, size);
  return mods;
}

function qrrs(blk, ec) {
  let divisor, i, $e17, root, $e18, j, $e19, rmd, $e20, b, factor, $e21;
  divisor = [];
  for (i = 0, $e17 = (ec - 1); i <= $e17; i++) {
    divisor.$push(0);
  }
  $six(divisor, (ec - 1), 1);
  root = 1;
  for (i = 0, $e18 = (ec - 1); i <= $e18; i++) {
    for (j = 0, $e19 = (ec - 1); j <= $e19; j++) {
      $six(divisor, j, qrmul($ix(divisor, j), root));
      if (((j + 1) < ec)) {
        $six(divisor, j, qrxor($ix(divisor, j), $ix(divisor, (j + 1))));
      }
    }
    root = qrmul(root, 2);
  }
  rmd = [];
  for (i = 0, $e20 = (ec - 1); i <= $e20; i++) {
    rmd.$push(0);
  }
  for (b of $iter(blk)) {
    factor = qrxor(b, $ix(rmd, 0));
    rmd.$delete(0);
    rmd.$push(0);
    for (i = 0, $e21 = (ec - 1); i <= $e21; i++) {
      $six(rmd, i, qrxor($ix(rmd, i), qrmul($ix(divisor, i), factor)));
    }
  }
  return rmd;
}

function qrpush(bits, value, count) {
  let i, $e22;
  for (i = (count - 1), $e22 = 0; i >= $e22; i--) {
    bits.$push($and(((value >> i)), 1));
  }
}

function qrset(mods, isfn, x, y, v) {
  $six($ix(mods, y), x, v);
  $six($ix(isfn, y), x, true);
}

function qrfinder(mods, isfn, cx, cy, size) {
  let dy, $e23, dx, $e24, dist, x, y, v;
  for (dy = (-4), $e23 = 4; dy <= $e23; dy++) {
    for (dx = (-4), $e24 = 4; dx <= $e24; dx++) {
      dist = $abs(dx);
      if (($abs(dy) > dist)) {
        dist = $abs(dy);
      }
      x = (cx + dx);
      y = (cy + dy);
      if ($and($and($and((x >= 0), (x < size)), (y >= 0)), (y < size))) {
        v = 1;
        if ($or((dist === 2), (dist === 4))) {
          v = 0;
        }
        qrset(mods, isfn, x, y, v);
      }
    }
  }
}

function qrformat(mods, isfn, size) {
  let dat, rmd, i, $e25, bits, $e26, $e27, $e28, $e29;
  dat = 24;
  rmd = dat;
  for (i = 0, $e25 = 9; i <= $e25; i++) {
    rmd = qrxor((rmd << 1), (((rmd >> 9)) * 1335));
  }
  bits = qrxor($or(((dat << 10)), rmd), 21522);
  for (i = 0, $e26 = 5; i <= $e26; i++) {
    qrset(mods, isfn, 8, i, $and(((bits >> i)), 1));
  }
  qrset(mods, isfn, 8, 7, $and(((bits >> 6)), 1));
  qrset(mods, isfn, 8, 8, $and(((bits >> 7)), 1));
  qrset(mods, isfn, 7, 8, $and(((bits >> 8)), 1));
  for (i = 9, $e27 = 14; i <= $e27; i++) {
    qrset(mods, isfn, (14 - i), 8, $and(((bits >> i)), 1));
  }
  for (i = 0, $e28 = 7; i <= $e28; i++) {
    qrset(mods, isfn, ((size - 1) - i), 8, $and(((bits >> i)), 1));
  }
  for (i = 8, $e29 = 14; i <= $e29; i++) {
    qrset(mods, isfn, 8, ((size - 15) + i), $and(((bits >> i)), 1));
  }
  qrset(mods, isfn, 8, (size - 8), 1);
}
// ---- components/utils.brs ----
function getattr(s, key) {
  let pat, p, okp, vstart, q, e, total, c;
  pat = (key + "=");
  p = $instr(1, s, pat);
  while ((p > 0)) {
    okp = false;
    if ((p === 1)) {
      okp = true;
    } else {
      okp = (($mid(s, (p - 1), 1) === " "));
    }
    if (okp) {
      break;
    }
    p = $instr((p + 1), s, pat);
  }
  if ((p === 0)) {
    return "";
  }
  vstart = (p + $len(pat));
  q = $mid(s, vstart, 1);
  if (((q === $chr(34)) || (q === "'"))) {
    e = $instr((vstart + 1), s, q);
    if ((e === 0)) {
      return "";
    }
    return $mid(s, (vstart + 1), ((e - vstart) - 1));
  }
  total = $len(s);
  e = vstart;
  while ((e <= total)) {
    c = $mid(s, e, 1);
    if (((c === " ") || (c === ","))) {
      break;
    }
    e = (e + 1);
  }
  return $mid(s, vstart, (e - vstart));
}

function normname(s) {
  let out, i, $e0, c, a;
  s = $lcase(s);
  out = "";
  for (i = 1, $e0 = $len(s); i <= $e0; i++) {
    c = $mid(s, i, 1);
    a = $asc(c);
    if (((((a >= 97) && (a <= 122))) || (((a >= 48) && (a <= 57))))) {
      out = (out + c);
    }
  }
  return out;
}

function decodeentities(s) {
  let p, semi, numstr, code, repl;
  p = $instr(1, s, "&#");
  while ((p > 0)) {
    semi = $instr(p, s, ";");
    if (((semi === 0) || ((semi - p) > 8))) {
      break;
    }
    numstr = $mid(s, (p + 2), ((semi - p) - 2));
    code = 0;
    if ((($left(numstr, 1) === "x") || ($left(numstr, 1) === "X"))) {
      code = $val($mid(numstr, 2), 16);
    } else {
      code = $val(numstr, 10);
    }
    repl = "";
    if ((code > 0)) {
      repl = $chr(code);
    }
    s = (($left(s, (p - 1)) + repl) + $mid(s, (semi + 1)));
    p = $instr((p + 1), s, "&#");
  }
  s = s.$replace("&lt;", "<");
  s = s.$replace("&gt;", ">");
  s = s.$replace("&quot;", $chr(34));
  s = s.$replace("&apos;", "'");
  s = s.$replace("&#39;", "'");
  s = s.$replace("&amp;", "&");
  return s;
}

function pad2(n) {
  if ((n < 10)) {
    return ("0" + n.$tostr());
  }
  return n.$tostr();
}

function fmttime(secs) {
  let dt;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  return i18nhm(dt.$gethours(), pad2(dt.$getminutes()), false);
}

function fmttimelong(secs) {
  let dt;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  return i18nhm(dt.$gethours(), pad2(dt.$getminutes()), true);
}

function fmtday(secs) {
  let dt, days, months;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  days = i18ndow3();
  months = i18nmon3();
  return (((($ix(days, dt.$getdayofweek()) + " ") + dt.$getdayofmonth().$tostr()) + " ") + $ix(months, (dt.$getmonth() - 1)));
}

function cleanlogo(u) {
  let low, base, q;
  u = u.$trim();
  if (((u === "") || ($len(u) > 2000))) {
    return "";
  }
  low = $lcase(u);
  if (($left(low, 4) !== "http")) {
    return "";
  }
  base = low;
  q = $instr(1, low, "?");
  if ((q > 0)) {
    base = $left(low, (q - 1));
  }
  if (($right(base, 4) === ".svg")) {
    return "";
  }
  return u;
}

function epgwantedof(root) {
  let wanted, i, $e1, cat, j, $e2, ch, cid, nk;
  wanted = {__proto__: $AAP};
  if ((root == null)) {
    return wanted;
  }
  for (i = 0, $e1 = (root.$getchildcount() - 1); i <= $e1; i++) {
    cat = root.$getchild(i);
    for (j = 0, $e2 = (cat.$getchildcount() - 1); j <= $e2; j++) {
      ch = cat.$getchild(j);
      cid = ch.id;
      if (((cid != null) && (cid !== ""))) {
        $six(wanted, $lcase(cid), true);
      }
      nk = normname(ch.title);
      if ((nk !== "")) {
        $six(wanted, nk, true);
      }
    }
  }
  return wanted;
}
// ---- components/controls.brs ----
function initcontrols() {
  let b, uris, i, $e0, x, f, ic, p;
  m.ctlbar = m.top.$findnode("ctlBar");
  m.trackpanel = m.top.$findnode("trackPanel");
  m.ctlhidetimer = m.top.$findnode("ctlHideTimer");
  m.ctlticktimer = m.top.$findnode("ctlTickTimer");
  m.ctlhidetimer.duration = 5;
  m.ctlticktimer.duration = 0.5;
  b = m.ctlbar;
  clearnode(b);
  dtfullimage(b, 0, 0, 1280, 200, "pkg:/images/grad_top.png");
  dtfullimage(b, 0, 0, 1280, 720, "pkg:/images/grad_bottom.png");
  m.ctltitle = dttext(b, 64, 44, 980, "", "0xFFFFFFFF", 30, "Bold");
  m.ctlsub = dttext(b, 64, 88, 980, "", "0xC8CCD2FF", 18, "Regular");
  m.ctllive = b.$createchild("Group");
  dtbox(m.ctllive, 1110, 48, 106, 30, "pkg:/images/rr_pill.9.png", "0xE5243BFF", 1.0);
  m.ctllivelbl = dttext(m.ctllive, 1110, 53, 106, "", "0xFFFFFFFF", 15, "Bold");
  m.ctllivelbl.horizalign = "center";
  m.ctlmsg = dttext(b, 64, 540, 1152, "", "0xFFFFFFFF", 18, "SemiBold");
  m.ctlmsg.horizalign = "center";
  m.ctltrack = addrect(b, 64, 598, 1152, 6, "0xFFFFFF40");
  m.ctlfill = addrect(b, 64, 598, 0, 6, "0xFF8A24FF");
  m.ctlknob = addposter(b, 53, 590, 22, 22, "pkg:/images/knob.png");
  m.ctlpreview = b.$createchild("Group");
  m.ctlpreviewbox = dtbox(m.ctlpreview, 0, 548, 150, 34, "pkg:/images/rr_pill.9.png", "0xFFFFFFFF", 1.0);
  m.ctlpreviewlbl = dttext(m.ctlpreview, 0, 553, 150, "", "0x0A0A0FFF", 17, "Bold");
  m.ctlpreviewlbl.horizalign = "center";
  m.ctlpreview.visible = false;
  m.ctlpos = dttext(b, 64, 614, 200, "", "0xE6E8EBFF", 16, "SemiBold");
  m.ctldur = dttext(b, 1016, 614, 200, "", "0xA8ADB5FF", 16, "SemiBold");
  m.ctldur.horizalign = "right";
  m.ctlbtnx = [395, 475, 555, 665, 745, 825];
  m.ctlfocus = [];
  m.ctlicons = [];
  uris = ["ctl_rew", "ctl_pause", "ctl_fwd", "ctl_cc", "ctl_audio", "ctl_heart"];
  for (i = 0, $e0 = 5; i <= $e0; i++) {
    x = $ix(m.ctlbtnx, i);
    f = dtbox(b, x, 642, 64, 52, "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 1.0);
    f.visible = false;
    m.ctlfocus.$push(f);
    ic = addposter(b, (x + 14), 650, 36, 36, (("pkg:/images/" + $ix(uris, i)) + ".png"));
    m.ctlicons.$push(ic);
  }
  m.ctlname = dttext(b, 905, 658, 320, "", "0xA8ADB5FF", 16, "Regular");
  m.ctlhelp = dttext(b, 64, 658, 320, "", "0xA8ADB5FF", 16, "Regular");
  p = m.trackpanel;
  clearnode(p);
  addrect(p, 0, 0, 1280, 720, "0x00000070");
  addrect(p, 820, 0, 460, 720, "0x0E0F13F5");
  addrect(p, 820, 0, 3, 720, "0xFF8A24FF");
  m.tracktitle = dttext(p, 860, 64, 380, "", "0xFFFFFFFF", 26, "Bold");
  m.trackbody = p.$createchild("Group");
  m.trackhint = dttext(p, 860, 664, 380, "", "0x80858CFF", 15, "Regular");
  m.seektimer = $createobject("roSGNode", "Timer");
  m.seektimer.duration = 0.8;
  m.seektimer.repeat = false;
  m.top.$appendchild(m.seektimer);
  m.seektimer.$observefield("fire", "seekCommit");
  m.ctlclock = $createobject("roTimespan");
  m.ctlopen = false;
  m.ctlidx = 1;
  m.ctlrow = "btns";
  m.seektarget = (-1);
  m.seeksteps = 0;
  m.seekhold = (-1);
  m.seekholdat = 0;
  m.ctlmsgat = 0;
  m.trackkind = "";
  m.trackitems = [];
  m.tracksel = 0;
  m.ctlhidetimer.$observefield("fire", "hideControls");
  m.ctlticktimer.$observefield("fire", "ctlUpdate");
}

function ctlfmt(secs) {
  let s, h, mi, se, ss, ms;
  s = $int(secs);
  if ((s < 0)) {
    s = 0;
  }
  h = $idiv(s, 3600);
  mi = $idiv(((s % 3600)), 60);
  se = (s % 60);
  ss = se.$tostr();
  if ((se < 10)) {
    ss = ("0" + ss);
  }
  if ((h > 0)) {
    ms = mi.$tostr();
    if ((mi < 10)) {
      ms = ("0" + ms);
    }
    return ((((h.$tostr() + ":") + ms) + ":") + ss);
  }
  return ((mi.$tostr() + ":") + ss);
}

function ismovieitem() {
  return ((m.playingitem != null) && (m.playingitem.description === "movie"));
}

function ctlduration() {
  let d;
  d = m.videoplayer.duration;
  if ((d == null)) {
    return 0;
  }
  return d;
}

function ctlposition() {
  let p;
  p = m.videoplayer.position;
  if ((p == null)) {
    return 0;
  }
  return p;
}

function showcontrols() {
  if (((!m.videoplayer.visible) || m.guideopen)) {
    return;
  }
  if (((m.ovstate === "loading") || (m.ovstate === "fail"))) {
    return;
  }
  m.zapbanner.visible = false;
  m.zaptimer.control = "stop";
  if ((!m.ctlopen)) {
    m.ctlrow = "btns";
    m.ctlidx = 1;
  }
  m.ctlopen = true;
  m.ctlbar.visible = true;
  ctlupdate();
  m.ctlticktimer.control = "start";
  restartctlhide();
}

function restartctlhide() {
  m.ctlhidetimer.control = "stop";
  if ((m.videoplayer.state === "paused")) {
    return;
  }
  if ((m.seektarget >= 0)) {
    return;
  }
  if (m.trackpanel.visible) {
    return;
  }
  m.ctlhidetimer.control = "start";
}

function hidecontrols() {
  if ((m.seektarget >= 0)) {
    seekcommit();
  }
  m.ctlopen = false;
  m.ctlbar.visible = false;
  m.ctlhidetimer.control = "stop";
  m.ctlticktimer.control = "stop";
  m.trackpanel.visible = false;
  m.ctlmsg.text = "";
  capturekeys();
}

function ctlshownpos() {
  let cur;
  if ((m.seektarget >= 0)) {
    return m.seektarget;
  }
  cur = ctlposition();
  if ((m.seekhold >= 0)) {
    if ((($abs((cur - m.seekhold)) > 3) && ((m.ctlclock.$totalmilliseconds() - m.seekholdat) < 12000))) {
      return m.seekhold;
    }
    m.seekhold = (-1);
  }
  return cur;
}

function ctlbtnname(i) {
  if ((i === 0)) {
    return tx("Retroceder");
  }
  if ((i === 1)) {
    if ((m.videoplayer.state === "paused")) {
      return tx("Reproducir");
    }
    return tx("Pausa");
  }
  if ((i === 2)) {
    return tx("Adelantar");
  }
  if ((i === 3)) {
    return tx("Subtítulos");
  }
  if ((i === 4)) {
    return tx("Idioma del audio");
  }
  return tx("Favorito");
}

function ctlupdate() {
  let item, live, sub2, dur, curpos, baron, th, ty, w, ks, txt, delta, sign, pw, px, fav, i, $e1;
  if ((!m.ctlopen)) {
    return;
  }
  if (((m.ctlmsg.text !== "") && (m.ctlmsgat != null))) {
    if ((((m.ctlclock.$totalmilliseconds() - m.ctlmsgat) > 3500) && (m.ctlmsg.text !== tx("En pausa")))) {
      m.ctlmsg.text = "";
    }
  }
  item = currentitem();
  live = ((ctlduration() <= 0));
  if ((item != null)) {
    if (ismovieitem()) {
      m.ctltitle.text = cleantitle(item.title);
      m.ctlsub.text = "";
    } else {
      m.ctltitle.text = displayname(item);
      sub2 = item.releasedate;
      if ((sub2 == null)) {
        sub2 = "";
      }
      m.ctlsub.text = sub2;
    }
  }
  m.ctllive.visible = live;
  m.ctllivelbl.text = tx("EN VIVO");
  dur = ctlduration();
  curpos = ctlshownpos();
  baron = ((m.ctlrow === "bar"));
  th = 6;
  if ((baron || (m.seektarget >= 0))) {
    th = 10;
  }
  m.ctltrack.height = th;
  m.ctlfill.height = th;
  ty = (601 - $idiv(th, 2));
  m.ctltrack.translation = [64, ty];
  m.ctlfill.translation = [64, ty];
  if ((!live)) {
    w = $int(((1152 * curpos) / dur));
    if ((w > 1152)) {
      w = 1152;
    }
    if ((w < 0)) {
      w = 0;
    }
    m.ctlfill.width = w;
    ks = 22;
    if ((baron || (m.seektarget >= 0))) {
      ks = 30;
    }
    m.ctlknob.width = ks;
    m.ctlknob.height = ks;
    m.ctlknob.translation = [((64 + w) - $idiv(ks, 2)), (601 - $idiv(ks, 2))];
    m.ctlknob.visible = true;
    m.ctlpos.text = ctlfmt(curpos);
    m.ctldur.text = ("-" + ctlfmt((dur - curpos)));
    if (((m.seektarget >= 0) || baron)) {
      txt = ctlfmt(curpos);
      if ((m.seektarget >= 0)) {
        delta = $int((m.seektarget - ctlposition()));
        sign = "+";
        if ((delta < 0)) {
          sign = "-";
        }
        txt = (((txt + "   ") + sign) + ctlfmt($abs(delta)));
      }
      m.ctlpreviewlbl.text = txt;
      pw = 150;
      if ((m.seektarget >= 0)) {
        pw = 200;
      }
      px = ((64 + w) - $idiv(pw, 2));
      if ((px < 40)) {
        px = 40;
      }
      if (((px + pw) > 1240)) {
        px = (1240 - pw);
      }
      m.ctlpreviewbox.width = pw;
      m.ctlpreviewbox.translation = [px, 548];
      m.ctlpreviewlbl.width = pw;
      m.ctlpreviewlbl.translation = [px, 554];
      m.ctlpreview.visible = true;
    } else {
      m.ctlpreview.visible = false;
    }
  } else {
    m.ctlfill.width = 1152;
    m.ctlknob.visible = false;
    m.ctlpreview.visible = false;
    m.ctlpos.text = "";
    m.ctldur.text = "";
  }
  if ((m.videoplayer.state === "paused")) {
    $ix(m.ctlicons, 1).uri = "pkg:/images/ctl_play.png";
  } else {
    $ix(m.ctlicons, 1).uri = "pkg:/images/ctl_pause.png";
  }
  fav = false;
  if ((((item != null) && (m.favmap != null)) && (item.url != null))) {
    fav = m.favmap.$doesexist(item.url);
  }
  if (fav) {
    $ix(m.ctlicons, 5).uri = "pkg:/images/ctl_heart_on.png";
  } else {
    $ix(m.ctlicons, 5).uri = "pkg:/images/ctl_heart.png";
  }
  for (i = 0, $e1 = 5; i <= $e1; i++) {
    $ix(m.ctlfocus, i).visible = (((m.ctlrow === "btns") && (i === m.ctlidx)));
  }
  if ((m.ctlrow === "btns")) {
    m.ctlname.text = ctlbtnname(m.ctlidx);
    if (live) {
      m.ctlhelp.text = tx("Arriba/Abajo: cambiar canal");
    } else {
      m.ctlhelp.text = tx("Arriba: barra de tiempo");
    }
  } else {
    m.ctlname.text = "";
    m.ctlhelp.text = tx("Izq/Der: buscar    OK: ir");
  }
}

function seekby(secs) {
  if ((secs < 0)) {
    scrub((-1));
  } else {
    scrub(1);
  }
}

function scrub(dir) {
  let dur, base, stp, target;
  if ((m.ovstate === "fail")) {
    return;
  }
  dur = ctlduration();
  if ((dur <= 0)) {
    if ((!m.ctlopen)) {
      showcontrols();
    }
    ctlsay(tx("Este canal en vivo no permite adelantar"));
    return;
  }
  if ((!m.ctlopen)) {
    showcontrols();
  }
  m.ctlrow = "bar";
  if ((m.seektarget < 0)) {
    base = ctlshownpos();
    m.seeksteps = 0;
  } else {
    base = m.seektarget;
  }
  m.seeksteps = (m.seeksteps + 1);
  stp = 10;
  if ((m.seeksteps > 3)) {
    stp = 30;
  }
  if ((m.seeksteps > 6)) {
    stp = 60;
  }
  if ((m.seeksteps > 10)) {
    stp = 120;
  }
  target = (base + (dir * stp));
  if ((target < 0)) {
    target = 0;
  }
  if ((target > (dur - 3))) {
    target = (dur - 3);
  }
  m.seektarget = target;
  m.ctlmsg.text = "";
  m.seektimer.control = "stop";
  m.seektimer.control = "start";
  m.ctlhidetimer.control = "stop";
  ctlupdate();
}

function quickseek(secs) {
  let dur, base, target;
  dur = ctlduration();
  if ((dur <= 0)) {
    return;
  }
  base = ctlshownpos();
  if ((m.seektarget >= 0)) {
    base = m.seektarget;
  }
  target = (base + secs);
  if ((target < 0)) {
    target = 0;
  }
  if ((target > (dur - 3))) {
    target = (dur - 3);
  }
  m.seektarget = target;
  seekcommit();
  if ((!m.ctlopen)) {
    showcontrols();
  }
}

function ctlsay(t) {
  m.ctlmsg.text = t;
  m.ctlmsgat = m.ctlclock.$totalmilliseconds();
}

function seekcommit() {
  let t;
  m.seektimer.control = "stop";
  if ((m.seektarget < 0)) {
    return;
  }
  t = m.seektarget;
  m.seektarget = (-1);
  m.seeksteps = 0;
  m.seekhold = t;
  m.seekholdat = m.ctlclock.$totalmilliseconds();
  m.videoplayer.seek = t;
  if ((m.videoplayer.state === "paused")) {
    m.videoplayer.control = "resume";
  }
  ctlupdate();
  restartctlhide();
}

function togglepause() {
  if (((m.ovstate === "loading") || (m.ovstate === "fail"))) {
    return;
  }
  if ((m.seektarget >= 0)) {
    seekcommit();
    return;
  }
  if ((m.videoplayer.state === "paused")) {
    m.videoplayer.control = "resume";
    m.ctlmsg.text = "";
  } else {
    m.videoplayer.control = "pause";
    ctlsay(tx("En pausa"));
  }
  if ((!m.ctlopen)) {
    showcontrols();
  }
  ctlupdate();
  restartctlhide();
}

function ctlactivate() {
  let i;
  i = m.ctlidx;
  if ((i === 0)) {
    scrub((-1));
  } else if ((i === 1)) {
    togglepause();
  } else if ((i === 2)) {
    scrub(1);
  } else if ((i === 3)) {
    opentrackpanel("sub");
  } else if ((i === 4)) {
    opentrackpanel("audio");
  } else if ((i === 5)) {
    togglefavorite(currentitem());
    ctlupdate();
  }
}

function ctlkey(key) {
  let live;
  if (m.trackpanel.visible) {
    return trackkey(key);
  }
  live = ((ctlduration() <= 0));
  if ((key === "back")) {
    if ((m.seektarget >= 0)) {
      m.seektarget = (-1);
      m.seeksteps = 0;
      m.seektimer.control = "stop";
      ctlupdate();
      restartctlhide();
    } else {
      hidecontrols();
    }
    return true;
  } else if ((key === "play")) {
    togglepause();
    return true;
  } else if ((key === "rev")) {
    scrub((-1));
    return true;
  } else if ((key === "fwd")) {
    scrub(1);
    return true;
  } else if ((key === "replay")) {
    if (ismovieitem()) {
      quickseek((-15));
    } else {
      hidecontrols();
      replaylast();
    }
    return true;
  }
  if ((m.ctlrow === "bar")) {
    if ((key === "left")) {
      scrub((-1));
    } else if ((key === "right")) {
      scrub(1);
    } else if ((key === "OK")) {
      if ((m.seektarget >= 0)) {
        seekcommit();
      } else {
        togglepause();
      }
    } else if ((key === "down")) {
      if ((m.seektarget >= 0)) {
        seekcommit();
      }
      m.ctlrow = "btns";
      ctlupdate();
      restartctlhide();
    } else if ((key === "up")) {
      hidecontrols();
    }
    return true;
  }
  if ((key === "left")) {
    if ((m.ctlidx > 0)) {
      m.ctlidx = (m.ctlidx - 1);
    }
    ctlupdate();
    restartctlhide();
  } else if ((key === "right")) {
    if ((m.ctlidx < 5)) {
      m.ctlidx = (m.ctlidx + 1);
    }
    ctlupdate();
    restartctlhide();
  } else if ((key === "OK")) {
    ctlactivate();
    restartctlhide();
  } else if ((key === "up")) {
    if (live) {
      hidecontrols();
      zap(1);
    } else {
      m.ctlrow = "bar";
      ctlupdate();
      restartctlhide();
    }
  } else if ((key === "down")) {
    if (live) {
      hidecontrols();
      zap((-1));
    } else {
      hidecontrols();
    }
  }
  return true;
}

function langname(s) {
  let t, rx, orig, lang, map, k;
  t = s.$trim();
  if (($left($lcase(t), 6) === "#uniq:")) {
    t = $mid(t, 7);
  }
  rx = $createobject("roRegex", "\\s*\\(\\d+\\)\\s*$", "");
  t = rx.$replace(t, "");
  orig = false;
  if (($instr(1, $lcase(t), "[original]") > 0)) {
    orig = true;
    t = t.$replace("[Original]", "").$replace("[original]", "").$trim();
  }
  lang = "";
  if (((m.global != null) && (m.global.lang != null))) {
    lang = m.global.lang;
  }
  if ((lang === "es")) {
    map = {__proto__: $AAP, "english": "Inglés", "eng": "Inglés", "en": "Inglés", "spanish": "Español", "spa": "Español", "es": "Español", "european spanish": "Español (España)", "castilian": "Español (España)", "spanish (spain)": "Español (España)", "latin american spanish": "Español (Latino)", "spanish (latin america)": "Español (Latino)", "latino": "Español (Latino)", "french": "Francés", "fre": "Francés", "fra": "Francés", "portuguese": "Portugués", "por": "Portugués", "brazilian portuguese": "Portugués (Brasil)", "italian": "Italiano", "ita": "Italiano", "german": "Alemán", "ger": "Alemán", "deu": "Alemán", "japanese": "Japonés", "jpn": "Japonés", "korean": "Coreano", "kor": "Coreano", "chinese": "Chino", "chi": "Chino", "russian": "Ruso", "rus": "Ruso", "und": "Desconocido"};
    k = $lcase(t);
    if (map.$doesexist(k)) {
      t = $ix(map, k);
    }
  }
  if ((t === "")) {
    return "";
  }
  if (orig) {
    t = ((t + "  ·  ") + tx("Original"));
  }
  return t;
}

function audiotech(s) {
  let k, map, v;
  k = $lcase(s.$trim());
  if ((k === "")) {
    return "";
  }
  map = {__proto__: $AAP, "surround": "Surround", "stereo": "Estéreo", "mono": "Mono", "5.1": "5.1", "7.1": "7.1", "2.0": "Estéreo", "dolby": "Dolby", "dolby digital": "Dolby", "dolby digital plus": "Dolby+", "ac3": "Dolby", "eac3": "Dolby+", "e-ac3": "Dolby+", "aac": "AAC", "dts": "DTS", "atmos": "Atmos", "default": "", "audio": ""};
  if (map.$doesexist(k)) {
    v = $ix(map, k);
    if ((v === "")) {
      return "-";
    }
    return tx(v);
  }
  if (((($instr(1, k, "surround") > 0) || ($instr(1, k, "stereo") > 0)) || ($instr(1, k, "5.1") > 0))) {
    return s.$trim();
  }
  return "";
}

function opentrackpanel(kind) {
  let items, seen, sel, tracks, cur, n, t, nameraw, langraw, tech, ln, nm, capon, raw, lr;
  m.trackkind = kind;
  items = [];
  seen = {__proto__: $AAP};
  sel = 0;
  if ((kind === "audio")) {
    tracks = m.videoplayer.availableaudiotracks;
    cur = m.videoplayer.audiotrack;
    if ((tracks != null)) {
      n = 0;
      for (t of $iter(tracks)) {
        n = (n + 1);
        nameraw = "";
        if ((t.name != null)) {
          nameraw = t.name.$trim();
        }
        langraw = "";
        if ((t.language != null)) {
          langraw = t.language.$trim();
        }
        tech = audiotech(nameraw);
        ln = "";
        if (((langraw !== "") && ($lcase(langraw) !== "und"))) {
          ln = langname(langraw);
        }
        nm = "";
        if ((tech !== "")) {
          nm = ln;
          if ((nm === "")) {
            nm = (tx("Pista ") + n.$tostr());
          }
          if ((tech !== "-")) {
            nm = ((nm + "  ·  ") + tech);
          }
        } else {
          if ((nameraw !== "")) {
            nm = langname(nameraw);
          }
          if ((nm === "")) {
            nm = ln;
          }
          if ((nm === "")) {
            nm = (tx("Pista ") + n.$tostr());
          }
        }
        if ((t.track === cur)) {
          sel = items.$count();
        }
        items.$push({__proto__: $AAP, "t": nm, "id": t.track});
      }
    }
    if ((items.$count() === 0)) {
      showcontrols();
      ctlsay(tx("Este contenido no ofrece otros idiomas de audio"));
      return;
    }
  } else {
    items.$push({__proto__: $AAP, "t": tx("Desactivados"), "id": ""});
    tracks = m.videoplayer.availablesubtitletracks;
    cur = m.videoplayer.subtitletrack;
    capon = ((m.videoplayer.globalcaptionmode === "On"));
    if ((tracks != null)) {
      for (t of $iter(tracks)) {
        raw = "";
        if (((t.description != null) && (t.description !== ""))) {
          raw = t.description;
        }
        if (((raw === "") && (t.language != null))) {
          raw = t.language;
        }
        lr = $lcase(raw.$trim());
        if (((((lr !== "") && (lr !== "off")) && (lr !== "none")) && (lr !== "disabled"))) {
          nm = langname(raw);
          if ((((t.language != null) && (t.language !== "")) && ($lcase(t.language) !== lr))) {
            ln = langname(t.language);
            if (((ln !== "") && (ln !== nm))) {
              nm = ((nm + "  ·  ") + ln);
            }
          }
          if ((!seen.$doesexist($lcase(nm)))) {
            $six(seen, $lcase(nm), true);
            if ((capon && (t.trackname === cur))) {
              sel = items.$count();
            }
            items.$push({__proto__: $AAP, "t": nm, "id": t.trackname});
          }
        }
      }
    }
    if ((items.$count() === 1)) {
      showcontrols();
      ctlsay(tx("Este contenido no trae subtítulos"));
      return;
    }
  }
  m.trackitems = items;
  m.tracksel = sel;
  m.trackcur = sel;
  if ((kind === "audio")) {
    m.tracktitle.text = tx("Idioma del audio");
  } else {
    m.tracktitle.text = tx("Subtítulos");
  }
  m.trackhint.text = tx("OK: elegir     Atrás: cerrar");
  drawtrackpanel();
  m.trackpanel.visible = true;
  m.ctlhidetimer.control = "stop";
}

function drawtrackpanel() {
  let g, n, first, y, i, $e2, focused, c;
  g = m.trackbody;
  clearnode(g);
  n = m.trackitems.$count();
  first = (m.tracksel - 6);
  if ((first < 0)) {
    first = 0;
  }
  y = 130;
  for (i = first, $e2 = (n - 1); i <= $e2; i++) {
    if ((y > 620)) {
      break;
    }
    focused = ((i === m.tracksel));
    if (focused) {
      dtbox(g, 844, y, 412, 56, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 1.0);
    }
    c = "0xE6E8EBFF";
    if (focused) {
      c = "0x0A0A0FFF";
    }
    dttext(g, 900, (y + 16), 340, fittext($ix(m.trackitems, i).t, 330), c, 20, "SemiBold");
    if ((i === m.trackcur)) {
      addposter(g, 858, (y + 15), 26, 26, "pkg:/images/check_circle.png");
    }
    y = (y + 64);
  }
}

function trackkey(key) {
  let n, it;
  n = m.trackitems.$count();
  if (((key === "back") || (key === "left"))) {
    m.trackpanel.visible = false;
    capturekeys();
    restartctlhide();
  } else if ((key === "up")) {
    if ((m.tracksel > 0)) {
      m.tracksel = (m.tracksel - 1);
    }
    drawtrackpanel();
  } else if ((key === "down")) {
    if ((m.tracksel < (n - 1))) {
      m.tracksel = (m.tracksel + 1);
    }
    drawtrackpanel();
  } else if ((key === "OK")) {
    it = $ix(m.trackitems, m.tracksel);
    if ((m.trackkind === "audio")) {
      m.videoplayer.audiotrack = it.id;
      ctlsay((tx("Audio: ") + it.t));
    } else {
      if ((it.id === "")) {
        m.videoplayer.globalcaptionmode = "Off";
        ctlsay(tx("Subtítulos desactivados"));
      } else {
        m.videoplayer.globalcaptionmode = "On";
        m.videoplayer.subtitletrack = it.id;
        ctlsay((tx("Subtítulos: ") + it.t));
      }
    }
    m.trackpanel.visible = false;
    capturekeys();
    ctlupdate();
    restartctlhide();
  }
  return true;
}
// ---- components/bookmarks.brs ----
function bmkey(url) {
  let ba;
  ba = $createobject("roByteArray");
  ba.$fromasciistring(url);
  return ba.$getcrc32().$tostr();
}

function initbookmarks() {
  let obj, now, k, v, sep, ts;
  m.bmtimer = m.top.$findnode("bmTimer");
  m.bmtimer.$observefield("fire", "onBmTick");
  m.resumepos = 0;
  m.bm = {__proto__: $AAP};
  if ((!m.sec.$exists("bookmarks"))) {
    return;
  }
  obj = $parsejson(m.sec.$read("bookmarks"));
  if (($type(obj) !== "roAssociativeArray")) {
    return;
  }
  now = $createobject("roDateTime").$asseconds();
  for (k of $iter(obj)) {
    v = $ix(obj, k);
    if ((($type(v) === "roString") || ($type(v) === "String"))) {
      sep = $instr(1, v, "|");
      if ((sep > 0)) {
        ts = $val($mid(v, (sep + 1)));
        if (((now - ts) < 5184000)) {
          $six(m.bm, k, v);
        }
      }
    }
  }
}

function bmposition(url) {
  let k, v, sep;
  k = bmkey(url);
  if ((!m.bm.$doesexist(k))) {
    return 0;
  }
  v = $ix(m.bm, k);
  sep = $instr(1, v, "|");
  if ((sep < 2)) {
    return 0;
  }
  return $int($val($left(v, (sep - 1))));
}

function bmsave(url, curpos, dur) {
  let k, oldkey, oldts, kk, v, ts;
  if (((curpos == null) || (dur == null))) {
    return;
  }
  if ((dur <= 900)) {
    return;
  }
  k = bmkey(url);
  if (((curpos < 30) || (curpos > (dur - 45)))) {
    if (m.bm.$doesexist(k)) {
      m.bm.$delete(k);
    }
  } else {
    $six(m.bm, k, (($int(curpos).$tostr() + "|") + $createobject("roDateTime").$asseconds().$tostr()));
  }
  while ((m.bm.$count() > 80)) {
    oldkey = "";
    oldts = 99999999999;
    for (kk of $iter(m.bm)) {
      v = $ix(m.bm, kk);
      ts = $val($mid(v, ($instr(1, v, "|") + 1)));
      if ((ts < oldts)) {
        oldts = ts;
        oldkey = kk;
      }
    }
    if ((oldkey === "")) {
      break;
    }
    m.bm.$delete(oldkey);
  }
  m.sec.$write("bookmarks", $formatjson(m.bm));
  m.sec.$flush();
}

function bmprepare(item) {
  m.resumepos = 0;
  m.bmtimer.control = "stop";
  if ((((item.description === "movie") && (item.url != null)) && (item.url !== ""))) {
    m.resumepos = bmposition(item.url);
    m.bmtimer.control = "start";
  }
}

function bmonplaying() {
  let p;
  if ((m.resumepos > 0)) {
    p = m.resumepos;
    m.resumepos = 0;
    m.videoplayer.seek = p;
    ctlsay((tx("Retomando desde ") + ctlfmt(p)));
    showcontrols();
  }
}

function onbmtick() {
  if ((m.videoplayer.state !== "playing")) {
    return;
  }
  bmsavenow();
}

function bmsavenow() {
  let item;
  item = m.playingitem;
  if ((((item == null) || (item.description !== "movie")) || (item.url == null))) {
    return;
  }
  if (((m.ovstate === "loading") || (m.ovstate === "fail"))) {
    return;
  }
  bmsave(item.url, m.videoplayer.position, m.videoplayer.duration);
  cwtick(m.videoplayer.position, m.videoplayer.duration);
}
// ---- components/welcome.brs ----
function greetingtext() {
  let dt, h;
  dt = $createobject("roDateTime");
  dt.$tolocaltime();
  h = dt.$gethours();
  if ((h < 12)) {
    return tx("Buenos días");
  } else if ((h < 19)) {
    return tx("Buenas tardes");
  }
  return tx("Buenas noches");
}

function prefline() {
  let p;
  p = "";
  if (m.sec.$exists("pref_start")) {
    p = m.sec.$read("pref_start");
  }
  if ((p === "live")) {
    return tx("Tu inicio abrirá en Ver televisión.");
  }
  if ((p === "movies")) {
    return tx("Tu inicio abrirá en Explorar películas.");
  }
  return tx("Tu inicio abrirá con todo a la mano.");
}

function showwelcome(first) {
  let p;
  m.welcomefirst = first;
  m.wpage = 0;
  m.wsel = 0;
  p = "";
  if (m.sec.$exists("pref_start")) {
    p = m.sec.$read("pref_start");
  }
  m.wchoice = 2;
  if ((p === "live")) {
    m.wchoice = 0;
  }
  if ((p === "movies")) {
    m.wchoice = 1;
  }
  reshowwelcome();
}

function reshowwelcome() {
  m.mode = "welcome";
  hidepanels();
  m.topbar.visible = false;
  m.welcomepanel.visible = true;
  if ((m.wgroup == null)) {
    m.wgroup = m.top.$findnode("wGroup");
  }
  drawwelcome();
  capturekeys();
}

function welcomeaftertour() {
  m.wpage = 3;
  m.wsel = 0;
  reshowwelcome();
}

function wdots(g) {
  let i, $e0, x;
  for (i = 0, $e0 = 3; i <= $e0; i++) {
    x = (568 + (i * 38));
    if ((i === m.wpage)) {
      dtbox(g, x, 44, 30, 6, "pkg:/images/rr_pill.9.png", "0xFF8A24FF", 1.0);
    } else if ((i < m.wpage)) {
      dtbox(g, x, 44, 30, 6, "pkg:/images/rr_pill.9.png", "0xFFFFFFFF", 0.55);
    } else {
      dtbox(g, x, 44, 30, 6, "pkg:/images/rr_pill.9.png", "0xFFFFFFFF", 0.15);
    }
  }
}

function wbutton(g, x, y, w, text, icon, focused) {
  let ba, tc, tmp, tw, sx, ip, l;
  ba = 0.14;
  tc = "0xFFFFFFFF";
  if (focused) {
    ba = 1.0;
    tc = "0x0A0A0FFF";
  }
  dtbox(g, x, y, w, 56, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", ba);
  if ((icon !== "")) {
    tmp = dttext(g, (-3000), 0, 0, text, tc, 19, "SemiBold");
    tw = (dtw(tmp) + 36);
    g.$removechild(tmp);
    sx = (x + $idiv(((w - tw)), 2));
    ip = addposter(g, sx, (y + 16), 24, 24, (("pkg:/images/" + icon) + ".png"));
    ip.blendcolor = tc;
    dttext(g, (sx + 36), (y + 17), w, text, tc, 19, "SemiBold");
  } else {
    l = dttext(g, x, (y + 17), w, text, tc, 19, "SemiBold");
    l.horizalign = "center";
  }
}

function wcard(g, x, y, w, h, icon, title, subt, focused, badge) {
  let tg, fg, sg, ip, bc, btc, bl, tl, st, an, vi;
  tg = g.$createchild("Group");
  tg.translation = [x, y];
  tg.scalerotatecenter = [$idiv(w, 2), $idiv(h, 2)];
  if (focused) {
    dtbox(tg, (-6), (-6), (w + 12), (h + 12), "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 0.25);
    dtbox(tg, 0, 0, w, h, "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 1.0);
    fg = "0x0A0A0FFF";
    sg = "0x0A0A0FB3";
  } else {
    dtbox(tg, 0, 0, w, h, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.07);
    dtbox(tg, 0, 0, w, h, "pkg:/images/rr_line.9.png", "0xFFFFFFFF", 0.10);
    fg = "0xFFFFFFFF";
    sg = "0x8A8F98FF";
  }
  ip = addposter(tg, 26, 26, 46, 46, (("pkg:/images/" + icon) + ".png"));
  ip.blendcolor = fg;
  if ((badge !== "")) {
    bc = "0xFF8A24FF";
    btc = "0x0A0A0FFF";
    if (focused) {
      bc = "0x0A0A0FFF";
      btc = "0xFF8A24FF";
    }
    dtbox(tg, (w - 96), 26, 74, 26, "pkg:/images/rr_pill.9.png", bc, 1.0);
    bl = dttext(tg, (w - 96), 30, 74, badge, btc, 13, "Bold");
    bl.horizalign = "center";
  }
  tl = dttext(tg, 26, (h - 78), (w - 44), title, fg, 22, "SemiBold");
  st = dttext(tg, 26, (h - 46), (w - 44), subt, sg, 15, "Regular");
  st.wrap = true;
  st.maxlines = 2;
  if (focused) {
    an = tg.$createchild("Animation");
    an.duration = 0.18;
    an.easefunction = "outQuad";
    vi = an.$createchild("Vector2DFieldInterpolator");
    vi.key = [0.0, 1.0];
    vi.keyvalue = [[1.0, 1.0], [1.05, 1.05]];
    tg.id = "wCardOn";
    vi.fieldtointerp = "wCardOn.scale";
    an.control = "start";
  }
}

function drawwelcome() {
  let g, k, t, s, lg, l2, btxt, hint, h, opts, i, $e1, items, $e2, y, ip, bl;
  g = m.wgroup;
  clearnode(g);
  wdots(g);
  if ((m.wpage === 0)) {
    addposter(g, 580, 96, 120, 76, "pkg:/images/logo_mark.png");
    k = dttext(g, 0, 196, 1280, $ucase(greetingtext()), "0xFF8A24FF", 15, "Bold");
    k.horizalign = "center";
    t = dttext(g, 0, 220, 1280, tx("Bienvenido a Smart IPTV MX"), "0xFFFFFFFF", 44, "Bold");
    t.horizalign = "center";
    s = dttext(g, 0, 280, 1280, tx("Tu reproductor para tus propias listas."), "0xC8CCD2FF", 20, "Regular");
    s.horizalign = "center";
    dtbox(g, 260, 330, 760, 168, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.06);
    lg = dttext(g, 290, 350, 700, tx("Smart IPTV MX no incluye, no distribuye ni vende canales, películas ni listas de reproducción. Tú aportas tus listas y eres responsable de que su contenido sea legal y de contar con el permiso para verlo."), "0xD0D4DAFF", 17, "Regular");
    lg.wrap = true;
    lg.maxlines = 4;
    lg.linespacing = 3;
    l2 = dttext(g, 290, 462, 700, tx("Al continuar confirmas que estás de acuerdo."), "0x9A9FA8FF", 15, "Regular");
    btxt = tx("Siguiente");
    if (m.welcomefirst) {
      btxt = tx("Acepto y continuar");
    }
    wbutton(g, 490, 532, 300, btxt, "", true);
    hint = tx("OK: continuar     Atrás: volver");
    if (m.welcomefirst) {
      hint = tx("OK: acepto y continuar     Atrás: salir");
    }
    h = dttext(g, 0, 676, 1280, hint, "0x7E838CFF", 15, "Regular");
    h.horizalign = "center";
  } else if ((m.wpage === 1)) {
    k = dttext(g, 0, 110, 1280, tx("PERSONALIZA TU INICIO"), "0xFF8A24FF", 15, "Bold");
    k.horizalign = "center";
    t = dttext(g, 0, 134, 1280, tx("¿Qué te gusta ver más?"), "0xFFFFFFFF", 44, "Bold");
    t.horizalign = "center";
    s = dttext(g, 0, 194, 1280, tx("Dejamos tu inicio listo para ti. Puedes cambiarlo cuando quieras."), "0xC8CCD2FF", 19, "Regular");
    s.horizalign = "center";
    opts = [{__proto__: $AAP, "ic": "ic_live", "t": tx("Televisión en vivo"), "s": tx("Canales con guía de programación")}, {__proto__: $AAP, "ic": "ic_movies", "t": tx("Películas y series"), "s": tx("Catálogo con portadas y fichas")}, {__proto__: $AAP, "ic": "ic_play", "t": tx("Un poco de todo"), "s": tx("Todo a la mano desde el inicio")}];
    for (i = 0, $e1 = 2; i <= $e1; i++) {
      wcard(g, (160 + (i * 330)), 268, 300, 210, $ix(opts, i).ic, $ix(opts, i).t, $ix(opts, i).s, (i === m.wchoice), "");
    }
    h = dttext(g, 0, 676, 1280, tx("Izquierda / Derecha: elegir     OK: confirmar     Atrás: regresar"), "0x7E838CFF", 15, "Regular");
    h.horizalign = "center";
  } else if ((m.wpage === 2)) {
    k = dttext(g, 100, 120, 560, tx("MENOS DE 1 MINUTO"), "0xFF8A24FF", 15, "Bold");
    t = dttext(g, 100, 144, 560, tx("¿Te enseñamos lo mejor de la app?"), "0xFFFFFFFF", 40, "Bold");
    t.wrap = true;
    t.maxlines = 2;
    s = dttext(g, 100, 254, 520, tx("Un recorrido rápido con tu propio control: el botón que debes presionar se ilumina. Puedes saltar cualquier paso."), "0xC8CCD2FF", 19, "Regular");
    s.wrap = true;
    s.maxlines = 4;
    wbutton(g, 100, 400, 250, tx("Sí, enséñame"), "ic_play", (m.wsel === 0));
    wbutton(g, 364, 400, 200, tx("Ahora no"), "", (m.wsel === 1));
    dtbox(g, 690, 120, 490, 420, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.06);
    dttext(g, 718, 142, 440, tx("INCLUYE"), "0x9A9FA8FF", 14, "Bold");
    items = [{__proto__: $AAP, "ic": "ic_xtream", "t": tx("Cuentas Xtream Codes"), "hot": true}, {__proto__: $AAP, "ic": "ic_live", "t": tx("Guía y canal anterior"), "hot": false}, {__proto__: $AAP, "ic": "ic_search", "t": tx("Buscar y letra A-Z"), "hot": false}, {__proto__: $AAP, "ic": "ic_remote", "t": tx("Adelantar como pro"), "hot": false}, {__proto__: $AAP, "ic": "ic_globe", "t": tx("Idioma y subtítulos"), "hot": false}, {__proto__: $AAP, "ic": "ic_heart", "t": tx("Favoritos"), "hot": false}];
    for (i = 0, $e2 = (items.$count() - 1); i <= $e2; i++) {
      y = (178 + (i * 58));
      if ($ix(items, i).hot) {
        dtbox(g, 706, (y - 8), 458, 50, "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 0.16);
      }
      ip = addposter(g, 724, (y + 2), 26, 26, (("pkg:/images/" + $ix(items, i).ic) + ".png"));
      ip.blendcolor = "0xFF8A24FF";
      dttext(g, 766, (y + 4), 300, $ix(items, i).t, "0xFFFFFFFF", 18, "SemiBold");
      if ($ix(items, i).hot) {
        dtbox(g, 1072, (y + 1), 76, 26, "pkg:/images/rr_pill.9.png", "0xFF8A24FF", 1.0);
        bl = dttext(g, 1072, (y + 5), 76, tx("NUEVO"), "0x0A0A0FFF", 13, "Bold");
        bl.horizalign = "center";
      }
    }
    h = dttext(g, 0, 676, 1280, tx("Izquierda / Derecha: elegir     OK: continuar     Atrás: regresar"), "0x7E838CFF", 15, "Regular");
    h.horizalign = "center";
  } else {
    addposter(g, 600, 92, 80, 80, "pkg:/images/check_circle.png");
    t = dttext(g, 0, 190, 1280, tx("¡Todo listo!"), "0xFFFFFFFF", 44, "Bold");
    t.horizalign = "center";
    s = dttext(g, 0, 250, 1280, ((prefline() + "  ") + tx("Ahora agrega tu lista para empezar.")), "0xC8CCD2FF", 19, "Regular");
    s.horizalign = "center";
    wcard(g, 250, 306, 380, 220, "ic_qr", tx("Cargar desde el celular"), tx("Tu lista M3U o tu cuenta Xtream, en segundos con el código QR."), (m.wsel === 0), tx("RÁPIDO"));
    l2 = tx("Explorar primero");
    if ((!m.welcomefirst)) {
      l2 = tx("Volver al inicio");
    }
    wcard(g, 650, 306, 380, 220, "ic_play", l2, tx("Conoce la app y agrega tu lista cuando quieras desde Mis listas."), (m.wsel === 1), "");
    h = dttext(g, 0, 676, 1280, tx("Izquierda / Derecha: elegir     OK: continuar     Atrás: regresar"), "0x7E838CFF", 15, "Regular");
    h.horizalign = "center";
  }
  if ((m.wanim != null)) {
    m.wanim.control = "stop";
    m.wanim.control = "start";
  }
}

function welcomekey(key) {
  let pref;
  if ((m.wpage === 0)) {
    if ((key === "OK")) {
      m.wpage = 1;
      drawwelcome();
    } else if ((key === "back")) {
      if (m.welcomefirst) {
        return false;
      }
      showhome();
    }
    return true;
  }
  if ((m.wpage === 1)) {
    if ((key === "left")) {
      if ((m.wchoice > 0)) {
        m.wchoice = (m.wchoice - 1);
      }
      drawwelcome();
    } else if ((key === "right")) {
      if ((m.wchoice < 2)) {
        m.wchoice = (m.wchoice + 1);
      }
      drawwelcome();
    } else if ((key === "OK")) {
      pref = "all";
      if ((m.wchoice === 0)) {
        pref = "live";
      }
      if ((m.wchoice === 1)) {
        pref = "movies";
      }
      m.sec.$write("pref_start", pref);
      m.sec.$flush();
      if ((pref === "movies")) {
        m.homeindex = 7;
      } else {
        m.homeindex = 6;
      }
      m.wpage = 2;
      m.wsel = 0;
      drawwelcome();
    } else if ((key === "back")) {
      m.wpage = 0;
      drawwelcome();
    }
    return true;
  }
  if ((m.wpage === 2)) {
    if ((key === "left")) {
      m.wsel = 0;
      drawwelcome();
    } else if ((key === "right")) {
      m.wsel = 1;
      drawwelcome();
    } else if ((key === "OK")) {
      if ((m.wsel === 0)) {
        showquicktour();
      } else {
        m.wpage = 3;
        m.wsel = 0;
        drawwelcome();
      }
    } else if ((key === "back")) {
      m.wpage = 1;
      drawwelcome();
    }
    return true;
  }
  if ((key === "left")) {
    m.wsel = 0;
    drawwelcome();
  } else if ((key === "right")) {
    m.wsel = 1;
    drawwelcome();
  } else if ((key === "OK")) {
    markwelcomedone();
    if ((m.wsel === 0)) {
      showqr();
    } else {
      showhome();
    }
  } else if ((key === "back")) {
    m.wpage = 2;
    m.wsel = 0;
    drawwelcome();
  }
  return true;
}

function markwelcomedone() {
  if (m.welcomefirst) {
    m.sec.$write("welcome_done", "1");
    m.sec.$flush();
    m.welcomefirst = false;
  }
}

function opendialog(dialog) {
  m.top.$signalbeacon("AppDialogInitiate");
  dialog.$observefieldscoped("wasClosed", "onDialogClosed");
  m.top.dialog = dialog;
}

function ondialogclosed() {
  m.top.$signalbeacon("AppDialogComplete");
}

function showexitdialog() {
  let dialog;
  if ((m.exitdialog != null)) {
    if ((m.exitopen === true)) {
      return;
    }
  }
  m.exitchoice = (-1);
  m.exitopen = true;
  dialog = {__proto__: $AAP, "title": "", "message": [], "buttons": []};
  dialog.title = tx("¿Salir de Smart IPTV MX?");
  dialog.message = [tx("Se cerrará la aplicación.")];
  dialog.buttons = [tx("Salir"), tx("Cancelar")];
  m.exitdialog = dialog;
  uiask(dialog.title, dialog.message, dialog.buttons, "onExitButton");
}

function onexitbutton() {
  m.exitopen = false;
  m.exitchoice = m.uibtn;
  if ((m.exitchoice === 0)) {
    doexit();
  }
}

function onexitclosed() {
  m.exitopen = false;
  if ((m.exitchoice === 0)) {
    doexit();
  }
}

function doexit() {
  m.top.exitrequested = false;
  m.top.exitrequested = true;
}
// ---- components/about.brs ----
function aboutemail() {
  return "jean.iptvmx@gmail.com";
}

function aboutsections() {
  return [{__proto__: $AAP, "t": tx("Acerca de"), "ic": "ic_info"}, {__proto__: $AAP, "t": tx("Contacto"), "ic": "ic_mail"}, {__proto__: $AAP, "t": tx("Recomendaciones"), "ic": "ic_bulb"}, {__proto__: $AAP, "t": tx("Fallos y soluciones"), "ic": "ic_wrench"}, {__proto__: $AAP, "t": tx("Idioma"), "ic": "ic_globe"}, {__proto__: $AAP, "t": tx("Tutorial interactivo"), "ic": "ic_remote"}, {__proto__: $AAP, "t": tx("Apoya el proyecto"), "ic": "ic_heart"}];
}

function showabout() {
  m.mode = "about";
  hidepanels();
  settitle(tx("Acerca de"));
  m.aboutpanel.visible = true;
  if ((m.aboutidx == null)) {
    m.aboutidx = 0;
  }
  drawabout();
  capturekeys();
}

function aboutkey(key) {
  let n;
  n = aboutsections().$count();
  if ((key === "back")) {
    m.aboutidx = 0;
    showhome();
  } else if ((key === "up")) {
    if ((m.aboutidx > 0)) {
      m.aboutidx = (m.aboutidx - 1);
      drawabout();
    }
  } else if ((key === "down")) {
    if ((m.aboutidx < (n - 1))) {
      m.aboutidx = (m.aboutidx + 1);
      drawabout();
    }
  } else if (((key === "OK") || (key === "right"))) {
    if ((m.aboutidx === 6)) {
      showsupport("about");
    }
    if ((m.aboutidx === 5)) {
      showtutorial("about");
    }
    if ((m.aboutidx === 4)) {
      showlang(false);
    }
  }
  return true;
}

function aboutversion() {
  let v, ai, mj, mn;
  v = "1";
  ai = $createobject("roAppInfo");
  if ((ai != null)) {
    mj = ai.$getvalue("major_version");
    mn = ai.$getvalue("minor_version");
    if (((mj !== "") && (mn !== ""))) {
      v = ((mj + ".") + mn);
    }
  }
  return v;
}

function aboutqrdraw(parent, x, y, px, text) {
  let mat, n, pad, r, $e0, c, c0;
  mat = qrmatrix(text);
  if ((mat == null)) {
    return y;
  }
  n = mat.$count();
  pad = 14;
  dtbox(parent, x, y, ((n * px) + (pad * 2)), ((n * px) + (pad * 2)), "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 1.0);
  for (r = 0, $e0 = (n - 1); r <= $e0; r++) {
    c = 0;
    while ((c < n)) {
      if (($ix($ix(mat, r), c) === 1)) {
        c0 = c;
        while (((c < n) && ($ix($ix(mat, r), c) === 1))) {
          c = (c + 1);
        }
        addrect(parent, ((x + pad) + (c0 * px)), ((y + pad) + (r * px)), (((c - c0)) * px), px, "0x000000FF");
      } else {
        c = (c + 1);
      }
    }
  }
  return ((y + (n * px)) + (pad * 2));
}

function abwrap(parent, x, y, w, lines, text, color, size, weight) {
  let l;
  l = dttext(parent, x, y, w, text, color, size, weight);
  l.wrap = true;
  l.maxlines = lines;
  return l;
}

function abh(l) {
  return $int(l.$boundingrect().height);
}

function drawabout() {
  let secs, i, $e1, y, ison, fg, ip, w, b, white, grey, soft, orange, x, lg, vl, feats, $e2, cx, cy, qb, l1, l2, tips, $e3, nl, probs, $e4, langs, cur, t, hp, chs, $e5;
  clearnode(m.aboutmenu);
  clearnode(m.aboutbody);
  secs = aboutsections();
  for (i = 0, $e1 = (secs.$count() - 1); i <= $e1; i++) {
    y = (i * 62);
    ison = ((i === m.aboutidx));
    fg = "0xA8ADB5FF";
    if (ison) {
      dtbox(m.aboutmenu, 0, y, 300, 52, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 1.0);
      fg = "0x0A0A0FFF";
    }
    ip = addposter(m.aboutmenu, 18, (y + 14), 24, 24, (("pkg:/images/" + $ix(secs, i).ic) + ".png"));
    ip.blendcolor = fg;
    w = "Regular";
    if (ison) {
      w = "SemiBold";
    }
    dttext(m.aboutmenu, 56, (y + 15), 236, $ix(secs, i).t, fg, 18, w);
  }
  b = m.aboutbody;
  white = "0xFFFFFFFF";
  grey = "0x9A9FA8FF";
  soft = "0xD0D4DAFF";
  orange = "0xFF8A24FF";
  dtbox(b, 0, 0, 824, 560, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.05);
  x = 36;
  if ((m.aboutidx === 0)) {
    lg = addposter(b, x, 30, 92, 86, "pkg:/images/logo_full.png");
    dttext(b, (x + 116), 34, 500, "SMART IPTV MX", white, 32, "Bold");
    dtbox(b, (x + 116), 82, 120, 30, "pkg:/images/rr_pill.9.png", orange, 1.0);
    vl = dttext(b, (x + 116), 87, 120, (tx("Versión ") + aboutversion()), "0x0A0A0FFF", 15, "Bold");
    vl.horizalign = "center";
    dttext(b, (x + 252), 87, 420, tx("Tu entretenimiento, en un solo lugar"), grey, 16, "Regular");
    abwrap(b, x, 140, 752, 2, tx("Reproductor para Google TV: carga tus listas M3U o tu cuenta Xtream y disfruta canales en vivo con guía, películas y series."), soft, 18, "Regular");
    dttext(b, x, 210, 500, tx("NOVEDADES"), orange, 14, "Bold");
    feats = [{__proto__: $AAP, "ic": "ic_play", "t": tx("Inicio con destacados")}, {__proto__: $AAP, "ic": "ic_movies", "t": tx("Fichas con sinopsis y reparto")}, {__proto__: $AAP, "ic": "ic_series", "t": tx("Series por temporadas")}, {__proto__: $AAP, "ic": "ic_search", "t": tx("Buscador al instante y letra A-Z")}, {__proto__: $AAP, "ic": "ic_remote", "t": tx("Controles de video renovados")}, {__proto__: $AAP, "ic": "ic_refresh", "t": tx("Reconexión automática")}, {__proto__: $AAP, "ic": "ic_xtream", "t": tx("Cuentas Xtream Codes")}, {__proto__: $AAP, "ic": "ic_globe", "t": tx("6 idiomas")}];
    for (i = 0, $e2 = (feats.$count() - 1); i <= $e2; i++) {
      cx = (x + (((i % 2)) * 380));
      cy = (238 + (($idiv(i, 2)) * 54));
      dtbox(b, cx, cy, 366, 46, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.06);
      ip = addposter(b, (cx + 14), (cy + 12), 22, 22, (("pkg:/images/" + $ix(feats, i).ic) + ".png"));
      ip.blendcolor = orange;
      dttext(b, (cx + 48), (cy + 13), 310, $ix(feats, i).t, white, 16, "SemiBold");
    }
    dtbox(b, x, 466, 752, 66, "pkg:/images/rr_fill.9.png", orange, 0.12);
    abwrap(b, (x + 20), 476, 712, 2, tx("Smart IPTV MX es únicamente un reproductor. No incluye ni distribuye canales, películas ni listas. Cada usuario es responsable del contenido que carga."), soft, 15, "Regular");
  } else if ((m.aboutidx === 1)) {
    dttext(b, x, 34, 460, tx("Contacto"), white, 32, "Bold");
    abwrap(b, x, 90, 440, 3, tx("¿Tienes dudas, sugerencias o necesitas ayuda? Escríbenos y con gusto te apoyamos."), soft, 18, "Regular");
    dttext(b, x, 196, 440, tx("CORREO"), orange, 14, "Bold");
    dttext(b, x, 222, 460, aboutemail(), white, 22, "SemiBold");
    addrect(b, x, 270, 440, 1, "0xFFFFFF22");
    abwrap(b, x, 290, 440, 4, tx("Al escribir, cuéntanos qué modelo de Google TV tienes, qué canal o lista falló y qué ocurrió. Así podemos resolverlo más rápido."), grey, 16, "Regular");
    qb = aboutqrdraw(b, 520, 40, 8, ("mailto:" + aboutemail()));
    l1 = dttext(b, 520, (qb + 16), 260, tx("Escanéalo con tu celular"), white, 16, "SemiBold");
    l2 = dttext(b, 520, (qb + 42), 260, tx("y abre tu correo"), grey, 15, "Regular");
  } else if ((m.aboutidx === 2)) {
    dttext(b, x, 30, 700, tx("Recomendaciones"), white, 30, "Bold");
    tips = [tx("Usa cable de red o Wi-Fi de 5 GHz para ver los canales sin cortes."), tx("Si tu proveedor te da usuario y contraseña, usa Xtream: carga más rápido y trae sinopsis, reparto y portadas."), tx("La guía tarda la primera vez del día; después abre al instante porque se guarda por 6 horas."), tx("En Películas o Series presiona Atrás: arriba aparecen Buscar y Letra A-Z para encontrar todo rápido."), tx("Para adelantar, presiona el botón de adelantar varias veces: suma 10 s, luego 30 s y 1 min, y salta al soltar."), tx("Idioma y subtítulos: en el video presiona OK y elige CC o el altavoz (si el archivo los trae)."), tx("Si tu lista es muy grande, divídela en varias o usa tu cuenta Xtream."), tx("Presiona Play en un canal, película o capítulo para guardarlo en Favoritos.")];
    for (i = 0, $e3 = (tips.$count() - 1); i <= $e3; i++) {
      y = (84 + (i * 58));
      dtbox(b, x, (y + 4), 34, 34, "pkg:/images/rr_fill.9.png", orange, 1.0);
      nl = dttext(b, x, (y + 11), 34, ((i + 1)).$tostr(), "0x0A0A0FFF", 16, "Bold");
      nl.horizalign = "center";
      abwrap(b, (x + 52), y, 700, 2, $ix(tips, i), soft, 16, "Regular");
    }
  } else if ((m.aboutidx === 3)) {
    dttext(b, x, 30, 700, tx("Fallos y soluciones"), white, 30, "Bold");
    probs = [[tx("Aparece \"Reconectando...\""), tx("El servidor cortó la conexión y la app la recupera sola. Si pasa muy seguido, revisa tu internet o prueba más tarde.")], [tx("Canal no disponible"), tx("El canal puede estar caído. Presiona OK para reintentar o prueba otro canal.")], [tx("Se queda en \"Preparando tu catálogo\""), tx("La lista es muy grande o el servidor está lento. Espera un poco o usa tu cuenta Xtream.")], [tx("No aparece la guía"), tx("Revisa el link de la guía (.xml o .gz) en Mis listas. La primera carga del día tarda unos minutos.")], [tx("No hay otros idiomas o subtítulos"), tx("Ese archivo no trae otras pistas. Depende de cómo lo entregue tu proveedor.")], [tx("Xtream dice \"Invalid credentials\""), tx("El usuario o la contraseña no son válidos o la cuenta venció. Verifícalos con tu proveedor.")]];
    for (i = 0, $e4 = (probs.$count() - 1); i <= $e4; i++) {
      y = (82 + (i * 76));
      addrect(b, x, (y + 4), 3, 58, orange);
      dttext(b, (x + 18), y, 720, $ix($ix(probs, i), 0), white, 17, "SemiBold");
      abwrap(b, (x + 18), (y + 26), 720, 2, $ix($ix(probs, i), 1), grey, 15, "Regular");
    }
  } else if ((m.aboutidx === 4)) {
    dttext(b, x, 34, 700, tx("Idioma"), white, 32, "Bold");
    abwrap(b, x, 90, 700, 2, tx("Elige el idioma de Smart IPTV MX. Se aplica al instante en toda la app."), soft, 18, "Regular");
    langs = i18nlangs();
    cur = $ix(langs, langindexof(i18nlang()));
    dtbox(b, x, 170, 460, 110, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.06);
    addposter(b, (x + 24), 195, 90, 60, cur.flag);
    dttext(b, (x + 136), 202, 300, cur.name, white, 28, "Bold");
    dttext(b, (x + 136), 240, 300, tx("Idioma actual"), grey, 15, "Regular");
    dtbox(b, x, 310, 300, 54, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 1.0);
    t = dttext(b, x, 326, 300, tx("OK: cambiar idioma"), "0x0A0A0FFF", 18, "SemiBold");
    t.horizalign = "center";
  } else if ((m.aboutidx === 6)) {
    hp = addposter(b, x, 34, 40, 40, "pkg:/images/ic_heart.png");
    hp.blendcolor = orange;
    dttext(b, (x + 56), 36, 640, tx("Apoya el proyecto"), white, 32, "Bold");
    abwrap(b, x, 100, 720, 3, tx("Smart IPTV MX es un proyecto independiente, hecho en México con mucho cariño. La app es gratis y lo seguirá siendo."), soft, 18, "Regular");
    abwrap(b, x, 184, 720, 3, tx("Si te gusta y quieres apoyar su desarrollo, puedes invitarme un café desde tu celular, con la cantidad que tú quieras."), soft, 18, "Regular");
    dttext(b, x, 270, 700, tx("CÓMO APOYAR"), orange, 14, "Bold");
    dttext(b, x, 296, 700, tx("Todo el mundo · Tarjeta, Apple Pay, Google Pay"), white, 17, "SemiBold");
    dttext(b, x, 326, 700, tx("Solo México · Tarjeta u OXXO"), white, 17, "SemiBold");
    abwrap(b, x, 372, 720, 2, tx("Es totalmente voluntario y no desbloquea funciones ni contenido."), grey, 15, "Regular");
    dtbox(b, x, 466, 300, 54, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 1.0);
    t = dttext(b, x, 482, 300, tx("OK: ver códigos QR"), "0x0A0A0FFF", 18, "SemiBold");
    t.horizalign = "center";
  } else {
    addposter(b, 560, 24, 168, 420, "pkg:/images/remote.png");
    dttext(b, x, 34, 480, tx("Tutorial interactivo"), white, 32, "Bold");
    abwrap(b, x, 88, 480, 3, tx("Aprende a usar la app con tu propio control: el botón que debes presionar se ilumina y avanzas al presionarlo."), soft, 18, "Regular");
    chs = tutchapters();
    for (i = 0, $e5 = (chs.$count() - 1); i <= $e5; i++) {
      y = (190 + (i * 44));
      ip = addposter(b, x, (y + 4), 22, 22, (("pkg:/images/" + $ix(chs, i).ic) + ".png"));
      ip.blendcolor = orange;
      dttext(b, (x + 36), (y + 4), 420, $ix(chs, i).t, white, 17, "SemiBold");
    }
    dtbox(b, x, 466, 260, 54, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 1.0);
    t = dttext(b, x, 482, 260, tx("OK: comenzar"), "0x0A0A0FFF", 18, "SemiBold");
    t.horizalign = "center";
  }
}
// ---- components/weather.brs ----
function wxinit() {
  m.wx = null;
  m.wxat = 0;
  m.wxbusy = false;
  m.wxfail = false;
  m.wxlist = [];
  m.wxidx = 0;
  m.wxsearching = false;
  m.wxpending = null;
  m.wxunitsel = 0;
  m.wxbody = m.top.$findnode("wxBody");
  m.wxhint = m.top.$findnode("wxHint");
  m.wxfocus = m.top.$findnode("wxFocus");
  m.wxicon = m.top.$findnode("wxIcon");
  m.wxtemp = m.top.$findnode("wxTemp");
  m.wxfontbig = $createobject("roSGNode", "Font");
  m.wxfontbig.uri = "pkg:/fonts/Inter-ExtraLight.ttf";
  m.wxfontbig.size = 100;
  m.wxfonttile = $createobject("roSGNode", "Font");
  m.wxfonttile.uri = "pkg:/fonts/Inter-ExtraLight.ttf";
  m.wxfonttile.size = 34;
  m.wxlat = "";
  m.wxlon = "";
  m.wxname = "";
  m.wxcity = "";
  m.wxunit = "c";
  if (m.sec.$exists("wx_lat")) {
    m.wxlat = m.sec.$read("wx_lat");
  }
  if (m.sec.$exists("wx_lon")) {
    m.wxlon = m.sec.$read("wx_lon");
  }
  if (m.sec.$exists("wx_name")) {
    m.wxname = m.sec.$read("wx_name");
  }
  if (m.sec.$exists("wx_city")) {
    m.wxcity = m.sec.$read("wx_city");
  }
  if ((m.sec.$exists("wx_unit") && (m.sec.$read("wx_unit") === "f"))) {
    m.wxunit = "f";
  }
  m.wxtimer = m.top.$findnode("wxTimer");
  m.wxtimer.$observefield("fire", "onWxTimer");
  m.wxtimer.control = "start";
  wxupdatewidget();
  if ((m.wxlat !== "")) {
    wxrefresh();
  }
}

function onwxtimer() {
  if (m.videoplayer.visible) {
    return;
  }
  wxrefresh();
}

function wxrefresh() {
  let t;
  if (((m.wxlat === "") || (m.wxlon === ""))) {
    return;
  }
  if (m.wxbusy) {
    return;
  }
  m.wxbusy = true;
  t = $createobject("roSGNode", "WeatherTask");
  t.op = "load";
  t.lat = m.wxlat;
  t.lon = m.wxlon;
  t.unit = m.wxunit;
  t.$observefield("result", "onWxLoaded");
  m.wxtask = t;
  t.control = "RUN";
}

function onwxloaded() {
  let r;
  m.wxbusy = false;
  r = m.wxtask.result;
  if (((r != null) && (r.ok === true))) {
    m.wx = r;
    m.wxat = r.ts;
    m.wxfail = false;
    wxupdatewidget();
  } else {
    m.wxfail = true;
  }
  if ((m.mode === "weather")) {
    wxdraw();
  }
}

function wxupdatewidget() {
  if (((m.wx != null) && (m.wx.cur != null))) {
    m.wxicon.uri = wxiconuri(m.wx.cur.code, m.wx.cur.isday);
    m.wxtemp.text = (wxn(m.wx.cur.t) + $chr(176));
  } else if ((m.wxlat !== "")) {
    m.wxicon.uri = "pkg:/images/wx_pcloud_d.png";
    m.wxtemp.text = "...";
  } else {
    m.wxicon.uri = "pkg:/images/wx_pcloud_d.png";
    m.wxtemp.text = tx("Clima");
  }
}

function wxn(v) {
  let a, neg, r;
  if ((v == null)) {
    return "--";
  }
  a = v;
  neg = false;
  if ((a < 0)) {
    neg = true;
    a = (-a);
  }
  r = $int((a + 0.5));
  if ((r === 0)) {
    return "0";
  }
  if (neg) {
    return ("-" + r.$tostr());
  }
  return r.$tostr();
}

function wxd1(v) {
  let r;
  if ((v == null)) {
    return "--";
  }
  r = ($int(((v * 10) + 0.5)) / 10);
  return r.$tostr();
}

function wxiconuri(code, isday) {
  let n;
  n = "wx_cloud";
  if (((code === 0) || (code === 1))) {
    if ((isday === 1)) {
      n = "wx_clear_d";
    } else {
      n = "wx_clear_n";
    }
  } else if ((code === 2)) {
    if ((isday === 1)) {
      n = "wx_pcloud_d";
    } else {
      n = "wx_pcloud_n";
    }
  } else if ((code === 3)) {
    n = "wx_cloud";
  } else if (((code === 45) || (code === 48))) {
    n = "wx_fog";
  } else if (((code >= 51) && (code <= 57))) {
    n = "wx_drizzle";
  } else if (((((code >= 61) && (code <= 67))) || (((code >= 80) && (code <= 82))))) {
    n = "wx_rain";
  } else if ((((((code >= 71) && (code <= 77))) || (code === 85)) || (code === 86))) {
    n = "wx_snow";
  } else if ((code >= 95)) {
    n = "wx_storm";
  }
  return (("pkg:/images/" + n) + ".png");
}

function wxtext(code) {
  if ((code === 0)) {
    return tx("Despejado");
  }
  if ((code === 1)) {
    return tx("Mayormente despejado");
  }
  if ((code === 2)) {
    return tx("Parcialmente nublado");
  }
  if ((code === 3)) {
    return tx("Nublado");
  }
  if (((code === 45) || (code === 48))) {
    return tx("Niebla");
  }
  if (((code >= 51) && (code <= 57))) {
    return tx("Llovizna");
  }
  if (((code >= 61) && (code <= 67))) {
    return tx("Lluvia");
  }
  if (((code >= 71) && (code <= 77))) {
    return tx("Nieve");
  }
  if (((code >= 80) && (code <= 82))) {
    return tx("Chubascos");
  }
  if (((code === 85) || (code === 86))) {
    return tx("Chubascos de nieve");
  }
  if ((code >= 95)) {
    return tx("Tormenta");
  }
  return tx("Nublado");
}

function wxhour(h) {
  let suf, x;
  if (i18n24h()) {
    return i18nhm(h, "00", false);
  }
  suf = " AM";
  if ((h >= 12)) {
    suf = " PM";
  }
  x = (h % 12);
  if ((x === 0)) {
    x = 12;
  }
  return (x.$tostr() + suf);
}

function wxclock(iso) {
  let h, mi;
  if (($len(iso) < 16)) {
    return "--";
  }
  h = $int($val($mid(iso, 12, 2)));
  mi = $mid(iso, 15, 2);
  return i18nhm(h, mi, true);
}

function wxdayname(date_, idx) {
  let dt;
  if ((idx === 0)) {
    return tx("Hoy");
  }
  dt = $createobject("roDateTime");
  dt.$fromiso8601string((date_ + "T12:00:00"));
  return $ix(i18ndowfull(), dt.$getdayofweek());
}

function wxdirname(deg) {
  let names, i;
  if (((deg == null) || (deg < 0))) {
    return "";
  }
  names = i18ncompass();
  i = ($int((((deg + 22.5)) / 45)) % 8);
  return $ix(names, i);
}

function wxaqi(v) {
  if (((v == null) || (v < 0))) {
    return {__proto__: $AAP, "t": tx("Sin datos"), "c": "0xA8ADB5FF"};
  }
  if ((v <= 50)) {
    return {__proto__: $AAP, "t": tx("Bueno"), "c": "0x50E68CFF"};
  }
  if ((v <= 100)) {
    return {__proto__: $AAP, "t": tx("Moderado"), "c": "0xFFD84DFF"};
  }
  if ((v <= 150)) {
    return {__proto__: $AAP, "t": tx("Dañino (sensibles)"), "c": "0xFF9A3CFF"};
  }
  if ((v <= 200)) {
    return {__proto__: $AAP, "t": tx("Dañino"), "c": "0xFF5C5CFF"};
  }
  if ((v <= 300)) {
    return {__proto__: $AAP, "t": tx("Muy dañino"), "c": "0xC77DFFFF"};
  }
  return {__proto__: $AAP, "t": tx("Peligroso"), "c": "0xC77DFFFF"};
}

function wxuv(v) {
  if ((v < 3)) {
    return {__proto__: $AAP, "t": tx("Bajo"), "c": "0x50E68CFF"};
  }
  if ((v < 6)) {
    return {__proto__: $AAP, "t": tx("Moderado"), "c": "0xFFD84DFF"};
  }
  if ((v < 8)) {
    return {__proto__: $AAP, "t": tx("Alto"), "c": "0xFF9A3CFF"};
  }
  if ((v < 11)) {
    return {__proto__: $AAP, "t": tx("Muy alto"), "c": "0xFF5C5CFF"};
  }
  return {__proto__: $AAP, "t": tx("Extremo"), "c": "0xC77DFFFF"};
}

function wxlabel(parent, x, y, w, text, color, font, align) {
  let l;
  l = $createobject("roSGNode", "Label");
  l.translation = [x, y];
  l.width = w;
  l.text = text;
  l.color = color;
  l.font = font;
  if ((align !== "")) {
    l.horizalign = align;
  }
  parent.$appendchild(l);
  return l;
}

function openweather() {
  let nows;
  if ((m.wxlat === "")) {
    wxask();
    return;
  }
  m.mode = "weather";
  hidepanels();
  settitle(tx("Clima"));
  m.wxpanel.visible = true;
  wxdraw();
  capturekeys();
  nows = $createobject("roDateTime").$asseconds();
  if (((m.wx == null) || ((nows - m.wxat) > 600))) {
    wxrefresh();
  }
}

function wxdraw() {
  let b, t;
  clearnode(m.wxbody);
  b = m.wxbody;
  if ((m.wx == null)) {
    if (m.wxfail) {
      wxcard(b, 200, 150, 840, 240);
      wxlabel(b, 230, 176, 780, tx("No se pudo obtener el clima"), "0xFFFFFFFF", "font:LargeBoldSystemFont", "");
      t = wxlabel(b, 230, 232, 780, tx("Revisa tu conexión a internet y vuelve a intentarlo en un momento."), "0xA8ADB5FF", "font:MediumSystemFont", "");
      t.wrap = true;
      t.numlines = 3;
      t.height = 120;
    } else {
      wxcard(b, 200, 190, 840, 160);
      wxlabel(b, 200, 244, 840, tx("Cargando el clima..."), "0xFFFFFFFF", "font:MediumBoldSystemFont", "center");
    }
    m.wxhint.text = tx("OK: cambiar ciudad o unidades     Atrás: volver");
    return;
  }
  wxdrawmain();
}

function wxcard(b, x, y, w, h) {
  dtbox(b, x, y, w, h, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.06);
  dtbox(b, x, y, w, h, "pkg:/images/rr_line.9.png", "0xFFFFFFFF", 0.09);
}

function wxtint(code, isday) {
  if ((code == null)) {
    return "0x8FA3C0FF";
  }
  if ((code <= 1)) {
    if ((isday === 1)) {
      return "0xFFB347FF";
    }
    return "0x6C7BFFFF";
  }
  if ((code === 2)) {
    if ((isday === 1)) {
      return "0xFFC870FF";
    }
    return "0x7D88D8FF";
  }
  if (((code === 45) || (code === 48))) {
    return "0xA0A8B4FF";
  }
  if ((code >= 95)) {
    return "0x8E6CFFFF";
  }
  if ((((((code >= 71) && (code <= 77))) || (code === 85)) || (code === 86))) {
    return "0xBFD9FFFF";
  }
  if ((code >= 51)) {
    return "0x4A90E2FF";
  }
  return "0x8FA3C0FF";
}

function wxmins(iso) {
  if (($len(iso) < 16)) {
    return (-1);
  }
  return (($int($val($mid(iso, 12, 2))) * 60) + $int($val($mid(iso, 15, 2))));
}

function wxfloat(node, x, y, dx, dy, dur) {
  let an, vi;
  if ((m.wxanims == null)) {
    m.wxanims = [];
  }
  m.wxanimn = (m.wxanimn + 1);
  node.id = ("wxA" + m.wxanimn.$tostr());
  an = m.wxbody.$createchild("Animation");
  an.duration = dur;
  an.repeat = true;
  an.easefunction = "inOutQuad";
  vi = an.$createchild("Vector2DFieldInterpolator");
  vi.key = [0.0, 0.5, 1.0];
  vi.keyvalue = [[x, y], [(x + dx), (y + dy)], [x, y]];
  vi.fieldtointerp = (node.id + ".translation");
  an.control = "start";
  m.wxanims.$push(an);
}

function wxstopanims() {
  let an;
  if ((m.wxanims == null)) {
    return;
  }
  for (an of $iter(m.wxanims)) {
    an.control = "stop";
  }
  m.wxanims = [];
}

function wxmeter(b, x, y, w, uri, frac, fill) {
  let fw, p, mx;
  if ((frac < 0)) {
    frac = 0;
  }
  if ((frac > 1)) {
    frac = 1;
  }
  if (fill) {
    dtbox(b, x, y, w, 6, "pkg:/images/rr_pill.9.png", "0xFFFFFFFF", 0.12);
    fw = $int((w * frac));
    if ((fw < 6)) {
      fw = 6;
    }
    p = addposter(b, x, y, fw, 6, uri);
    p.loaddisplaymode = "scaleToFill";
  } else {
    p = addposter(b, x, y, w, 6, uri);
    p.loaddisplaymode = "scaleToFill";
    p.opacity = 0.9;
    mx = ((x + $int((w * frac))) - 7);
    dtbox(b, (mx - 2), (y - 6), 18, 18, "pkg:/images/rr_pill.9.png", "0x0A0A0FFF", 1.0);
    addposter(b, (mx + 1), (y - 3), 12, 12, "pkg:/images/dot_w.png");
  }
}

function wxdrawmain() {
  let b, w, c, deg, white, grey, soft, blue, d0, tint, g1, g2, nm, reg, tl, ic, sub0, hrs, n, tmin, tmax, i, $e0, tsp, pts, $e1, hh, cx, py, lab, col, hl, tt, pp, $e2, x1, y1, dx, dy, ln, r, $e3, dc, sz, dp, gmin, gmax, dd, span, bw, $e4, y, namecol, mn, bx, fx, fw, tb, cxp, wu, pu, feelnote, df, humnote, uvv, aqv, aqi, aqval, humval, aqf, sr, ss, nowl, nm0, sunf, tiles, $e5, t, x, tw, st, nt, rg, ag, bear, al, upd;
  b = m.wxbody;
  w = m.wx;
  c = w.cur;
  deg = $chr(176);
  white = "0xFFFFFFFF";
  grey = "0x9AA0A8FF";
  soft = "0xC8CCD2FF";
  blue = "0x6CB8FFFF";
  d0 = $ix(w.days, 0);
  wxstopanims();
  m.wxanimn = 0;
  tint = wxtint(c.code, c.isday);
  g1 = addposter(b, (-260), (-300), 980, 760, "pkg:/images/glow.png");
  g1.blendcolor = tint;
  g1.opacity = 0.30;
  wxfloat(g1, (-260), (-300), 60, 40, 14.0);
  g2 = addposter(b, 700, 220, 820, 640, "pkg:/images/glow.png");
  g2.blendcolor = tint;
  g2.opacity = 0.14;
  wxfloat(g2, 700, 220, (-50), (-30), 18.0);
  wxcard(b, 0, 0, 400, 236);
  nm = m.wxname;
  if ((nm === "")) {
    nm = tx("Mi ciudad");
  }
  dttext(b, 24, 18, 260, nm, white, 21, "SemiBold");
  reg = m.wxcity;
  if (($left(reg, ($len(nm) + 2)) === (nm + ", "))) {
    reg = $mid(reg, ($len(nm) + 3));
  }
  if ((reg === nm)) {
    reg = "";
  }
  dttext(b, 24, 46, 260, fittext(reg, 250), grey, 14, "Regular");
  tl = dttext(b, 20, 62, 0, (wxn(c.t) + deg), white, 92, "Regular");
  ic = addposter(b, 272, 52, 108, 108, wxiconuri(c.code, c.isday));
  wxfloat(ic, 272, 52, 0, (-8), 3.6);
  dttext(b, 24, 176, 352, wxtext(c.code), white, 18, "SemiBold");
  sub0 = ((((((tx("Máx ") + wxn(d0.max)) + deg) + "   ") + tx("Mín ")) + wxn(d0.min)) + deg);
  if ((d0.pop >= 10)) {
    sub0 = ((((sub0 + "   ·   ") + tx("Lluvia ")) + wxn(d0.pop)) + "%");
  }
  dttext(b, 24, 202, 352, sub0, grey, 15, "Regular");
  wxcard(b, 416, 0, 824, 236);
  dttext(b, 440, 18, 0, tx("PRÓXIMAS HORAS"), grey, 12, "Bold");
  hrs = w.hours;
  n = hrs.$count();
  if ((n > 10)) {
    n = 10;
  }
  if ((n > 0)) {
    tmin = 1000;
    tmax = (-1000);
    for (i = 0, $e0 = (n - 1); i <= $e0; i++) {
      if (($ix(hrs, i).t < tmin)) {
        tmin = $ix(hrs, i).t;
      }
      if (($ix(hrs, i).t > tmax)) {
        tmax = $ix(hrs, i).t;
      }
    }
    tsp = (tmax - tmin);
    if ((tsp < 1)) {
      tsp = 1;
    }
    pts = [];
    for (i = 0, $e1 = (n - 1); i <= $e1; i++) {
      hh = $ix(hrs, i);
      cx = ((428 + (i * 80)) + 40);
      py = (186 - $int(((((hh.t - tmin)) / tsp) * 44)));
      pts.$push([cx, py]);
      lab = wxhour(hh.h);
      col = grey;
      if ((i === 0)) {
        lab = tx("Ahora");
        col = white;
        dtbox(b, (cx - 36), 40, 72, 186, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.07);
      }
      hl = dttext(b, (cx - 40), 46, 80, lab, col, 14, "SemiBold");
      hl.horizalign = "center";
      addposter(b, (cx - 16), 68, 32, 32, wxiconuri(hh.code, hh.day));
      tt = dttext(b, (cx - 40), (py - 28), 80, (wxn(hh.t) + deg), white, 15, "SemiBold");
      tt.horizalign = "center";
      if ((hh.pop >= 10)) {
        pp = dttext(b, (cx - 40), 202, 80, (wxn(hh.pop) + "%"), blue, 13, "SemiBold");
        pp.horizalign = "center";
      }
    }
    for (i = 0, $e2 = (n - 2); i <= $e2; i++) {
      x1 = $ix($ix(pts, i), 0);
      y1 = $ix($ix(pts, i), 1);
      dx = ($ix($ix(pts, (i + 1)), 0) - x1);
      dy = ($ix($ix(pts, (i + 1)), 1) - y1);
      ln = $sqr(((dx * dx) + (dy * dy)));
      r = $createobject("roSGNode", "Rectangle");
      r.width = ln;
      r.height = 3;
      r.color = "0xFFB347CC";
      r.translation = [x1, (y1 - 1)];
      r.scalerotatecenter = [0, 1.5];
      r.rotation = (-$atn((dy / dx)));
      b.$appendchild(r);
    }
    for (i = 0, $e3 = (n - 1); i <= $e3; i++) {
      dc = "0xFFFFFFFF";
      sz = 10;
      if ((i === 0)) {
        dc = "0xFF8A24FF";
        sz = 14;
      }
      dp = addposter(b, ($ix($ix(pts, i), 0) - (sz / 2)), ($ix($ix(pts, i), 1) - (sz / 2)), sz, sz, "pkg:/images/dot_w.png");
      dp.blendcolor = dc;
    }
  }
  wxcard(b, 0, 252, 640, 318);
  dttext(b, 24, 270, 0, tx("PRONÓSTICO A 7 DÍAS"), grey, 12, "Bold");
  gmin = 1000;
  gmax = (-1000);
  for (dd of $iter(w.days)) {
    if ((dd.min < gmin)) {
      gmin = dd.min;
    }
    if ((dd.max > gmax)) {
      gmax = dd.max;
    }
  }
  span = (gmax - gmin);
  if ((span < 1)) {
    span = 1;
  }
  bw = 236;
  for (i = 0, $e4 = (w.days.$count() - 1); i <= $e4; i++) {
    if ((i >= 7)) {
      break;
    }
    dd = $ix(w.days, i);
    y = (300 + (i * 38));
    if ((i > 0)) {
      addrect(b, 24, (y - 4), 592, 1, "0xFFFFFF12");
    }
    namecol = soft;
    if ((i === 0)) {
      namecol = white;
    }
    dttext(b, 24, (y + 6), 120, wxdayname(dd.date, i), namecol, 16, "SemiBold");
    addposter(b, 140, (y + 2), 30, 30, wxiconuri(dd.code, 1));
    if ((dd.pop >= 10)) {
      dttext(b, 176, (y + 9), 52, (wxn(dd.pop) + "%"), blue, 13, "SemiBold");
    }
    mn = dttext(b, 226, (y + 7), 56, (wxn(dd.min) + deg), grey, 16, "SemiBold");
    mn.horizalign = "right";
    bx = 298;
    dtbox(b, bx, (y + 14), bw, 6, "pkg:/images/rr_pill.9.png", "0xFFFFFFFF", 0.12);
    fx = $int(((((dd.min - gmin)) / span) * bw));
    fw = $int(((((dd.max - dd.min)) / span) * bw));
    if ((fw < 10)) {
      fw = 10;
    }
    if (((fx + fw) > bw)) {
      fx = (bw - fw);
    }
    tb = addposter(b, (bx + fx), (y + 14), fw, 6, "pkg:/images/wx_tbar.png");
    tb.loaddisplaymode = "scaleToFill";
    if ((i === 0)) {
      cxp = (bx + $int(((((c.t - gmin)) / span) * bw)));
      if ((cxp < bx)) {
        cxp = bx;
      }
      if ((cxp > (bx + bw))) {
        cxp = (bx + bw);
      }
      dtbox(b, (cxp - 7), (y + 10), 14, 14, "pkg:/images/rr_pill.9.png", "0x0A0A0FFF", 1.0);
      addposter(b, (cxp - 5), (y + 12), 10, 10, "pkg:/images/dot_w.png");
    }
    dttext(b, ((bx + bw) + 16), (y + 7), 70, (wxn(dd.max) + deg), white, 16, "SemiBold");
  }
  wu = "km/h";
  pu = "mm";
  if ((w.unit === "f")) {
    wu = "mph";
    pu = "in";
  }
  feelnote = tx("Similar");
  df = (c.feel - c.t);
  if ((df >= 2)) {
    feelnote = tx("Más caliente");
  }
  if ((df <= (-2))) {
    feelnote = tx("Más fresco");
  }
  humnote = tx("Confortable");
  if ((c.hum < 0)) {
    humnote = "";
  } else if ((c.hum < 30)) {
    humnote = tx("Seco");
  } else if ((c.hum > 80)) {
    humnote = tx("Muy húmedo");
  } else if ((c.hum > 60)) {
    humnote = tx("Húmedo");
  }
  uvv = wxuv(d0.uv);
  aqv = null;
  if ((w.aq != null)) {
    aqv = w.aq.aqi;
  }
  aqi = wxaqi(aqv);
  aqval = "--";
  if (((aqv != null) && (aqv >= 0))) {
    aqval = wxn(aqv);
  }
  humval = "--";
  if ((c.hum >= 0)) {
    humval = (wxn(c.hum) + "%");
  }
  aqf = 0.0;
  if (((aqv != null) && (aqv >= 0))) {
    if ((aqv <= 200)) {
      aqf = ((aqv / 200.0) * 0.8);
    } else {
      aqf = (0.8 + (((aqv - 200)) / 500.0));
    }
  }
  sr = wxmins(d0.sunrise);
  ss = wxmins(d0.sunset);
  nowl = $createobject("roDateTime");
  nowl.$tolocaltime();
  nm0 = ((nowl.$gethours() * 60) + nowl.$getminutes());
  sunf = 0.0;
  if (((ss > sr) && (sr >= 0))) {
    sunf = (((nm0 - sr)) / ((ss - sr)));
  }
  tiles = [{__proto__: $AAP, "t": tx("SENSACIÓN TÉRMICA"), "v": (wxn(c.feel) + deg), "n": feelnote, "c": soft, "k": ""}, {__proto__: $AAP, "t": tx("HUMEDAD"), "v": humval, "n": humnote, "c": soft, "k": "hum"}, {__proto__: $AAP, "t": tx("VIENTO"), "v": wxn(c.wind), "n": "", "c": soft, "k": "wind"}, {__proto__: $AAP, "t": tx("ÍNDICE UV"), "v": wxn(d0.uv), "n": uvv.t, "c": uvv.c, "k": "uv"}, {__proto__: $AAP, "t": tx("CALIDAD DEL AIRE"), "v": aqval, "n": aqi.t, "c": aqi.c, "k": "aq"}, {__proto__: $AAP, "t": tx("AMANECER / ATARDECER"), "v": "", "n": "", "c": soft, "k": "sun"}];
  for (i = 0, $e5 = 5; i <= $e5; i++) {
    t = $ix(tiles, i);
    x = (656 + (((i % 2)) * 298));
    y = (252 + (($idiv(i, 2)) * 110));
    tw = 286;
    wxcard(b, x, y, tw, 98);
    dttext(b, (x + 18), (y + 14), (tw - 36), t.t, grey, 12, "Bold");
    if ((t.k === "sun")) {
      dttext(b, (x + 18), (y + 36), 0, wxclock(d0.sunrise), white, 19, "SemiBold");
      st = dttext(b, (x + 18), (y + 36), (tw - 36), wxclock(d0.sunset), white, 19, "SemiBold");
      st.horizalign = "right";
      wxmeter(b, (x + 18), (y + 74), (tw - 36), "pkg:/images/wx_tbar.png", sunf, false);
    } else {
      dttext(b, (x + 18), (y + 32), 140, t.v, white, 28, "SemiBold");
      if ((t.n !== "")) {
        nt = dttext(b, (x + 110), (y + 42), (tw - 128), t.n, t.c, 14, "SemiBold");
        nt.horizalign = "right";
      }
      if (((t.k === "hum") && (c.hum >= 0))) {
        wxmeter(b, (x + 18), (y + 78), (tw - 36), "pkg:/images/wx_hbar.png", (c.hum / 100.0), true);
      }
      if ((t.k === "uv")) {
        wxmeter(b, (x + 18), (y + 78), (tw - 36), "pkg:/images/wx_scale.png", (d0.uv / 11.0), false);
      }
      if ((((t.k === "aq") && (aqv != null)) && (aqv >= 0))) {
        wxmeter(b, (x + 18), (y + 78), (tw - 36), "pkg:/images/wx_scale.png", aqf, false);
      }
      if ((((t.k === "wind") && (c.dir != null)) && (c.dir >= 0))) {
        rg = addposter(b, ((x + tw) - 64), (y + 12), 44, 44, "pkg:/images/ring.png");
        rg.opacity = 0.35;
        ag = b.$createchild("Group");
        ag.translation = [((x + tw) - 42), (y + 34)];
        bear = ((($int(c.dir) + 180)) % 360);
        ag.rotation = ((3.14159265 / 2) - ((bear * 3.14159265) / 180.0));
        al = dttext(ag, (-9), (-12), 18, "▶", "0xFF8A24FF", 16, "Bold");
        al.horizalign = "center";
        dttext(b, (x + 18), (y + 70), (tw - 90), ((((wu + "  ·  ") + tx("del")) + " ") + wxdirname(c.dir)), grey, 13, "Regular");
      }
      if ((t.k === "")) {
        dttext(b, (x + 18), (y + 70), (tw - 36), (((((tx("Lluvia hoy ") + wxn(d0.pop)) + "%  ·  ") + wxd1(d0.psum)) + " ") + pu), grey, 13, "Regular");
      }
    }
  }
  upd = "";
  if ((m.wxat > 0)) {
    upd = ((tx("Actualizado ") + fmttime(m.wxat)) + "     ");
  }
  m.wxhint.text = (upd + tx("OK: cambiar ciudad o unidades     Atrás: volver"));
}

function wxask() {
  showkeyboard(tx("Ciudad para el clima (ej: Guadalajara)"), "", "wxcity");
}

function wxshowpanel() {
  hidepanels();
  settitle(tx("Clima"));
  m.wxpanel.visible = true;
  clearnode(m.wxbody);
  capturekeys();
}

function wxgeo(text) {
  let t;
  m.mode = "wxsearch";
  m.wxsearching = true;
  wxshowpanel();
  wxcard(m.wxbody, 200, 190, 840, 160);
  wxlabel(m.wxbody, 200, 244, 840, tx("Buscando ciudad..."), "0xFFFFFFFF", "font:MediumBoldSystemFont", "center");
  m.wxhint.text = tx("Atrás: cancelar");
  t = $createobject("roSGNode", "WeatherTask");
  t.op = "geo";
  t.query = text;
  t.$observefield("result", "onWxGeo");
  m.wxgeotask = t;
  t.control = "RUN";
}

function onwxgeo() {
  let r;
  if ((!m.wxsearching)) {
    return;
  }
  m.wxsearching = false;
  r = m.wxgeotask.result;
  if (((r == null) || (r.ok !== true))) {
    wxmessage(tx("Sin conexión"), tx("No se pudo buscar la ciudad. Revisa tu internet e inténtalo de nuevo."));
    return;
  }
  if ((r.list.$count() === 0)) {
    wxmessage(tx("No encontré esa ciudad"), tx("Prueba escribiendo solo el nombre, por ejemplo: Monterrey, Guadalajara o Madrid."));
    return;
  }
  m.wxlist = r.list;
  m.wxidx = 0;
  wxdrawresults();
}

function wxmessage(title, text) {
  let t;
  m.mode = "wxmsg";
  clearnode(m.wxbody);
  wxcard(m.wxbody, 200, 150, 840, 250);
  wxlabel(m.wxbody, 230, 176, 780, title, "0xFFFFFFFF", "font:LargeBoldSystemFont", "");
  t = wxlabel(m.wxbody, 230, 232, 780, text, "0xA8ADB5FF", "font:MediumSystemFont", "");
  t.wrap = true;
  t.numlines = 3;
  t.height = 120;
  m.wxhint.text = tx("OK: intentar de nuevo     Atrás: volver");
}

function wxdrawresults() {
  let b, n, i, $e6, y;
  m.mode = "wxsearch";
  b = m.wxbody;
  clearnode(b);
  n = m.wxlist.$count();
  wxcard(b, 200, 20, 840, (100 + (n * 56)));
  wxlabel(b, 230, 38, 780, tx("Elige tu ciudad"), "0xFFFFFFFF", "font:LargeBoldSystemFont", "");
  for (i = 0, $e6 = (n - 1); i <= $e6; i++) {
    y = (100 + (i * 56));
    if ((i === m.wxidx)) {
      addrect(b, 220, y, 800, 50, "0xFF8A2433");
      addrect(b, 220, y, 5, 50, "0xFF8A24FF");
      wxlabel(b, 244, (y + 10), 760, $ix(m.wxlist, i).label, "0xFFFFFFFF", "font:MediumBoldSystemFont", "");
    } else {
      wxlabel(b, 244, (y + 10), 760, $ix(m.wxlist, i).label, "0xA8ADB5FF", "font:MediumSystemFont", "");
    }
  }
  m.wxhint.text = tx("Arriba/Abajo: elegir     OK: continuar     Atrás: volver");
}

function wxdrawunit() {
  let b, names, subs, i, $e7, x, col, tc, sc;
  m.mode = "wxunit";
  b = m.wxbody;
  clearnode(b);
  wxcard(b, 200, 90, 840, 360);
  wxlabel(b, 230, 112, 780, tx("Unidades de temperatura"), "0xFFFFFFFF", "font:LargeBoldSystemFont", "");
  wxlabel(b, 230, 158, 780, m.wxpending.label, "0xA8ADB5FF", "font:SmallSystemFont", "");
  names = ["°C", "°F"];
  subs = [tx("Celsius  -  km/h  -  mm"), tx("Fahrenheit  -  mph  -  in")];
  for (i = 0, $e7 = 1; i <= $e7; i++) {
    x = (260 + (i * 280));
    col = "0x1E222CFF";
    tc = "0xFFFFFFFF";
    sc = "0xA8ADB5FF";
    if ((i === m.wxunitsel)) {
      col = "0xFF8A24FF";
      tc = "0x090A0CFF";
      sc = "0x090A0CCC";
    }
    addrect(b, x, 210, 260, 150, col);
    wxlabel(b, x, 232, 260, $ix(names, i), tc, "font:LargeBoldSystemFont", "center");
    wxlabel(b, x, 300, 260, $ix(subs, i), sc, "font:SmallSystemFont", "center");
  }
  m.wxhint.text = tx("Izquierda/Derecha: elegir     OK: guardar     Atrás: volver");
}

function wxsave() {
  let p, u;
  p = m.wxpending;
  u = "c";
  if ((m.wxunitsel === 1)) {
    u = "f";
  }
  m.wxlat = p.lat;
  m.wxlon = p.lon;
  m.wxname = p.name;
  m.wxcity = p.label;
  m.wxunit = u;
  m.sec.$write("wx_lat", p.lat);
  m.sec.$write("wx_lon", p.lon);
  m.sec.$write("wx_name", p.name);
  m.sec.$write("wx_city", p.label);
  m.sec.$write("wx_unit", u);
  m.sec.$flush();
  m.wx = null;
  m.wxfail = false;
  m.wxbusy = false;
  wxupdatewidget();
  wxrefresh();
  openweather();
}

function wxkey(key) {
  let mode;
  mode = m.mode;
  if ((mode === "weather")) {
    if ((key === "back")) {
      showhome();
    } else if (((key === "OK") || (key === "options"))) {
      wxask();
    }
  } else if ((mode === "wxsearch")) {
    if ((key === "back")) {
      m.wxsearching = false;
      showhome();
    } else if (m.wxsearching) {
    } else if ((key === "up")) {
      if ((m.wxidx > 0)) {
        m.wxidx = (m.wxidx - 1);
        wxdrawresults();
      }
    } else if ((key === "down")) {
      if ((m.wxidx < (m.wxlist.$count() - 1))) {
        m.wxidx = (m.wxidx + 1);
        wxdrawresults();
      }
    } else if ((key === "OK")) {
      m.wxpending = $ix(m.wxlist, m.wxidx);
      m.wxunitsel = 0;
      if ((m.wxunit === "f")) {
        m.wxunitsel = 1;
      }
      wxdrawunit();
    }
  } else if ((mode === "wxunit")) {
    if ((key === "back")) {
      wxdrawresults();
    } else if ((key === "left")) {
      m.wxunitsel = 0;
      wxdrawunit();
    } else if ((key === "right")) {
      m.wxunitsel = 1;
      wxdrawunit();
    } else if ((key === "OK")) {
      wxsave();
    }
  } else if ((mode === "wxmsg")) {
    if ((key === "back")) {
      if ((m.wxlat !== "")) {
        openweather();
      } else {
        showhome();
      }
    } else if ((key === "OK")) {
      wxask();
    }
  }
  return true;
}
// ---- components/i18n.brs ----
function i18nlangs() {
  return [{__proto__: $AAP, "code": "es", "name": "Español", "flag": "pkg:/images/flag_es.png"}, {__proto__: $AAP, "code": "en", "name": "English", "flag": "pkg:/images/flag_en.png"}, {__proto__: $AAP, "code": "pt", "name": "Português", "flag": "pkg:/images/flag_pt.png"}, {__proto__: $AAP, "code": "fr", "name": "Français", "flag": "pkg:/images/flag_fr.png"}, {__proto__: $AAP, "code": "de", "name": "Deutsch", "flag": "pkg:/images/flag_de.png"}, {__proto__: $AAP, "code": "it", "name": "Italiano", "flag": "pkg:/images/flag_it.png"}];
}

function i18nvalid(code) {
  let l;
  for (l of $iter(i18nlangs())) {
    if ((l.code === code)) {
      return true;
    }
  }
  return false;
}

function i18ndetect() {
  let code, di, loc, c;
  code = "en";
  di = $createobject("roDeviceInfo");
  if ((di != null)) {
    loc = di.$getcurrentlocale();
    if (((loc != null) && ($len(loc) >= 2))) {
      c = $lcase($left(loc, 2));
      if (i18nvalid(c)) {
        code = c;
      }
    }
  }
  return code;
}

function i18nload(lang) {
  let d, txt, arr, p;
  d = $createobject("roAssociativeArray");
  d.$setmodecasesensitive();
  txt = $readasciifile((("pkg:/locale/" + lang) + ".json"));
  if (((txt != null) && (txt !== ""))) {
    arr = $parsejson(txt);
    if ((arr != null)) {
      for (p of $iter(arr)) {
        $six(d, $ix(p, 0), $ix(p, 1));
      }
    }
  }
  m.i18nd = d;
  m.i18nlang = lang;
}

function tx(s) {
  let lang, v;
  lang = m.global.lang;
  if ((lang == null)) {
    return s;
  }
  if ((lang === "es")) {
    return s;
  }
  if ((m.i18nlang == null)) {
    i18nload(lang);
  } else if ((m.i18nlang !== lang)) {
    i18nload(lang);
  }
  v = m.i18nd.$lookup(s);
  if ((v == null)) {
    return s;
  }
  return v;
}

function i18nlang() {
  let l;
  l = m.global.lang;
  if ((l == null)) {
    return "es";
  }
  return l;
}

function i18n24h() {
  let l;
  l = i18nlang();
  return (((l !== "es") && (l !== "en")));
}

function i18ndow3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  }
  if ((l === "pt")) {
    return ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
  }
  if ((l === "fr")) {
    return ["dim.", "lun.", "mar.", "mer.", "jeu.", "ven.", "sam."];
  }
  if ((l === "de")) {
    return ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
  }
  if ((l === "it")) {
    return ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
  }
  return ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
}

function i18nmon3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  }
  if ((l === "pt")) {
    return ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
  }
  if ((l === "fr")) {
    return ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
  }
  if ((l === "de")) {
    return ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];
  }
  if ((l === "it")) {
    return ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"];
  }
  return ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
}

function i18ndowfull() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  }
  if ((l === "pt")) {
    return ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
  }
  if ((l === "fr")) {
    return ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  }
  if ((l === "de")) {
    return ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
  }
  if ((l === "it")) {
    return ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"];
  }
  return ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
}

function i18ncompass() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  }
  if ((l === "pt")) {
    return ["N", "NE", "L", "SE", "S", "SO", "O", "NO"];
  }
  if ((l === "de")) {
    return ["N", "NO", "O", "SO", "S", "SW", "W", "NW"];
  }
  if ((l === "it")) {
    return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
  }
  return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
}

function i18nhm(h, mm, longfmt) {
  let hs, h12, l, suf;
  if (i18n24h()) {
    hs = h.$tostr();
    if ((h < 10)) {
      hs = ("0" + hs);
    }
    return ((hs + ":") + mm);
  }
  h12 = (h % 12);
  if ((h12 === 0)) {
    h12 = 12;
  }
  l = i18nlang();
  if ((l === "en")) {
    suf = " AM";
    if ((h >= 12)) {
      suf = " PM";
    }
    if ((!longfmt)) {
      suf = "a";
      if ((h >= 12)) {
        suf = "p";
      }
    }
    return (((h12.$tostr() + ":") + mm) + suf);
  }
  if (longfmt) {
    suf = " a. m.";
    if ((h >= 12)) {
      suf = " p. m.";
    }
  } else {
    suf = "a";
    if ((h >= 12)) {
      suf = "p";
    }
  }
  return (((h12.$tostr() + ":") + mm) + suf);
}
// ---- components/series.brs ----
function epregexes() {
  let b;
  if ((m.eprx == null)) {
    b = "(?:^|[\\s\\.\\-_\\[\\(])";
    m.eprx = [{__proto__: $AAP, "rx": $createobject("roRegex", (b + "S(\\d{1,2})[\\s\\.\\-_]*E(\\d{1,3})(?!\\d)"), "i"), "strong": true}, {__proto__: $AAP, "rx": $createobject("roRegex", (b + "(?:(?:Season|Temporada|Temp)\\.?\\s*|T)(\\d{1,2})[\\s\\.\\-_,]*(?:Episode|Episodio|Cap\\w*|Ep|E)\\.?\\s*(\\d{1,3})(?!\\d)"), "i"), "strong": true}, {__proto__: $AAP, "rx": $createobject("roRegex", (b + "(\\d{1,2})x(\\d{1,3})(?![\\dp])"), "i"), "strong": false}];
  }
  return m.eprx;
}

function epparse(title) {
  let p, r, full, at, nm, rest;
  for (p of $iter(epregexes())) {
    r = p.rx.$match(title);
    if ((r.$count() >= 3)) {
      full = $ix(r, 0);
      at = $instr(1, title, full);
      if ((at > 0)) {
        nm = eptrim($left(title, (at - 1)));
        rest = eptrim($mid(title, (at + $len(full))));
        return {__proto__: $AAP, "name": nm, "s": $val($ix(r, 1)), "e": $val($ix(r, 2)), "t": rest, "strong": p.strong};
      }
    }
  }
  return null;
}

function eptrim(s) {
  let seps;
  s = s.$trim();
  seps = "-:|.,([_ ";
  while ((($len(s) > 0) && ($instr(1, seps, $left(s, 1)) > 0))) {
    s = $mid(s, 2).$trim();
  }
  while ((($len(s) > 0) && ($instr(1, seps, $right(s, 1)) > 0))) {
    s = $left(s, ($len(s) - 1)).$trim();
  }
  return s;
}

function sortkey(t) {
  let s, ff, tt, i, $e0, a;
  s = $lcase(t);
  ff = ["á", "é", "í", "ó", "ú", "ü", "ñ", "Á", "É", "Í", "Ó", "Ú", "Ü", "Ñ"];
  tt = ["a", "e", "i", "o", "u", "u", "n", "a", "e", "i", "o", "u", "u", "n"];
  for (i = 0, $e0 = (ff.$count() - 1); i <= $e0; i++) {
    s = s.$replace($ix(ff, i), $ix(tt, i));
  }
  while (($len(s) > 1)) {
    a = $asc($left(s, 1));
    if (((((a >= 48) && (a <= 57))) || (((a >= 97) && (a <= 122))))) {
      break;
    }
    s = $mid(s, 2);
  }
  return s;
}

function seradd(sd, order, gname, ep, entry) {
  let g, key, rec, sk, num;
  if ((!sd.$doesexist(gname))) {
    $six(sd, gname, {__proto__: $AAP, "order": [], "map": {__proto__: $AAP}});
    order.$push(gname);
  }
  g = $ix(sd, gname);
  key = $lcase(ep.name);
  if ((!g.map.$doesexist(key))) {
    $six(g.map, key, {__proto__: $AAP, "name": ep.name, "poster": "", "seasons": {__proto__: $AAP}, "snums": []});
    g.order.$push(key);
  }
  rec = $ix(g.map, key);
  if (((rec.poster === "") && (entry.l !== ""))) {
    rec.poster = entry.l;
  }
  sk = ep.s.$tostr();
  if ((!rec.seasons.$doesexist(sk))) {
    $six(rec.seasons, sk, []);
    rec.snums.$push(ep.s);
  }
  num = ep.e;
  if ((num <= 0)) {
    num = ($ix(rec.seasons, sk).$count() + 1);
  }
  $ix(rec.seasons, sk).$push({__proto__: $AAP, "e": num, "t": ep.t, "u": entry.u, "f": entry.f, "l": entry.l});
}

function serfill(root, sd, order) {
  let gname, g, arr, key, rec, cat, a, sn, s, season, eps, ep, item;
  for (gname of $iter(order)) {
    g = $ix(sd, gname);
    arr = [];
    for (key of $iter(g.order)) {
      rec = $ix(g.map, key);
      arr.$push({__proto__: $AAP, "k": sortkey(rec.name), "r": rec});
    }
    arr.$sortby("k");
    cat = root.$createchild("ContentNode");
    cat.id = gname;
    cat.title = (((gname + "  (") + arr.$count().$tostr()) + ")");
    for (a of $iter(arr)) {
      rec = a.r;
      sn = cat.$createchild("ContentNode");
      sn.title = rec.name;
      sn.id = $lcase(rec.name);
      sn.hdposterurl = rec.poster;
      sn.description = "series";
      rec.snums.$sort();
      for (s of $iter(rec.snums)) {
        season = sn.$createchild("ContentNode");
        season.id = s.$tostr();
        season.title = (tx("Temporada ") + s.$tostr());
        eps = $ix(rec.seasons, s.$tostr());
        eps.$sortby("e");
        for (ep of $iter(eps)) {
          item = season.$createchild("ContentNode");
          item.title = sereptitle(rec.name, s, ep);
          item.shortdescriptionline2 = ep.t;
          item.url = ep.u;
          item.streamformat = ep.f;
          item.hdposterurl = ep.l;
          item.shortdescriptionline1 = ep.e.$tostr();
          item.description = "movie";
        }
      }
    }
  }
}

function serfilldirect(root, sd, order, seen, favs) {
  let gname, g, arr, key, rec, cat, a, sn, s, eps, season, ep, u, sr, item;
  for (gname of $iter(order)) {
    g = $ix(sd, gname);
    sd.$delete(gname);
    if (((g == null) || ($lcase(gname) === "adultos"))) {
      continue;
    }
    arr = [];
    for (key of $iter(g.order)) {
      rec = $ix(g.map, key);
      arr.$push({__proto__: $AAP, "k": sortkey(rec.name), "r": rec});
    }
    arr.$sortby("k");
    cat = null;
    for (a of $iter(arr)) {
      rec = a.r;
      sn = null;
      rec.snums.$sort();
      for (s of $iter(rec.snums)) {
        eps = $ix(rec.seasons, s.$tostr());
        eps.$sortby("e");
        season = null;
        for (ep of $iter(eps)) {
          u = ep.u;
          if (((u !== "") && (!seen.$doesexist(u)))) {
            $six(seen, u, true);
            if ((cat == null)) {
              cat = root.$createchild("ContentNode");
              cat.id = gname;
            }
            if ((sn == null)) {
              sn = cat.$createchild("ContentNode");
              sn.$setfields({__proto__: $AAP, "title": rec.name, "id": $lcase(rec.name), "hdposterurl": rec.poster, "description": "series"});
            }
            if ((season == null)) {
              season = sn.$createchild("ContentNode");
              season.id = s.$tostr();
              season.title = (tx("Temporada ") + s.$tostr());
            }
            sr = 0;
            if (favs.$doesexist(u)) {
              sr = 100;
            }
            item = season.$createchild("ContentNode");
            item.$setfields({__proto__: $AAP, "title": sereptitle(rec.name, s, ep), "shortdescriptionline2": ep.t, "url": u, "streamformat": ep.f, "hdposterurl": ep.l, "shortdescriptionline1": ep.e.$tostr(), "description": "movie", "starrating": sr});
          }
        }
      }
    }
    if ((cat != null)) {
      cat.title = (((gname + "  (") + cat.$getchildcount().$tostr()) + ")");
    }
  }
}

function sereptitle(name, s, ep) {
  let t;
  t = ((((name + "  T") + s.$tostr()) + " E") + ep.e.$tostr());
  if ((ep.t !== "")) {
    t = ((t + " - ") + ep.t);
  }
  return t;
}
// ---- components/episodes.brs ----
function mergeseries(dest, src, srcname) {
  let ci, $e0, cat, cname, dcat, j, $e1, si, $e2, sn, key, dsn, ki, $e3, season, dseason, $e4, ei, $e5, ep, it;
  if (((dest == null) || (src == null))) {
    return;
  }
  if ((m.seenurls == null)) {
    m.seenurls = {__proto__: $AAP};
  }
  if ((m.seridx == null)) {
    m.seridx = {__proto__: $AAP};
  }
  for (ci = 0, $e0 = (src.$getchildcount() - 1); ci <= $e0; ci++) {
    cat = src.$getchild(ci);
    cname = cat.id;
    if (($lcase(cname) === "adultos")) {
      continue;
    }
    dcat = null;
    for (j = 0, $e1 = (dest.$getchildcount() - 1); j <= $e1; j++) {
      if ((dest.$getchild(j).id === cname)) {
        dcat = dest.$getchild(j);
      }
    }
    if ((dcat == null)) {
      dcat = dest.$createchild("ContentNode");
      dcat.id = cname;
    }
    for (si = 0, $e2 = (cat.$getchildcount() - 1); si <= $e2; si++) {
      sn = cat.$getchild(si);
      key = ((cname + "|") + sn.id);
      dsn = $ix(m.seridx, key);
      if ((dsn == null)) {
        dsn = dcat.$createchild("ContentNode");
        dsn.id = sn.id;
        dsn.title = sn.title;
        dsn.hdposterurl = sn.hdposterurl;
        dsn.description = "series";
        $six(m.seridx, key, dsn);
      }
      for (ki = 0, $e3 = (sn.$getchildcount() - 1); ki <= $e3; ki++) {
        season = sn.$getchild(ki);
        dseason = null;
        for (j = 0, $e4 = (dsn.$getchildcount() - 1); j <= $e4; j++) {
          if ((dsn.$getchild(j).id === season.id)) {
            dseason = dsn.$getchild(j);
          }
        }
        if ((dseason == null)) {
          dseason = dsn.$createchild("ContentNode");
          dseason.id = season.id;
          dseason.title = season.title;
        }
        for (ei = 0, $e5 = (season.$getchildcount() - 1); ei <= $e5; ei++) {
          ep = season.$getchild(ei);
          if ((((ep.url != null) && (ep.url !== "")) && (!m.seenurls.$doesexist(ep.url)))) {
            $six(m.seenurls, ep.url, true);
            it = dseason.$createchild("ContentNode");
            it.title = ep.title;
            it.url = ep.url;
            it.streamformat = ep.streamformat;
            it.hdposterurl = ep.hdposterurl;
            it.shortdescriptionline1 = ep.shortdescriptionline1;
            it.shortdescriptionline2 = ep.shortdescriptionline2;
            it.description = "movie";
            if (((m.favmap != null) && m.favmap.$doesexist(ep.url))) {
              it.starrating = 100;
            }
          }
        }
      }
    }
  }
}

function showepisodes(ser) {
  if ((ser == null)) {
    return;
  }
  m.epseries = ser;
  m.epseason = 0;
  m.epidx = 0;
  m.epzone = "play";
  m.eploading = false;
  m.eperror = "";
  m.dtitem = ser;
  m.dtinfo = null;
  m.dtloading = false;
  dtbuildbackground();
  if ((((m.xtactive != null) && (ser.$getchildcount() === 0)) && (xtserid(ser) !== ""))) {
    m.eploading = true;
    xtloadseries(ser);
  }
  reshowepisodes();
}

function reshowepisodes() {
  m.mode = "episodes";
  hidepanels();
  setbgfrozen(true);
  m.topbar.visible = false;
  m.detailpanel.visible = true;
  drawepisodes();
  capturekeys();
}

function epinfo() {
  let ser, k;
  ser = m.epseries;
  if (((ser == null) || (m.serinfo == null))) {
    return {__proto__: $AAP};
  }
  k = xtserid(ser);
  if (((k !== "") && m.serinfo.$doesexist(k))) {
    return $ix(m.serinfo, k);
  }
  return {__proto__: $AAP};
}

function epstr(inf, key) {
  if ((inf.$doesexist(key) && ($ix(inf, key) != null))) {
    return $ix(inf, key);
  }
  return "";
}

function epfield(node, f) {
  let v;
  if ((node == null)) {
    return "";
  }
  if ((!node.$hasfield(f))) {
    return "";
  }
  v = node.$getfield(f);
  if ((v == null)) {
    return "";
  }
  return v;
}

function epupdatebackground() {
  let ser, inf, back, poster;
  ser = m.epseries;
  inf = epinfo();
  back = epstr(inf, "backdrop");
  if ((back !== "")) {
    dtsetimage(back, "full");
  } else if ((!m.eploading)) {
    poster = ser.hdposterurl;
    if (((poster == null) || (poster === ""))) {
      poster = epstr(inf, "cover");
    }
    if ((poster !== "")) {
      dtsetimage(poster, "side");
    }
  }
}

function drawepisodes() {
  let b, ser, inf, ns, lg, x, w, st, tl, y, cx, parts, yr, d, first, t, dot, lb, rt, rl, gn, season, total, head, body, ep, nm, ebody, pl, cast, playtxt, ep0, f0, ba, tc, l0, ty, i, $e6, label, tmp, tw, selected, c, tl2, cw, gap, vis, start, n, $e7, ix, ex, ey, thumb, focused, tp, num, du;
  b = m.detailbody;
  clearnode(b);
  ser = m.epseries;
  if ((ser == null)) {
    return;
  }
  epupdatebackground();
  inf = epinfo();
  ns = ser.$getchildcount();
  if ((ns > 0)) {
    if ((m.epseason >= ns)) {
      m.epseason = (ns - 1);
    }
    if ((m.epseason < 0)) {
      m.epseason = 0;
    }
  }
  lg = addposter(b, 64, 36, 150, 40, "pkg:/images/logo_small.png");
  lg.loaddisplaymode = "scaleToFit";
  x = 64;
  w = 700;
  dttext(b, x, 98, w, tx("SERIE"), "0xFF8A24FF", 16, "Bold");
  st = splittitle(ser.title);
  tl = dttext(b, x, 120, w, st.t, "0xFFFFFFFF", 44, "Bold");
  tl.maxlines = 1;
  tl.wrap = false;
  y = 182;
  cx = x;
  parts = [];
  yr = st.year;
  d = epstr(inf, "date");
  if (((yr === "") && ($len(d) >= 4))) {
    yr = $left(d, 4);
  }
  if ((yr !== "")) {
    parts.$push(yr);
  }
  if ((ns === 1)) {
    parts.$push(tx("1 temporada"));
  } else if ((ns > 1)) {
    parts.$push((ns.$tostr() + tx(" temporadas")));
  }
  first = true;
  for (t of $iter(parts)) {
    if ((!first)) {
      dot = dttext(b, cx, y, 0, "•", "0x80858CFF", 20, "Regular");
      cx = ((cx + dtw(dot)) + 12);
    }
    lb = dttext(b, cx, y, 0, t, "0xE6E8EBFF", 20, "SemiBold");
    cx = ((cx + dtw(lb)) + 12);
    first = false;
  }
  rt = fmtrating(epstr(inf, "rating"));
  if ((rt !== "")) {
    if ((!first)) {
      cx = (cx + 6);
    }
    dtbox(b, cx, (y - 3), 84, 30, "pkg:/images/rr_pill.9.png", "0xFF8A24FF", 1.0);
    rl = dttext(b, cx, y, 84, ("★ " + rt), "0x101016FF", 18, "Bold");
    rl.horizalign = "center";
  }
  y = (y + 38);
  gn = fmtgenres(epstr(inf, "genre"));
  if ((gn !== "")) {
    dttext(b, x, y, w, gn, "0xC8CCD2FF", 19, "Regular");
    y = (y + 32);
  }
  season = null;
  total = 0;
  if ((ns > 0)) {
    season = ser.$getchild(m.epseason);
    total = season.$getchildcount();
    if ((m.epidx >= total)) {
      m.epidx = (total - 1);
    }
    if ((m.epidx < 0)) {
      m.epidx = 0;
    }
  }
  head = "";
  body = epstr(inf, "plot");
  if (((m.epzone === "eps") && (total > 0))) {
    ep = season.$getchild(m.epidx);
    head = ((("T" + season.id) + ":E") + ep.shortdescriptionline1);
    nm = ep.shortdescriptionline2;
    if (((nm != null) && (nm !== ""))) {
      head = ((head + "  ·  ") + nm.$replace("\\", ""));
    }
    ebody = epfield(ep, "epplot");
    if ((ebody !== "")) {
      body = ebody;
    }
  }
  if ((body === "")) {
    if (m.eploading) {
      body = tx("Cargando capítulos...");
    } else if ((m.eperror !== "")) {
      body = m.eperror;
    } else if ((head === "")) {
      body = tx("Esta lista no trae sinopsis para este título.");
    }
  }
  if ((head !== "")) {
    dttext(b, x, y, w, head, "0xFFFFFFFF", 19, "SemiBold");
    y = (y + 28);
  }
  pl = dttext(b, x, y, w, body, "0xE4E6EAFF", 19, "Regular");
  pl.wrap = true;
  pl.maxlines = 3;
  pl.linespacing = 3;
  cast = firstnames(epstr(inf, "cast"), 4);
  if (((cast !== "") && (head === ""))) {
    dttext(b, x, 352, 100, tx("Reparto"), "0x80858CFF", 16, "SemiBold");
    dttext(b, (x + 92), 352, (w - 92), fittext(cast, 560), "0xD0D4DAFF", 16, "Regular");
  }
  playtxt = tx("Reproducir");
  if ((total > 0)) {
    ep0 = season.$getchild(m.epidx);
    playtxt = ((((tx("Reproducir") + "  T") + season.id) + ":E") + ep0.shortdescriptionline1);
  }
  f0 = ((m.epzone === "play"));
  ba = 0.2;
  tc = "0xFFFFFFFF";
  if (f0) {
    ba = 1.0;
    tc = "0x0A0A0FFF";
  }
  dtbox(b, 64, 380, 300, 52, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", ba);
  l0 = dttext(b, 64, 393, 300, ("▶   " + playtxt), tc, 20, "SemiBold");
  l0.horizalign = "center";
  if (((((total === 0) && (m.eploading === false)) && (m.eperror === "")) && (ns === 0))) {
    dttext(b, 390, 396, 600, tx("Esta serie no tiene capítulos."), "0xA8ADB5FF", 17, "Regular");
  }
  if ((ns > 0)) {
    ty = 450;
    first = (m.epseason - 3);
    if ((first < 0)) {
      first = 0;
    }
    cx = 64;
    for (i = first, $e6 = (ns - 1); i <= $e6; i++) {
      label = (tx("Temporada ") + ser.$getchild(i).id);
      tmp = dttext(b, (-2000), 0, 0, label, "0xFFFFFFFF", 17, "SemiBold");
      tw = (dtw(tmp) + 32);
      b.$removechild(tmp);
      if (((cx + tw) > 1216)) {
        break;
      }
      selected = ((i === m.epseason));
      if ((selected && (m.epzone === "seasons"))) {
        dtbox(b, cx, ty, tw, 38, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 1.0);
        c = "0x0A0A0FFF";
      } else if (selected) {
        dtbox(b, cx, ty, tw, 38, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.22);
        c = "0xFFFFFFFF";
      } else {
        c = "0xA8ADB5FF";
      }
      tl2 = dttext(b, cx, (ty + 9), tw, label, c, 17, "SemiBold");
      tl2.horizalign = "center";
      cx = ((cx + tw) + 10);
    }
  }
  if ((total > 0)) {
    cw = 212;
    gap = 14;
    vis = 5;
    start = (m.epidx - 2);
    if ((start > (total - vis))) {
      start = (total - vis);
    }
    if ((start < 0)) {
      start = 0;
    }
    for (n = 0, $e7 = (vis - 1); n <= $e7; n++) {
      ix = (start + n);
      if ((ix >= total)) {
        break;
      }
      ep = season.$getchild(ix);
      ex = (64 + (n * ((cw + gap))));
      ey = 512;
      thumb = ep.hdposterurl;
      if (((thumb == null) || (thumb === ""))) {
        thumb = ser.hdposterurl;
      }
      focused = (((m.epzone === "eps") && (ix === m.epidx)));
      addrect(b, ex, ey, cw, 119, "0x1C1C24FF");
      if (((thumb != null) && (thumb !== ""))) {
        tp = dtphoto(b, ex, ey, cw, 119, thumb);
        tp.failedbitmapuri = emptycover("t");
      } else {
        dtphoto(b, ex, ey, cw, 119, emptycover("t"));
      }
      if (focused) {
        dtbox(b, (ex - 4), (ey - 4), (cw + 8), 127, "pkg:/images/rr_line.9.png", "0xFFFFFFFF", 1.0);
      }
      if ((((m.favmap != null) && (ep.url != null)) && m.favmap.$doesexist(ep.url))) {
        addposter(b, ((ex + cw) - 34), (ey + 6), 28, 28, "pkg:/images/heart_on.png");
      }
      num = ep.shortdescriptionline1;
      nm = ep.shortdescriptionline2;
      if (((nm == null) || (nm === ""))) {
        nm = (tx("Capítulo ") + num);
      }
      nm = nm.$replace("\\", "");
      tc = "0xD0D4DAFF";
      if (focused) {
        tc = "0xFFFFFFFF";
      }
      dttext(b, ex, (ey + 128), cw, fittext(((num + ". ") + nm), (cw - 10)), tc, 16, "SemiBold");
      du = fmtduration(epfield(ep, "epdur"));
      if ((du !== "")) {
        dttext(b, ex, (ey + 152), cw, du, "0x80858CFF", 14, "Regular");
      }
    }
  }
}

function episodeskey(key) {
  let ser, ns, total, season;
  ser = m.epseries;
  if ((key === "back")) {
    leaveepisodes();
    return true;
  }
  if ((ser == null)) {
    return true;
  }
  ns = ser.$getchildcount();
  total = 0;
  season = null;
  if ((ns > 0)) {
    season = ser.$getchild(m.epseason);
    total = season.$getchildcount();
  }
  if ((m.epzone === "play")) {
    if ((key === "down")) {
      if ((ns > 1)) {
        m.epzone = "seasons";
      } else if ((total > 0)) {
        m.epzone = "eps";
      }
    } else if (((key === "OK") || (key === "play"))) {
      if ((total > 0)) {
        playnode(season.$getchild(m.epidx), "episodes");
        return true;
      }
    }
  } else if ((m.epzone === "seasons")) {
    if ((key === "left")) {
      if ((m.epseason > 0)) {
        m.epseason = (m.epseason - 1);
        m.epidx = 0;
      }
    } else if ((key === "right")) {
      if ((m.epseason < (ns - 1))) {
        m.epseason = (m.epseason + 1);
        m.epidx = 0;
      }
    } else if ((key === "up")) {
      m.epzone = "play";
    } else if (((key === "down") || (key === "OK"))) {
      if ((total > 0)) {
        m.epzone = "eps";
      }
    }
  } else {
    if ((key === "left")) {
      if ((m.epidx > 0)) {
        m.epidx = (m.epidx - 1);
      }
    } else if ((key === "right")) {
      if ((m.epidx < (total - 1))) {
        m.epidx = (m.epidx + 1);
      }
    } else if ((key === "up")) {
      if ((ns > 1)) {
        m.epzone = "seasons";
      } else {
        m.epzone = "play";
      }
    } else if ((key === "OK")) {
      if ((total > 0)) {
        playnode(season.$getchild(m.epidx), "episodes");
        return true;
      }
    } else if ((key === "play")) {
      if ((total > 0)) {
        togglefavorite(season.$getchild(m.epidx));
      }
    }
  }
  drawepisodes();
  return true;
}

function leaveepisodes() {
  m.detailpanel.visible = false;
  if ((m.epback === "search")) {
    showsearchresults();
  } else if ((m.epback === "adult")) {
    showadult();
  } else {
    showserieslist();
  }
}
// ---- components/lang.brs ----
function i18ninit() {
  let sec, lang;
  sec = $createobject("roRegistrySection", "IPTV_Settings");
  lang = "";
  if (sec.$exists("lang")) {
    lang = sec.$read("lang");
  }
  m.langchosen = i18nvalid(lang);
  if ((!m.langchosen)) {
    lang = i18ndetect();
  }
  m.global.$addfields({__proto__: $AAP, "lang": lang});
  xmlcollect();
}

function xmlcollect() {
  let skip;
  m.xmllbl = [];
  skip = {__proto__: $AAP, "toptitle": 1, "wxtemp": 1, "activename": 1, "wfinl1": 1, "ctlpos": 1, "wbtnlabel": 1};
  xmlwalk(m.top, skip);
}

function xmlwalk(n, skip) {
  let i, $e0, c;
  for (i = 0, $e0 = (n.$getchildcount() - 1); i <= $e0; i++) {
    c = n.$getchild(i);
    if ((c.$subtype() === "Label")) {
      if (((c.text !== "") && (!skip.$doesexist(c.id)))) {
        m.xmllbl.$push({__proto__: $AAP, "n": c, "t": c.text});
      }
    }
    xmlwalk(c, skip);
  }
}

function xmltranslate() {
  let e;
  for (e of $iter(m.xmllbl)) {
    e.n.text = tx(e.t);
  }
}

function langindexof(code) {
  let ls, i, $e1;
  ls = i18nlangs();
  for (i = 0, $e1 = (ls.$count() - 1); i <= $e1; i++) {
    if (($ix(ls, i).code === code)) {
      return i;
    }
  }
  return 0;
}

function applylanguage(code) {
  m.global.lang = code;
  m.sec.$write("lang", code);
  m.sec.$flush();
  m.langchosen = true;
  xmltranslate();
  updateactivechip();
  wxupdatewidget();
}

function showlang(first) {
  m.langfirst = first;
  m.mode = "lang";
  hidepanels();
  if (first) {
    m.topbar.visible = false;
  }
  settitle(tx("Idioma"));
  m.langpanel.visible = true;
  m.langidx = langindexof(i18nlang());
  drawlang();
  capturekeys();
}

function drawlang() {
  let g, ls, mk, k, t, y0, i, $e2, y, on2, fg, w, hint, h;
  g = m.langbody;
  clearnode(g);
  m.langhead.text = "";
  m.langhint.text = "";
  ls = i18nlangs();
  if (m.langfirst) {
    mk = addposter(g, 580, 52, 120, 76, "pkg:/images/logo_mark.png");
    k = dttext(g, 0, 150, 1280, "IDIOMA  ·  LANGUAGE", "0xFF8A24FF", 15, "Bold");
    k.horizalign = "center";
    t = dttext(g, 0, 174, 1280, "Elige tu idioma  ·  Choose your language", "0xFFFFFFFF", 34, "Bold");
    t.horizalign = "center";
    y0 = 248;
  } else {
    t = dttext(g, 0, 96, 1280, tx("Elige tu idioma"), "0xFFFFFFFF", 34, "Bold");
    t.horizalign = "center";
    y0 = 166;
  }
  for (i = 0, $e2 = (ls.$count() - 1); i <= $e2; i++) {
    y = (y0 + (i * 62));
    on2 = ((i === m.langidx));
    fg = "0xE6E8EBFF";
    if (on2) {
      dtbox(g, 400, y, 480, 54, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 1.0);
      fg = "0x0A0A0FFF";
    } else {
      dtbox(g, 400, y, 480, 54, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.06);
    }
    addposter(g, 424, (y + 12), 45, 30, $ix(ls, i).flag);
    w = "Regular";
    if (on2) {
      w = "SemiBold";
    }
    dttext(g, 490, (y + 15), 360, $ix(ls, i).name, fg, 20, w);
  }
  hint = tx("Arriba/Abajo: elegir     OK: confirmar     Atrás: volver");
  if (m.langfirst) {
    hint = "Arriba/Abajo  ·  Up/Down          OK";
  }
  h = dttext(g, 0, 676, 1280, hint, "0x7E838CFF", 15, "Regular");
  h.horizalign = "center";
}

function langkey(key) {
  let n;
  n = i18nlangs().$count();
  if ((key === "up")) {
    if ((m.langidx > 0)) {
      m.langidx = (m.langidx - 1);
      drawlang();
    }
  } else if ((key === "down")) {
    if ((m.langidx < (n - 1))) {
      m.langidx = (m.langidx + 1);
      drawlang();
    }
  } else if ((key === "OK")) {
    applylanguage($ix(i18nlangs(), m.langidx).code);
    if (m.langfirst) {
      showwelcome(true);
    } else {
      showabout();
      m.aboutidx = (aboutsections().$count() - 2);
      drawabout();
    }
  } else if ((key === "back")) {
    if (m.langfirst) {
      return false;
    }
    showabout();
    m.aboutidx = (aboutsections().$count() - 2);
    drawabout();
  }
  return true;
}
// ---- components/xtcommon.brs ----
function dstr(v) {
  let t;
  t = $type(v);
  if (((t === "roString") || (t === "String"))) {
    return v;
  }
  if (((((((((((t === "roInt") || (t === "Integer")) || (t === "roLongInteger")) || (t === "LongInteger")) || (t === "roFloat")) || (t === "Float")) || (t === "roDouble")) || (t === "Double")) || (t === "roBoolean")) || (t === "Boolean"))) {
    return v.$tostr();
  }
  return "";
}

function xtesc(s) {
  let ba, hex, out, i, $e0, b;
  ba = $createobject("roByteArray");
  ba.$fromasciistring(s);
  hex = "0123456789ABCDEF";
  out = "";
  for (i = 0, $e0 = (ba.$count() - 1); i <= $e0; i++) {
    b = $ix(ba, i);
    if ((((((((((b >= 48) && (b <= 57))) || (((b >= 65) && (b <= 90)))) || (((b >= 97) && (b <= 122)))) || (b === 45)) || (b === 46)) || (b === 95)) || (b === 126))) {
      out = (out + $chr(b));
    } else {
      out = (((out + "%") + $mid(hex, (($idiv(b, 16)) + 1), 1)) + $mid(hex, (((b % 16)) + 1), 1));
    }
  }
  return out;
}

function xthexval(c) {
  if (((c >= 48) && (c <= 57))) {
    return (c - 48);
  }
  if (((c >= 65) && (c <= 70))) {
    return (c - 55);
  }
  if (((c >= 97) && (c <= 102))) {
    return (c - 87);
  }
  return (-1);
}

function xtunesc(s) {
  let src, dst, n, i, b, used, hi, lo;
  src = $createobject("roByteArray");
  src.$fromasciistring(s);
  dst = $createobject("roByteArray");
  n = src.$count();
  i = 0;
  while ((i < n)) {
    b = $ix(src, i);
    used = false;
    if ((b === 37)) {
      if (((i + 2) < n)) {
        hi = xthexval($ix(src, (i + 1)));
        lo = xthexval($ix(src, (i + 2)));
        if (((hi >= 0) && (lo >= 0))) {
          dst.$push(((hi * 16) + lo));
          i = (i + 3);
          used = true;
        }
      }
    }
    if ((!used)) {
      dst.$push(b);
      i = (i + 1);
    }
  }
  return dst.$toasciistring();
}

function xtbase(h) {
  let s, low, q, done, tail;
  s = h.$trim();
  if ((s === "")) {
    return "";
  }
  low = $lcase(s);
  if ((($left(low, 7) !== "http://") && ($left(low, 8) !== "https://"))) {
    s = ("http://" + s);
  }
  q = $instr(1, s, "?");
  if ((q > 0)) {
    s = $left(s, (q - 1));
  }
  done = false;
  while ((!done)) {
    done = true;
    while ((($right(s, 1) === "/") && ($len(s) > 8))) {
      s = $left(s, ($len(s) - 1));
      done = false;
    }
    for (tail of $iter(["/player_api.php", "/get.php", "/xmltv.php", "/panel_api.php", "/c"])) {
      if (((($len(s) - $len(tail)) > 8) && ($lcase($right(s, $len(tail))) === tail))) {
        s = $left(s, ($len(s) - $len(tail)));
        done = false;
      }
    }
  }
  return s;
}

function xtparam(s, key) {
  let low, sep, p, st, en;
  low = $lcase(s);
  for (sep of $iter(["?", "&"])) {
    p = $instr(1, low, ((sep + $lcase(key)) + "="));
    if ((p > 0)) {
      st = ((p + $len(key)) + 2);
      en = $instr(st, s, "&");
      if ((en === 0)) {
        en = ($len(s) + 1);
      }
      return xtunesc($mid(s, st, (en - st)));
    }
  }
  return "";
}

function xtfromurl(s) {
  let u, p;
  u = xtparam(s, "username");
  p = xtparam(s, "password");
  if (((u === "") || (p === ""))) {
    return null;
  }
  return {__proto__: $AAP, "host": xtbase(s), "user": u, "pass": p};
}
// ---- components/xtream.brs ----
function xtinit() {
  let arr, a, h, u, p, sm, i;
  m.xthint = m.top.$findnode("xtHint");
  m.libhint = m.top.$findnode("hintLabel");
  m.btnxt = m.top.$findnode("btnXt");
  m.xtaccounts = [];
  m.xtactive = null;
  m.xtactiveidx = (-1);
  m.xterr = "";
  m.xtserbusy = false;
  if (m.sec.$exists("xt_accounts")) {
    arr = $parsejson(m.sec.$read("xt_accounts"));
    if (($type(arr) === "roArray")) {
      for (a of $iter(arr)) {
        if (($type(a) === "roAssociativeArray")) {
          h = dstr(a.host);
          u = dstr(a.user);
          p = dstr(a.pass);
          if ((((h !== "") && (u !== "")) && (p !== ""))) {
            m.xtaccounts.$push({__proto__: $AAP, "name": dstr(a.name), "host": h, "user": u, "pass": p});
          }
        }
      }
    }
  }
  if (m.sec.$exists("src_mode")) {
    sm = m.sec.$read("src_mode");
    if (($left(sm, 3) === "xt:")) {
      i = $int($val($mid(sm, 4)));
      if (((i >= 0) && (i < m.xtaccounts.$count()))) {
        m.xtactive = $ix(m.xtaccounts, i);
        m.xtactiveidx = i;
      }
    }
  }
}

function xtsave() {
  m.sec.$write("xt_accounts", $formatjson(m.xtaccounts));
  m.sec.$flush();
}

function xtpseudo(a) {
  let base, nm;
  base = xtbase(a.host);
  nm = a.name;
  if ((nm === "")) {
    nm = "Xtream";
  }
  return {__proto__: $AAP, "name": nm, "url": ((("xtream:" + base) + "|") + a.user), "epg": ((((base + "/xmltv.php?username=") + xtesc(a.user)) + "&password=") + xtesc(a.pass)), "xt": a};
}

function xtsetactive(idx) {
  m.xtactive = $ix(m.xtaccounts, idx);
  m.xtactiveidx = idx;
  m.sec.$write("src_mode", ("xt:" + idx.$tostr()));
  m.sec.$flush();
  resetcatalog();
  updateactivechip();
}

function xtclear() {
  if ((m.xtactive == null)) {
    return;
  }
  m.xtactive = null;
  m.xtactiveidx = (-1);
  m.sec.$write("src_mode", "");
  m.sec.$flush();
}

function xthintmode(on) {
  if ((m.xthint != null)) {
    m.xthint.visible = on;
  }
  if ((m.libhint != null)) {
    m.libhint.visible = (!on);
  }
}

function showxtream() {
  m.mode = "xtlist";
  hidepanels();
  settitle("Xtream");
  m.librarypanel.visible = true;
  xthintmode(true);
  xtrefresh();
  m.librarylist.$setfocus(true);
}

function xtrefresh() {
  let root, i, $e0, c;
  root = $createobject("roSGNode", "ContentNode");
  for (i = 0, $e0 = (m.xtaccounts.$count() - 1); i <= $e0; i++) {
    c = root.$createchild("ContentNode");
    c.title = $ix(m.xtaccounts, i).name;
    if (((m.xtactive != null) && (m.xtactiveidx === i))) {
      c.shortdescriptionline1 = tx("EN USO");
    }
  }
  c = root.$createchild("ContentNode");
  c.title = tx("+  Agregar cuenta Xtream con el teclado");
  c.starrating = 1;
  c = root.$createchild("ContentNode");
  c.title = tx("+  Agregar cuenta Xtream desde el celular (QR)");
  c.starrating = 1;
  m.librarylist.content = root;
  if ((m.xtaccounts.$count() === 0)) {
    m.statuslabel.text = tx("Aún no hay cuentas Xtream. Agrega una.");
  } else if ((m.xtactive != null)) {
    m.statuslabel.text = (tx("Cuenta en uso: ") + m.xtactive.name);
  } else {
    m.statuslabel.text = "";
  }
}

function xtselected() {
  let idx, n;
  idx = m.librarylist.itemselected;
  n = m.xtaccounts.$count();
  if ((idx < n)) {
    xtoptions(idx);
  } else if ((idx === n)) {
    xtstartadd();
  } else {
    showqr();
  }
}

function xtkey(key) {
  let idx;
  if ((key === "back")) {
    showhome();
    if (m.needreload) {
      m.needreload = false;
      opensection("preload");
    }
    return true;
  } else if ((key === "options")) {
    idx = m.librarylist.itemfocused;
    if (((idx >= 0) && (idx < m.xtaccounts.$count()))) {
      xtoptions(idx);
      return true;
    }
  }
  return false;
}

function xtoptions(idx) {
  let a, dialog;
  m.xtoptidx = idx;
  a = $ix(m.xtaccounts, idx);
  dialog = {__proto__: $AAP, "title": "", "message": [], "buttons": []};
  dialog.title = a.name;
  dialog.message = [xtbase(a.host), a.user];
  dialog.buttons = [tx("Usar esta cuenta"), tx("Editar"), tx("Eliminar"), tx("Cancelar")];
  uiask(dialog.title, dialog.message, dialog.buttons, "onXtOptions");
}

function onxtoptions() {
  let button, idx;
  button = m.uibtn;
  idx = m.xtoptidx;
  if ((button === 0)) {
    xtsetactive(idx);
    showhome();
    m.homestatus.text = ((tx("Cargando ") + $ix(m.xtaccounts, idx).name) + "...");
    opensection("preload");
  } else if ((button === 1)) {
    xtstartedit(idx);
  } else if ((button === 2)) {
    xtconfirmdelete(idx);
  } else {
    m.librarylist.$setfocus(true);
  }
}

function xtconfirmdelete(idx) {
  let dialog;
  dialog = {__proto__: $AAP, "title": "", "message": [], "buttons": []};
  dialog.title = tx("Eliminar esta cuenta?");
  dialog.message = [$ix(m.xtaccounts, idx).name];
  dialog.buttons = [tx("Si, eliminar"), tx("Cancelar")];
  uiask(dialog.title, dialog.message, dialog.buttons, "onXtDelete");
}

function onxtdelete() {
  let button, idx, wasactive;
  button = m.uibtn;
  idx = m.xtoptidx;
  if ((((button === 0) && (idx >= 0)) && (idx < m.xtaccounts.$count()))) {
    wasactive = (((m.xtactive != null) && (m.xtactiveidx === idx)));
    m.xtaccounts.$delete(idx);
    xtsave();
    if (wasactive) {
      xtclear();
      resetcatalog();
      m.needreload = true;
      updateactivechip();
    } else if (((m.xtactive != null) && (idx < m.xtactiveidx))) {
      m.xtactiveidx = (m.xtactiveidx - 1);
      m.sec.$write("src_mode", ("xt:" + m.xtactiveidx.$tostr()));
      m.sec.$flush();
    }
    xtrefresh();
    m.statuslabel.text = tx("Cuenta eliminada.");
  }
  m.librarylist.$setfocus(true);
}

function xtstartadd() {
  m.xtedit = (-1);
  m.xtnew = {__proto__: $AAP, "name": "", "host": "", "user": "", "pass": ""};
  xtask(tx("Nombre de la cuenta (opcional)"), "", "xtname");
}

function xtstartedit(idx) {
  let a;
  m.xtedit = idx;
  a = $ix(m.xtaccounts, idx);
  m.xtnew = {__proto__: $AAP, "name": a.name, "host": a.host, "user": a.user, "pass": a.pass};
  xtask(tx("Nombre de la cuenta (opcional)"), a.name, "xtname");
}

function xtask(title, text, stage) {
  let okl;
  okl = tx("Siguiente");
  if ((stage === "xtpass")) {
    okl = tx("Guardar");
  }
  kbopen(title, text, stage, okl);
}

function xtkeyboarddone(button, text, stage) {
  let full;
  if ((button !== 0)) {
    m.librarylist.$setfocus(true);
    return;
  }
  if ((stage === "xtname")) {
    m.xtnew.name = text;
    xtask(tx("Servidor (ej. http://servidor.com:8080)"), m.xtnew.host, "xthost");
  } else if ((stage === "xthost")) {
    if ((text === "")) {
      m.statuslabel.text = tx("Escribe el servidor.");
      m.librarylist.$setfocus(true);
      return;
    }
    full = xtfromurl(text);
    if ((full != null)) {
      m.xtnew.host = full.host;
      m.xtnew.user = full.user;
      m.xtnew.pass = full.pass;
      xtfinish();
    } else {
      m.xtnew.host = text;
      xtask(tx("Usuario"), m.xtnew.user, "xtuser");
    }
  } else if ((stage === "xtuser")) {
    if ((text === "")) {
      m.statuslabel.text = tx("Falta el usuario.");
      m.librarylist.$setfocus(true);
      return;
    }
    m.xtnew.user = text;
    xtask(tx("Contraseña"), m.xtnew.pass, "xtpass");
  } else {
    if ((text === "")) {
      m.statuslabel.text = tx("Falta la contraseña.");
      m.librarylist.$setfocus(true);
      return;
    }
    m.xtnew.pass = text;
    xtfinish();
  }
}

function xtfinish() {
  let a, idx, isnew, wasactive, activated;
  a = m.xtnew;
  a.host = xtbase(a.host);
  idx = m.xtedit;
  isnew = ((idx < 0));
  wasactive = ((((!isnew) && (m.xtactive != null)) && (m.xtactiveidx === idx)));
  if ((a.name === "")) {
    a.name = ("Xtream " + ((m.xtaccounts.$count() + 1)).$tostr());
  }
  if (isnew) {
    m.xtaccounts.$push(a);
    idx = (m.xtaccounts.$count() - 1);
  } else {
    $six(m.xtaccounts, idx, a);
  }
  xtsave();
  activated = ((isnew || wasactive));
  if (activated) {
    xtsetactive(idx);
    opensection("preload");
  }
  xtrefresh();
  if (activated) {
    m.statuslabel.text = tx("Cuenta guardada y en uso.");
  }
  m.librarylist.$setfocus(true);
}

function xtaddfromqr(it) {
  let x, base, idx, i, $e1, a, acc;
  x = it.xt;
  if ((x == null)) {
    return "";
  }
  base = xtbase(x.host);
  idx = (-1);
  for (i = 0, $e1 = (m.xtaccounts.$count() - 1); i <= $e1; i++) {
    a = $ix(m.xtaccounts, i);
    if ((($lcase(xtbase(a.host)) === $lcase(base)) && (a.user === x.user))) {
      idx = i;
    }
  }
  acc = {__proto__: $AAP, "name": it.name, "host": base, "user": x.user, "pass": x.pass};
  if ((idx >= 0)) {
    if ((acc.name === "")) {
      acc.name = $ix(m.xtaccounts, idx).name;
    }
    $six(m.xtaccounts, idx, acc);
  } else {
    if ((acc.name === "")) {
      acc.name = ("Xtream " + ((m.xtaccounts.$count() + 1)).$tostr());
    }
    m.xtaccounts.$push(acc);
    idx = (m.xtaccounts.$count() - 1);
  }
  xtsave();
  xtsetactive(idx);
  opensection("preload");
  return acc.name;
}

function onxtstatus() {
  let s;
  if ((m.contenttask == null)) {
    return;
  }
  s = m.contenttask.status;
  if (((s != null) && ($left(s, 6) === "error:"))) {
    m.xterr = $mid(s, 7);
  }
}

function xtserid(ser) {
  let l1;
  l1 = ser.shortdescriptionline1;
  if (((l1 != null) && ($left(l1, 3) === "xt:"))) {
    return $mid(l1, 4);
  }
  return "";
}

function xtloadseries(ser) {
  let a, t;
  if ((m.xtserbusy === true)) {
    return;
  }
  a = m.xtactive;
  if ((a == null)) {
    return;
  }
  m.xtserbusy = true;
  m.xtsernode = ser;
  m.moviehint.text = tx("Cargando capítulos...");
  t = $createobject("roSGNode", "XtreamReader");
  t.op = "series";
  t.host = a.host;
  t.user = a.user;
  t.pass = a.pass;
  t.serid = xtserid(ser);
  m.xtsertask = t;
  t.$observefield("result", "onXtSeries");
  t.control = "RUN";
}

function onxtseries() {
  let ser, r, sn, season, ep, item, sr;
  m.xtserbusy = false;
  ser = m.xtsernode;
  if ((m.xtsertask == null)) {
    return;
  }
  r = m.xtsertask.result;
  if (((ser == null) || (r == null))) {
    return;
  }
  if ((r.ok !== true)) {
    m.moviehint.text = tx("No se pudieron cargar los capítulos.");
    if ((((m.mode === "episodes") && (m.epseries != null)) && m.epseries.$issamenode(ser))) {
      m.eploading = false;
      m.eperror = tx("No se pudieron cargar los capítulos.");
      drawepisodes();
    }
    return;
  }
  if ((m.serinfo == null)) {
    m.serinfo = {__proto__: $AAP};
  }
  if ((r.info != null)) {
    $six(m.serinfo, xtserid(ser), r.info);
  }
  for (sn of $iter(r.seasons)) {
    season = ser.$createchild("ContentNode");
    season.id = sn.s.$tostr();
    season.title = (tx("Temporada ") + sn.s.$tostr());
    for (ep of $iter(sn.eps)) {
      item = season.$createchild("ContentNode");
      sr = 0;
      if (((m.favmap != null) && m.favmap.$doesexist(ep.u))) {
        sr = 100;
      }
      item.$setfields({__proto__: $AAP, "title": sereptitle(ser.title, sn.s, ep), "shortdescriptionline2": ep.t, "url": ep.u, "streamformat": ep.f, "hdposterurl": ep.l, "shortdescriptionline1": ep.e.$tostr(), "description": "movie", "starrating": sr});
      item.$addfields({__proto__: $AAP, "epplot": ep.p, "epdur": ep.d});
    }
  }
  if ((((m.mode === "episodes") && (m.epseries != null)) && m.epseries.$issamenode(ser))) {
    m.eploading = false;
    drawepisodes();
  }
}
// ---- components/vodsearch.brs ----
function letterof(t) {
  let n, i, $e0, a;
  if ((t == null)) {
    return "#";
  }
  n = $len(t);
  if ((n > 16)) {
    n = 16;
  }
  for (i = 1, $e0 = n; i <= $e0; i++) {
    a = $asc($mid(t, i, 1));
    if (((a >= 97) && (a <= 122))) {
      return $chr((a - 32));
    }
    if (((a >= 65) && (a <= 90))) {
      return $chr(a);
    }
    if (((a >= 48) && (a <= 57))) {
      return "#";
    }
    if (((((a === 225) || (a === 193)) || (a === 224)) || (a === 192))) {
      return "A";
    }
    if (((((a === 233) || (a === 201)) || (a === 232)) || (a === 200))) {
      return "E";
    }
    if (((a === 237) || (a === 205))) {
      return "I";
    }
    if (((a === 243) || (a === 211))) {
      return "O";
    }
    if (((((a === 250) || (a === 218)) || (a === 252)) || (a === 220))) {
      return "U";
    }
    if (((a === 241) || (a === 209))) {
      return "N";
    }
  }
  return "#";
}

function letterjump(cat, idx, dir) {
  let total, cur, i, $e1, start, prev;
  total = cat.$getchildcount();
  if ((total === 0)) {
    return 0;
  }
  cur = letterof(cat.$getchild(idx).title);
  if ((dir > 0)) {
    for (i = (idx + 1), $e1 = (total - 1); i <= $e1; i++) {
      if ((letterof(cat.$getchild(i).title) !== cur)) {
        return i;
      }
    }
    return (total - 1);
  }
  start = idx;
  while (((start > 0) && (letterof(cat.$getchild((start - 1)).title) === cur))) {
    start = (start - 1);
  }
  if ((start < idx)) {
    return start;
  }
  if ((start === 0)) {
    return 0;
  }
  prev = letterof(cat.$getchild((start - 1)).title);
  i = (start - 1);
  while (((i > 0) && (letterof(cat.$getchild((i - 1)).title) === prev))) {
    i = (i - 1);
  }
  return i;
}

function vsletters() {
  return ["#", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];
}

function lettermapfor(cat) {
  let n, map, i, $e2, l;
  n = cat.$getchildcount();
  if (((m.lmcat != null) && (m.lmcount === n))) {
    if (m.lmcat.$issamenode(cat)) {
      return m.lmmap;
    }
  }
  map = {__proto__: $AAP};
  for (i = 0, $e2 = (n - 1); i <= $e2; i++) {
    l = letterof(cat.$getchild(i).title);
    if ((!map.$doesexist(l))) {
      $six(map, l, i);
    }
  }
  m.lmcat = cat;
  m.lmcount = n;
  m.lmmap = map;
  return map;
}

function drawmoviebar(cat, total) {
  let focus0, focus1, cur, nm, info;
  clearnode(m.moviebar);
  focus0 = (((m.movside === "bar") && (m.baridx === 0)));
  focus1 = (((m.movside === "bar") && (m.baridx === 1)));
  vsbutton(0, 230, "pkg:/images/ico_search_s.png", tx("Buscar"), focus0);
  cur = "-";
  if ((((total > 0) && (m.movidx >= 0)) && (m.movidx < total))) {
    cur = letterof(cat.$getchild(m.movidx).title);
  }
  vsbutton(246, 200, "", (tx("Letra: ") + cur), focus1);
  if ((cat != null)) {
    nm = cat.id;
    if (((nm == null) || (nm === ""))) {
      nm = cat.title;
    }
    info = (((cleancatname(nm) + "   ·   ") + total.$tostr()) + tx(" títulos"));
    addlabel(m.moviebar, 466, 6, 474, fittext(info, 470), "0xFFFFFFFF", "font:SmallBoldSystemFont");
  }
}

function vsbutton(x, w, icon, text, focused) {
  let bg, fg, tx0;
  bg = "0xFFFFFF14";
  fg = "0xC8CCD2FF";
  if (focused) {
    bg = "0xFF8A2440";
    fg = "0xFF8A24FF";
    addrect(m.moviebar, x, 38, w, 3, "0xFF8A24FF");
  }
  addrect(m.moviebar, x, 0, w, 38, bg);
  tx0 = (x + 14);
  if ((icon !== "")) {
    addposter(m.moviebar, (x + 12), 6, 26, 26, icon);
    tx0 = (x + 48);
  }
  addlabel(m.moviebar, tx0, 5, ((w - ((tx0 - x))) - 8), text, fg, "font:SmallBoldSystemFont");
}

function barkey(key) {
  if ((key === "left")) {
    if ((m.baridx === 1)) {
      m.baridx = 0;
    } else {
      m.movside = "cats";
    }
  } else if ((key === "right")) {
    if ((m.baridx === 0)) {
      m.baridx = 1;
    }
  } else if ((key === "down")) {
    m.movside = "grid";
  } else if (((((key === "up") && (((m.mode === "movies") || (m.mode === "series")))) && (m.cwlist != null)) && (m.cwlist.$count() > 0))) {
    m.movside = "cw";
  } else if ((key === "back")) {
    m.movside = "cats";
  } else if ((key === "OK")) {
    if ((m.baridx === 0)) {
      vsopen();
      return true;
    } else {
      pickopen();
      return true;
    }
  }
  drawmovies();
  return true;
}

function pickopen() {
  let cat, cur, ls, i, $e3;
  cat = m.vodroot.$getchild(m.movcat);
  if (((cat == null) || (cat.$getchildcount() === 0))) {
    return;
  }
  m.movpick = true;
  cur = "#";
  if (((m.movidx >= 0) && (m.movidx < cat.$getchildcount()))) {
    cur = letterof(cat.$getchild(m.movidx).title);
  }
  m.pickidx = 0;
  ls = vsletters();
  for (i = 0, $e3 = (ls.$count() - 1); i <= $e3; i++) {
    if (($ix(ls, i) === cur)) {
      m.pickidx = i;
    }
  }
  drawmovies();
}

function drawpicker(cat) {
  let map, ls, cols, cw, ch, px, py, pw, ph, i, $e4, x, y, has, color, lb;
  clearnode(m.movieoverlay);
  map = lettermapfor(cat);
  ls = vsletters();
  cols = 9;
  cw = 70;
  ch = 62;
  px = 360;
  py = 150;
  pw = ((cols * cw) + 40);
  ph = ((3 * ch) + 110);
  addrect(m.movieoverlay, (px - 4), (py - 4), (pw + 8), (ph + 8), "0xFF8A2466");
  addrect(m.movieoverlay, px, py, pw, ph, "0x101016F5");
  addlabel(m.movieoverlay, (px + 20), (py + 16), (pw - 40), tx("Ir a la letra"), "0xFFFFFFFF", "font:MediumBoldSystemFont");
  for (i = 0, $e4 = (ls.$count() - 1); i <= $e4; i++) {
    x = ((px + 20) + (((i % cols)) * cw));
    y = ((py + 64) + (($idiv(i, cols)) * ch));
    has = map.$doesexist($ix(ls, i));
    color = "0x5A5E66FF";
    if (has) {
      color = "0xFFFFFFFF";
    }
    if ((i === m.pickidx)) {
      addrect(m.movieoverlay, x, y, (cw - 8), (ch - 8), "0xFF8A24FF");
      color = "0x101016FF";
    } else if (has) {
      addrect(m.movieoverlay, x, y, (cw - 8), (ch - 8), "0xFFFFFF14");
    }
    lb = addlabel(m.movieoverlay, x, (y + 12), (cw - 8), $ix(ls, i), color, "font:MediumBoldSystemFont");
    lb.horizalign = "center";
  }
}

function pickkey(key) {
  let ls, n, cols, cat, map, target, i, $e5;
  ls = vsletters();
  n = ls.$count();
  cols = 9;
  if ((key === "back")) {
    m.movpick = false;
  } else if ((key === "left")) {
    if ((((m.pickidx % cols)) > 0)) {
      m.pickidx = (m.pickidx - 1);
    }
  } else if ((key === "right")) {
    if (((((m.pickidx % cols)) < (cols - 1)) && (m.pickidx < (n - 1)))) {
      m.pickidx = (m.pickidx + 1);
    }
  } else if ((key === "up")) {
    if (((m.pickidx - cols) >= 0)) {
      m.pickidx = (m.pickidx - cols);
    }
  } else if ((key === "down")) {
    if (((m.pickidx + cols) < n)) {
      m.pickidx = (m.pickidx + cols);
    }
  } else if ((key === "OK")) {
    cat = m.vodroot.$getchild(m.movcat);
    if (((cat != null) && (cat.$getchildcount() > 0))) {
      map = lettermapfor(cat);
      target = (-1);
      for (i = m.pickidx, $e5 = (n - 1); i <= $e5; i++) {
        if (map.$doesexist($ix(ls, i))) {
          target = $ix(map, $ix(ls, i));
          break;
        }
      }
      if ((target < 0)) {
        target = (cat.$getchildcount() - 1);
      }
      m.movidx = target;
      m.movside = "grid";
    }
    m.movpick = false;
  }
  drawmovies();
  return true;
}

function vskeys() {
  return ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"];
}

function vsopen() {
  m.vson = true;
  m.movpick = false;
  if ((m.vsquery == null)) {
    m.vsquery = "";
  }
  m.vsside = "kb";
  m.vsrow = 0;
  m.vscol = 0;
  m.vsresidx = 0;
  vsensureindex();
  vsrunquery();
  drawmovies();
}

function vsclose() {
  m.vson = false;
  m.movside = "grid";
  clearnode(m.movieoverlay);
  drawmovies();
}

function vsfold(t) {
  let s;
  if ((t == null)) {
    return "";
  }
  if ((m.vsrxna == null)) {
    m.vsrxna = $createobject("roRegex", "[^\\x00-\\x7F]", "");
    m.vsrxdel = $createobject("roRegex", (("['`\\\\" + $chr(34)) + "]"), "");
    m.vsrxsp = $createobject("roRegex", "[-_.:,;!?/()\\[\\]|+&]+", "");
  }
  s = $lcase(t);
  if (m.vsrxna.$ismatch(s)) {
    s = foldtext(s);
  }
  s = m.vsrxdel.$replaceall(s, "");
  s = m.vsrxsp.$replaceall(s, " ");
  return s;
}

function vsensureindex() {
  let root, i, $e6;
  root = m.vodroot;
  if ((root == null)) {
    return;
  }
  if ((((m.vsroot != null) && m.vsroot.$issamenode(root)) && (m.vsmode === m.mode))) {
    return;
  }
  m.vsroot = root;
  m.vsmode = m.mode;
  m.vsf = [];
  m.vsc = [];
  m.vsi = [];
  m.vsbc = 0;
  m.vsbi = 0;
  m.vsbcat = null;
  m.vsdone = false;
  m.vsqcache = {__proto__: $AAP};
  m.vstotal = 0;
  for (i = 0, $e6 = (root.$getchildcount() - 1); i <= $e6; i++) {
    m.vstotal = (m.vstotal + root.$getchild(i).$getchildcount());
  }
  if ((m.vstotal === 0)) {
    m.vsdone = true;
    return;
  }
  m.vstimer.control = "start";
}

function onvstick() {
  let root, ts, nc, cnt, k;
  root = m.vsroot;
  if (((root == null) || m.vsdone)) {
    m.vstimer.control = "stop";
    return;
  }
  ts = $createobject("roTimespan");
  nc = root.$getchildcount();
  while ((ts.$totalmilliseconds() < 45)) {
    if ((m.vsbc >= nc)) {
      m.vsdone = true;
      break;
    }
    if ((m.vsbcat == null)) {
      m.vsbcat = root.$getchild(m.vsbc);
    }
    cnt = m.vsbcat.$getchildcount();
    k = 0;
    while (((m.vsbi < cnt) && (k < 25))) {
      m.vsf.$push(vsfold(m.vsbcat.$getchild(m.vsbi).title));
      m.vsc.$push(m.vsbc);
      m.vsi.$push(m.vsbi);
      m.vsbi = (m.vsbi + 1);
      k = (k + 1);
    }
    if ((m.vsbi >= cnt)) {
      m.vsbc = (m.vsbc + 1);
      m.vsbi = 0;
      m.vsbcat = null;
    }
  }
  if (m.vsdone) {
    m.vstimer.control = "stop";
    m.vsqcache = {__proto__: $AAP};
    if ((m.vson && ((((m.mode === "movies") || (m.mode === "series")) || (m.mode === "adult"))))) {
      vsrunquery();
      drawmovies();
    }
  } else if ((m.vson && (m.vshdr != null))) {
    m.vshdr.text = vsheadertext();
  }
}

function vsrunquery() {
  let q, c, tokens, t, t0, l0, cand, best, k, ck, found, all, n, j, $e7, p, f, ok, score;
  q = vsfold(m.vsquery).$trim();
  m.vscapped = false;
  if (((q === "") || (m.vsf == null))) {
    m.vsresults = [];
    return;
  }
  if ((m.vsdone && m.vsqcache.$doesexist(q))) {
    c = $ix(m.vsqcache, q);
    m.vsresults = c.res;
    m.vscapped = c.capped;
    return;
  }
  tokens = [];
  for (t of $iter(q.$split(" "))) {
    if ((t !== "")) {
      tokens.$push(t);
    }
  }
  t0 = $ix(tokens, 0);
  l0 = $len(t0);
  cand = null;
  if (m.vsdone) {
    best = "";
    for (k of $iter(m.vsqcache)) {
      ck = $ix(m.vsqcache, k);
      if ((((!ck.capped) && ($len(k) > $len(best))) && ($left(q, $len(k)) === k))) {
        best = k;
      }
    }
    if ((best !== "")) {
      cand = $ix(m.vsqcache, best).all;
    }
  }
  found = [];
  all = [];
  if ((cand == null)) {
    n = m.vsf.$count();
  } else {
    n = cand.$count();
  }
  for (j = 0, $e7 = (n - 1); j <= $e7; j++) {
    if ((cand == null)) {
      p = j;
    } else {
      p = $ix(cand, j);
    }
    f = $ix(m.vsf, p);
    ok = true;
    for (t of $iter(tokens)) {
      if (($instr(1, f, t) === 0)) {
        ok = false;
        break;
      }
    }
    if (ok) {
      score = 2;
      if (($left(f, l0) === t0)) {
        score = 0;
      } else if (($instr(1, f, (" " + t0)) > 0)) {
        score = 1;
      }
      found.$push({__proto__: $AAP, "k": ((score * 10000000) + p), "p": p});
      all.$push(p);
      if ((found.$count() >= 2000)) {
        m.vscapped = true;
        break;
      }
    }
  }
  found.$sortby("k");
  m.vsresults = found;
  if (m.vsdone) {
    if ((m.vsqcache.$count() > 30)) {
      m.vsqcache = {__proto__: $AAP};
    }
    $six(m.vsqcache, q, {__proto__: $AAP, "res": found, "all": all, "capped": m.vscapped});
  }
}

function vsheadertext() {
  let pct, n, more;
  if (((!m.vsdone) && (m.vstotal > 0))) {
    pct = $int(((m.vsf.$count() * 100) / m.vstotal));
    return ((tx("Preparando la búsqueda... ") + pct.$tostr()) + "%");
  }
  if ((m.vsquery === "")) {
    return tx("Escribe con las flechas y OK: los resultados aparecen mientras escribes");
  }
  n = m.vsresults.$count();
  if ((n === 0)) {
    return ((tx("Sin resultados para \"") + m.vsquery) + $chr(34));
  }
  more = "";
  if (m.vscapped) {
    more = "+";
  }
  return ((((n.$tostr() + more) + tx(" resultados para \"")) + m.vsquery) + $chr(34));
}

function vsnode(r) {
  let cat;
  if ((m.vsroot == null)) {
    return null;
  }
  cat = m.vsroot.$getchild($ix(m.vsc, r.p));
  if ((cat == null)) {
    return null;
  }
  return cat.$getchild($ix(m.vsi, r.p));
}

function drawsearch() {
  let o, shown, keys, r, $e8, c, $e9, k, x, y, ison, bg, fg, lb, acts, a, $e10, scope, res, total, start, n, $e11, ix, item, focused, logo, nc, pages, pg, lp;
  clearnode(m.moviecats);
  clearnode(m.moviegrid);
  clearnode(m.moviebar);
  clearnode(m.movieoverlay);
  o = m.movieoverlay;
  addrect(o, 20, 66, 384, 44, "0xFFFFFF14");
  addrect(o, 20, 108, 384, 2, "0xFF8A24FF");
  addposter(o, 30, 75, 26, 26, "pkg:/images/ico_search_s.png");
  shown = m.vsquery;
  if (($len(shown) > 26)) {
    shown = ("..." + $right(shown, 25));
  }
  addlabel(o, 66, 74, 330, (shown + "_"), "0xFFFFFFFF", "font:MediumSystemFont");
  keys = vskeys();
  for (r = 0, $e8 = 5; r <= $e8; r++) {
    for (c = 0, $e9 = 5; c <= $e9; c++) {
      k = $ix(keys, ((r * 6) + c));
      x = (20 + (c * 64));
      y = (126 + (r * 56));
      ison = ((((m.vsside === "kb") && (m.vsrow === r)) && (m.vscol === c)));
      bg = "0xFFFFFF10";
      fg = "0xFFFFFFFF";
      if (ison) {
        bg = "0xFF8A24FF";
        fg = "0x101016FF";
      }
      addrect(o, x, y, 58, 50, bg);
      lb = addlabel(o, x, (y + 10), 58, $ucase(k), fg, "font:MediumBoldSystemFont");
      lb.horizalign = "center";
    }
  }
  acts = [tx("Espacio"), tx("Borrar"), tx("Limpiar")];
  for (a = 0, $e10 = 2; a <= $e10; a++) {
    x = (20 + (a * 128));
    y = (126 + (6 * 56));
    ison = ((((m.vsside === "kb") && (m.vsrow === 6)) && (($idiv(m.vscol, 2)) === a)));
    bg = "0xFFFFFF10";
    fg = "0xFFFFFFFF";
    if (ison) {
      bg = "0xFF8A24FF";
      fg = "0x101016FF";
    }
    addrect(o, x, y, 122, 50, bg);
    lb = addlabel(o, x, (y + 11), 122, $ix(acts, a), fg, "font:SmallBoldSystemFont");
    lb.horizalign = "center";
  }
  scope = tx("Películas");
  if ((m.mode === "series")) {
    scope = tx("Series");
  }
  addlabel(o, 20, ((126 + (7 * 56)) + 6), 384, (tx("Buscando en: ") + scope), "0xA8ADB5FF", "font:SmallSystemFont");
  m.vshdr = addlabel(o, 440, 72, 800, vsheadertext(), "0xFFFFFFFF", "font:SmallBoldSystemFont");
  res = m.vsresults;
  if ((res == null)) {
    res = [];
  }
  total = res.$count();
  if ((m.vsresidx >= total)) {
    m.vsresidx = (total - 1);
  }
  if ((m.vsresidx < 0)) {
    m.vsresidx = 0;
  }
  start = (($idiv(m.vsresidx, 8)) * 8);
  for (n = 0, $e11 = 7; n <= $e11; n++) {
    ix = (start + n);
    if ((ix >= total)) {
      break;
    }
    item = vsnode($ix(res, ix));
    favsync(item);
    if ((item != null)) {
      x = (440 + (((n % 4)) * 196));
      y = (116 + (($idiv(n, 4)) * 270));
      focused = (((m.vsside === "res") && (ix === m.vsresidx)));
      if (focused) {
        addrect(o, x, y, 180, 256, "0xFF8A24FF");
      }
      addrect(o, (x + 3), (y + 3), 174, 210, "0x1C1C24FF");
      logo = item.hdposterurl;
      if ((logo == null)) {
        logo = "";
      }
      coverposter(o, (x + 3), (y + 3), 174, 210, logo);
      if (((m.mode === "movies") && (item.starrating === 100))) {
        addposter(o, (x + 142), (y + 6), 32, 32, "pkg:/images/heart_on.png");
      }
      nc = "0xFFFFFFFF";
      if (focused) {
        nc = "0x101016FF";
      }
      addlabel(o, (x + 6), (y + 220), 168, fittext(cleantitle(item.title), 160), nc, "font:SmallSystemFont");
    }
  }
  if ((total > 8)) {
    pages = $idiv(((total + 7)), 8);
    pg = (((tx("Página ") + ((($idiv(m.vsresidx, 8)) + 1)).$tostr()) + " / ") + pages.$tostr());
    lp = addlabel(o, 440, 640, 776, pg, "0xA8ADB5FF", "font:SmallSystemFont");
    lp.horizalign = "right";
  }
  if ((m.vsside === "kb")) {
    m.moviehint.text = tx("Flechas + OK: escribir     Play: borrar     Derecha: resultados     Atrás: salir");
  } else if ((m.mode === "series")) {
    m.moviehint.text = tx("Flechas: mover     OK: ver temporadas     Izquierda: teclado     Atrás: teclado");
  } else if ((m.mode === "adult")) {
    m.moviehint.text = tx("Flechas: mover     OK: ver     Izquierda: teclado     Atrás: teclado");
  } else {
    m.moviehint.text = tx("Flechas: mover     OK: ver     Play: favorito     Izquierda: teclado     Atrás: teclado");
  }
}

function vstype(s) {
  if (($len(m.vsquery) >= 40)) {
    return;
  }
  m.vsquery = (m.vsquery + s);
  m.vsresidx = 0;
  vsrunquery();
}

function vsbackspace() {
  if (($len(m.vsquery) > 0)) {
    m.vsquery = $left(m.vsquery, ($len(m.vsquery) - 1));
  }
  m.vsresidx = 0;
  vsrunquery();
}

function vskey(key) {
  let total, atedge, kk, a, item;
  total = 0;
  if ((m.vsresults != null)) {
    total = m.vsresults.$count();
  }
  if ((m.vsside === "kb")) {
    if ((key === "back")) {
      vsclose();
      return true;
    } else if ((key === "up")) {
      if ((m.vsrow > 0)) {
        m.vsrow = (m.vsrow - 1);
      }
      if (((m.vsrow < 6) && (m.vscol > 5))) {
        m.vscol = 5;
      }
    } else if ((key === "down")) {
      if ((m.vsrow < 6)) {
        m.vsrow = (m.vsrow + 1);
      }
    } else if ((key === "left")) {
      if ((m.vsrow === 6)) {
        if ((m.vscol >= 2)) {
          m.vscol = ((($idiv(m.vscol, 2)) * 2) - 2);
        }
      } else if ((m.vscol > 0)) {
        m.vscol = (m.vscol - 1);
      }
    } else if ((key === "right")) {
      atedge = (((m.vscol >= 5)) || (((m.vsrow === 6) && (m.vscol >= 4))));
      if (atedge) {
        if ((total > 0)) {
          m.vsside = "res";
          m.vsresidx = (($idiv(m.vsresidx, 8)) * 8);
        }
      } else if ((m.vsrow === 6)) {
        m.vscol = ((($idiv(m.vscol, 2)) * 2) + 2);
      } else {
        m.vscol = (m.vscol + 1);
      }
    } else if ((key === "OK")) {
      if ((m.vsrow < 6)) {
        kk = vskeys();
        vstype($ix(kk, ((m.vsrow * 6) + m.vscol)));
      } else {
        a = $idiv(m.vscol, 2);
        if ((a === 0)) {
          if (((m.vsquery !== "") && ($right(m.vsquery, 1) !== " "))) {
            vstype(" ");
          }
        } else if ((a === 1)) {
          vsbackspace();
        } else {
          m.vsquery = "";
          m.vsresidx = 0;
          vsrunquery();
        }
      }
    } else if ((((key === "play") || (key === "rev")) || (key === "replay"))) {
      vsbackspace();
    }
    drawsearch();
    return true;
  }
  if ((key === "back")) {
    m.vsside = "kb";
  } else if ((key === "left")) {
    if ((((m.vsresidx % 4)) === 0)) {
      m.vsside = "kb";
    } else {
      m.vsresidx = (m.vsresidx - 1);
    }
  } else if ((key === "right")) {
    if ((m.vsresidx < (total - 1))) {
      m.vsresidx = (m.vsresidx + 1);
    }
  } else if ((key === "up")) {
    if (((m.vsresidx - 4) >= 0)) {
      m.vsresidx = (m.vsresidx - 4);
    }
  } else if ((key === "down")) {
    if (((m.vsresidx + 4) < total)) {
      m.vsresidx = (m.vsresidx + 4);
    } else if ((($idiv(m.vsresidx, 8)) < ($idiv(((total - 1)), 8)))) {
      m.vsresidx = (total - 1);
    }
  } else if ((key === "OK")) {
    if (((m.vsresidx >= 0) && (m.vsresidx < total))) {
      item = vsnode($ix(m.vsresults, m.vsresidx));
      if ((item != null)) {
        vodopen(item);
        return true;
      }
    }
  } else if ((key === "play")) {
    if ((((m.mode === "movies") && (m.vsresidx >= 0)) && (m.vsresidx < total))) {
      item = vsnode($ix(m.vsresults, m.vsresidx));
      if ((item != null)) {
        togglefavorite(item);
      }
    }
  }
  drawsearch();
  return true;
}
// ---- components/detail.brs ----
function joinarr(a, sep) {
  let out, v;
  out = "";
  for (v of $iter(a)) {
    if ((out !== "")) {
      out = (out + sep);
    }
    out = (out + v);
  }
  return out;
}

function cleancatname(s) {
  let t, n, i, a, isalnum, yr, close, rest;
  if ((s == null)) {
    return "";
  }
  s = cleanglyphs(s);
  t = s.$trim();
  n = $len(t);
  i = 1;
  while ((i <= n)) {
    a = $asc($mid(t, i, 1));
    isalnum = ((((((a >= 48) && (a <= 57))) || (((a >= 65) && (a <= 90)))) || (((a >= 97) && (a <= 122)))) || (((a >= 192) && (a <= 591))));
    if (((isalnum || (a === 40)) || (a === 91))) {
      break;
    }
    i = (i + 1);
  }
  if ((i > n)) {
    return s.$trim();
  }
  t = $mid(t, i).$trim();
  if ((($len(t) > 7) && ((($left(t, 1) === "(") || ($left(t, 1) === "["))))) {
    yr = $mid(t, 2, 4);
    close = $mid(t, 6, 1);
    if ((((((close === ")") || (close === "]"))) && ($val(yr) >= 1900)) && ($val(yr) <= 2100))) {
      rest = $mid(t, 7).$trim();
      if ((($len(rest) > 0) && ($instr(1, "-|:*", $left(rest, 1)) > 0))) {
        rest = $mid(rest, 2).$trim();
      }
      if ((rest !== "")) {
        t = ((yr + " · ") + rest);
      }
    }
  }
  if ((($left(t, 1) === "(") || ($left(t, 1) === "["))) {
    t = $mid(t, 2);
  }
  t = t.$replace(" | ", " · ").$replace("|", " ").$trim();
  while ((($len(t) > 1) && ($instr(1, "*-_.:|#~+", $right(t, 1)) > 0))) {
    t = $left(t, ($len(t) - 1)).$trim();
  }
  t = t.$replace("*", "").$trim();
  return smartcase(t);
}

function smartcase(t) {
  let keep, out, w;
  if ((($lcase(t) === t) || ($ucase(t) !== t))) {
    return t;
  }
  keep = {__proto__: $AAP, "4k": 1, "uhd": 1, "hd": 1, "fhd": 1, "sd": 1, "tv": 1, "vip": 1, "hdr": 1, "3d": 1, "usa": 1, "uk": 1, "mx": 1, "lat": 1, "vod": 1, "dc": 1, "hbo": 1, "amc": 1, "tnt": 1, "espn": 1, "xxx": 1};
  out = [];
  for (w of $iter(t.$split(" "))) {
    if ((((w === "") || keep.$doesexist(w)) || ($instr(1, "0123456789", $left(w, 1)) > 0))) {
      out.$push(w);
    } else {
      out.$push(($ucase($left(w, 1)) + $lcase($mid(w, 2))));
    }
  }
  return joinarr(out, " ");
}

function splittitle(raw) {
  let t, tags, year, guard, p, i, $e0, inner;
  t = raw.$replace("\\", "").$trim();
  if (($instr(1, t, "&") > 0)) {
    t = decodeentities(t);
  }
  tags = [];
  year = "";
  guard = 0;
  while ((($right(t, 1) === ")") && (guard < 4))) {
    guard = (guard + 1);
    p = 0;
    for (i = $len(t), $e0 = 1; i >= $e0; i--) {
      if (($mid(t, i, 1) === "(")) {
        p = i;
        break;
      }
    }
    if ((p <= 1)) {
      break;
    }
    inner = $mid(t, (p + 1), (($len(t) - p) - 1)).$trim();
    if (((($len(inner) === 4) && ($val(inner) >= 1900)) && ($val(inner) <= 2100))) {
      year = inner;
    } else if ((inner !== "")) {
      tags.$unshift(inner);
    }
    t = $left(t, (p - 1)).$trim();
  }
  if ((t === "")) {
    t = raw;
  }
  return {__proto__: $AAP, "t": t, "tags": joinarr(tags, " "), "year": year};
}

function cleantitle(raw) {
  return cleanglyphs(splittitle(raw).t);
}

function audiolabel(tags) {
  let map, rx, out, w;
  if ((tags === "")) {
    return "";
  }
  map = {__proto__: $AAP, "lat": "Latino", "latino": "Latino", "esp": "Español", "es": "Español", "cast": "Castellano", "castellano": "Castellano", "eng": "Inglés", "ing": "Inglés", "en": "Inglés", "sub": "Subtitulado", "subt": "Subtitulado", "vose": "Subtitulado", "dual": "Dual", "jap": "Japonés", "por": "Portugués", "fr": "Francés"};
  rx = $createobject("roRegex", "[/,\\-\\s\\+]+", "");
  out = [];
  for (w of $iter(rx.$split($lcase(tags)))) {
    if ((w !== "")) {
      if (map.$doesexist(w)) {
        out.$push(tx($ix(map, w)));
      } else {
        out.$push($ucase(w));
      }
    }
  }
  return joinarr(out, " · ");
}

function showdetail(item, backto) {
  let xt, t;
  if ((item == null)) {
    return;
  }
  favsync(item);
  m.dtitem = item;
  m.dtback = backto;
  m.dtbtn = 0;
  m.dtinfo = null;
  m.dtloading = false;
  dtbuildbackground();
  xt = vodxtfromurl(item.url);
  if ((xt != null)) {
    m.dtloading = true;
    t = $createobject("roSGNode", "XtreamReader");
    t.op = "vodinfo";
    t.host = xt.host;
    t.user = xt.user;
    t.pass = xt.pass;
    t.serid = xt.id;
    m.dttask = t;
    t.$observefield("result", "onDetailInfo");
    t.control = "RUN";
  }
  reshowdetail();
}

function reshowdetail() {
  m.mode = "detail";
  hidepanels();
  setbgfrozen(true);
  m.topbar.visible = false;
  m.detailpanel.visible = true;
  drawdetail();
  capturekeys();
}

function vodxtfromurl(u) {
  let rx, r;
  if (((u == null) || (u === ""))) {
    return null;
  }
  rx = $createobject("roRegex", "^(https?://[^/]+)/movie/([^/]+)/([^/]+)/(\\d+)\\.\\w+", "i");
  r = rx.$match(u);
  if ((r.$count() < 5)) {
    return null;
  }
  return {__proto__: $AAP, "host": $ix(r, 1), "user": $ix(r, 2), "pass": $ix(r, 3), "id": $ix(r, 4)};
}

function ondetailinfo() {
  let r;
  if ((m.dttask == null)) {
    return;
  }
  r = m.dttask.result;
  m.dtloading = false;
  if (((r != null) && (r.ok === true))) {
    m.dtinfo = r;
  }
  if ((m.mode === "detail")) {
    drawdetail();
  }
}

function dtstr(key) {
  let v;
  if ((m.dtinfo == null)) {
    return "";
  }
  if ((!m.dtinfo.$doesexist(key))) {
    return "";
  }
  v = $ix(m.dtinfo, key);
  if ((v == null)) {
    return "";
  }
  return v;
}

function dtfont(size, weight) {
  let k, f;
  if ((m.dtfonts == null)) {
    m.dtfonts = {__proto__: $AAP};
  }
  k = (weight + size.$tostr());
  if ((!m.dtfonts.$doesexist(k))) {
    f = $createobject("roSGNode", "Font");
    f.uri = (("pkg:/fonts/Inter-" + weight) + ".ttf");
    f.size = size;
    $six(m.dtfonts, k, f);
  }
  return $ix(m.dtfonts, k);
}

function dttext(parent, x, y, w, text, color, size, weight) {
  let l;
  l = $createobject("roSGNode", "Label");
  l.translation = [x, y];
  if ((w > 0)) {
    l.width = w;
  }
  l.text = text;
  l.color = color;
  l.font = dtfont(size, weight);
  parent.$appendchild(l);
  return l;
}

function dtw(l) {
  let r;
  r = l.$boundingrect();
  return $int(r.width);
}

function dtbox(parent, x, y, w, h, uri, color, alpha) {
  let p;
  p = $createobject("roSGNode", "Poster");
  p.translation = [x, y];
  p.width = w;
  p.height = h;
  p.uri = uri;
  p.blendcolor = color;
  p.opacity = alpha;
  parent.$appendchild(p);
  return p;
}

function dtphoto(parent, x, y, w, h, uri) {
  return dtfullimage(parent, x, y, w, h, uri, "scaleToZoom");
}

function dtfullimage(parent, x, y, w, h, uri, mode = "scaleToFill") {
  let p;
  p = $createobject("roSGNode", "Poster");
  p.translation = [x, y];
  p.width = w;
  p.height = h;
  p.loadwidth = w;
  p.loadheight = h;
  p.loaddisplaymode = mode;
  p.uri = uri;
  parent.$appendchild(p);
  return p;
}

function fmtduration(d) {
  let mins, parts, h, mm;
  if ((d === "")) {
    return "";
  }
  mins = 0;
  parts = d.$split(":");
  if ((parts.$count() >= 2)) {
    mins = (($int($val($ix(parts, 0))) * 60) + $int($val($ix(parts, 1))));
  } else {
    mins = $int($val(d));
  }
  if ((mins <= 0)) {
    return "";
  }
  h = $idiv(mins, 60);
  mm = (mins % 60);
  if ((h === 0)) {
    return (mm.$tostr() + " min");
  }
  if ((mm === 0)) {
    return (h.$tostr() + " h");
  }
  return (((h.$tostr() + " h ") + mm.$tostr()) + " min");
}

function fmtrating(rt) {
  let r, n;
  r = $val(rt);
  if ((r <= 0)) {
    return "";
  }
  if ((r > 10)) {
    r = (r / 10);
  }
  n = $int(((r * 10) + 0.5));
  return ((($idiv(n, 10)).$tostr() + ".") + ((n % 10)).$tostr());
}

function fmtgenres(g) {
  let lang, es, out, rx, w;
  if ((g === "")) {
    return "";
  }
  lang = "";
  if (((m.global != null) && (m.global.lang != null))) {
    lang = m.global.lang;
  }
  es = {__proto__: $AAP, "action": "Acción", "adventure": "Aventura", "animation": "Animación", "comedy": "Comedia", "crime": "Crimen", "documentary": "Documental", "drama": "Drama", "family": "Familiar", "fantasy": "Fantasía", "history": "Historia", "horror": "Terror", "music": "Música", "mystery": "Misterio", "romance": "Romance", "science fiction": "Ciencia ficción", "sci-fi": "Ciencia ficción", "thriller": "Suspenso", "war": "Bélica", "western": "Western", "tv movie": "Película de TV", "biography": "Biografía", "sport": "Deporte", "musical": "Musical", "kids": "Infantil", "action & adventure": "Acción y aventura", "sci-fi & fantasy": "Ciencia ficción y fantasía", "war & politics": "Bélica y política"};
  out = [];
  rx = $createobject("roRegex", "\\s*[,/|]\\s*", "");
  for (w of $iter(rx.$split(g))) {
    w = w.$trim();
    if ((w !== "")) {
      if (((lang === "es") && es.$doesexist($lcase(w)))) {
        w = $ix(es, $lcase(w));
      }
      out.$push(w);
    }
    if ((out.$count() >= 3)) {
      break;
    }
  }
  return joinarr(out, "  ·  ");
}

function firstnames(s, n) {
  let out, w;
  out = [];
  for (w of $iter(s.$split(","))) {
    w = w.$trim();
    if ((w !== "")) {
      out.$push(w);
    }
    if ((out.$count() >= n)) {
      break;
    }
  }
  return joinarr(out, ", ");
}

function dtbuildbackground() {
  let p, bgl, an, fi;
  p = m.detailpanel;
  clearnode(p);
  bgl = p.$createchild("Group");
  addrect(bgl, 0, 0, 1280, 720, "0x0A0A0FFF");
  m.dtimgslot = bgl.$createchild("Group");
  dtfullimage(bgl, 0, 0, 1280, 720, "pkg:/images/grad_left.png");
  dtfullimage(bgl, 0, 0, 1280, 720, "pkg:/images/grad_bottom.png");
  dtfullimage(bgl, 0, 0, 1280, 160, "pkg:/images/grad_top.png");
  an = bgl.$createchild("Animation");
  an.duration = 0.6;
  an.easefunction = "outQuad";
  fi = an.$createchild("FloatFieldInterpolator");
  fi.key = [0.0, 1.0];
  fi.keyvalue = [0.0, 1.0];
  fi.fieldtointerp = "dtImg.opacity";
  m.dtfadeanim = an;
  m.dtimguri = "";
  m.detailbody = p.$createchild("Group");
}

function dtupdatebackground() {
  let item, back, poster;
  item = m.dtitem;
  if ((item == null)) {
    return;
  }
  back = dtstr("backdrop");
  if ((back !== "")) {
    dtsetimage(back, "full");
  } else if ((!m.dtloading)) {
    poster = item.hdposterurl;
    if (((poster == null) || (poster === ""))) {
      poster = dtstr("poster");
    }
    if ((poster !== "")) {
      dtsetimage(poster, "side");
    }
  }
}

function dtsetimage(uri, mode) {
  let img;
  if ((uri === m.dtimguri)) {
    return;
  }
  m.dtimguri = uri;
  m.dtimgmode = mode;
  clearnode(m.dtimgslot);
  if ((mode === "full")) {
    img = dtphoto(m.dtimgslot, 0, 0, 1280, 720, uri);
  } else {
    img = dtphoto(m.dtimgslot, 560, 0, 720, 720, uri);
  }
  img.id = "dtImg";
  img.opacity = 0;
  img.$observefield("loadStatus", "onDtImgStatus");
  m.dtimg = img;
  if ((img.loadstatus === "ready")) {
    ondtimgstatus();
  }
}

function ondtimgstatus() {
  let img, st, target, poster;
  img = m.dtimg;
  if ((img == null)) {
    return;
  }
  st = img.loadstatus;
  if ((st === "ready")) {
    img.$unobservefield("loadStatus");
    target = 1.0;
    if ((m.dtimgmode === "side")) {
      target = 0.6;
    }
    m.dtfadeanim.control = "stop";
    m.dtfadeanim.$getchild(0).fieldtointerp = "dtImg.opacity";
    m.dtfadeanim.$getchild(0).keyvalue = [0.0, target];
    m.dtfadeanim.control = "start";
  } else if ((st === "failed")) {
    img.$unobservefield("loadStatus");
    if ((m.dtimgmode === "full")) {
      poster = m.dtitem.hdposterurl;
      if (((poster != null) && (poster !== ""))) {
        dtsetimage(poster, "side");
      }
    }
  }
}

function drawdetail() {
  let b, item, st, lg, x, w, kind, tl, th, y, cx, yr, d, first, items, du, it, dot, lb, rt, chip, rl, au, a, txt, tmp, tw, al, gn, plot, pl, ph, cast, k1, dir, hint;
  b = m.detailbody;
  clearnode(b);
  item = m.dtitem;
  if ((item == null)) {
    return;
  }
  dtupdatebackground();
  st = splittitle(item.title);
  lg = addposter(b, 64, 40, 150, 40, "pkg:/images/logo_small.png");
  lg.loaddisplaymode = "scaleToFit";
  x = 64;
  w = 640;
  kind = tx("PELÍCULA");
  dttext(b, x, 200, w, kind, "0xFF8A24FF", 16, "Bold");
  tl = dttext(b, x, 224, w, st.t, "0xFFFFFFFF", 46, "Bold");
  tl.wrap = true;
  tl.maxlines = 2;
  th = $int(tl.$boundingrect().height);
  if ((th < 50)) {
    th = 56;
  }
  if ((th > 120)) {
    th = 112;
  }
  y = ((224 + th) + 10);
  cx = x;
  yr = st.year;
  d = dtstr("date");
  if (((yr === "") && ($len(d) >= 4))) {
    yr = $left(d, 4);
  }
  first = true;
  items = [];
  if ((yr !== "")) {
    items.$push({__proto__: $AAP, "t": yr, "c": "0xE6E8EBFF"});
  }
  du = fmtduration(dtstr("duration"));
  if ((du !== "")) {
    items.$push({__proto__: $AAP, "t": du, "c": "0xE6E8EBFF"});
  }
  for (it of $iter(items)) {
    if ((!first)) {
      dot = dttext(b, cx, y, 0, "•", "0x80858CFF", 20, "Regular");
      cx = ((cx + dtw(dot)) + 12);
    }
    lb = dttext(b, cx, y, 0, it.t, it.c, 20, "SemiBold");
    cx = ((cx + dtw(lb)) + 12);
    first = false;
  }
  rt = fmtrating(dtstr("rating"));
  if ((rt !== "")) {
    if ((!first)) {
      cx = (cx + 6);
    }
    chip = dtbox(b, cx, (y - 3), 84, 30, "pkg:/images/rr_pill.9.png", "0xFF8A24FF", 1.0);
    rl = dttext(b, cx, y, 84, ("★ " + rt), "0x101016FF", 18, "Bold");
    rl.horizalign = "center";
    cx = (cx + 96);
  }
  au = audiolabel(st.tags);
  if ((au !== "")) {
    for (a of $iter(au.$split(" · "))) {
      txt = $ucase(a);
      tmp = dttext(b, (-2000), 0, 0, txt, "0xFFFFFFFF", 14, "SemiBold");
      tw = (dtw(tmp) + 22);
      b.$removechild(tmp);
      if (((cx + tw) > 1200)) {
        break;
      }
      dtbox(b, cx, (y - 2), tw, 28, "pkg:/images/rr_line.9.png", "0xFFFFFFFF", 0.55);
      al = dttext(b, cx, (y + 3), tw, txt, "0xFFFFFFFF", 14, "SemiBold");
      al.horizalign = "center";
      cx = ((cx + tw) + 8);
    }
  }
  y = (y + 40);
  gn = fmtgenres(dtstr("genre"));
  if ((gn !== "")) {
    dttext(b, x, y, w, gn, "0xC8CCD2FF", 19, "Regular");
    y = (y + 36);
  }
  plot = dtstr("plot");
  if ((plot === "")) {
    if (m.dtloading) {
      plot = tx("Cargando información...");
    } else {
      plot = tx("Esta lista no trae sinopsis para este título.");
    }
  }
  pl = dttext(b, x, y, w, plot, "0xE4E6EAFF", 20, "Regular");
  pl.wrap = true;
  pl.maxlines = 4;
  pl.linespacing = 4;
  ph = $int(pl.$boundingrect().height);
  if ((ph < 24)) {
    ph = 112;
  }
  if ((ph > 130)) {
    ph = 130;
  }
  y = ((y + ph) + 18);
  cast = firstnames(dtstr("cast"), 4);
  if (((cast !== "") && (y < 540))) {
    k1 = dttext(b, x, y, 120, tx("Reparto"), "0x80858CFF", 17, "SemiBold");
    dttext(b, (x + 100), y, (w - 100), fittext(cast, 520), "0xD0D4DAFF", 17, "Regular");
    y = (y + 28);
  }
  dir = firstnames(dtstr("director"), 2);
  if (((dir !== "") && (y < 562))) {
    dttext(b, x, y, 120, tx("Dirección"), "0x80858CFF", 17, "SemiBold");
    dttext(b, (x + 100), y, (w - 100), fittext(dir, 520), "0xD0D4DAFF", 17, "Regular");
  }
  m.dtbtns = b.$createchild("Group");
  drawdetailbuttons();
  hint = dttext(b, 64, 672, 1150, ((tx("Atrás: volver") + "      ·      ") + tx("En el video: OK > Idioma o Subtítulos")), "0x6E737AFF", 15, "Regular");
}

function drawdetailbuttons() {
  let g, item, isfav, f0, bc, ba, tc, l0, f1, favtxt, icon, l1;
  g = m.dtbtns;
  if ((g == null)) {
    return;
  }
  clearnode(g);
  item = m.dtitem;
  isfav = ((item.starrating === 100));
  f0 = ((m.dtbtn === 0));
  bc = "0xFFFFFFFF";
  ba = 0.2;
  tc = "0xFFFFFFFF";
  if (f0) {
    ba = 1.0;
    tc = "0x0A0A0FFF";
  }
  dtbox(g, 64, 590, 230, 58, "pkg:/images/rr_fill.9.png", bc, ba);
  l0 = dttext(g, 64, 604, 230, ("▶   " + tx("Reproducir")), tc, 21, "SemiBold");
  l0.horizalign = "center";
  f1 = ((m.dtbtn === 1));
  ba = 0.2;
  tc = "0xFFFFFFFF";
  if (f1) {
    ba = 1.0;
    tc = "0x0A0A0FFF";
  }
  favtxt = tx("Mi lista");
  if (isfav) {
    favtxt = tx("En mi lista");
  }
  dtbox(g, 310, 590, 230, 58, "pkg:/images/rr_fill.9.png", bc, ba);
  icon = "pkg:/images/heart_off.png";
  if (isfav) {
    icon = "pkg:/images/heart_on.png";
  }
  addposter(g, 340, 604, 30, 30, icon);
  l1 = dttext(g, 380, 604, 150, favtxt, tc, 21, "SemiBold");
}

function detailkey(key) {
  let item;
  item = m.dtitem;
  if ((key === "back")) {
    leavedetail();
  } else if ((key === "left")) {
    m.dtbtn = 0;
    drawdetailbuttons();
  } else if ((key === "right")) {
    m.dtbtn = 1;
    drawdetailbuttons();
  } else if ((key === "OK")) {
    if ((m.dtbtn === 0)) {
      playnode(item, "detail");
    } else {
      togglefavorite(item);
      drawdetailbuttons();
    }
  } else if ((key === "play")) {
    playnode(item, "detail");
  }
  return true;
}

function leavedetail() {
  m.detailpanel.visible = false;
  if ((m.dtback === "favs")) {
    showfavs();
  } else if ((m.dtback === "home")) {
    showhome();
  } else if ((m.dtback === "adult")) {
    showadult();
  } else {
    showmovies();
  }
}
// ---- components/home.brs ----
function homeinit() {
  m.hminit = true;
  m.heroa = m.top.$findnode("heroA");
  m.herob = m.top.$findnode("heroB");
  m.herotext = m.top.$findnode("heroText");
  m.herobtns = m.top.$findnode("heroBtns");
  m.homebody = m.top.$findnode("homeBody");
  m.herofade = m.top.$findnode("heroFade");
  m.herofadein = m.top.$findnode("heroFadeIn");
  m.herofadeout = m.top.$findnode("heroFadeOut");
  m.herotextfade = m.top.$findnode("heroTextFade");
  m.feattimer = m.top.$findnode("featTimer");
  m.feattimer.$observefield("fire", "onFeatTimer");
  m.herofront = null;
  m.heropending = null;
  m.herocururi = "";
  m.heropendingmode = "full";
  m.featrequrl = "";
  if ((m.catalogready == null)) {
    m.catalogready = false;
  }
  m.feat = [];
  m.featidx = 0;
  m.featinfo = {__proto__: $AAP};
  m.featbusy = false;
  m.hz = "hero";
  m.hi = 0;
  m.lasttile = 0;
  m.lastutil = 0;
  if ((m.homeindex === 7)) {
    m.hz = "tiles";
    m.hi = 1;
  }
  m.loadpct = 0;
  m.featfromcatalog = false;
  homeloadfeat();
}

function hometiles() {
  return [{__proto__: $AAP, "t": tx("En vivo"), "ic": "ic_live", "a": "live"}, {__proto__: $AAP, "t": tx("Películas"), "ic": "ic_movies", "a": "movies"}, {__proto__: $AAP, "t": tx("Series"), "ic": "ic_series", "a": "series"}, {__proto__: $AAP, "t": tx("Favoritos"), "ic": "ic_heart", "a": "favs"}, {__proto__: $AAP, "t": tx("Buscar"), "ic": "ic_search", "a": "search"}, {__proto__: $AAP, "t": tx("Mosaico"), "ic": "ic_mosaic", "a": "mosaic"}];
}

function homeutils() {
  let u;
  u = [{__proto__: $AAP, "t": tx("Mis listas"), "ic": "ic_list", "a": "lists"}, {__proto__: $AAP, "t": tx("Cargar con QR"), "ic": "ic_qr", "a": "qr"}, {__proto__: $AAP, "t": "Xtream", "ic": "ic_xtream", "a": "xtream"}, {__proto__: $AAP, "t": tx("Actualizar"), "ic": "ic_refresh", "a": "reload"}, {__proto__: $AAP, "t": tx("Acerca de"), "ic": "ic_info", "a": "about"}, {__proto__: $AAP, "t": tx("Control parental"), "ic": "ic_lock", "a": "parental"}];
  if (pcadulton()) {
    u.$push({__proto__: $AAP, "t": tx("Adultos"), "ic": "ic_18", "a": "adult"});
  }
  u.$push({__proto__: $AAP, "t": "", "lab": tx("Apoya el proyecto"), "ic": "ic_heart", "a": "support"});
  return u;
}

function homeenter() {
  if ((m.hminit !== true)) {
    homeinit();
  }
  if ((m.feat.$count() === 0)) {
    homepickfeatures();
  }
  homeshowfeature(false);
  painthome();
  if ((m.feat.$count() > 1)) {
    m.feattimer.control = "start";
  }
}

function homeoncatalog() {
  if ((m.hminit !== true)) {
    homeinit();
  }
  m.feat = [];
  m.featidx = 0;
  homepickfeatures();
  m.featfromcatalog = true;
  homesavefeat();
  if ((m.mode === "home")) {
    homeshowfeature(true);
    painthome();
    m.feattimer.control = "stop";
    if ((m.feat.$count() > 1)) {
      m.feattimer.control = "start";
    }
  }
}

function homepickfeatures() {
  let root, best, bestscore, i, $e0, nm, sc, cat, n, used, tries, k, it;
  m.feat = [];
  root = m.movieroot;
  if (((root == null) || (root.$getchildcount() === 0))) {
    return;
  }
  best = 0;
  bestscore = (-1);
  for (i = 0, $e0 = (root.$getchildcount() - 1); i <= $e0; i++) {
    nm = $lcase(root.$getchild(i).id);
    sc = 0;
    if (($instr(1, nm, "2026") > 0)) {
      sc = (sc + 4);
    }
    if ((((($instr(1, nm, "estreno") > 0) || ($instr(1, nm, "release") > 0)) || ($instr(1, nm, "new") > 0)) || ($instr(1, nm, "nuev") > 0))) {
      sc = (sc + 3);
    }
    if (($instr(1, nm, "2025") > 0)) {
      sc = (sc + 1);
    }
    if ((($instr(1, nm, "adult") > 0) || ($instr(1, nm, "xxx") > 0))) {
      sc = (-10);
    }
    if ((root.$getchild(i).$getchildcount() < 6)) {
      sc = (sc - 2);
    }
    if ((sc > bestscore)) {
      bestscore = sc;
      best = i;
    }
  }
  cat = root.$getchild(best);
  n = cat.$getchildcount();
  if ((n === 0)) {
    return;
  }
  used = {__proto__: $AAP};
  tries = 0;
  while (((m.feat.$count() < 6) && (tries < 60))) {
    tries = (tries + 1);
    k = ($rnd(n) - 1);
    if ((!used.$doesexist(k.$tostr()))) {
      $six(used, k.$tostr(), true);
      it = cat.$getchild(k);
      if ((((((it != null) && (it.hdposterurl != null)) && (it.hdposterurl !== "")) && (it.url != null)) && (it.url !== ""))) {
        m.feat.$push(it);
      }
    }
  }
}

function homefeature() {
  if ((m.feat.$count() === 0)) {
    return null;
  }
  if ((m.featidx >= m.feat.$count())) {
    m.featidx = 0;
  }
  return $ix(m.feat, m.featidx);
}

function onfeattimer() {
  if ((m.mode !== "home")) {
    return;
  }
  homestepfeature(1);
}

function homestepfeature(d) {
  let n;
  n = m.feat.$count();
  if ((n < 2)) {
    return;
  }
  m.featidx = ((((m.featidx + d) + n)) % n);
  homeshowfeature(true);
  drawherobuttons();
  m.feattimer.control = "stop";
  m.feattimer.control = "start";
}

function featinfofor(it) {
  if ((it == null)) {
    return null;
  }
  if (m.featinfo.$doesexist(it.url)) {
    return $ix(m.featinfo, it.url);
  }
  return null;
}

function homeshowfeature(animatetext) {
  let it, inf, xt, t, back;
  it = homefeature();
  if ((it == null)) {
    homeheroimage("", "");
    drawherotext(false);
    return;
  }
  inf = featinfofor(it);
  if ((inf == null)) {
    xt = vodxtfromurl(it.url);
    if ((xt != null)) {
      if ((!m.featbusy)) {
        m.featbusy = true;
        m.featrequrl = it.url;
        t = $createobject("roSGNode", "XtreamReader");
        t.op = "vodinfo";
        t.host = xt.host;
        t.user = xt.user;
        t.pass = xt.pass;
        t.serid = xt.id;
        m.feattask = t;
        t.$observefield("result", "onFeatInfo");
        t.control = "RUN";
      }
    } else {
      $six(m.featinfo, it.url, {__proto__: $AAP, "ok": false});
      inf = $ix(m.featinfo, it.url);
    }
  }
  if ((inf != null)) {
    back = "";
    if ((inf.$doesexist("backdrop") && (inf.backdrop != null))) {
      back = inf.backdrop;
    }
    if ((back !== "")) {
      homeheroimage(back, "full");
    } else {
      homeheroimage(it.hdposterurl, "side");
    }
  }
  drawherotext(animatetext);
}

function onfeatinfo() {
  let r, u, it;
  m.featbusy = false;
  if ((m.feattask == null)) {
    return;
  }
  r = m.feattask.result;
  u = m.featrequrl;
  if ((r == null)) {
    r = {__proto__: $AAP, "ok": false};
  }
  if ((u != null)) {
    $six(m.featinfo, u, r);
  }
  if ((m.featfromcatalog === true)) {
    homesavefeat();
  }
  it = homefeature();
  if ((((m.mode === "home") && (it != null)) && (it.url === u))) {
    homeshowfeature(true);
  } else if ((((m.mode === "home") && (it != null)) && (featinfofor(it) == null))) {
    homeshowfeature(true);
  }
}

function homeheroimage(uri, mode) {
  let back;
  if ((uri === "")) {
    m.heroa.opacity = 0;
    m.herob.opacity = 0;
    m.herocururi = "";
    return;
  }
  if ((m.herocururi === uri)) {
    return;
  }
  m.herocururi = uri;
  back = m.heroa;
  if (((m.herofront != null) && m.herofront.$issamenode(m.heroa))) {
    back = m.herob;
  }
  if ((mode === "full")) {
    back.translation = [0, 0];
    back.width = 1280;
    back.height = 720;
    back.loadwidth = 1280;
    back.loadheight = 720;
  } else {
    back.translation = [700, 0];
    back.width = 580;
    back.height = 720;
    back.loadwidth = 580;
    back.loadheight = 720;
  }
  back.opacity = 0;
  m.heropending = back;
  m.heropendingmode = mode;
  back.$unobservefield("loadStatus");
  back.uri = uri;
  if ((back.loadstatus === "ready")) {
    herofadenow();
  } else {
    back.$observefield("loadStatus", "onHeroLoad");
  }
}

function onheroload() {
  let p;
  p = m.heropending;
  if ((p == null)) {
    return;
  }
  if ((p.loadstatus === "ready")) {
    p.$unobservefield("loadStatus");
    herofadenow();
  } else if ((p.loadstatus === "failed")) {
    p.$unobservefield("loadStatus");
  }
}

function herofadenow() {
  let p, target, other;
  p = m.heropending;
  if ((p == null)) {
    return;
  }
  target = 1.0;
  if ((m.heropendingmode === "side")) {
    target = 0.75;
  }
  m.herofade.control = "stop";
  m.herofadein.fieldtointerp = (p.id + ".opacity");
  m.herofadein.keyvalue = [0.0, target];
  if (((m.herofront != null) && (!m.herofront.$issamenode(p)))) {
    m.herofadeout.fieldtointerp = (m.herofront.id + ".opacity");
    m.herofadeout.keyvalue = [m.herofront.opacity, 0.0];
  } else {
    other = m.herob;
    if (p.$issamenode(m.herob)) {
      other = m.heroa;
    }
    m.herofadeout.fieldtointerp = (other.id + ".opacity");
    m.herofadeout.keyvalue = [other.opacity, 0.0];
  }
  m.herofade.control = "start";
  m.herofront = p;
  m.heropending = null;
}

function fmtnum(n) {
  let s, out, c, i, $e1;
  s = n.$tostr();
  out = "";
  c = 0;
  for (i = $len(s), $e1 = 1; i >= $e1; i--) {
    out = ($mid(s, i, 1) + out);
    c = (c + 1);
    if ((((c % 3) === 0) && (i > 1))) {
      out = ("," + out);
    }
  }
  return out;
}

function drawherotext(animate) {
  let g, x, it, inf, st, tl, th, y, parts, yr, d, du, gn, cx, first, p, dot, lb, rt, rl, plot, pl;
  g = m.herotext;
  clearnode(g);
  x = 64;
  it = homefeature();
  if ((it != null)) {
    inf = featinfofor(it);
    st = splittitle(it.title);
    dttext(g, x, 150, 400, tx("DESTACADO"), "0xFF8A24FF", 15, "Bold");
    tl = dttext(g, x, 172, 640, st.t, "0xFFFFFFFF", 50, "Bold");
    tl.wrap = true;
    tl.maxlines = 2;
    th = $int(tl.$boundingrect().height);
    if ((th < 56)) {
      th = 62;
    }
    if ((th > 130)) {
      th = 124;
    }
    y = ((172 + th) + 8);
    parts = [];
    yr = st.year;
    if ((inf != null)) {
      d = "";
      if ((inf.$doesexist("date") && (inf.date != null))) {
        d = inf.date;
      }
      if (((yr === "") && ($len(d) >= 4))) {
        yr = $left(d, 4);
      }
    }
    if ((yr !== "")) {
      parts.$push(yr);
    }
    if ((((inf != null) && inf.$doesexist("duration")) && (inf.duration != null))) {
      du = fmtduration(inf.duration);
      if ((du !== "")) {
        parts.$push(du);
      }
    }
    if ((((inf != null) && inf.$doesexist("genre")) && (inf.genre != null))) {
      gn = fmtgenres(inf.genre);
      if ((gn !== "")) {
        parts.$push(gn);
      }
    }
    cx = x;
    first = true;
    for (p of $iter(parts)) {
      if ((!first)) {
        dot = dttext(g, cx, y, 0, "•", "0x80858CFF", 18, "Regular");
        cx = ((cx + dtw(dot)) + 10);
      }
      lb = dttext(g, cx, y, 0, p, "0xE6E8EBFF", 18, "SemiBold");
      cx = ((cx + dtw(lb)) + 10);
      first = false;
    }
    if ((((inf != null) && inf.$doesexist("rating")) && (inf.rating != null))) {
      rt = fmtrating(inf.rating);
      if ((rt !== "")) {
        if ((!first)) {
          cx = (cx + 6);
        }
        dtbox(g, cx, (y - 3), 78, 28, "pkg:/images/rr_pill.9.png", "0xFF8A24FF", 1.0);
        rl = dttext(g, cx, (y + 1), 78, ("★ " + rt), "0x101016FF", 16, "Bold");
        rl.horizalign = "center";
      }
    }
    plot = "";
    if ((((inf != null) && inf.$doesexist("plot")) && (inf.plot != null))) {
      plot = inf.plot;
    }
    if (((plot !== "") && ((y + 36) < 380))) {
      pl = dttext(g, x, (y + 34), 560, plot, "0xD8DCE2FF", 18, "Regular");
      pl.wrap = true;
      pl.maxlines = 2;
      pl.linespacing = 2;
    }
  } else if ((homestate() === "loading")) {
    drawheroloading(g);
  } else if ((homestate() === "empty")) {
    drawherowelcome(g);
  } else {
    dttext(g, x, 158, 400, "SMART IPTV MX", "0xFF8A24FF", 15, "Bold");
    dttext(g, x, 182, 700, tx("Tu entretenimiento,"), "0xFFFFFFFF", 50, "Bold");
    dttext(g, x, 240, 700, tx("en un solo lugar."), "0xFFFFFFFF", 50, "Bold");
    pl = dttext(g, x, 316, 620, tx("Canales en vivo, películas y series con una interfaz pensada para ti."), "0xC8CCD2FF", 19, "Regular");
    pl.wrap = true;
    pl.maxlines = 2;
  }
  if (animate) {
    m.herotextfade.control = "stop";
    m.herotext.opacity = 0;
    m.herotextfade.control = "start";
  } else {
    m.herotext.opacity = 1;
    m.herotext.translation = [0, 0];
  }
}

function homeherolabels() {
  if ((homefeature() != null)) {
    return [tx("Reproducir"), tx("Más información")];
  }
  if ((m.catalogready === true)) {
    return [tx("Ver TV en vivo"), tx("Explorar películas")];
  }
  return [tx("Mis listas"), tx("Cargar con QR")];
}

function drawherobuttons() {
  let g, labels, x, y, i, $e2, focused, w, ba, tc, ic, icp, n, dx, $e3;
  g = m.herobtns;
  clearnode(g);
  labels = homeherolabels();
  x = 64;
  y = 396;
  for (i = 0, $e2 = 1; i <= $e2; i++) {
    focused = (((m.hz === "hero") && (m.hi === i)));
    w = 220;
    if ((i === 1)) {
      w = 240;
    }
    ba = 0.16;
    tc = "0xFFFFFFFF";
    if (focused) {
      ba = 1.0;
      tc = "0x0A0A0FFF";
    }
    dtbox(g, x, y, w, 54, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", ba);
    ic = "pkg:/images/ic_play.png";
    if ((i === 1)) {
      ic = "pkg:/images/ic_info.png";
    }
    if ((homefeature() == null)) {
      if ((i === 0)) {
        ic = "pkg:/images/ic_live.png";
      }
      if ((i === 1)) {
        ic = "pkg:/images/ic_movies.png";
      }
      if ((m.catalogready !== true)) {
        if ((i === 0)) {
          ic = "pkg:/images/ic_list.png";
        }
        if ((i === 1)) {
          ic = "pkg:/images/ic_qr.png";
        }
      }
    }
    icp = addposter(g, (x + 22), (y + 15), 24, 24, ic);
    icp.blendcolor = tc;
    dttext(g, (x + 56), (y + 15), (w - 64), $ix(labels, i), tc, 19, "SemiBold");
    x = ((x + w) + 14);
  }
  n = m.feat.$count();
  if ((n > 1)) {
    dx = (x + 18);
    for (i = 0, $e3 = (n - 1); i <= $e3; i++) {
      if ((i === m.featidx)) {
        dtbox(g, dx, (y + 23), 22, 8, "pkg:/images/rr_pill.9.png", "0xFF8A24FF", 1.0);
        dx = (dx + 30);
      } else {
        dtbox(g, dx, (y + 23), 8, 8, "pkg:/images/rr_pill.9.png", "0xFFFFFFFF", 0.35);
        dx = (dx + 16);
      }
    }
  }
}

function tilesub(a) {
  let n;
  if ((((((a === "live") || (a === "movies")) || (a === "series"))) && (homestate() === "loading"))) {
    return tx("Cargando...");
  }
  if ((((a === "live") && (m.cntlive != null)) && (m.cntlive > 0))) {
    return (fmtnum(m.cntlive) + tx(" canales"));
  }
  if ((((a === "movies") && (m.cntmov != null)) && (m.cntmov > 0))) {
    return (fmtnum(m.cntmov) + tx(" títulos"));
  }
  if ((((a === "series") && (m.cntser != null)) && (m.cntser > 0))) {
    return (fmtnum(m.cntser) + tx(" series"));
  }
  if ((a === "favs")) {
    n = 0;
    if ((m.favs != null)) {
      n = m.favs.$count();
    }
    if ((n > 0)) {
      return (n.$tostr() + tx(" guardados"));
    }
    return tx("Tu selección");
  }
  if ((a === "search")) {
    return tx("Todo tu catálogo");
  }
  if ((a === "mosaic")) {
    return mossub();
  }
  if ((a === "live")) {
    return tx("Canales y guía");
  }
  if ((a === "movies")) {
    return tx("Catálogo con portadas");
  }
  return tx("Temporadas y capítulos");
}

function drawhomebody() {
  let g, tiles, w, h, gap, y, i, $e4, t, x, focused, tg, fg, sg, ip, an, vi, utils, uy, ugap, $e5, u, utxt, tw, tmp, ix, tl;
  g = m.homebody;
  clearnode(g);
  tiles = hometiles();
  w = 180;
  h = 124;
  gap = 14;
  y = 474;
  for (i = 0, $e4 = (tiles.$count() - 1); i <= $e4; i++) {
    t = $ix(tiles, i);
    x = (64 + (i * ((w + gap))));
    focused = (((m.hz === "tiles") && (m.hi === i)));
    tg = g.$createchild("Group");
    tg.translation = [x, y];
    tg.scalerotatecenter = [(w / 2), (h / 2)];
    if (focused) {
      dtbox(tg, (-6), (-6), (w + 12), (h + 12), "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 0.25);
      dtbox(tg, 0, 0, w, h, "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 1.0);
      fg = "0x0A0A0FFF";
      sg = "0x0A0A0FB3";
    } else {
      dtbox(tg, 0, 0, w, h, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.07);
      dtbox(tg, 0, 0, w, h, "pkg:/images/rr_line.9.png", "0xFFFFFFFF", 0.10);
      fg = "0xFFFFFFFF";
      sg = "0x8A8F98FF";
    }
    ip = addposter(tg, 20, 18, 38, 38, (("pkg:/images/" + t.ic) + ".png"));
    ip.blendcolor = fg;
    dttext(tg, 20, 68, (w - 30), t.t, fg, 21, "SemiBold");
    dttext(tg, 20, 96, (w - 30), tilesub(t.a), sg, 14, "Regular");
    if (focused) {
      an = tg.$createchild("Animation");
      an.duration = 0.18;
      an.easefunction = "outQuad";
      vi = an.$createchild("Vector2DFieldInterpolator");
      vi.key = [0.0, 1.0];
      vi.keyvalue = [[1.0, 1.0], [1.06, 1.06]];
      tg.id = "homeTileOn";
      vi.fieldtointerp = "homeTileOn.scale";
      an.control = "start";
    }
  }
  utils = homeutils();
  x = 64;
  uy = 620;
  ugap = 12;
  if ((utils.$count() >= 8)) {
    ugap = 8;
  }
  for (i = 0, $e5 = (utils.$count() - 1); i <= $e5; i++) {
    u = $ix(utils, i);
    focused = (((m.hz === "utils") && (m.hi === i)));
    utxt = u.t;
    if ((utxt === "")) {
      tw = 46;
    } else {
      tmp = dttext(g, (-3000), 0, 0, utxt, "0xFFFFFFFF", 16, "SemiBold");
      tw = (dtw(tmp) + 62);
      g.$removechild(tmp);
    }
    if (focused) {
      dtbox(g, x, uy, tw, 42, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 1.0);
      fg = "0x0A0A0FFF";
    } else {
      dtbox(g, x, uy, tw, 42, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.07);
      fg = "0xC8CCD2FF";
    }
    ix = (x + 16);
    if ((utxt === "")) {
      ix = (x + 12);
    }
    ip = addposter(g, ix, (uy + 10), 22, 22, (("pkg:/images/" + u.ic) + ".png"));
    ip.blendcolor = fg;
    if ((utxt !== "")) {
      dttext(g, (x + 46), (uy + 11), (tw - 50), utxt, fg, 16, "SemiBold");
    }
    if (((utxt === "") && focused)) {
      tl = dttext(g, ((x + 46) - 220), (uy + 50), 220, u.lab, "0xFF8A24FF", 13, "SemiBold");
      tl.horizalign = "right";
    }
    x = ((x + tw) + ugap);
  }
}

function painthome() {
  if ((m.hminit !== true)) {
    homeinit();
  }
  drawherobuttons();
  drawhomebody();
  if ((m.wxfocus != null)) {
    m.wxfocus.visible = ((m.hz === "top"));
  }
}

function movehome(dx, dy) {
  let mx, ni;
  if ((m.hminit !== true)) {
    homeinit();
  }
  if ((dy < 0)) {
    if ((m.hz === "utils")) {
      m.lastutil = m.hi;
      m.hz = "tiles";
      m.hi = m.lasttile;
    } else if ((m.hz === "tiles")) {
      m.lasttile = m.hi;
      m.hz = "hero";
      m.hi = 0;
    } else if ((m.hz === "hero")) {
      m.hz = "top";
      m.hi = 0;
    }
  } else if ((dy > 0)) {
    if ((m.hz === "top")) {
      m.hz = "hero";
      m.hi = 0;
    } else if ((m.hz === "hero")) {
      m.hz = "tiles";
      m.hi = m.lasttile;
    } else if ((m.hz === "tiles")) {
      m.lasttile = m.hi;
      m.hz = "utils";
      m.hi = m.lastutil;
      if ((m.hi > (homeutils().$count() - 1))) {
        m.hi = (homeutils().$count() - 1);
      }
    }
  } else if ((dx !== 0)) {
    mx = 0;
    if ((m.hz === "hero")) {
      mx = 1;
    }
    if ((m.hz === "tiles")) {
      mx = (hometiles().$count() - 1);
    }
    if ((m.hz === "utils")) {
      mx = (homeutils().$count() - 1);
    }
    ni = (m.hi + dx);
    if ((ni < 0)) {
      ni = 0;
    }
    if ((ni > mx)) {
      ni = mx;
    }
    m.hi = ni;
  }
  if ((m.hz === "hero")) {
    m.feattimer.control = "stop";
    if ((m.feat.$count() > 1)) {
      m.feattimer.control = "start";
    }
  }
  painthome();
}

function openhomecard() {
  let it, tl, ul, a;
  if ((m.hminit !== true)) {
    homeinit();
  }
  if ((m.hz === "top")) {
    openweather();
  } else if ((m.hz === "hero")) {
    it = homefeature();
    if ((it != null)) {
      if ((m.hi === 0)) {
        playnode(it, "home");
      } else {
        showdetail(it, "home");
      }
    } else if ((m.catalogready === true)) {
      if ((m.hi === 0)) {
        opensection("live");
      } else {
        opensection("movies");
      }
    } else {
      if ((m.hi === 0)) {
        showlists();
      } else {
        showqr();
      }
    }
  } else if ((m.hz === "tiles")) {
    tl = hometiles();
    if (($ix(tl, m.hi).a === "mosaic")) {
      showmosaic();
    } else {
      opensection($ix(tl, m.hi).a);
    }
  } else if ((m.hz === "utils")) {
    ul = homeutils();
    if ((m.hi > (ul.$count() - 1))) {
      return;
    }
    a = $ix(ul, m.hi).a;
    if ((a === "lists")) {
      showlists();
    }
    if ((a === "qr")) {
      showqr();
    }
    if ((a === "xtream")) {
      showxtream();
    }
    if ((a === "reload")) {
      reloadactive();
    }
    if ((a === "about")) {
      showabout();
    }
    if ((a === "parental")) {
      showparental();
    }
    if ((a === "adult")) {
      askadultpin();
    }
    if ((a === "support")) {
      showsupport("home");
    }
  }
}

function homehaslists() {
  let ls;
  if ((m.xtactive != null)) {
    return true;
  }
  ls = activelists();
  return (ls.$count() > 0);
}

function homestate() {
  if ((homefeature() != null)) {
    return "feat";
  }
  if ((m.loadingall === true)) {
    return "loading";
  }
  if ((m.catalogready === true)) {
    return "ready";
  }
  if (homehaslists()) {
    return "loading";
  }
  return "empty";
}

function drawheroloading(g) {
  let x, st, pct, w, i, $e6, px, clip, sh, an, vi;
  x = 64;
  dttext(g, x, 158, 400, "SMART IPTV MX", "0xFF8A24FF", 15, "Bold");
  dttext(g, x, 182, 660, tx("Preparando"), "0xFFFFFFFF", 50, "Bold");
  dttext(g, x, 240, 660, tx("tu catálogo..."), "0xFFFFFFFF", 50, "Bold");
  st = m.homestatus.text;
  if ((st === "")) {
    st = tx("Conectando con tu lista...");
  }
  m.hplbl = dttext(g, x, 312, 600, st, "0xC8CCD2FF", 18, "Regular");
  dtbox(g, x, 348, 520, 8, "pkg:/images/rr_pill.9.png", "0xFFFFFFFF", 0.12);
  pct = 0;
  if ((m.loadpct != null)) {
    pct = m.loadpct;
  }
  w = $int(((520 * pct) / 100));
  if ((w < 12)) {
    w = 12;
  }
  m.hpbar = dtbox(g, x, 348, w, 8, "pkg:/images/rr_pill.9.png", "0xFF8A24FF", 1.0);
  for (i = 0, $e6 = 3; i <= $e6; i++) {
    px = (740 + (i * 122));
    dtbox(g, px, 140, 108, 162, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.06);
    dtbox(g, px, 312, 90, 10, "pkg:/images/rr_pill.9.png", "0xFFFFFFFF", 0.06);
    dtbox(g, px, 330, 60, 8, "pkg:/images/rr_pill.9.png", "0xFFFFFFFF", 0.04);
  }
  clip = g.$createchild("Group");
  clip.clippingrect = [740, 140, 474, 200];
  sh = clip.$createchild("Poster");
  sh.uri = "pkg:/images/glow.png";
  sh.width = 220;
  sh.height = 360;
  sh.translation = [560, 60];
  sh.opacity = 0.10;
  sh.id = "homeShimmer";
  an = g.$createchild("Animation");
  an.duration = 1.8;
  an.repeat = true;
  an.easefunction = "inOutQuad";
  vi = an.$createchild("Vector2DFieldInterpolator");
  vi.key = [0.0, 1.0];
  vi.keyvalue = [[560.0, 60.0], [1240.0, 60.0]];
  vi.fieldtointerp = "homeShimmer.translation";
  an.control = "start";
}

function drawherowelcome(g) {
  let x, pl, steps, i, $e7, y, nl;
  x = 64;
  dttext(g, x, 158, 400, "SMART IPTV MX", "0xFF8A24FF", 15, "Bold");
  dttext(g, x, 182, 640, tx("Tu entretenimiento,"), "0xFFFFFFFF", 50, "Bold");
  dttext(g, x, 240, 640, tx("en un solo lugar."), "0xFFFFFFFF", 50, "Bold");
  pl = dttext(g, x, 316, 600, tx("Agrega tu lista para empezar: desde Mis listas o con el código QR."), "0xC8CCD2FF", 19, "Regular");
  pl.wrap = true;
  pl.maxlines = 2;
  steps = [{__proto__: $AAP, "t": tx("Agrega tu lista"), "d": tx("Desde Mis listas o escaneando el QR con tu celular."), "ic": "ic_qr"}, {__proto__: $AAP, "t": tx("Explora tu catálogo"), "d": tx("Canales con guía, películas y series con portadas."), "ic": "ic_movies"}, {__proto__: $AAP, "t": tx("Disfruta a tu manera"), "d": tx("Guarda favoritos y retoma donde te quedaste."), "ic": "ic_heart"}];
  for (i = 0, $e7 = 2; i <= $e7; i++) {
    y = (146 + (i * 92));
    dtbox(g, 760, y, 456, 80, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.06);
    dtbox(g, 776, (y + 20), 40, 40, "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 1.0);
    nl = dttext(g, 776, (y + 28), 40, ((i + 1)).$tostr(), "0x0A0A0FFF", 18, "Bold");
    nl.horizalign = "center";
    dttext(g, 832, (y + 16), 370, $ix(steps, i).t, "0xFFFFFFFF", 18, "SemiBold");
    dttext(g, 832, (y + 42), 370, $ix(steps, i).d, "0x9A9FA8FF", 14, "Regular");
  }
}

function homeonprogress(pct) {
  let w;
  m.loadpct = pct;
  if (((m.mode !== "home") || (m.hminit !== true))) {
    return;
  }
  if ((homefeature() != null)) {
    return;
  }
  if (((((m.hpbar != null) && (m.hplbl != null)) && (homestate() === "loading")) && (m.herotext.$getchildcount() > 0))) {
    w = $int(((520 * pct) / 100));
    if ((w < 12)) {
      w = 12;
    }
    m.hpbar.width = w;
    m.hplbl.text = m.homestatus.text;
  } else {
    drawherotext(false);
    drawherobuttons();
  }
}

function homesavefeat() {
  let arr, it, e, inf, p, js;
  if (((m.sec == null) || (m.feat.$count() === 0))) {
    return;
  }
  arr = [];
  for (it of $iter(m.feat)) {
    e = {__proto__: $AAP, "t": it.title, "u": it.url, "l": it.hdposterurl, "f": it.streamformat};
    inf = featinfofor(it);
    if (((inf != null) && (inf.ok === true))) {
      p = "";
      if ((inf.plot != null)) {
        p = inf.plot;
      }
      if (($len(p) > 240)) {
        p = ($left(p, 237) + "...");
      }
      e.b = inf.backdrop;
      e.p = p;
      e.d = inf.date;
      e.du = inf.duration;
      e.g = inf.genre;
      e.r = inf.rating;
    }
    arr.$push(e);
  }
  js = $formatjson(arr);
  if (($len(js) > 6000)) {
    return;
  }
  m.sec.$write("home_feat", js);
  m.sec.$flush();
}

function homeloadfeat() {
  let arr, e, n, fmt, ttl, pst;
  if (((m.sec == null) || (!m.sec.$exists("home_feat")))) {
    return;
  }
  if ((!homehaslists())) {
    return;
  }
  arr = $parsejson(m.sec.$read("home_feat"));
  if (($type(arr) !== "roArray")) {
    return;
  }
  for (e of $iter(arr)) {
    if (((($type(e) === "roAssociativeArray") && (e.u != null)) && (e.u !== ""))) {
      n = $createobject("roSGNode", "ContentNode");
      fmt = "mp4";
      if (((e.f != null) && (e.f !== ""))) {
        fmt = e.f;
      }
      ttl = "";
      if ((e.t != null)) {
        ttl = e.t;
      }
      pst = "";
      if ((e.l != null)) {
        pst = e.l;
      }
      n.$setfields({__proto__: $AAP, "title": ttl, "url": e.u, "hdposterurl": pst, "streamformat": fmt, "description": "movie"});
      m.feat.$push(n);
      if ((e.$doesexist("b") && (e.b != null))) {
        $six(m.featinfo, e.u, {__proto__: $AAP, "ok": true, "backdrop": e.b, "plot": e.p, "date": e.d, "duration": e.du, "genre": e.g, "rating": e.r});
      }
    }
  }
}
// ---- components/tutorial.brs ----
function tutbuttons() {
  return {__proto__: $AAP, "back": {__proto__: $AAP, "x": 78, "y": 98, "w": 84, "h": 50}, "ok": {__proto__: $AAP, "x": 120, "y": 212, "w": 74, "h": 74}, "up": {__proto__: $AAP, "x": 120, "y": 150, "w": 58, "h": 58}, "down": {__proto__: $AAP, "x": 120, "y": 274, "w": 58, "h": 58}, "left": {__proto__: $AAP, "x": 58, "y": 212, "w": 58, "h": 58}, "right": {__proto__: $AAP, "x": 182, "y": 212, "w": 58, "h": 58}, "replay": {__proto__: $AAP, "x": 62, "y": 334, "w": 60, "h": 60}, "options": {__proto__: $AAP, "x": 178, "y": 334, "w": 60, "h": 60}, "rev": {__proto__: $AAP, "x": 62, "y": 394, "w": 60, "h": 60}, "play": {__proto__: $AAP, "x": 120, "y": 394, "w": 60, "h": 60}, "fwd": {__proto__: $AAP, "x": 178, "y": 394, "w": 60, "h": 60}};
}

function tutkeyname(k) {
  if ((k === "OK")) {
    return "OK";
  }
  if ((k === "back")) {
    return tx("Atrás");
  }
  if ((k === "up")) {
    return tx("Arriba");
  }
  if ((k === "down")) {
    return tx("Abajo");
  }
  if ((k === "left")) {
    return tx("Izquierda");
  }
  if ((k === "right")) {
    return tx("Derecha");
  }
  if ((k === "replay")) {
    return tx("Repetir");
  }
  if ((k === "options")) {
    return tx("Asterisco *");
  }
  if ((k === "rev")) {
    return tx("Retroceder");
  }
  if ((k === "fwd")) {
    return tx("Adelantar");
  }
  if ((k === "play")) {
    return tx("Play / Pausa");
  }
  return k;
}

function tutchapters() {
  return [{__proto__: $AAP, "t": tx("Lo básico"), "ic": "ic_remote", "steps": [{__proto__: $AAP, "t": tx("Muévete con las flechas"), "d": tx("Las flechas te mueven por menús, mosaicos y listas. El elemento elegido se ilumina en naranja."), "k": "right"}, {__proto__: $AAP, "t": tx("OK para abrir"), "d": tx("OK abre lo que tengas elegido: una sección, un canal, una película o un botón."), "k": "OK"}, {__proto__: $AAP, "t": tx("Atrás para regresar"), "d": tx("Atrás te lleva a la pantalla anterior. En el inicio, te pregunta si quieres salir."), "k": "back"}, {__proto__: $AAP, "t": tx("Play: música de fondo"), "d": tx("En el inicio, Play / Pausa enciende o apaga el sonido de fondo de la app."), "k": "play"}]}, {__proto__: $AAP, "t": tx("TV en vivo"), "ic": "ic_live", "steps": [{__proto__: $AAP, "t": tx("Cambia de canal"), "d": tx("Mientras ves un canal, Arriba y Abajo pasan al canal siguiente o al anterior."), "k": "up"}, {__proto__: $AAP, "t": tx("Abre la guía"), "d": tx("Izquierda abre la guía: lo que pasan ahora, lo que sigue y el resto de tus canales."), "k": "left"}, {__proto__: $AAP, "t": tx("Regresa al canal anterior"), "d": tx("El botón Repetir te lleva de vuelta al último canal que viste."), "k": "replay"}, {__proto__: $AAP, "t": tx("Guarda tus favoritos"), "d": tx("En la lista de canales, Play / Pausa guarda el canal en Favoritos para encontrarlo rápido."), "k": "play"}]}, {__proto__: $AAP, "t": tx("Películas y series"), "ic": "ic_movies", "steps": [{__proto__: $AAP, "t": tx("Busca al instante"), "d": tx("Desde la cuadrícula presiona Atrás: arriba aparecen Buscar y Letra. En Buscar escribe con las flechas y los resultados salen mientras escribes."), "k": "back"}, {__proto__: $AAP, "t": tx("Salta a una letra"), "d": tx("En esa barra, Derecha te lleva a Letra y OK abre las letras A-Z: elige una y llegas directo."), "k": "right"}, {__proto__: $AAP, "t": tx("Abre la ficha"), "d": tx("OK sobre un póster abre la ficha con sinopsis, reparto, calificación y el botón Reproducir."), "k": "OK"}, {__proto__: $AAP, "t": tx("Temporadas y capítulos"), "d": tx("En una serie, Abajo te lleva a las temporadas y a la fila de capítulos con su miniatura."), "k": "down"}]}, {__proto__: $AAP, "t": tx("Reproductor"), "ic": "ic_play", "steps": [{__proto__: $AAP, "t": tx("Adelanta"), "d": tx("Cada vez que lo presionas suma tiempo: 10 s, luego 30 s y 1 min. El video salta cuando sueltas."), "k": "fwd"}, {__proto__: $AAP, "t": tx("Retrocede"), "d": tx("Funciona igual que adelantar, pero hacia atrás. Atrás cancela el salto si te pasaste."), "k": "rev"}, {__proto__: $AAP, "t": tx("Pausa y continúa"), "d": tx("Play / Pausa detiene el video y lo reanuda donde lo dejaste."), "k": "play"}, {__proto__: $AAP, "t": tx("Regresa 15 segundos"), "d": tx("¿Te perdiste algo? Repetir regresa 15 segundos al instante."), "k": "replay"}, {__proto__: $AAP, "t": tx("Idioma y subtítulos"), "d": tx("OK muestra los botones del video: elige CC para subtítulos o el altavoz para el idioma del audio."), "k": "OK"}]}, {__proto__: $AAP, "t": tx("Cuenta Xtream Codes"), "ic": "ic_xtream", "steps": [{__proto__: $AAP, "t": tx("¿Qué es Xtream Codes?"), "d": tx("Es otra forma de entrar a tu servicio: en lugar de un link largo usas 3 datos que te da tu proveedor."), "k": "OK"}, {__proto__: $AAP, "t": tx("Los 3 datos"), "d": tx("Servidor (por ejemplo http://servidor.com:8080), Usuario y Contraseña. Escríbelos tal como te los dieron."), "k": "OK"}, {__proto__: $AAP, "t": tx("Agrégala desde el celular"), "d": tx("En el inicio elige Cargar con QR, escanéalo, toca la pestaña Xtream, escribe los datos y envíalos."), "k": "OK"}, {__proto__: $AAP, "t": tx("¿Tienes un link completo?"), "d": tx("En la página del celular puedes pegar el link get.php completo: los 3 datos se llenan solos."), "k": "OK"}, {__proto__: $AAP, "t": tx("Lo que ganas"), "d": tx("Carga más rápida por categorías, fichas con sinopsis y reparto, y series con temporadas y capítulos."), "k": "OK"}]}, {__proto__: $AAP, "t": tx("Cargar con QR"), "ic": "ic_qr", "steps": [{__proto__: $AAP, "t": tx("Mismo Wi-Fi"), "d": tx("Conecta tu celular a la misma red Wi-Fi que la TV."), "k": "OK"}, {__proto__: $AAP, "t": tx("Escanea el código"), "d": tx("En el inicio elige Cargar con QR y escanea el código con la cámara de tu celular."), "k": "OK"}, {__proto__: $AAP, "t": tx("Lista M3U o Xtream"), "d": tx("Elige la pestaña Lista M3U para pegar un link, o Xtream si tienes usuario y contraseña."), "k": "OK"}, {__proto__: $AAP, "t": tx("Envía y listo"), "d": tx("Toca Enviar a la TV: la lista llega al instante y la app la empieza a cargar."), "k": "OK"}]}];
}

function showtutorial(from) {
  if ((m.tutpanel == null)) {
    m.tutpanel = m.top.$findnode("tutPanel");
    m.tutbody = m.top.$findnode("tutBody");
  }
  m.tutfrom = from;
  m.mode = "tutorial";
  hidepanels();
  m.topbar.visible = false;
  m.tutpanel.visible = true;
  if ((m.tutdone == null)) {
    m.tutdone = {__proto__: $AAP};
  }
  if ((m.tuttimer == null)) {
    m.tuttimer = $createobject("roSGNode", "Timer");
    m.tuttimer.duration = 0.75;
    m.tuttimer.repeat = false;
    m.top.$appendchild(m.tuttimer);
    m.tuttimer.$observefield("fire", "onTutTimer");
  }
  m.tutview = "menu";
  if ((m.tutch == null)) {
    m.tutch = 0;
  }
  m.tutstep = 0;
  m.tutbusy = false;
  drawtutorial();
  capturekeys();
}

function leavetutorial() {
  m.tutpanel.visible = false;
  if ((m.tutfrom === "about")) {
    showabout();
  } else {
    showhome();
  }
}

function tutdrawremote(g, key, okmark) {
  let rx, ry, btns, bt, cx, cy, w, h, rg, rp, fixed, an, vi, fi;
  rx = 120;
  ry = 64;
  addposter(g, rx, ry, 240, 600, "pkg:/images/remote.png");
  btns = tutbuttons();
  if (((key === "") || (!btns.$doesexist(key)))) {
    return;
  }
  bt = $ix(btns, key);
  cx = (rx + bt.x);
  cy = (ry + bt.y);
  w = (bt.w + 34);
  h = (bt.h + 34);
  if (okmark) {
    dtbox(g, (cx - $idiv(bt.w, 2)), (cy - $idiv(bt.h, 2)), bt.w, bt.h, "pkg:/images/rr_fill.9.png", "0x34C759FF", 0.85);
    addposter(g, (cx - 16), (cy - 16), 32, 32, "pkg:/images/check_circle.png");
    return;
  }
  rg = g.$createchild("Group");
  rg.translation = [(cx - $idiv(w, 2)), (cy - $idiv(h, 2))];
  rg.scalerotatecenter = [$idiv(w, 2), $idiv(h, 2)];
  rg.id = "tutRing";
  rp = rg.$createchild("Poster");
  rp.uri = "pkg:/images/ring.png";
  rp.width = w;
  rp.height = h;
  fixed = g.$createchild("Poster");
  fixed.uri = "pkg:/images/ring.png";
  fixed.width = (w - 10);
  fixed.height = (h - 10);
  fixed.translation = [(cx - $idiv(((w - 10)), 2)), (cy - $idiv(((h - 10)), 2))];
  an = g.$createchild("Animation");
  an.duration = 1.1;
  an.repeat = true;
  an.easefunction = "outQuad";
  vi = an.$createchild("Vector2DFieldInterpolator");
  vi.key = [0.0, 1.0];
  vi.keyvalue = [[0.9, 0.9], [1.35, 1.35]];
  vi.fieldtointerp = "tutRing.scale";
  fi = an.$createchild("FloatFieldInterpolator");
  fi.key = [0.0, 0.2, 1.0];
  fi.keyvalue = [0.0, 1.0, 0.0];
  fi.fieldtointerp = "tutRing.opacity";
  an.control = "start";
}

function drawtutorial() {
  let g, chs, x, w, lg, hl, menu, i, $e0, y, on2, fg, sg, ip, sub2, ch, donet, nexttxt, bl, st, n, segw, $e1, c, a, tl, th, dl, py, l1, cx, kn, tmp, kw, kl, sl, hint;
  g = m.tutbody;
  clearnode(g);
  chs = tutcurchapters();
  x = 440;
  w = 776;
  lg = addposter(g, x, 40, 120, 34, "pkg:/images/logo_small.png");
  lg.loaddisplaymode = "scaleToFit";
  if ((m.tutview === "menu")) {
    tutdrawremote(g, "OK", false);
    dttext(g, x, 96, w, tx("TUTORIAL INTERACTIVO"), "0xFF8A24FF", 15, "Bold");
    dttext(g, x, 120, w, tx("Aprende con tu control"), "0xFFFFFFFF", 40, "Bold");
    hl = dttext(g, x, 172, w, tx("Elige un capítulo. En cada paso se ilumina el botón que debes presionar."), "0xC8CCD2FF", 18, "Regular");
    hl.wrap = true;
    menu = tutmenuitems();
    for (i = 0, $e0 = (menu.$count() - 1); i <= $e0; i++) {
      y = (206 + (i * 56));
      on2 = ((i === m.tutch));
      fg = "0xFFFFFFFF";
      sg = "0x9A9FA8FF";
      if (on2) {
        dtbox(g, x, y, w, 50, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 1.0);
        fg = "0x0A0A0FFF";
        sg = "0x0A0A0FA0";
      } else {
        dtbox(g, x, y, w, 50, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.06);
      }
      ip = addposter(g, (x + 18), (y + 13), 24, 24, (("pkg:/images/" + $ix(menu, i).ic) + ".png"));
      ip.blendcolor = fg;
      dttext(g, (x + 58), (y + 14), 480, $ix(menu, i).t, fg, 19, "SemiBold");
      sub2 = dttext(g, ((x + w) - 260), (y + 16), 200, $ix(menu, i).s, sg, 14, "Regular");
      sub2.horizalign = "right";
      if (((i < 6) && m.tutdone.$doesexist(i.$tostr()))) {
        addposter(g, ((x + w) - 44), (y + 13), 24, 24, "pkg:/images/check_circle.png");
      }
    }
    dttext(g, x, 660, w, tx("Arriba/Abajo: elegir     OK: empezar     Atrás: salir"), "0x7E838CFF", 15, "Regular");
    return;
  }
  ch = $ix(chs, m.tutch);
  if ((m.tutview === "done")) {
    tutdrawremote(g, "", false);
    addposter(g, x, 150, 96, 96, "pkg:/images/check_circle.png");
    donet = tx("¡Capítulo completado!");
    if ((m.tutquick === true)) {
      donet = tx("¡Ya conoces lo esencial!");
    }
    dttext(g, x, 270, w, donet, "0xFFFFFFFF", 40, "Bold");
    dttext(g, x, 324, w, ch.t, "0xFF8A24FF", 20, "SemiBold");
    nexttxt = tx("Siguiente capítulo");
    if ((m.tutch >= (chs.$count() - 1))) {
      nexttxt = tx("Ver todos los capítulos");
    }
    if ((m.tutquick === true)) {
      nexttxt = tx("Continuar");
    }
    dtbox(g, x, 392, 330, 56, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 1.0);
    bl = dttext(g, x, 409, 330, ("OK: " + nexttxt), "0x0A0A0FFF", 18, "SemiBold");
    bl.horizalign = "center";
    dttext(g, x, 660, w, tx("Atrás: capítulos"), "0x7E838CFF", 15, "Regular");
    return;
  }
  st = $ix(ch.steps, m.tutstep);
  n = ch.steps.$count();
  tutdrawremote(g, st.k, m.tutbusy);
  if ((m.tutquick === true)) {
    dttext(g, x, 96, w, (((($ucase(tx("Recorrido rápido")) + "  ·  ") + ((m.tutstep + 1)).$tostr()) + " / ") + n.$tostr()), "0xFF8A24FF", 15, "Bold");
  } else {
    dttext(g, x, 96, w, ((($ucase(tx("Capítulo ")) + ((m.tutch + 1)).$tostr()) + "  ·  ") + $ucase(ch.t)), "0xFF8A24FF", 15, "Bold");
  }
  segw = $int((((w - (((n - 1)) * 8))) / n));
  for (i = 0, $e1 = (n - 1); i <= $e1; i++) {
    c = "0xFFFFFFFF";
    a = 0.15;
    if (((i < m.tutstep) || (((i === m.tutstep) && m.tutbusy)))) {
      c = "0xFF8A24FF";
      a = 1.0;
    } else if ((i === m.tutstep)) {
      a = 0.7;
    }
    dtbox(g, (x + (i * ((segw + 8)))), 126, segw, 6, "pkg:/images/rr_pill.9.png", c, a);
  }
  tl = dttext(g, x, 160, w, st.t, "0xFFFFFFFF", 40, "Bold");
  tl.wrap = true;
  tl.maxlines = 2;
  th = $int(tl.$boundingrect().height);
  if ((th < 46)) {
    th = 50;
  }
  if ((th > 110)) {
    th = 104;
  }
  dl = dttext(g, x, ((160 + th) + 14), 720, st.d, "0xD0D4DAFF", 21, "Regular");
  dl.wrap = true;
  dl.maxlines = 5;
  dl.linespacing = 4;
  if (st.$doesexist("demo")) {
    tutdrawxtdemo(g, x, ((((160 + th) + 14) + $int(dl.$boundingrect().height)) + 18));
  }
  py = 470;
  dtbox(g, x, py, w, 84, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.06);
  if ((m.tutbusy && (m.tutskipped === true))) {
    ip = addposter(g, (x + 28), (py + 26), 32, 32, "pkg:/images/ic_play.png");
    ip.blendcolor = "0x9A9FA8FF";
    dttext(g, (x + 80), (py + 28), 600, tx("Paso saltado"), "0xC8CCD2FF", 24, "Bold");
  } else if (m.tutbusy) {
    addposter(g, (x + 24), (py + 22), 40, 40, "pkg:/images/check_circle.png");
    dttext(g, (x + 80), (py + 28), 600, tx("¡Muy bien!"), "0xFFFFFFFF", 24, "Bold");
  } else {
    l1 = dttext(g, (x + 24), (py + 30), 0, tx("Presiona"), "0xC8CCD2FF", 20, "Regular");
    cx = (((x + 24) + dtw(l1)) + 12);
    kn = tutkeyname(st.k);
    tmp = dttext(g, (-3000), 0, 0, kn, "0xFFFFFFFF", 20, "Bold");
    kw = (dtw(tmp) + 32);
    g.$removechild(tmp);
    dtbox(g, cx, (py + 22), kw, 40, "pkg:/images/rr_pill.9.png", "0xFF8A24FF", 1.0);
    kl = dttext(g, cx, (py + 30), kw, kn, "0x0A0A0FFF", 20, "Bold");
    kl.horizalign = "center";
    dttext(g, ((cx + kw) + 12), (py + 30), 360, tx("en tu control"), "0xC8CCD2FF", 20, "Regular");
    if ((st.k !== "OK")) {
      dtbox(g, ((x + w) - 196), (py + 22), 176, 40, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.12);
      sl = dttext(g, ((x + w) - 196), (py + 31), 176, tx("OK: saltar paso"), "0xE6E8EBFF", 16, "SemiBold");
      sl.horizalign = "center";
    }
  }
  m.tuthintlbl = dttext(g, x, 580, w, "", "0xFF8A24FF", 16, "SemiBold");
  hint = tx("Atrás: capítulos");
  if ((m.tutquick === true)) {
    hint = tx("Atrás: saltar el recorrido");
  }
  if ((st.k === "back")) {
    hint = tx("En este paso, Atrás cuenta como respuesta.");
  }
  dttext(g, x, 660, w, hint, "0x7E838CFF", 15, "Regular");
}

function tutkey(key) {
  let chs, st;
  chs = tutcurchapters();
  if ((m.tutview === "menu")) {
    if ((key === "back")) {
      leavetutorial();
    } else if ((key === "up")) {
      if ((m.tutch > 0)) {
        m.tutch = (m.tutch - 1);
      }
      drawtutorial();
    } else if ((key === "down")) {
      if ((m.tutch < (tutmenuitems().$count() - 1))) {
        m.tutch = (m.tutch + 1);
      }
      drawtutorial();
    } else if ((key === "OK")) {
      if ((m.tutch === 6)) {
        startquicktour("menu");
      } else if ((m.tutch === 7)) {
        m.tutpanel.visible = false;
        showwelcome(false);
      } else {
        m.tutview = "step";
        m.tutstep = 0;
        m.tutbusy = false;
        drawtutorial();
      }
    }
    return true;
  }
  if ((m.tutview === "done")) {
    if ((m.tutquick === true)) {
      if (((key === "OK") || (key === "back"))) {
        tutquickexit();
      }
      return true;
    }
    if ((key === "OK")) {
      if ((m.tutch < (chs.$count() - 1))) {
        m.tutch = (m.tutch + 1);
        m.tutview = "step";
        m.tutstep = 0;
      } else {
        m.tutview = "menu";
      }
      drawtutorial();
    } else if ((key === "back")) {
      m.tutview = "menu";
      drawtutorial();
    }
    return true;
  }
  if (m.tutbusy) {
    return true;
  }
  st = $ix($ix(chs, m.tutch).steps, m.tutstep);
  if ((key === st.k)) {
    m.tutbusy = true;
    m.tutskipped = false;
    playchime();
    drawtutorial();
    m.tuttimer.control = "stop";
    m.tuttimer.control = "start";
  } else if ((key === "OK")) {
    m.tutbusy = true;
    m.tutskipped = true;
    drawtutorial();
    m.tuttimer.control = "stop";
    m.tuttimer.control = "start";
  } else if ((key === "back")) {
    if ((m.tutquick === true)) {
      tutquickexit();
      return true;
    }
    m.tutview = "menu";
    drawtutorial();
  } else {
    if ((m.tuthintlbl != null)) {
      m.tuthintlbl.text = tx("Ese no. Busca el botón que brilla. ¿No responde en tu control? Presiona OK para saltar este paso.");
    }
  }
  return true;
}

function ontuttimer() {
  let chs, ch;
  if ((m.mode !== "tutorial")) {
    return;
  }
  chs = tutcurchapters();
  ch = $ix(chs, m.tutch);
  m.tutbusy = false;
  m.tutskipped = false;
  if ((m.tutstep < (ch.steps.$count() - 1))) {
    m.tutstep = (m.tutstep + 1);
  } else {
    if ((m.tutquick !== true)) {
      $six(m.tutdone, m.tutch.$tostr(), true);
    }
    m.tutview = "done";
  }
  drawtutorial();
}

function tutquickchapter() {
  return {__proto__: $AAP, "t": tx("Recorrido rápido"), "ic": "ic_play", "steps": [{__proto__: $AAP, "t": tx("Conecta tu cuenta Xtream Codes"), "d": tx("¿Tu proveedor te dio usuario y contraseña? Con Xtream cargas más rápido y ves fichas con sinopsis, reparto y series por temporadas."), "k": "OK", "demo": "xt"}, {__proto__: $AAP, "t": tx("Agrégala en segundos"), "d": tx("Elige Cargar con QR, abre la pestaña Xtream en tu celular y escribe los 3 datos. Si tienes el link completo, se llenan solos."), "k": "OK"}, {__proto__: $AAP, "t": tx("Abre la guía"), "d": tx("Mientras ves un canal, Izquierda abre la guía con lo que pasan ahora y lo que sigue."), "k": "left"}, {__proto__: $AAP, "t": tx("Regresa al canal anterior"), "d": tx("El botón Repetir te lleva de vuelta al último canal que viste."), "k": "replay"}, {__proto__: $AAP, "t": tx("Busca al instante"), "d": tx("En Películas o Series presiona Atrás: arriba aparecen Buscar y Letra A-Z para encontrar todo rápido."), "k": "back"}, {__proto__: $AAP, "t": tx("Adelanta como pro"), "d": tx("Cada vez que lo presionas suma tiempo: 10 s, luego 30 s y 1 min. El video salta cuando sueltas."), "k": "fwd"}, {__proto__: $AAP, "t": tx("Idioma y subtítulos"), "d": tx("OK muestra los botones del video: elige CC para subtítulos o el altavoz para el idioma del audio."), "k": "OK"}, {__proto__: $AAP, "t": tx("Guarda tus favoritos"), "d": tx("Play / Pausa guarda el canal, la película o el capítulo en Favoritos."), "k": "play"}]};
}

function tutcurchapters() {
  if ((m.tutquick === true)) {
    return [tutquickchapter()];
  }
  return tutchapters();
}

function tutmenuitems() {
  let items, c;
  items = [];
  for (c of $iter(tutchapters())) {
    items.$push({__proto__: $AAP, "t": c.t, "ic": c.ic, "s": (c.steps.$count().$tostr() + tx(" pasos"))});
  }
  items.$push({__proto__: $AAP, "t": tx("Recorrido rápido"), "ic": "ic_play", "s": tx("1 minuto")});
  items.$push({__proto__: $AAP, "t": tx("Ver bienvenida de nuevo"), "ic": "ic_info", "s": ""});
  return items;
}

function showquicktour() {
  startquicktour("welcome");
}

function startquicktour(from) {
  if ((m.tutpanel == null)) {
    m.tutpanel = m.top.$findnode("tutPanel");
    m.tutbody = m.top.$findnode("tutBody");
  }
  if ((m.tuttimer == null)) {
    m.tuttimer = $createobject("roSGNode", "Timer");
    m.tuttimer.duration = 0.75;
    m.tuttimer.repeat = false;
    m.top.$appendchild(m.tuttimer);
    m.tuttimer.$observefield("fire", "onTutTimer");
  }
  if ((m.tutdone == null)) {
    m.tutdone = {__proto__: $AAP};
  }
  if ((from === "welcome")) {
    m.tutfrom = "home";
  }
  m.tutquick = true;
  m.tutquickfrom = from;
  m.tutch = 0;
  m.tutstep = 0;
  m.tutbusy = false;
  m.tutview = "step";
  m.mode = "tutorial";
  hidepanels();
  m.topbar.visible = false;
  m.tutpanel.visible = true;
  drawtutorial();
  capturekeys();
}

function tutquickexit() {
  m.tutquick = false;
  m.tutbusy = false;
  m.tuttimer.control = "stop";
  if ((m.tutquickfrom === "welcome")) {
    m.tutpanel.visible = false;
    welcomeaftertour();
  } else {
    m.tutview = "menu";
    m.tutch = 6;
    drawtutorial();
  }
}

function tutdrawxtdemo(g, x, y) {
  let nb, rows, i, $e2, ry;
  if ((y > 330)) {
    y = 330;
  }
  dtbox(g, x, y, 560, 132, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.06);
  dtbox(g, ((x + 560) - 92), (y + 12), 76, 24, "pkg:/images/rr_pill.9.png", "0xFF8A24FF", 1.0);
  nb = dttext(g, ((x + 560) - 92), (y + 15), 76, tx("NUEVO"), "0x0A0A0FFF", 12, "Bold");
  nb.horizalign = "center";
  rows = [[tx("Servidor"), "http://tu-servidor.com:8080"], [tx("Usuario"), "tu_usuario"], [tx("Contraseña"), "••••••••"]];
  for (i = 0, $e2 = 2; i <= $e2; i++) {
    ry = ((y + 14) + (i * 38));
    dttext(g, (x + 18), (ry + 8), 120, $ix($ix(rows, i), 0), "0x9A9FA8FF", 14, "SemiBold");
    dtbox(g, (x + 132), ry, 300, 32, "pkg:/images/rr_fill.9.png", "0x000000FF", 0.45);
    dttext(g, (x + 146), (ry + 7), 280, $ix($ix(rows, i), 1), "0xE6E8EBFF", 14, "Regular");
  }
}
// ---- components/intro.brs ----
function startintro() {
  let c;
  m.intropanel = m.top.$findnode("introPanel");
  m.introanim = m.top.$findnode("introAnim");
  m.introout = m.top.$findnode("introOut");
  m.introtimer = m.top.$findnode("introTimer");
  m.introsfx = m.top.$findnode("introSfx");
  m.introon = true;
  m.mode = "intro";
  m.intropanel.opacity = 1;
  m.intropanel.visible = true;
  m.introtimer.$observefield("fire", "onIntroTimer");
  m.introout.$observefield("state", "onIntroOutState");
  m.introanim.control = "start";
  m.introtimer.control = "start";
  if ((m.bgmon === true)) {
    c = $createobject("roSGNode", "ContentNode");
    c.url = "pkg:/sounds/intro.mp3";
    c.streamformat = "mp3";
    m.introsfx.content = c;
    m.introsfx.control = "play";
  }
  capturekeys();
}

function onintrotimer() {
  if ((m.introon !== true)) {
    return;
  }
  m.introout.control = "start";
}

function onintrooutstate() {
  if (((m.introout.state === "stopped") && (m.introon === true))) {
    introdone();
  }
}

function introdone() {
  let t;
  if ((m.introon !== true)) {
    return;
  }
  m.introon = false;
  m.introtimer.control = "stop";
  m.introanim.control = "stop";
  m.intropanel.visible = false;
  if ((m.introsfx != null)) {
    m.introsfx.control = "stop";
  }
  if (m.sec.$exists("welcome_done")) {
    showhome();
  } else if ((!m.langchosen)) {
    showlang(true);
  } else {
    showwelcome(true);
  }
  t = $createobject("roSGNode", "Timer");
  t.duration = 0.4;
  t.repeat = false;
  t.$observefield("fire", "onIntroBgm");
  m.top.$appendchild(t);
  m.introbgmtimer = t;
  t.control = "start";
}

function onintrobgm() {
  let st;
  if ((m.introbgmtries == null)) {
    m.introbgmtries = 0;
  }
  m.introbgmtries = (m.introbgmtries + 1);
  bgmstart();
  if (((m.bgm == null) || (!m.bgmon))) {
    return;
  }
  st = m.bgm.state;
  if ((((st !== "playing") && (st !== "buffering")) && (m.introbgmtries < 4))) {
    m.introbgmtimer.duration = 0.8;
    m.introbgmtimer.control = "start";
  }
}

function introkey(key) {
  if ((key === "back")) {
    return true;
  }
  if ((m.introsfx != null)) {
    m.introsfx.control = "stop";
  }
  introdone();
  return true;
}
// ---- components/parental.brs ----
function pcpin() {
  let p;
  if (m.sec.$exists("pc_pin")) {
    p = m.sec.$read("pc_pin");
    if (($len(p) === 4)) {
      return p;
    }
  }
  return "0000";
}

function pcisset() {
  return (m.sec.$exists("pc_set") && (m.sec.$read("pc_set") === "1"));
}

function pcadulton() {
  return ((pcisset() && m.sec.$exists("pc_adult")) && (m.sec.$read("pc_adult") === "1"));
}

function pcadultcount() {
  if ((m.cntadult == null)) {
    return 0;
  }
  return m.cntadult;
}

function showparental() {
  pinopen("settings");
}

function askadultpin() {
  if ((!pcadulton())) {
    return;
  }
  if ((m.loadingall === true)) {
    m.homestatus.text = tx("Cargando la lista, un momento...");
    return;
  }
  if (((m.adultroot == null) || (m.adultroot.$getchildcount() === 0))) {
    m.homestatus.text = tx("Tus listas no tienen contenido para adultos.");
    return;
  }
  pinopen("adult");
}

function showadult() {
  if (((m.adultroot == null) || (m.adultroot.$getchildcount() === 0))) {
    showhome();
    m.homestatus.text = tx("Tus listas no tienen contenido para adultos.");
    return;
  }
  m.mode = "adult";
  m.adultctx = true;
  m.vodroot = m.adultroot;
  hidepanels();
  setbgfrozen(true);
  settitle(tx("Adultos"));
  m.moviepanel.visible = true;
  drawmovies();
  capturekeys();
}

function pinopen(purpose) {
  if ((m.pinpanel == null)) {
    m.pinpanel = m.top.$findnode("pinPanel");
    m.pinbody = m.top.$findnode("pinBody");
  }
  m.pinpurpose = purpose;
  m.pinstep = "enter";
  m.pindigits = "";
  m.pinnew = "";
  m.pinmsg = "";
  m.pinmsgok = false;
  m.pinrow = 0;
  m.pincol = 0;
  m.pinmenu = 0;
  if ((m.pinfails == null)) {
    m.pinfails = 0;
  }
  if ((m.pinlockuntil == null)) {
    m.pinlockuntil = 0;
  }
  m.mode = "pin";
  hidepanels();
  settitle(tx("Control parental"));
  m.pinpanel.visible = true;
  drawpin();
  capturekeys();
}

function pinexit() {
  m.pinpanel.visible = false;
  showhome();
}

function pinkeys() {
  return ["1", "2", "3", "4", "5", "6", "7", "8", "9", "del", "0", "exit"];
}

function pinnow() {
  return $createobject("roDateTime").$asseconds();
}

function pinkey(key) {
  let keys;
  if ((m.pinstep === "menu")) {
    return pinmenukey(key);
  }
  if ((key === "back")) {
    pinexit();
  } else if ((key === "up")) {
    if ((m.pinrow > 0)) {
      m.pinrow = (m.pinrow - 1);
    }
    drawpin();
  } else if ((key === "down")) {
    if ((m.pinrow < 3)) {
      m.pinrow = (m.pinrow + 1);
    }
    drawpin();
  } else if ((key === "left")) {
    if ((m.pincol > 0)) {
      m.pincol = (m.pincol - 1);
    }
    drawpin();
  } else if ((key === "right")) {
    if ((m.pincol < 2)) {
      m.pincol = (m.pincol + 1);
    }
    drawpin();
  } else if ((key === "OK")) {
    keys = pinkeys();
    pinpress($ix(keys, ((m.pinrow * 3) + m.pincol)));
  } else if (((key === "rev") || (key === "replay"))) {
    pinpress("del");
  }
  return true;
}

function pinpress(k) {
  if ((k === "exit")) {
    pinexit();
    return;
  }
  if ((k === "del")) {
    if (($len(m.pindigits) > 0)) {
      m.pindigits = $left(m.pindigits, ($len(m.pindigits) - 1));
    }
    m.pinmsg = "";
    drawpin();
    return;
  }
  if (((m.pinstep === "enter") && (pinnow() < m.pinlockuntil))) {
    m.pinmsg = tx("Demasiados intentos. Espera 30 segundos.");
    m.pinmsgok = false;
    drawpin();
    return;
  }
  if (($len(m.pindigits) >= 4)) {
    return;
  }
  m.pindigits = (m.pindigits + k);
  m.pinmsg = "";
  drawpin();
  if (($len(m.pindigits) === 4)) {
    pinsubmit();
  }
}

function pinsubmit() {
  let d;
  d = m.pindigits;
  m.pindigits = "";
  m.pinmsgok = false;
  if ((m.pinstep === "enter")) {
    if ((d === pcpin())) {
      m.pinfails = 0;
      m.pinmsg = "";
      if ((m.pinpurpose === "adult")) {
        m.pinpanel.visible = false;
        m.movcat = 0;
        m.movidx = 0;
        m.movside = "grid";
        m.vson = false;
        m.movpick = false;
        showadult();
        return;
      } else if ((!pcisset())) {
        m.pinstep = "new";
      } else {
        m.pinstep = "menu";
        m.pinmenu = 0;
      }
    } else {
      m.pinfails = (m.pinfails + 1);
      if ((m.pinfails >= 5)) {
        m.pinfails = 0;
        m.pinlockuntil = (pinnow() + 30);
        m.pinmsg = tx("Demasiados intentos. Espera 30 segundos.");
      } else {
        m.pinmsg = tx("PIN incorrecto. Intenta de nuevo.");
      }
    }
  } else if ((m.pinstep === "new")) {
    if ((d === "0000")) {
      m.pinmsg = tx("Elige un PIN distinto de 0000.");
    } else {
      m.pinnew = d;
      m.pinstep = "confirm";
      m.pinmsg = "";
    }
  } else if ((m.pinstep === "confirm")) {
    if ((d === m.pinnew)) {
      m.sec.$write("pc_pin", d);
      m.sec.$write("pc_set", "1");
      m.sec.$flush();
      m.pinstep = "menu";
      m.pinmenu = 0;
      m.pinmsg = tx("PIN guardado. Ya puedes activar la sección para adultos.");
      m.pinmsgok = true;
      playchime();
    } else {
      m.pinstep = "new";
      m.pinmsg = tx("Los PIN no coinciden. Intenta de nuevo.");
    }
  }
  drawpin();
}

function pinmenukey(key) {
  if ((key === "back")) {
    pinexit();
  } else if ((key === "up")) {
    if ((m.pinmenu > 0)) {
      m.pinmenu = (m.pinmenu - 1);
    }
    drawpin();
  } else if ((key === "down")) {
    if ((m.pinmenu < 2)) {
      m.pinmenu = (m.pinmenu + 1);
    }
    drawpin();
  } else if ((key === "OK")) {
    if ((m.pinmenu === 0)) {
      if (pcadulton()) {
        m.sec.$write("pc_adult", "0");
        m.pinmsg = tx("Sección para adultos desactivada.");
      } else {
        m.sec.$write("pc_adult", "1");
        m.pinmsg = tx("Activada: verás el botón Adultos en el inicio.");
      }
      m.sec.$flush();
      m.pinmsgok = true;
      drawpin();
    } else if ((m.pinmenu === 1)) {
      m.pinstep = "new";
      m.pindigits = "";
      m.pinmsg = "";
      m.pinrow = 0;
      m.pincol = 0;
      drawpin();
    } else {
      pinexit();
    }
  }
  return true;
}

function pinwrap(parent, x, y, w, text, color, size, weight, lines) {
  let l;
  l = dttext(parent, x, y, w, text, color, size, weight);
  l.wrap = true;
  l.maxlines = lines;
  l.linespacing = 6;
  return l;
}

function drawpin() {
  let g, pstep, eyebrow, title, body, ic, mc, cx, cy, cw, ch, hint, bw, bh, gap, bx, by, n, i, $e0, x, dot, keys, kw, kh, kg, kx, ky, r, $e1, c, $e2, k, y, kon, fg, lb, h;
  g = m.pinbody;
  clearnode(g);
  pstep = m.pinstep;
  eyebrow = tx("CONTROL PARENTAL");
  if ((m.pinpurpose === "adult")) {
    eyebrow = tx("SECCIÓN PROTEGIDA");
  }
  title = tx("Ingresa tu PIN");
  body = tx("Para cambiar la configuración, escribe tu PIN de 4 dígitos.");
  if ((pstep === "enter")) {
    if ((m.pinpurpose === "adult")) {
      body = tx("Esta sección está protegida. Escribe tu PIN de 4 dígitos para continuar.");
    } else if ((!pcisset())) {
      title = tx("Ingresa el PIN inicial");
      body = tx("El contenido para adultos de tus listas está apartado. El PIN inicial es 0000; enseguida crearás el tuyo.");
    }
  } else if ((pstep === "new")) {
    title = tx("Crea tu PIN");
    body = tx("Elige 4 números que solo tú conozcas. No puede ser 0000.");
  } else if ((pstep === "confirm")) {
    title = tx("Confirma tu PIN");
    body = tx("Escríbelo otra vez para confirmar.");
  } else if ((pstep === "menu")) {
    title = tx("Control parental");
    body = tx("Lo de adultos de tus listas se guarda aparte: nunca aparece en En vivo, Películas, Series, Buscar ni en los destacados.");
  }
  ic = addposter(g, 100, 136, 40, 40, "pkg:/images/ic_lock.png");
  ic.blendcolor = "0xFF8A24FF";
  dttext(g, 100, 196, 0, eyebrow, "0xFF8A24FF", 15, "Bold");
  dttext(g, 100, 220, 520, title, "0xFFFFFFFF", 40, "Bold");
  pinwrap(g, 100, 282, 500, body, "0xC8CCD2FF", 19, "Regular", 4);
  if ((m.pinmsg !== "")) {
    mc = "0xFF6B6BFF";
    if (m.pinmsgok) {
      mc = "0x34D399FF";
    }
    pinwrap(g, 100, 420, 500, m.pinmsg, mc, 17, "SemiBold", 2);
  }
  cx = 690;
  cy = 120;
  cw = 500;
  ch = 470;
  if ((pstep === "menu")) {
    ch = 366;
  }
  dtbox(g, cx, cy, cw, ch, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.05);
  dtbox(g, cx, cy, cw, ch, "pkg:/images/rr_line.9.png", "0xFFFFFFFF", 0.08);
  if ((pstep === "menu")) {
    drawpinmenu(g, (cx + 20), (cy + 24), (cw - 40));
    hint = tx("Arriba/Abajo: elegir     OK: confirmar     Atrás: salir");
  } else {
    bw = 72;
    bh = 84;
    gap = 20;
    bx = (cx + $int((((cw - (((4 * bw) + (3 * gap))))) / 2)));
    by = (cy + 32);
    n = $len(m.pindigits);
    for (i = 0, $e0 = 3; i <= $e0; i++) {
      x = (bx + (i * ((bw + gap))));
      dtbox(g, x, by, bw, bh, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.08);
      if ((i === n)) {
        dtbox(g, x, by, bw, bh, "pkg:/images/rr_line.9.png", "0xFF8A24FF", 1.0);
      } else if ((((m.pinmsg !== "") && (!m.pinmsgok)) && (n === 0))) {
        dtbox(g, x, by, bw, bh, "pkg:/images/rr_line.9.png", "0xFF6B6BFF", 0.8);
      }
      if ((i < n)) {
        dot = dttext(g, x, (by + 14), bw, "•", "0xFFFFFFFF", 44, "Bold");
        dot.horizalign = "center";
      }
    }
    keys = pinkeys();
    kw = 128;
    kh = 60;
    kg = 14;
    kx = (cx + $int((((cw - (((3 * kw) + (2 * kg))))) / 2)));
    ky = ((by + bh) + 34);
    for (r = 0, $e1 = 3; r <= $e1; r++) {
      for (c = 0, $e2 = 2; c <= $e2; c++) {
        k = $ix(keys, ((r * 3) + c));
        x = (kx + (c * ((kw + kg))));
        y = (ky + (r * ((kh + 12))));
        kon = (((m.pinrow === r) && (m.pincol === c)));
        if (kon) {
          dtbox(g, (x - 4), (y - 4), (kw + 8), (kh + 8), "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 0.25);
          dtbox(g, x, y, kw, kh, "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 1.0);
          fg = "0x0A0A0FFF";
        } else {
          dtbox(g, x, y, kw, kh, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.08);
          fg = "0xFFFFFFFF";
        }
        if ((k === "del")) {
          lb = dttext(g, x, (y + 19), kw, tx("Borrar"), fg, 17, "SemiBold");
        } else if ((k === "exit")) {
          lb = dttext(g, x, (y + 19), kw, tx("Salir"), fg, 17, "SemiBold");
        } else {
          lb = dttext(g, x, (y + 13), kw, k, fg, 26, "SemiBold");
        }
        lb.horizalign = "center";
      }
    }
    hint = tx("Flechas: mover     OK: elegir     Atrás: salir");
  }
  h = dttext(g, 0, 676, 1280, hint, "0x7E838CFF", 15, "Regular");
  h.horizalign = "center";
}

function drawpinmenu(g, x, y, w) {
  let ison, st, rows, rh, i, $e3, rw, ry, foc, fg, sg, ip, pill, pc, pt;
  ison = pcadulton();
  st = tx("Desactivada");
  if (ison) {
    st = tx("Activada: aparece en el inicio como Adultos");
  }
  rows = [{__proto__: $AAP, "ic": "ic_lock", "t": tx("Sección para adultos"), "s": st}, {__proto__: $AAP, "ic": "ic_refresh", "t": tx("Cambiar PIN"), "s": tx("Elige un PIN nuevo de 4 dígitos")}, {__proto__: $AAP, "ic": "ic_play", "t": tx("Listo"), "s": tx("Volver al inicio")}];
  rh = 92;
  for (i = 0, $e3 = 2; i <= $e3; i++) {
    rw = $ix(rows, i);
    ry = (y + (i * ((rh + 14))));
    foc = ((m.pinmenu === i));
    if (foc) {
      dtbox(g, x, ry, w, rh, "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 1.0);
      fg = "0x0A0A0FFF";
      sg = "0x0A0A0FB3";
    } else {
      dtbox(g, x, ry, w, rh, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.06);
      fg = "0xFFFFFFFF";
      sg = "0x8A8F98FF";
    }
    ip = addposter(g, (x + 22), (ry + 28), 36, 36, (("pkg:/images/" + rw.ic) + ".png"));
    ip.blendcolor = fg;
    dttext(g, (x + 78), (ry + 20), (w - 210), rw.t, fg, 21, "SemiBold");
    dttext(g, (x + 78), (ry + 52), (w - 100), rw.s, sg, 15, "Regular");
    if ((i === 0)) {
      pill = tx("NO");
      pc = "0x8A8F98FF";
      if (ison) {
        pill = tx("SÍ");
        pc = "0x34D399FF";
      }
      if (foc) {
        pc = "0x0A0A0FFF";
      }
      dtbox(g, ((x + w) - 92), (ry + 22), 70, 30, "pkg:/images/rr_pill.9.png", pc, 1.0);
      pt = dttext(g, ((x + w) - 92), (ry + 27), 70, pill, "0x0A0A0FFF", 15, "Bold");
      if (foc) {
        pt.color = "0xFF8A24FF";
      }
      pt.horizalign = "center";
    }
  }
}
// ---- components/glyphs.brs ----
function cleanglyphs(s) {
  let n, out, changed, i, $e0, ch, a, keep, sx;
  if ((s == null)) {
    return "";
  }
  n = $len(s);
  if ((n === 0)) {
    return "";
  }
  out = "";
  changed = false;
  for (i = 1, $e0 = n; i <= $e0; i++) {
    ch = $mid(s, i, 1);
    a = $asc(ch);
    if ((a < 128)) {
      out = (out + ch);
    } else {
      keep = true;
      if (((a >= 8192) && (a <= 11263))) {
        keep = ((((((((((a === 8211) || (a === 8212)) || (a === 8216)) || (a === 8217)) || (a === 8220)) || (a === 8221)) || (a === 8226)) || (a === 8230)) || (a === 8364)));
      } else if (((a >= 7424) && (a <= 7615))) {
        sx = $instr(1, "ᴬᴮᴰᴱᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾᴿᵀᵁᵂ", ch);
        if ((sx > 0)) {
          ch = $mid("ABDEGHIJKLMNOPRTUW", sx, 1);
        } else {
          keep = false;
        }
      } else if (((a >= 65024) && (a <= 65039))) {
        keep = false;
      } else if (((a >= 57344) && (a <= 63743))) {
        keep = false;
      } else if (((a >= 65536) || (((a >= 55296) && (a <= 57343))))) {
        keep = false;
      }
      if (keep) {
        if ((a === 477)) {
          ch = "e";
        }
        if ((a === 592)) {
          ch = "a";
        }
        if ((a === 633)) {
          ch = "r";
        }
        if ((a === 647)) {
          ch = "t";
        }
        if ((a === 623)) {
          ch = "m";
        }
        if ((a === 654)) {
          ch = "y";
        }
        if ((a === 613)) {
          ch = "h";
        }
        if ((a === 596)) {
          ch = "o";
        }
        out = (out + ch);
      }
      changed = true;
    }
  }
  if ((!changed)) {
    return s;
  }
  out = out.$trim();
  while ((($len(out) > 0) && ($instr(1, "|-·:._*", $left(out, 1)) > 0))) {
    out = $mid(out, 2).$trim();
  }
  while (($instr(1, out, "  ") > 0)) {
    out = out.$replace("  ", " ");
  }
  if ((out === "")) {
    return s;
  }
  return out;
}
// ---- components/matches.brs ----
function mtcollect() {
  let items, rxt, rxv, i, $e0, cat, n, nm, ok, w, hits, lim, j, $e1, sportcat, lastj, $e2, ch, take, cu, cf, cl;
  items = [];
  if ((m.root == null)) {
    return items;
  }
  rxt = $createobject("roRegex", "(^|[^\\d])\\d{1,2}:\\d{2}", "");
  rxv = $createobject("roRegex", "\\s(vs\\.?|v\\.)\\s", "i");
  for (i = 0, $e0 = (m.root.$getchildcount() - 1); i <= $e0; i++) {
    cat = m.root.$getchild(i);
    n = cat.$getchildcount();
    if ((n > 0)) {
      nm = $lcase(cat.id);
      if ((nm === "")) {
        nm = $lcase(cat.title);
      }
      ok = false;
      for (w of $iter(["event", "evento", "partido", "agenda", "ppv", "diario", "match", "jornada", "en vivo hoy", "live events"])) {
        if (($instr(1, nm, w) > 0)) {
          ok = true;
        }
      }
      if ((!ok)) {
        hits = 0;
        lim = (n - 1);
        if ((lim > 5)) {
          lim = 5;
        }
        for (j = 0, $e1 = lim; j <= $e1; j++) {
          if (rxt.$ismatch(cat.$getchild(j).title)) {
            hits = (hits + 1);
          }
        }
        ok = ((hits >= 2));
      }
      sportcat = false;
      if ((!ok)) {
        for (w of $iter(["deport", "sport", "futbol", "fútbol", "soccer", "liga", "league", "premier", "champions", "espn", "fox", "tudn", "bein", "dazn", "sky", "tnt", "vix", "copa", "cup", "mls", "laliga", "serie a", "bundesliga", "ligue"])) {
          if (($instr(1, nm, w) > 0)) {
            sportcat = true;
          }
        }
      }
      lastj = (n - 1);
      if (((!ok) && (!sportcat))) {
        lastj = (-1);
      }
      for (j = 0, $e2 = lastj; j <= $e2; j++) {
        ch = cat.$getchild(j);
        take = false;
        if (ok) {
          take = rxt.$ismatch(ch.title);
        } else {
          take = rxv.$ismatch(ch.title);
        }
        if (take) {
          if (true) {
            cu = ch.url;
            if ((cu == null)) {
              cu = "";
            }
            cf = ch.streamformat;
            if ((cf == null)) {
              cf = "";
            }
            cl = ch.hdposterurl;
            if ((cl == null)) {
              cl = "";
            }
            if ((cu !== "")) {
              items.$push({__proto__: $AAP, "t": ch.title, "u": cu, "f": cf, "l": cl, "g": cleancatname(cat.id)});
            }
            if ((items.$count() >= 900)) {
              return items;
            }
          }
        }
      }
    }
  }
  return items;
}

function mtstartsoon() {
  let t;
  if ((m.mtsoon == null)) {
    t = $createobject("roSGNode", "Timer");
    t.duration = 3;
    t.repeat = false;
    t.$observefield("fire", "onMtSoon");
    m.top.$appendchild(t);
    m.mtsoon = t;
  }
  m.mtloading = true;
  mtdrawbtn();
  m.mtsoon.control = "stop";
  m.mtsoon.control = "start";
}

function onmtsoon() {
  m.mtloading = false;
  mtstart(true);
}

function mtstart(full = true) {
  let only, now, seen, mt, t;
  if (((m.mtitems == null) || (m.mtfresh !== true))) {
    try {
      m.mtitems = mtcollect();
    } catch (e) {
      console.log("[MT] error al leer canales: ", e.message);
      m.mtitems = [];
    }
    m.mtfresh = true;
  }
  only = [];
  if ((((!full) && (m.mtespn === true)) && (m.mtdata != null))) {
    now = $createobject("roDateTime").$asseconds();
    seen = {__proto__: $AAP};
    for (mt of $iter(m.mtdata)) {
      if (((((!mt.est) && (mt.lid != null)) && (mt.lid !== "")) && (!seen.$doesexist(mt.lid)))) {
        if (((mt.state === "in") || ((((mt.state !== "post") && ((mt.start - now) < 10800)) && ((now - mt.start) < 10800))))) {
          $six(seen, mt.lid, true);
          only.$push(mt.lid);
        }
      }
    }
    if ((only.$count() === 0)) {
      m.mtfetched = now;
      return;
    }
  }
  if ((m.mttask != null)) {
    m.mttask.control = "STOP";
  }
  t = $createobject("roSGNode", "MatchesTask");
  t.items = m.mtitems;
  t.only = only;
  m.mtfullreq = full;
  t.$observefield("result", "onMtResult");
  m.mttask = t;
  m.mtloading = true;
  t.control = "RUN";
  mtdrawbtn();
}

function mtreset() {
  if ((m.mtsoon != null)) {
    m.mtsoon.control = "stop";
  }
  if ((m.mttask != null)) {
    m.mttask.control = "STOP";
  }
  m.mttask = null;
  m.mtespn = false;
  m.mtsameday = false;
  m.mtitems = null;
  m.mtfresh = false;
  m.mtdata = null;
  m.mtloading = false;
}

function onmtresult() {
  let r, ok, okl, now, resp, n, merged, mt, mid;
  if ((m.mttask == null)) {
    return;
  }
  r = m.mttask.result;
  if ((r == null)) {
    r = [];
  }
  ok = m.mttask.espnok;
  okl = m.mttask.okleagues;
  now = $createobject("roDateTime").$asseconds();
  m.mtloading = false;
  m.mtfetched = now;
  if (((((m.mtespn === true) && (m.mtdata != null)) && (m.mtdata.$count() > 0)) && (m.mtsameday === true))) {
    if ((ok !== true)) {
      m.mtfetched = (now - 60);
      mtdrawbtn();
      return;
    }
    resp = {__proto__: $AAP};
    if ((okl != null)) {
      for (n of $iter(okl)) {
        $six(resp, n, true);
      }
    }
    merged = [];
    for (mt of $iter(r)) {
      merged.$push(mt);
    }
    mid = mtmidutc();
    for (mt of $iter(m.mtdata)) {
      if (((!resp.$doesexist(mt.league)) && (((mt.start >= mid) || (mt.state === "in"))))) {
        merged.$push(mt);
      }
    }
    r = merged;
  } else {
    m.mtespn = ((ok === true));
  }
  m.mtdata = r;
  m.mtsameday = true;
  m.mtday = mttoday();
  if ((m.mtfullreq === true)) {
    m.mtlastfull = now;
  }
  mtdrawbtn();
  if ((m.mode === "matches")) {
    mtrefreshview();
  }
  if ((m.mode === "mosaic")) {
    mosonmatches();
  }
}

function mtmidutc() {
  let u, d, off, loc;
  u = $createobject("roDateTime").$asseconds();
  d = $createobject("roDateTime");
  d.$tolocaltime();
  off = (d.$asseconds() - u);
  loc = (u + off);
  return ((loc - ((loc % 86400))) - off);
}

function mttoday() {
  let d;
  d = $createobject("roDateTime");
  d.$tolocaltime();
  return d.$getdayofmonth();
}

function mtrefreshview() {
  mtbuild(true);
  if ((m.mtsignew !== m.mtsig)) {
    mtdraw();
  }
}

function mtbuild(keeppos) {
  let now, mid, live, bylg, lglist, nch, nwith, mt, s, st, show, lg, lgall, r, chips, i, $e3, rows, lv, nx, fin, lgo, sig;
  now = $createobject("roDateTime").$asseconds();
  mid = mtmidutc();
  live = [];
  bylg = {__proto__: $AAP};
  lglist = [];
  nch = 0;
  nwith = 0;
  if ((m.mtdata == null)) {
    m.mtdata = [];
  }
  for (mt of $iter(m.mtdata)) {
    s = mt.start;
    st = mt.state;
    if (((st === "") || mt.est)) {
      if ((now < (s - 600))) {
        st = "pre";
      } else if ((now <= (s + 7800))) {
        st = "in";
      } else {
        st = "post";
      }
    }
    show = true;
    if (((st === "post") && mt.est)) {
      show = false;
    }
    if (((st === "post") && (s < mid))) {
      show = false;
    }
    if (show) {
      mt.s2 = s;
      mt.st2 = st;
      mt.ord = s;
      if ((st === "post")) {
        mt.ord = (s + 10000000);
      }
      if ((mt.ch.$count() > 0)) {
        nwith = (nwith + 1);
        nch = (nch + mt.ch.$count());
      }
      if ((st === "in")) {
        mt.ordl = ((mt.prio * 100000000) + s);
        live.$push(mt);
      } else {
        lg = mt.league;
        if ((!bylg.$doesexist(lg))) {
          $six(bylg, lg, {__proto__: $AAP, "t": lg, "logo": mt.lglogo, "prio": mt.prio, "live": false, "items": []});
          lglist.$push($ix(bylg, lg));
        }
        $ix(bylg, lg).items.$push(mt);
      }
    }
  }
  lgall = {__proto__: $AAP};
  for (r of $iter(lglist)) {
    $six(lgall, r.t, true);
  }
  for (mt of $iter(live)) {
    if ((!lgall.$doesexist(mt.league))) {
      $six(lgall, mt.league, true);
      lglist.$push({__proto__: $AAP, "t": mt.league, "logo": mt.lglogo, "prio": mt.prio, "live": false, "items": []});
    }
  }
  lglist.$sortby("prio");
  chips = [{__proto__: $AAP, "t": tx("Todas"), "f": "", "logo": ""}];
  for (r of $iter(lglist)) {
    chips.$push({__proto__: $AAP, "t": r.t, "f": r.t, "logo": r.logo});
  }
  m.mtchips = chips;
  if ((m.mtfilter == null)) {
    m.mtfilter = "";
  }
  if (((m.mtfilter !== "") && (!lgall.$doesexist(m.mtfilter)))) {
    m.mtfilter = "";
  }
  m.mtchip = 0;
  for (i = 0, $e3 = (chips.$count() - 1); i <= $e3; i++) {
    if (($ix(chips, i).f === m.mtfilter)) {
      m.mtchip = i;
    }
  }
  live.$sortby("ordL");
  rows = [];
  if ((m.mtfilter === "")) {
    if ((live.$count() > 0)) {
      rows.$push({__proto__: $AAP, "t": tx("EN VIVO AHORA"), "logo": "", "prio": 0, "live": true, "items": live});
    }
    for (r of $iter(lglist)) {
      if ((r.items.$count() > 0)) {
        r.items.$sortby("ord");
        rows.$push(r);
      }
    }
  } else {
    lv = [];
    for (mt of $iter(live)) {
      if ((mt.league === m.mtfilter)) {
        lv.$push(mt);
      }
    }
    nx = [];
    fin = [];
    lgo = "";
    for (r of $iter(lglist)) {
      if ((r.t === m.mtfilter)) {
        lgo = r.logo;
        for (mt of $iter(r.items)) {
          if ((mt.st2 === "post")) {
            fin.$push(mt);
          } else {
            nx.$push(mt);
          }
        }
      }
    }
    nx.$sortby("ord");
    fin.$sortby("ord");
    if ((lv.$count() > 0)) {
      rows.$push({__proto__: $AAP, "t": tx("EN VIVO AHORA"), "logo": "", "prio": 0, "live": true, "items": lv});
    }
    if ((nx.$count() > 0)) {
      rows.$push({__proto__: $AAP, "t": ((m.mtfilter + "  ·  ") + tx("PRÓXIMOS")), "logo": lgo, "prio": 1, "live": false, "items": nx});
    }
    if ((fin.$count() > 0)) {
      rows.$push({__proto__: $AAP, "t": ((m.mtfilter + "  ·  ") + tx("FINALIZADOS")), "logo": lgo, "prio": 2, "live": false, "items": fin});
    }
  }
  m.mtrows = rows;
  m.mtcount = 0;
  for (r of $iter(rows)) {
    m.mtcount = (m.mtcount + r.items.$count());
  }
  m.mtwith = nwith;
  m.mtchn = nch;
  if (((!keeppos) || (m.mtrow == null))) {
    m.mtrow = 0;
    m.mtrowfirst = 0;
    m.mtcols = {__proto__: $AAP};
  }
  if ((m.mtrow >= rows.$count())) {
    m.mtrow = (rows.$count() - 1);
  }
  if ((m.mtrow < 0)) {
    m.mtrow = 0;
  }
  if ((m.mtrowfirst > m.mtrow)) {
    m.mtrowfirst = m.mtrow;
  }
  if ((m.mtrow > (m.mtrowfirst + 1))) {
    m.mtrowfirst = (m.mtrow - 1);
  }
  if ((m.mtzone == null)) {
    m.mtzone = "rows";
  }
  if ((rows.$count() === 0)) {
    m.mtzone = "chips";
  }
  sig = ((m.mtfilter + "|") + rows.$count().$tostr());
  for (r of $iter(rows)) {
    for (mt of $iter(r.items)) {
      sig = ((((((((sig + "|") + mt.k) + mt.st2) + mt.hsc) + "-") + mt.asc) + mt.detail) + mt.ch.$count().$tostr());
    }
  }
  m.mtsignew = sig;
}

function mtcolof(r) {
  let k, c, n;
  if ((m.mtcols == null)) {
    m.mtcols = {__proto__: $AAP};
  }
  if (((r < 0) || (r >= m.mtrows.$count()))) {
    return 0;
  }
  k = $ix(m.mtrows, r).t;
  c = 0;
  if (m.mtcols.$doesexist(k)) {
    c = $ix(m.mtcols, k);
  }
  n = $ix(m.mtrows, r).items.$count();
  if ((c >= n)) {
    c = (n - 1);
  }
  if ((c < 0)) {
    c = 0;
  }
  return c;
}

function mtsetcol(r, c) {
  if ((m.mtcols == null)) {
    m.mtcols = {__proto__: $AAP};
  }
  if (((r < 0) || (r >= m.mtrows.$count()))) {
    return;
  }
  $six(m.mtcols, $ix(m.mtrows, r).t, c);
}

function mtdrawbtn() {
  let g, foc, fg, sg, ic, info, n, l;
  g = m.top.$findnode("matchBtn");
  if ((g == null)) {
    return;
  }
  clearnode(g);
  foc = ((m.mtbtnon === true));
  if (foc) {
    dtbox(g, 0, 0, 340, 50, "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 1.0);
    fg = "0x0A0A0FFF";
    sg = "0x0A0A0FB3";
  } else {
    dtbox(g, 0, 0, 340, 50, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.07);
    dtbox(g, 0, 0, 340, 50, "pkg:/images/rr_line.9.png", "0xFF8A24FF", 0.55);
    fg = "0xFFFFFFFF";
    sg = "0xFF8A24FF";
  }
  ic = addposter(g, 16, 12, 26, 26, "pkg:/images/ic_ball.png");
  ic.blendcolor = fg;
  dttext(g, 54, 14, 200, tx("Partidos de hoy"), fg, 18, "SemiBold");
  info = "";
  if ((m.mtloading === true)) {
    info = "...";
  } else if ((m.mtdata != null)) {
    n = mtcounttoday();
    if ((n > 0)) {
      info = n.$tostr();
    }
  }
  if ((info !== "")) {
    l = dttext(g, 240, 15, 84, info, sg, 16, "Bold");
    l.horizalign = "right";
  }
}

function mtcounttoday() {
  let now, n, mt, st;
  if ((m.mtdata == null)) {
    return 0;
  }
  now = $createobject("roDateTime").$asseconds();
  n = 0;
  for (mt of $iter(m.mtdata)) {
    st = mt.state;
    if (((st === "") || mt.est)) {
      if ((now > (mt.start + 7800))) {
        st = "post";
      } else {
        st = "pre";
      }
    }
    if (((st !== "post") && (mt.ch.$count() > 0))) {
      n = (n + 1);
    }
  }
  return n;
}

function livematchkey(key) {
  if ((m.mtbtnon === true)) {
    if ((key === "down")) {
      m.mtbtnon = false;
      mtdrawbtn();
      m.categorylist.$setfocus(true);
    } else if ((key === "OK")) {
      m.mtbtnon = false;
      showmatches();
    } else if ((key === "back")) {
      m.mtbtnon = false;
      stoppip();
      showhome();
    }
    return true;
  }
  if (((key === "up") && m.categorylist.$hasfocus())) {
    m.mtbtnon = true;
    capturekeys();
    mtdrawbtn();
    return true;
  }
  return false;
}

function showmatches() {
  let t, now;
  if ((m.pip === true)) {
    stoppip();
  }
  m.mode = "matches";
  m.adultctx = false;
  hidepanels();
  setbgfrozen(true);
  settitle(tx("Partidos de hoy"));
  if ((m.mtpanel == null)) {
    m.mtpanel = m.top.$findnode("matchesPanel");
    m.mtbody = m.top.$findnode("mtBody");
    t = $createobject("roSGNode", "Timer");
    t.duration = 30;
    t.repeat = true;
    t.$observefield("fire", "onMtTick");
    m.top.$appendchild(t);
    m.mttick = t;
  }
  m.mtpanel.visible = true;
  m.mtpick = false;
  m.mtmsg = "";
  if (((m.mtdata == null) && (m.mtloading !== true))) {
    mtstart();
  }
  if ((((m.mtsameday === true) && (m.mtday !== mttoday())) && (m.mtloading !== true))) {
    mtstart();
  }
  mtbuild(true);
  mtdraw();
  m.mttick.control = "start";
  capturekeys();
  now = $createobject("roDateTime").$asseconds();
  if ((((m.mtloading !== true) && (m.mtfetched != null)) && ((now - m.mtfetched) > 120))) {
    mtstart(false);
  }
}

function onmttick() {
  let now;
  if ((m.mode !== "matches")) {
    m.mttick.control = "stop";
    return;
  }
  now = $createobject("roDateTime").$asseconds();
  if ((m.mtloading === true)) {
    return;
  }
  if (((m.mtsameday === true) && (m.mtday !== mttoday()))) {
    mtstart(true);
  } else if (((m.mtlastfull == null) || ((now - m.mtlastfull) > 900))) {
    mtstart(true);
  } else if (((m.mtfetched != null) && ((now - m.mtfetched) > 120))) {
    mtstart(false);
  } else if ((m.mtpick !== true)) {
    mtrefreshview();
  }
}

function mtleave() {
  if ((m.mttick != null)) {
    m.mttick.control = "stop";
  }
  m.mtpanel.visible = false;
  showlive();
}

function mtlayers() {
  if ((m.mtgh != null)) {
    return;
  }
  clearnode(m.mtbody);
  m.mtgh = m.mtbody.$createchild("Group");
  m.mtgr0 = m.mtbody.$createchild("Group");
  m.mtgr1 = m.mtbody.$createchild("Group");
  m.mtgf = m.mtbody.$createchild("Group");
  m.mtgp = m.mtbody.$createchild("Group");
}

function mtdraw() {
  mtlayers();
  mtdrawhead();
  mtdrawrows();
  mtdrawfoot();
  mtdrawpicklayer();
  m.mtsig = m.mtsignew;
  m.mtloadingdrawn = m.mtloading;
}

function mtdrawhead() {
  let g, now, tl, info, msg, l;
  g = m.mtgh;
  clearnode(g);
  now = $createobject("roDateTime").$asseconds();
  dttext(g, 64, 76, 0, ((tx("HOY") + "  ·  ") + $ucase(fmtday(now))), "0xFF8A24FF", 15, "Bold");
  tl = dttext(g, 64, 94, 0, tx("Partidos de hoy"), "0xFFFFFFFF", 38, "Bold");
  info = "";
  if (((m.mtloading === true) && (m.mtrows.$count() === 0))) {
    info = tx("Buscando los partidos de hoy...");
  } else {
    info = ((((m.mtcount.$tostr() + tx(" partidos")) + "  ·  ") + m.mtwith.$tostr()) + tx(" con canal en tu lista"));
  }
  dttext(g, ((64 + dtw(tl)) + 24), 110, 0, info, "0x8A8F98FF", 18, "Regular");
  mtdrawchips(g);
  if ((m.mtrows.$count() === 0)) {
    msg = tx("Hoy no hay partidos de las ligas top.");
    if ((m.mtloading === true)) {
      msg = tx("Buscando los partidos de hoy...");
    }
    l = dttext(g, 0, 360, 1280, msg, "0xC8CCD2FF", 22, "SemiBold");
    l.horizalign = "center";
  }
}

function mtdrawrows() {
  mtdrawrow(0);
  mtdrawrow(1);
}

function mtdrawrow(k) {
  let g, now, r, row, y0, dot, tx0, lp, rc, ni, col, first, pg, j, $e4, ix, foc;
  g = m.mtgr0;
  if ((k === 1)) {
    g = m.mtgr1;
  }
  clearnode(g);
  now = $createobject("roDateTime").$asseconds();
  r = (m.mtrowfirst + k);
  if ((r < m.mtrows.$count())) {
    row = $ix(m.mtrows, r);
    y0 = (206 + (k * 220));
    if (row.live) {
      dot = addposter(g, 64, (y0 + 5), 12, 12, "pkg:/images/dot_w.png");
      dot.blendcolor = "0xEF4444FF";
      dttext(g, 84, y0, 0, row.t, "0xFFFFFFFF", 16, "Bold");
    } else {
      tx0 = 64;
      if (((row.logo != null) && (row.logo !== ""))) {
        lp = $createobject("roSGNode", "Poster");
        lp.translation = [62, (y0 - 8)];
        lp.width = 32;
        lp.height = 32;
        lp.loadwidth = 96;
        lp.loadheight = 96;
        lp.loaddisplaymode = "scaleToFit";
        lp.uri = row.logo;
        g.$appendchild(lp);
        tx0 = 104;
      }
      rc = "0xD0D4DAFF";
      if ((r === m.mtrow)) {
        rc = "0xFFFFFFFF";
      }
      dttext(g, tx0, y0, 0, $ucase(row.t), rc, 16, "Bold");
    }
    ni = row.items.$count();
    col = mtcolof(r);
    first = 0;
    if ((col > 3)) {
      first = (col - 3);
    }
    if ((ni > 4)) {
      pg = dttext(g, 1016, y0, 200, ((((col + 1)).$tostr() + " / ") + ni.$tostr()), "0x7E838CFF", 14, "Regular");
      pg.horizalign = "right";
    }
    for (j = 0, $e4 = 3; j <= $e4; j++) {
      ix = (first + j);
      if ((ix < ni)) {
        foc = (((((m.mtzone === "rows") && (r === m.mtrow)) && (col === ix)) && (m.mtpick !== true)));
        mttile(g, (64 + (j * 290)), (y0 + 30), $ix(row.items, ix), foc, now);
      }
    }
  }
}

function mtdrawfoot() {
  let g, ml, more, ml2, hint, h;
  g = m.mtgf;
  clearnode(g);
  if (((m.mtmsg != null) && (m.mtmsg !== ""))) {
    ml = dttext(g, 0, 640, 1280, m.mtmsg, "0xFF8A24FF", 17, "SemiBold");
    ml.horizalign = "center";
  }
  more = (m.mtrows.$count() - ((m.mtrowfirst + 2)));
  if (((more > 0) && (((m.mtmsg == null) || (m.mtmsg === ""))))) {
    ml2 = dttext(g, 0, 640, 1280, (((tx("Abajo: más ligas") + " (") + more.$tostr()) + ")"), "0x9A9FA8FF", 15, "SemiBold");
    ml2.horizalign = "center";
  }
  hint = tx("Flechas: mover     OK: elegir canal     Mantén OK: al mosaico     Atrás: En vivo");
  if ((m.mtzone === "chips")) {
    hint = tx("Izquierda/Derecha: elegir liga     Abajo: partidos     Atrás: En vivo");
  }
  h = dttext(g, 0, 676, 1280, hint, "0x7E838CFF", 15, "Regular");
  h.horizalign = "center";
}

function mtdrawpicklayer() {
  clearnode(m.mtgp);
  if ((m.mtpick === true)) {
    mtdrawpick(m.mtgp);
  }
}

function mtdrawchips(g) {
  let chips, ws, c, tmp, w, first, tot, i, $e5, x, y, $e6, sel, foc, fg, tx1, lp;
  chips = m.mtchips;
  if (((chips == null) || (chips.$count() <= 1))) {
    return;
  }
  ws = [];
  for (c of $iter(chips)) {
    tmp = dttext(g, (-3000), 0, 0, c.t, "0xFFFFFFFF", 16, "SemiBold");
    w = (dtw(tmp) + 36);
    if (((c.logo != null) && (c.logo !== ""))) {
      w = (w + 30);
    }
    g.$removechild(tmp);
    ws.$push(w);
  }
  first = 0;
  while ((first < m.mtchip)) {
    tot = 0;
    for (i = first, $e5 = m.mtchip; i <= $e5; i++) {
      tot = ((tot + $ix(ws, i)) + 10);
    }
    if ((tot <= 1152)) {
      break;
    }
    first = (first + 1);
  }
  x = 64;
  y = 148;
  for (i = first, $e6 = (chips.$count() - 1); i <= $e6; i++) {
    c = $ix(chips, i);
    w = $ix(ws, i);
    if (((x + w) > 1216)) {
      break;
    }
    sel = ((i === m.mtchip));
    foc = ((sel && (m.mtzone === "chips")));
    if (foc) {
      dtbox(g, (x - 3), (y - 3), (w + 6), 44, "pkg:/images/rr_pill.9.png", "0xFF8A24FF", 1.0);
      fg = "0x0A0A0FFF";
    } else if (sel) {
      dtbox(g, x, y, w, 38, "pkg:/images/rr_pill.9.png", "0xFFFFFFFF", 1.0);
      fg = "0x0A0A0FFF";
    } else {
      dtbox(g, x, y, w, 38, "pkg:/images/rr_pill.9.png", "0xFFFFFFFF", 0.09);
      fg = "0xC8CCD2FF";
    }
    tx1 = (x + 18);
    if (((c.logo != null) && (c.logo !== ""))) {
      lp = $createobject("roSGNode", "Poster");
      lp.translation = [(x + 14), (y + 7)];
      lp.width = 24;
      lp.height = 24;
      lp.loadwidth = 72;
      lp.loadheight = 72;
      lp.loaddisplaymode = "scaleToFit";
      lp.uri = c.logo;
      g.$appendchild(lp);
      tx1 = (x + 46);
    }
    dttext(g, tx1, (y + 9), 0, c.t, fg, 16, "SemiBold");
    x = ((x + w) + 10);
  }
}

function mttile(g, x, y, mt, foc, now) {
  let w, h, tg, islive, isfinal, noch, fg, sg, lc, lg, bc, lab, tmp, bw, dt, lb, tt, hasscore, names, logos, scores, i, $e7, ly, nx, lp, nw, sc, tl, ln, nc, cl, pr, bgc, fc, cc;
  w = 270;
  h = 168;
  tg = g.$createchild("Group");
  tg.translation = [x, y];
  islive = ((mt.st2 === "in"));
  isfinal = ((mt.st2 === "post"));
  noch = ((mt.ch.$count() === 0));
  if ((((noch || isfinal)) && (!foc))) {
    tg.opacity = 0.55;
  }
  if (foc) {
    dtbox(tg, (-6), (-6), (w + 12), (h + 12), "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 0.25);
    dtbox(tg, 0, 0, w, h, "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 1.0);
    fg = "0x0A0A0FFF";
    sg = "0x0A0A0FB3";
    lc = "0x0A0A0FFF";
  } else {
    dtbox(tg, 0, 0, w, h, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.07);
    fg = "0xFFFFFFFF";
    sg = "0x8A8F98FF";
    lc = "0xFF8A24FF";
  }
  lg = mt.league;
  if (((lg === "") && (mt.sport !== "soccer"))) {
    lg = tx("Más deportes");
  }
  if ((lg === "")) {
    lg = tx("Fútbol");
  }
  dttext(tg, 16, 14, 150, $ucase(cleanglyphs(lg)), lc, 12, "Bold");
  if (islive) {
    bc = "0xEF4444FF";
    if (foc) {
      bc = "0x0A0A0FFF";
    }
    lab = tx("VIVO");
    if (((!mt.est) && (mt.detail !== ""))) {
      lab = mt.detail;
    }
    tmp = dttext(tg, (-3000), 0, 0, lab, "0xFFFFFFFF", 12, "Bold");
    bw = (dtw(tmp) + 30);
    tg.$removechild(tmp);
    if ((bw > 110)) {
      bw = 110;
    }
    dtbox(tg, ((w - bw) - 12), 10, bw, 24, "pkg:/images/rr_pill.9.png", bc, 1.0);
    dt = addposter(tg, ((w - bw) - 2), 18, 8, 8, "pkg:/images/dot_w.png");
    dt.blendcolor = "0xFFFFFFFF";
    if (foc) {
      dt.blendcolor = "0xEF4444FF";
    }
    lb = dttext(tg, ((w - bw) + 10), 15, (bw - 20), lab, "0xFFFFFFFF", 12, "Bold");
  } else if (isfinal) {
    tt = dttext(tg, (w - 136), 14, 120, tx("FINAL"), fg, 14, "Bold");
    tt.horizalign = "right";
  } else {
    tt = dttext(tg, (w - 136), 12, 120, fmttimelong(mt.s2), fg, 17, "Bold");
    tt.horizalign = "right";
  }
  hasscore = ((((!mt.est) && ((islive || isfinal))) && (mt.hsc !== "")));
  if (((mt.h !== "") && (mt.a !== ""))) {
    names = [mt.h, mt.a];
    logos = [mt.hl, mt.al];
    scores = [mt.hsc, mt.asc];
    for (i = 0, $e7 = 1; i <= $e7; i++) {
      ly = (42 + (i * 38));
      nx = 16;
      if (($ix(logos, i) !== "")) {
        lp = $createobject("roSGNode", "Poster");
        lp.translation = [14, (ly - 3)];
        lp.width = 34;
        lp.height = 34;
        lp.loadwidth = 102;
        lp.loadheight = 102;
        lp.loaddisplaymode = "scaleToFit";
        lp.uri = $ix(logos, i);
        tg.$appendchild(lp);
        nx = 58;
      }
      nw = ((w - nx) - 16);
      if (hasscore) {
        nw = (nw - 34);
      }
      dttext(tg, nx, (ly + 2), nw, fittext(cleanglyphs($ix(names, i)), nw), fg, 19, "SemiBold");
      if (hasscore) {
        sc = dttext(tg, (w - 46), (ly + 1), 30, $ix(scores, i), fg, 20, "Bold");
        sc.horizalign = "right";
      }
    }
  } else {
    tl = dttext(tg, 16, 48, (w - 32), cleanglyphs(mt.full), fg, 18, "SemiBold");
    tl.wrap = true;
    tl.maxlines = 2;
  }
  ln = addrect(tg, 16, 122, (w - 32), 1, "0xFFFFFF22");
  if (foc) {
    ln.color = "0x0A0A0F33";
  }
  nc = mt.ch.$count();
  cl = (nc.$tostr() + tx(" canales"));
  if ((nc === 1)) {
    cl = tx("1 canal");
  }
  if ((nc === 0)) {
    cl = tx("Sin canal en tu lista");
  }
  if (islive) {
    pr = (((now - mt.s2)) / 6300.0);
    if ((pr < 0.03)) {
      pr = 0.03;
    }
    if ((pr > 1)) {
      pr = 1;
    }
    bgc = "0xFFFFFF26";
    fc = "0xEF4444FF";
    if (foc) {
      bgc = "0x0A0A0F33";
      fc = "0x0A0A0FFF";
    }
    addrect(tg, 16, 140, 140, 4, bgc);
    addrect(tg, 16, 140, $int((140 * pr)), 4, fc);
    cc = dttext(tg, (w - 116), 132, 100, cl, sg, 14, "Regular");
    cc.horizalign = "right";
  } else {
    dttext(tg, 16, 134, (w - 32), cl, sg, 14, "Regular");
  }
}

function mtdrawpick(g) {
  let mt, px, py, pw, chs, vis, ph, lg, top, ttl, k, $e8, ix, c, y, foc, fg, lp, ip, lab, rc;
  mt = mtcur();
  if ((mt == null)) {
    return;
  }
  addrect(g, 0, 0, 1280, 720, "0x000000B0");
  px = 360;
  py = 96;
  pw = 560;
  chs = mt.ch;
  vis = chs.$count();
  if ((vis > 7)) {
    vis = 7;
  }
  ph = (150 + (vis * 60));
  dtbox(g, px, py, pw, ph, "pkg:/images/rr_fill.9.png", "0x18181EFF", 1.0);
  lg = mt.league;
  if ((lg === "")) {
    lg = tx("Fútbol");
  }
  top = $ucase(cleanglyphs(lg));
  if ((mt.st2 === "in")) {
    top = ((top + "  ·  ") + tx("EN VIVO"));
  } else {
    top = ((top + "  ·  ") + fmttimelong(mt.s2));
  }
  dttext(g, (px + 30), (py + 28), (pw - 60), top, "0xFF8A24FF", 14, "Bold");
  ttl = cleanglyphs(mt.full);
  if (((mt.h !== "") && (mt.a !== ""))) {
    ttl = ((cleanglyphs(mt.h) + " vs ") + cleanglyphs(mt.a));
  }
  dttext(g, (px + 30), (py + 52), (pw - 60), fittext(ttl, (pw - 60)), "0xFFFFFFFF", 24, "Bold");
  dttext(g, (px + 30), (py + 90), (pw - 60), (((tx("Elige dónde verlo") + "  ·  ") + chs.$count().$tostr()) + tx(" opciones")), "0x8A8F98FF", 16, "Regular");
  if ((m.mtpickidx < m.mtpickfirst)) {
    m.mtpickfirst = m.mtpickidx;
  }
  if ((m.mtpickidx > ((m.mtpickfirst + vis) - 1))) {
    m.mtpickfirst = ((m.mtpickidx - vis) + 1);
  }
  for (k = 0, $e8 = (vis - 1); k <= $e8; k++) {
    ix = (m.mtpickfirst + k);
    if ((ix < chs.$count())) {
      c = $ix(chs, ix);
      y = ((py + 128) + (k * 60));
      foc = ((ix === m.mtpickidx));
      if (foc) {
        dtbox(g, (px + 24), y, (pw - 48), 50, "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 1.0);
        fg = "0x0A0A0FFF";
      } else {
        dtbox(g, (px + 24), y, (pw - 48), 50, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.06);
        fg = "0xFFFFFFFF";
      }
      if (((c.l != null) && (c.l !== ""))) {
        lp = $createobject("roSGNode", "Poster");
        lp.translation = [(px + 40), (y + 9)];
        lp.width = 48;
        lp.height = 32;
        lp.loadwidth = 96;
        lp.loadheight = 64;
        lp.loaddisplaymode = "scaleToFit";
        lp.uri = c.l;
        g.$appendchild(lp);
      } else {
        ip = addposter(g, (px + 52), (y + 13), 24, 24, "pkg:/images/ic_live.png");
        ip.blendcolor = fg;
      }
      lab = cleanglyphs(c.lab);
      dttext(g, (px + 102), (y + 14), (pw - 260), fittext(lab, (pw - 260)), fg, 18, "SemiBold");
      if ((ix === 0)) {
        rc = dttext(g, ((px + pw) - 180), (y + 17), 140, tx("RECOMENDADO"), fg, 12, "Bold");
        rc.horizalign = "right";
      }
    }
  }
}

function mtcur() {
  let r, items, c;
  r = m.mtrow;
  if ((((r == null) || (r < 0)) || (r >= m.mtrows.$count()))) {
    return null;
  }
  items = $ix(m.mtrows, r).items;
  c = mtcolof(r);
  if (((c < 0) || (c >= items.$count()))) {
    return null;
  }
  return $ix(items, c);
}

function mtplay(mt, c) {
  let node, ttl, fmt;
  node = $createobject("roSGNode", "ContentNode");
  ttl = cleanglyphs(mt.full);
  if (((mt.h !== "") && (mt.a !== ""))) {
    ttl = ((cleanglyphs(mt.h) + " vs ") + cleanglyphs(mt.a));
  }
  fmt = c.f;
  if (((fmt == null) || (fmt === ""))) {
    fmt = "hls";
  }
  node.$setfields({__proto__: $AAP, "title": ((ttl + "  ·  ") + cleanglyphs(c.lab)), "url": c.u, "streamformat": fmt, "hdposterurl": c.l, "description": "live"});
  m.mtpick = false;
  if ((m.mttick != null)) {
    m.mttick.control = "stop";
  }
  m.mtpanel.visible = false;
  playnode(node, "matches");
}

function matcheskey(key) {
  let mt, n, nrows, mtp, nc, ci, r, oldfirst, oldzone, c;
  if ((m.mtpick === true)) {
    mt = mtcur();
    if ((mt == null)) {
      m.mtpick = false;
      mtdraw();
      return true;
    }
    n = mt.ch.$count();
    if (((key === "back") || (key === "left"))) {
      m.mtpick = false;
    } else if ((key === "up")) {
      if ((m.mtpickidx > 0)) {
        m.mtpickidx = (m.mtpickidx - 1);
      }
    } else if ((key === "down")) {
      if ((m.mtpickidx < (n - 1))) {
        m.mtpickidx = (m.mtpickidx + 1);
      }
    } else if ((key === "OK")) {
      mtplay(mt, $ix(mt.ch, m.mtpickidx));
      return true;
    } else if ((key === "play")) {
      mosaddfrommatch(mt, $ix(mt.ch, m.mtpickidx));
      return true;
    }
    mtdrawpicklayer();
    if ((m.mtpick !== true)) {
      mtdrawrow((m.mtrow - m.mtrowfirst));
    }
    return true;
  }
  nrows = m.mtrows.$count();
  m.mtmsg = "";
  if ((key === "back")) {
    mtleave();
    return true;
  }
  if (((key === "play") && (m.mtzone !== "chips"))) {
    mtp = mtcur();
    if ((mtp != null)) {
      if ((mtp.ch.$count() === 0)) {
        m.mtmsg = tx("Este partido todavía no aparece en tu lista. Los proveedores suelen agregarlo unas horas antes.");
        mtdrawfoot();
      } else {
        mosaddfrommatch(mtp, $ix(mtp.ch, 0));
      }
    }
    return true;
  }
  if ((m.mtzone === "chips")) {
    nc = m.mtchips.$count();
    if (((key === "left") || (key === "right"))) {
      ci = m.mtchip;
      if (((key === "left") && (ci > 0))) {
        ci = (ci - 1);
      }
      if (((key === "right") && (ci < (nc - 1)))) {
        ci = (ci + 1);
      }
      if ((ci !== m.mtchip)) {
        m.mtchip = ci;
        m.mtfilter = $ix(m.mtchips, ci).f;
        mtbuild(false);
        m.mtzone = "chips";
        m.mtsig = "";
      }
    } else if (((key === "down") || (key === "OK"))) {
      if ((nrows > 0)) {
        m.mtzone = "rows";
      }
    }
    mtdraw();
    return true;
  }
  r = m.mtrow;
  oldfirst = m.mtrowfirst;
  oldzone = m.mtzone;
  if ((key === "up")) {
    if ((r > 0)) {
      m.mtrow = (r - 1);
    } else {
      m.mtzone = "chips";
    }
  } else if ((key === "down")) {
    if ((r < (nrows - 1))) {
      m.mtrow = (r + 1);
    }
  } else if ((key === "left")) {
    c = mtcolof(r);
    if ((c > 0)) {
      mtsetcol(r, (c - 1));
    }
  } else if ((key === "right")) {
    c = mtcolof(r);
    if (((r < nrows) && (c < ($ix(m.mtrows, r).items.$count() - 1)))) {
      mtsetcol(r, (c + 1));
    }
  } else if ((key === "OK")) {
    mt = mtcur();
    if ((mt != null)) {
      if ((mt.ch.$count() === 0)) {
        m.mtmsg = tx("Este partido todavía no aparece en tu lista. Los proveedores suelen agregarlo unas horas antes.");
      } else if ((mt.ch.$count() === 1)) {
        mtplay(mt, $ix(mt.ch, 0));
        return true;
      } else {
        m.mtpick = true;
        m.mtpickidx = 0;
        m.mtpickfirst = 0;
      }
    }
  }
  if ((m.mtrow < m.mtrowfirst)) {
    m.mtrowfirst = m.mtrow;
  }
  if ((m.mtrow > (m.mtrowfirst + 1))) {
    m.mtrowfirst = (m.mtrow - 1);
  }
  if (((key === "left") || (key === "right"))) {
    mtdrawrow((m.mtrow - m.mtrowfirst));
  } else if ((key === "OK")) {
    mtdrawrow((m.mtrow - m.mtrowfirst));
    mtdrawpicklayer();
  } else {
    if ((m.mtzone !== oldzone)) {
      mtdrawhead();
    }
    mtdrawrows();
  }
  mtdrawfoot();
  return true;
}
// ---- components/liveinfo.brs ----
function liveinfosoon() {
  let t;
  if ((m.liveinfotimer == null)) {
    t = $createobject("roSGNode", "Timer");
    t.duration = 0.12;
    t.repeat = false;
    t.$observefield("fire", "onLiveInfoTimer");
    m.top.$appendchild(t);
    m.liveinfotimer = t;
  }
  m.liveinfotimer.control = "stop";
  m.liveinfotimer.control = "start";
}

function onchannelfocused() {
  if (m.listspanel.visible) {
    liveinfosoon();
  }
}

function onliveinfotimer() {
  if ((!m.listspanel.visible)) {
    return;
  }
  try {
    livewindow();
    liveinfodraw();
  } catch (e) {
    console.log("[LIVE] error: ", e.message);
  }
}

function livefocusedcat() {
  let ci;
  if ((m.root == null)) {
    return null;
  }
  ci = m.categorylist.itemfocused;
  if (((ci < 0) || (ci >= m.root.$getchildcount()))) {
    return null;
  }
  return m.root.$getchild(ci);
}

function livewindow() {
  let cat, n, f, a, b, hasepg, hasicons, j, $e0, now, $e1, ch, cur, u, nn, p, pct, txt;
  cat = livefocusedcat();
  if ((cat == null)) {
    return;
  }
  n = cat.$getchildcount();
  if ((n === 0)) {
    return;
  }
  f = m.channellist.itemfocused;
  if ((f < 0)) {
    f = 0;
  }
  a = (f - 10);
  b = (f + 12);
  if ((a < 0)) {
    a = 0;
  }
  if ((b > (n - 1))) {
    b = (n - 1);
  }
  hasepg = ((((m.epg != null) && (m.epg.programs != null)) && (m.epg.programs.$count() > 0)));
  hasicons = ((((m.epg != null) && (m.epg.icons != null)) && (m.epg.icons.$count() > 0)));
  for (j = a, $e0 = b; j <= $e0; j++) {
    favsync(cat.$getchild(j));
  }
  if (((!hasepg) && (!hasicons))) {
    return;
  }
  now = $createobject("roDateTime").$asseconds();
  for (j = a, $e1 = b; j <= $e1; j++) {
    ch = cat.$getchild(j);
    if (hasicons) {
      cur = ch.hdposterurl;
      if (((cur == null) || (cur === ""))) {
        u = iconfor(ch);
        if ((u !== "")) {
          ch.hdposterurl = u;
        }
      }
    }
    if (hasepg) {
      nn = getnownext(ch);
      if ((nn.cur != null)) {
        p = nn.cur;
        pct = 0;
        if ((p.e > p.s)) {
          pct = $int(((((now - p.s)) * 100) / ((p.e - p.s))));
        }
        if ((pct < 1)) {
          pct = 1;
        }
        if ((pct > 100)) {
          pct = 100;
        }
        txt = ((fmttime(p.s) + "  ") + p.t);
        if ((ch.playstart !== pct)) {
          ch.playstart = pct;
        }
        if ((ch.releasedate !== txt)) {
          ch.releasedate = txt;
        }
      } else if (((ch.releasedate != null) && (ch.releasedate !== ""))) {
        ch.playstart = 0;
        ch.releasedate = "";
      }
    }
  }
}

function liveinfodraw() {
  let g, cat, f, ch, x, y, w, pad, iw, logo, lp, ip, num, meta, nm, ny, nn, p, now, pt, pr, minsleft, lt, q, qt, sl, hy, ok, fv, fl;
  g = m.top.$findnode("chInfo");
  if ((g == null)) {
    return;
  }
  clearnode(g);
  if ((m.pip === true)) {
    return;
  }
  cat = livefocusedcat();
  if (((cat == null) || (cat.$getchildcount() === 0))) {
    return;
  }
  f = m.channellist.itemfocused;
  if ((f < 0)) {
    f = 0;
  }
  if ((f >= cat.$getchildcount())) {
    f = (cat.$getchildcount() - 1);
  }
  ch = cat.$getchild(f);
  if ((ch == null)) {
    return;
  }
  x = 876;
  y = 76;
  w = 356;
  pad = 22;
  iw = (w - (pad * 2));
  dtbox(g, x, y, w, 552, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.05);
  dtbox(g, x, y, w, 552, "pkg:/images/rr_line.9.png", "0xFFFFFFFF", 0.08);
  logo = ch.hdposterurl;
  if ((logo == null)) {
    logo = "";
  }
  if ((logo !== "")) {
    lp = $createobject("roSGNode", "Poster");
    lp.translation = [(x + pad), (y + 22)];
    lp.width = 150;
    lp.height = 84;
    lp.loadwidth = 300;
    lp.loadheight = 168;
    lp.loaddisplaymode = "scaleToFit";
    lp.uri = logo;
    g.$appendchild(lp);
  } else {
    ip = addposter(g, (x + pad), (y + 32), 56, 56, "pkg:/images/ic_live.png");
    ip.blendcolor = "0x8A8F98FF";
    ip.opacity = 0.6;
  }
  if ((ch.starrating === 100)) {
    addposter(g, (((x + w) - pad) - 26), (y + 24), 26, 26, "pkg:/images/heart_on.png");
  }
  num = ch.shortdescriptionline1;
  if ((num == null)) {
    num = "";
  }
  meta = $ucase(cleancatname(cat.id));
  if ((num !== "")) {
    meta = ((((tx("CANAL") + " ") + num) + "  ·  ") + meta);
  }
  dttext(g, (x + pad), (y + 120), iw, fittext(meta, iw), "0xFF8A24FF", 12, "Bold");
  nm = dttext(g, (x + pad), (y + 140), iw, cleanglyphs(ch.title), "0xFFFFFFFF", 23, "Bold");
  nm.wrap = true;
  nm.maxlines = 2;
  ny = (y + 212);
  addrect(g, (x + pad), ny, iw, 1, "0xFFFFFF1F");
  nn = null;
  if ((((m.epg != null) && (m.epg.programs != null)) && (m.epg.programs.$count() > 0))) {
    nn = getnownext(ch);
  }
  if (((nn != null) && (nn.cur != null))) {
    p = nn.cur;
    now = $createobject("roDateTime").$asseconds();
    dttext(g, (x + pad), (ny + 18), 0, tx("AHORA"), "0xFF8A24FF", 12, "Bold");
    pt = dttext(g, (x + pad), (ny + 38), iw, p.t, "0xFFFFFFFF", 19, "SemiBold");
    pt.wrap = true;
    pt.maxlines = 2;
    dttext(g, (x + pad), (ny + 98), iw, ((fmttime(p.s) + " - ") + fmttime(p.e)), "0x9AA0A8FF", 14, "Regular");
    pr = 0.0;
    if ((p.e > p.s)) {
      pr = (((now - p.s)) / ((p.e - p.s)));
    }
    if ((pr < 0.02)) {
      pr = 0.02;
    }
    if ((pr > 1)) {
      pr = 1;
    }
    addrect(g, (x + pad), (ny + 126), iw, 4, "0xFFFFFF26");
    addrect(g, (x + pad), (ny + 126), $int((iw * pr)), 4, "0xFF8A24FF");
    minsleft = $int((((p.e - now)) / 60));
    if ((minsleft > 0)) {
      lt = dttext(g, (x + pad), (ny + 136), iw, ((tx("Quedan ") + minsleft.$tostr()) + " min"), "0x9AA0A8FF", 13, "Regular");
      lt.horizalign = "right";
    }
    if ((nn.nxt != null)) {
      q = nn.nxt;
      dttext(g, (x + pad), (ny + 166), 0, tx("DESPUÉS"), "0x9AA0A8FF", 12, "Bold");
      qt = dttext(g, (x + pad), (ny + 186), iw, q.t, "0xD8DCE2FF", 17, "SemiBold");
      qt.wrap = true;
      qt.maxlines = 2;
      dttext(g, (x + pad), (ny + 236), iw, ((fmttime(q.s) + " - ") + fmttime(q.e)), "0x7E838CFF", 13, "Regular");
    }
  } else {
    sl = dttext(g, (x + pad), (ny + 20), iw, tx("Sin guía de programación para este canal."), "0x9AA0A8FF", 15, "Regular");
    sl.wrap = true;
    sl.maxlines = 2;
  }
  hy = (y + 486);
  dtbox(g, (x + pad), hy, 96, 34, "pkg:/images/rr_pill.9.png", "0xFFFFFFFF", 0.1);
  ok = dttext(g, (x + pad), (hy + 8), 96, tx("OK  Ver"), "0xFFFFFFFF", 14, "SemiBold");
  ok.horizalign = "center";
  fv = tx("Play  Favorito");
  if ((ch.starrating === 100)) {
    fv = tx("Play  Quitar");
  }
  dtbox(g, ((x + pad) + 106), hy, 150, 34, "pkg:/images/rr_pill.9.png", "0xFFFFFFFF", 0.1);
  fl = dttext(g, ((x + pad) + 106), (hy + 8), 150, fv, "0xFFFFFFFF", 14, "SemiBold");
  fl.horizalign = "center";
}
// ---- components/ui.brs ----
function kbopen(title, text, stage, oklabel) {
  m.uilayer = m.top.$findnode("uiLayer");
  m.uikind = "kb";
  m.uiopen = true;
  m.kbtitle = title;
  m.kbtext = text;
  m.kbstage = stage;
  m.kbok = oklabel;
  m.kbshift = false;
  m.kbsym = false;
  m.kbrow = 0;
  m.kbcol = 0;
  capturekeys();
  m.uilayer.visible = true;
  kbdrawall();
}

function kbclose(button) {
  let txt, stage;
  txt = m.kbtext.$trim();
  stage = m.kbstage;
  m.uiopen = false;
  m.uikind = "";
  clearnode(m.uilayer);
  m.uilayer.visible = false;
  kbhandle(button, txt, stage);
}

function kbrows() {
  let rows, base, line, r, i, $e0, ch, lab, nums, d, sh, sy;
  rows = [];
  if (m.kbsym) {
    base = ["/:?=&%#+~!", "*,;()[]{}$", (("'" + $chr(34)) + "<>|\\^`.@")];
  } else {
    base = ["abcdefghij", "klmnopqrst", "uvwxyz.-_@"];
  }
  for (line of $iter(base)) {
    r = [];
    for (i = 1, $e0 = $len(line); i <= $e0; i++) {
      ch = $mid(line, i, 1);
      lab = ch;
      if ((m.kbshift && (!m.kbsym))) {
        lab = $ucase(ch);
      }
      r.$push({__proto__: $AAP, "t": lab, "v": lab, "w": 84});
    }
    rows.$push(r);
  }
  nums = [];
  for (d of $iter(["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"])) {
    nums.$push({__proto__: $AAP, "t": d, "v": d, "w": 84});
  }
  rows.$push(nums);
  sh = "ABC";
  if (m.kbshift) {
    sh = "abc";
  }
  sy = "#+=";
  if (m.kbsym) {
    sy = "ABC";
  }
  rows.$push([{__proto__: $AAP, "t": sh, "v": "@shift", "w": 104}, {__proto__: $AAP, "t": sy, "v": "@sym", "w": 104}, {__proto__: $AAP, "t": tx("Espacio"), "v": " ", "w": 208}, {__proto__: $AAP, "t": tx("Borrar"), "v": "@del", "w": 124}, {__proto__: $AAP, "t": tx("Limpiar"), "v": "@clear", "w": 124}, {__proto__: $AAP, "t": ".com", "v": ".com", "w": 96}, {__proto__: $AAP, "t": "http://", "v": "http://", "w": 112}]);
  rows.$push([{__proto__: $AAP, "t": m.kbok, "v": "@ok", "w": 300}, {__proto__: $AAP, "t": tx("Cancelar"), "v": "@cancel", "w": 200}]);
  return rows;
}

function kbdrawall() {
  let g, gl, y, r, $e1, row, tw, k, x, h, nrow, c, $e2, bg, sz, lb, h2;
  g = m.uilayer;
  clearnode(g);
  addrect(g, 0, 0, 1280, 720, "0x07070AF2");
  gl = addposter(g, (-200), (-260), 900, 700, "pkg:/images/glow.png");
  gl.blendcolor = "0xFF8A24FF";
  gl.opacity = 0.18;
  dttext(g, 184, 52, 0, tx("ESCRIBE CON EL CONTROL"), "0xFF8A24FF", 14, "Bold");
  dttext(g, 184, 72, 912, m.kbtitle, "0xFFFFFFFF", 28, "Bold");
  dtbox(g, 184, 128, 912, 66, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.07);
  addrect(g, 196, 190, 888, 2, "0xFF8A24FF");
  m.kbfield = g.$createchild("Group");
  kbdrawfield();
  m.kblayout = kbrows();
  m.kbnodes = [];
  y = 222;
  for (r = 0, $e1 = (m.kblayout.$count() - 1); r <= $e1; r++) {
    row = $ix(m.kblayout, r);
    tw = 0;
    for (k of $iter(row)) {
      tw = (tw + k.w);
    }
    tw = (tw + (((row.$count() - 1)) * 8));
    x = $int((((1280 - tw)) / 2));
    h = 54;
    if ((r === (m.kblayout.$count() - 1))) {
      y = (y + 14);
      h = 56;
    }
    nrow = [];
    for (c = 0, $e2 = (row.$count() - 1); c <= $e2; c++) {
      k = $ix(row, c);
      k.x = x;
      bg = dtbox(g, x, y, k.w, h, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.07);
      sz = 22;
      if (($len(k.t) > 1)) {
        sz = 16;
      }
      lb = dttext(g, x, ((y + $int((((h - sz)) / 2))) - 2), k.w, k.t, "0xFFFFFFFF", sz, "SemiBold");
      lb.horizalign = "center";
      nrow.$push({__proto__: $AAP, "bg": bg, "lb": lb});
      x = ((x + k.w) + 8);
    }
    m.kbnodes.$push(nrow);
    y = ((y + h) + 8);
  }
  h2 = dttext(g, 0, 676, 1280, tx("Flechas + OK: escribir     Play: borrar     Atrás: cancelar"), "0x7E838CFF", 15, "Regular");
  h2.horizalign = "center";
  if ((m.kbrow >= m.kblayout.$count())) {
    m.kbrow = 0;
  }
  if ((m.kbcol >= $ix(m.kblayout, m.kbrow).$count())) {
    m.kbcol = ($ix(m.kblayout, m.kbrow).$count() - 1);
  }
  kbpaint(m.kbrow, m.kbcol, true);
}

function kbpaint(r, c, foc) {
  let n, k, isok, ison;
  if (((r < 0) || (r >= m.kbnodes.$count()))) {
    return;
  }
  if (((c < 0) || (c >= $ix(m.kbnodes, r).$count()))) {
    return;
  }
  n = $ix($ix(m.kbnodes, r), c);
  k = $ix($ix(m.kblayout, r), c);
  isok = ((k.v === "@ok"));
  ison = (((((k.v === "@shift") && m.kbshift)) || (((k.v === "@sym") && m.kbsym))));
  if (foc) {
    n.bg.blendcolor = "0xFF8A24FF";
    n.bg.opacity = 1.0;
    n.lb.color = "0x0A0A0FFF";
  } else if (isok) {
    n.bg.blendcolor = "0xFFFFFFFF";
    n.bg.opacity = 1.0;
    n.lb.color = "0x0A0A0FFF";
  } else if (ison) {
    n.bg.blendcolor = "0xFF8A24FF";
    n.bg.opacity = 0.35;
    n.lb.color = "0xFFFFFFFF";
  } else {
    n.bg.blendcolor = "0xFFFFFFFF";
    n.bg.opacity = 0.07;
    n.lb.color = "0xFFFFFFFF";
  }
}

function kbdrawfield() {
  let g, t, shown, l;
  g = m.kbfield;
  clearnode(g);
  t = m.kbtext;
  shown = t;
  if (($len(shown) > 52)) {
    shown = ("..." + $right(shown, 50));
  }
  if ((t === "")) {
    dttext(g, 206, 148, 860, tx("Empieza a escribir..."), "0x5E636CFF", 22, "Regular");
    addrect(g, 204, 146, 2, 30, "0xFF8A24FF");
  } else {
    l = dttext(g, 206, 147, 0, shown, "0xFFFFFFFF", 23, "Regular");
    addrect(g, ((206 + dtw(l)) + 3), 146, 2, 30, "0xFF8A24FF");
  }
}

function kbkey(key) {
  let rows, r, c;
  rows = m.kblayout;
  r = m.kbrow;
  c = m.kbcol;
  if ((key === "back")) {
    kbclose(1);
    return true;
  } else if ((((key === "play") || (key === "rev")) || (key === "replay"))) {
    kbpress("@del");
    return true;
  } else if ((key === "left")) {
    if ((c > 0)) {
      kbmove(r, (c - 1));
    } else {
      kbmove(r, ($ix(rows, r).$count() - 1));
    }
  } else if ((key === "right")) {
    if ((c < ($ix(rows, r).$count() - 1))) {
      kbmove(r, (c + 1));
    } else {
      kbmove(r, 0);
    }
  } else if ((key === "up")) {
    if ((r > 0)) {
      kbmove((r - 1), kbnear(r, c, (r - 1)));
    }
  } else if ((key === "down")) {
    if ((r < (rows.$count() - 1))) {
      kbmove((r + 1), kbnear(r, c, (r + 1)));
    }
  } else if ((key === "OK")) {
    kbpress($ix($ix(rows, r), c).v);
  }
  return true;
}

function kbnear(r, c, r2) {
  let k, cx, best, bd, row, i, $e3, d;
  k = $ix($ix(m.kblayout, r), c);
  cx = (k.x + (k.w / 2));
  best = 0;
  bd = 99999;
  row = $ix(m.kblayout, r2);
  for (i = 0, $e3 = (row.$count() - 1); i <= $e3; i++) {
    d = $abs((($ix(row, i).x + ($ix(row, i).w / 2)) - cx));
    if ((d < bd)) {
      bd = d;
      best = i;
    }
  }
  return best;
}

function kbmove(r, c) {
  kbpaint(m.kbrow, m.kbcol, false);
  m.kbrow = r;
  m.kbcol = c;
  kbpaint(r, c, true);
}

function kbpress(v) {
  if ((v === "@ok")) {
    kbclose(0);
  } else if ((v === "@cancel")) {
    kbclose(1);
  } else if ((v === "@del")) {
    if (($len(m.kbtext) > 0)) {
      m.kbtext = $left(m.kbtext, ($len(m.kbtext) - 1));
    }
    kbdrawfield();
  } else if ((v === "@clear")) {
    m.kbtext = "";
    kbdrawfield();
  } else if ((v === "@shift")) {
    m.kbshift = (!m.kbshift);
    kbdrawall();
  } else if ((v === "@sym")) {
    m.kbsym = (!m.kbsym);
    kbdrawall();
  } else {
    if (($len(m.kbtext) < 600)) {
      m.kbtext = (m.kbtext + v);
    }
    kbdrawfield();
  }
}

function uiask(title, lines, buttons, cb) {
  m.uilayer = m.top.$findnode("uiLayer");
  m.uikind = "dlg";
  m.uiopen = true;
  m.uititle = title;
  m.uilines = lines;
  m.uibtns = buttons;
  m.uicb = cb;
  m.uisel = 0;
  m.uibtn = (-1);
  capturekeys();
  m.uilayer.visible = true;
  uidraw();
}

function uidraw() {
  let g, w, nb, nl, h, x, y, tl, yy, i, $e4, $e5, bg, lb;
  g = m.uilayer;
  clearnode(g);
  addrect(g, 0, 0, 1280, 720, "0x000000C8");
  w = 560;
  nb = m.uibtns.$count();
  nl = 0;
  if ((m.uilines != null)) {
    nl = m.uilines.$count();
  }
  h = ((120 + (nl * 28)) + (nb * 62));
  x = $int((((1280 - w)) / 2));
  y = $int((((720 - h)) / 2));
  dtbox(g, x, y, w, h, "pkg:/images/rr_fill.9.png", "0x18181EFF", 1.0);
  dtbox(g, x, y, w, h, "pkg:/images/rr_line.9.png", "0xFFFFFFFF", 0.08);
  tl = dttext(g, (x + 32), (y + 28), (w - 64), m.uititle, "0xFFFFFFFF", 24, "Bold");
  yy = (y + 72);
  for (i = 0, $e4 = (nl - 1); i <= $e4; i++) {
    dttext(g, (x + 32), yy, (w - 64), fittext(cleanglyphs($ix(m.uilines, i)), (w - 64)), "0x9AA0A8FF", 16, "Regular");
    yy = (yy + 28);
  }
  yy = (yy + 14);
  m.uinodes = [];
  for (i = 0, $e5 = (nb - 1); i <= $e5; i++) {
    bg = dtbox(g, (x + 24), yy, (w - 48), 52, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.07);
    lb = dttext(g, (x + 44), (yy + 15), (w - 88), $ix(m.uibtns, i), "0xFFFFFFFF", 18, "SemiBold");
    m.uinodes.$push({__proto__: $AAP, "bg": bg, "lb": lb});
    yy = (yy + 62);
  }
  uipaint();
}

function uipaint() {
  let i, $e6, n;
  for (i = 0, $e6 = (m.uinodes.$count() - 1); i <= $e6; i++) {
    n = $ix(m.uinodes, i);
    if ((i === m.uisel)) {
      n.bg.blendcolor = "0xFF8A24FF";
      n.bg.opacity = 1.0;
      n.lb.color = "0x0A0A0FFF";
    } else {
      n.bg.blendcolor = "0xFFFFFFFF";
      n.bg.opacity = 0.07;
      n.lb.color = "0xFFFFFFFF";
    }
  }
}

function dlgkey(key) {
  if ((key === "up")) {
    if ((m.uisel > 0)) {
      m.uisel = (m.uisel - 1);
      uipaint();
    }
  } else if ((key === "down")) {
    if ((m.uisel < (m.uibtns.$count() - 1))) {
      m.uisel = (m.uisel + 1);
      uipaint();
    }
  } else if ((key === "OK")) {
    uifinish(m.uisel);
  } else if ((key === "back")) {
    uifinish((-1));
  }
  return true;
}

function uifinish(idx) {
  let cb;
  m.uibtn = idx;
  m.uiopen = false;
  m.uikind = "";
  clearnode(m.uilayer);
  m.uilayer.visible = false;
  cb = m.uicb;
  if ((cb === "onOptionsButton")) {
    onoptionsbutton();
  }
  if ((cb === "onDeleteButton")) {
    ondeletebutton();
  }
  if ((cb === "onXtOptions")) {
    onxtoptions();
  }
  if ((cb === "onXtDelete")) {
    onxtdelete();
  }
  if ((cb === "onExitButton")) {
    onexitbutton();
  }
  if ((cb === "onMosOpt")) {
    onmosopt();
  }
}

function uikey(key) {
  if ((m.uikind === "kb")) {
    return kbkey(key);
  }
  return dlgkey(key);
}
// ---- components/cw.brs ----
function cwload() {
  let obj;
  m.cw = [];
  if ((!m.sec.$exists("cw"))) {
    return;
  }
  obj = $parsejson(m.sec.$read("cw"));
  if (($type(obj) === "roArray")) {
    m.cw = obj;
  }
}

function cwsave() {
  m.sec.$write("cw", $formatjson(m.cw));
  m.sec.$flush();
}

function cwfor(kind) {
  let out, e;
  out = [];
  if ((m.cw == null)) {
    cwload();
  }
  for (e of $iter(m.cw)) {
    if ((e.k === kind)) {
      out.$push(e);
    }
    if ((out.$count() >= 4)) {
      break;
    }
  }
  return out;
}

function cwbegin(item, backto) {
  let ser, season, sname, snum, epn, th, nx, nxnode, nxseason, s2, nl, ne, nt, et, b, l;
  m.cwcur = null;
  if ((((item == null) || (item.url == null)) || (item.url === ""))) {
    return;
  }
  if ((m.adultctx === true)) {
    return;
  }
  if ((backto === "cw")) {
    m.cwcur = m.cwplayentry;
    return;
  }
  if ((item.description !== "movie")) {
    return;
  }
  if (((backto === "episodes") && (m.epseries != null))) {
    ser = m.epseries;
    season = ser.$getchild(m.epseason);
    if ((season == null)) {
      return;
    }
    sname = cleantitle(ser.title);
    snum = season.id;
    epn = item.shortdescriptionline1;
    if ((epn == null)) {
      epn = "";
    }
    th = item.hdposterurl;
    if (((th == null) || (th === ""))) {
      th = ser.hdposterurl;
    }
    if ((th == null)) {
      th = "";
    }
    nx = null;
    nxnode = null;
    nxseason = snum;
    if (((m.epidx + 1) < season.$getchildcount())) {
      nxnode = season.$getchild((m.epidx + 1));
    } else if (((m.epseason + 1) < ser.$getchildcount())) {
      s2 = ser.$getchild((m.epseason + 1));
      if ((s2.$getchildcount() > 0)) {
        nxnode = s2.$getchild(0);
        nxseason = s2.id;
      }
    }
    if ((((nxnode != null) && (nxnode.url != null)) && (nxnode.url !== ""))) {
      nl = nxnode.hdposterurl;
      if (((nl == null) || (nl === ""))) {
        nl = th;
      }
      ne = nxnode.shortdescriptionline1;
      if ((ne == null)) {
        ne = "";
      }
      nt = nxnode.shortdescriptionline2;
      if ((nt == null)) {
        nt = "";
      }
      nx = {__proto__: $AAP, "u": nxnode.url, "f": mts0(nxnode.streamformat), "l": nl, "se": ((("T" + nxseason) + " · E") + ne), "ep": nt};
    }
    et = item.shortdescriptionline2;
    if ((et == null)) {
      et = "";
    }
    m.cwcur = {__proto__: $AAP, "k": "series", "u": item.url, "f": mts0(item.streamformat), "t": sname, "l": th, "b": "", "se": ((("T" + snum) + " · E") + epn), "ep": et, "nx": nx};
  } else {
    b = "";
    if (((((m.dtitem != null) && m.dtitem.$issamenode(item)) && (m.dtimgmode === "full")) && (m.dtimguri != null))) {
      b = m.dtimguri;
    }
    l = item.hdposterurl;
    if ((l == null)) {
      l = "";
    }
    m.cwcur = {__proto__: $AAP, "k": "movie", "u": item.url, "f": mts0(item.streamformat), "t": cleantitle(item.title), "l": l, "b": b, "se": "", "ep": "", "nx": null};
  }
}

function mts0(v) {
  if ((v == null)) {
    return "";
  }
  return v;
}

function cwtick(vpos, dur) {
  let c, kept, e, now, done, n;
  c = m.cwcur;
  if ((((c == null) || (vpos == null)) || (dur == null))) {
    return;
  }
  if ((dur < 300)) {
    return;
  }
  if ((m.cw == null)) {
    cwload();
  }
  kept = [];
  for (e of $iter(m.cw)) {
    if ((e.u !== c.u)) {
      kept.$push(e);
    }
  }
  m.cw = kept;
  now = $createobject("roDateTime").$asseconds();
  done = (((vpos >= (dur * 0.95)) || (vpos >= (dur - 60))));
  if (done) {
    if (((c.k === "series") && (c.nx != null))) {
      n = c.nx;
      m.cw.$unshift({__proto__: $AAP, "k": "series", "u": n.u, "f": n.f, "t": c.t, "l": n.l, "b": "", "se": n.se, "ep": n.ep, "p": 0, "d": 0, "ts": now, "nxt": true});
    }
  } else if ((vpos >= 60)) {
    m.cw.$unshift({__proto__: $AAP, "k": c.k, "u": c.u, "f": c.f, "t": c.t, "l": c.l, "b": c.b, "se": c.se, "ep": c.ep, "p": $int(vpos), "d": $int(dur), "ts": now, "nx": c.nx});
  }
  while ((m.cw.$count() > 12)) {
    m.cw.$pop();
  }
  cwsave();
}

function cwkind() {
  if ((m.mode === "series")) {
    return "series";
  }
  if ((m.mode === "movies")) {
    return "movie";
  }
  return "";
}

function cwitems() {
  let k;
  k = cwkind();
  if ((k === "")) {
    return [];
  }
  return cwfor(k);
}

function cwlayout(show) {
  let wrap, row, an, vi;
  wrap = m.top.$findnode("movieWrap");
  row = m.top.$findnode("cwRow");
  if (((wrap == null) || (row == null))) {
    return;
  }
  if ((m.cwshown === show)) {
    return;
  }
  m.cwshown = show;
  an = m.top.$findnode("cwSlide");
  vi = m.top.$findnode("cwSlideI");
  an.control = "stop";
  if (show) {
    vi.keyvalue = [wrap.translation, [0, 200]];
    wrap.clippingrect = [0, 0, 1280, 400];
    row.visible = true;
  } else {
    vi.keyvalue = [wrap.translation, [0, 0]];
    wrap.clippingrect = [(-4000), (-4000), 9000, 9000];
    row.visible = false;
  }
  an.control = "start";
}

function cwdraw() {
  let row, items, i, $e0, e, foc, w, h, x, y, g, img, p, gb, meta, lefttxt, pr, mins, hrs, lt, fw, pi;
  row = m.top.$findnode("cwRow");
  if ((row == null)) {
    return;
  }
  clearnode(row);
  items = m.cwlist;
  if (((items == null) || (items.$count() === 0))) {
    return;
  }
  dttext(row, 64, 74, 0, tx("SEGUIR VIENDO"), "0xFFFFFFFF", 15, "Bold");
  if ((m.cwidx >= items.$count())) {
    m.cwidx = (items.$count() - 1);
  }
  for (i = 0, $e0 = (items.$count() - 1); i <= $e0; i++) {
    e = $ix(items, i);
    foc = (((m.movside === "cw") && (i === m.cwidx)));
    w = 270;
    h = 152;
    x = (64 + (i * 290));
    y = 102;
    g = row.$createchild("Group");
    g.translation = [x, y];
    if (foc) {
      g.scalerotatecenter = [(w / 2), (h / 2)];
      g.scale = [1.05, 1.05];
      dtbox(g, (-5), (-5), (w + 10), (h + 10), "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 1.0);
    }
    dtbox(g, 0, 0, w, h, "pkg:/images/rr_fill.9.png", "0x1C1C24FF", 1.0);
    img = e.b;
    if (((img == null) || (img === ""))) {
      img = e.l;
    }
    if (((img != null) && (img !== ""))) {
      p = $createobject("roSGNode", "Poster");
      p.width = w;
      p.height = h;
      p.loadwidth = (w * 2);
      p.loadheight = (h * 2);
      p.loaddisplaymode = "scaleToZoom";
      p.failedbitmapuri = emptycover("t");
      p.uri = img;
      g.$appendchild(p);
    } else {
      addposter(g, 0, 0, w, h, emptycover("t"));
    }
    gb = addposter(g, 0, 40, w, (h - 40), "pkg:/images/grad_bottom.png");
    gb.loaddisplaymode = "scaleToFill";
    dttext(g, 14, (h - 62), (w - 28), fittext(cleanglyphs(e.t), (w - 28)), "0xFFFFFFFF", 16, "SemiBold");
    meta = tx("Película");
    if ((e.k === "series")) {
      meta = e.se;
      if ((e.nxt === true)) {
        meta = (tx("Siguiente: ") + e.se);
      }
    }
    dttext(g, 14, (h - 38), 150, meta, "0xC8CCD2FF", 12, "Regular");
    lefttxt = "";
    pr = 0.0;
    if (((e.d != null) && (e.d > 0))) {
      pr = (e.p / e.d);
      mins = $int((((e.d - e.p)) / 60));
      if ((mins >= 60)) {
        hrs = $int((mins / 60));
        lefttxt = ((((tx("Quedan ") + hrs.$tostr()) + " h ") + pad2((mins % 60))) + " min");
      } else {
        lefttxt = ((tx("Quedan ") + mins.$tostr()) + " min");
      }
    } else if ((e.nxt === true)) {
      lefttxt = tx("Empezar");
    }
    if ((lefttxt !== "")) {
      lt = dttext(g, 120, (h - 38), (w - 134), lefttxt, "0xC8CCD2FF", 12, "Regular");
      lt.horizalign = "right";
    }
    addrect(g, 14, (h - 16), (w - 28), 4, "0xFFFFFF46");
    if ((pr > 0)) {
      fw = $int((((w - 28)) * pr));
      if ((fw < 4)) {
        fw = 4;
      }
      addrect(g, 14, (h - 16), fw, 4, "0xFF8A24FF");
    }
    if (foc) {
      dtbox(g, ((w / 2) - 26), ((h / 2) - 44), 52, 52, "pkg:/images/rr_pill.9.png", "0x000000FF", 0.55);
      pi = addposter(g, ((w / 2) - 11), ((h / 2) - 30), 24, 24, "pkg:/images/ic_play.png");
      pi.blendcolor = "0xFFFFFFFF";
    }
  }
}

function cwupdate() {
  let has, show;
  m.cwlist = cwitems();
  has = (((m.cwlist.$count() > 0) && (m.vson !== true)));
  if (((!has) && (m.movside === "cw"))) {
    m.movside = "grid";
  }
  show = (has && (((m.movside === "cw") || (m.movside === "bar"))));
  cwlayout(show);
  if (show) {
    cwdraw();
  }
}

function cwkey(key) {
  let n;
  n = m.cwlist.$count();
  if ((key === "left")) {
    if ((m.cwidx > 0)) {
      m.cwidx = (m.cwidx - 1);
    }
  } else if ((key === "right")) {
    if ((m.cwidx < (n - 1))) {
      m.cwidx = (m.cwidx + 1);
    }
  } else if ((key === "down")) {
    m.movside = "bar";
    if ((m.baridx == null)) {
      m.baridx = 0;
    }
  } else if ((key === "back")) {
    showhome();
    return true;
  } else if ((key === "OK")) {
    if (((m.cwidx >= 0) && (m.cwidx < n))) {
      cwplay($ix(m.cwlist, m.cwidx));
    }
    return true;
  } else if ((key === "play")) {
    if (((m.cwidx >= 0) && (m.cwidx < n))) {
      cwremove($ix(m.cwlist, m.cwidx));
    }
  }
  drawmovies();
  return true;
}

function cwremove(e) {
  let kept, x;
  kept = [];
  for (x of $iter(m.cw)) {
    if ((x.u !== e.u)) {
      kept.$push(x);
    }
  }
  m.cw = kept;
  cwsave();
  if ((m.cwidx > 0)) {
    m.cwidx = (m.cwidx - 1);
  }
}

function cwplay(e) {
  let node, ttl, fmt;
  node = $createobject("roSGNode", "ContentNode");
  ttl = e.t;
  if ((e.k === "series")) {
    ttl = ((e.t + "  ") + e.se);
  }
  fmt = e.f;
  if (((fmt == null) || (fmt === ""))) {
    fmt = "mp4";
  }
  node.$setfields({__proto__: $AAP, "title": ttl, "url": e.u, "streamformat": fmt, "hdposterurl": e.l, "description": "movie"});
  m.cwplayentry = {__proto__: $AAP, "k": e.k, "u": e.u, "f": e.f, "t": e.t, "l": e.l, "b": e.b, "se": e.se, "ep": e.ep, "nx": e.nx};
  m.cwback = m.mode;
  playnode(node, "cw");
  if ((((m.resumepos === 0) && (e.p != null)) && (e.p > 30))) {
    m.resumepos = e.p;
  }
}
// ---- components/support.brs ----
function supportcfg() {
  return [{__proto__: $AAP, "url": "", "short": "", "img": "pkg:/images/qr_kofi.png", "t": tx("Todo el mundo"), "s": tx("Tarjeta, Apple Pay, Google Pay")}, {__proto__: $AAP, "url": "", "short": "", "img": "pkg:/images/qr_mp.png", "t": tx("Solo México"), "s": tx("Tarjeta u OXXO")}];
}

function showsupport(fromwhere) {
  let p;
  m.supback = fromwhere;
  m.mode = "support";
  hidepanels();
  settitle(tx("Apoya el proyecto"));
  p = m.top.$findnode("supportPanel");
  p.visible = true;
  supportdraw(p);
  capturekeys();
}

function supportkey(key) {
  if ((((key === "back") || (key === "OK")) || (key === "left"))) {
    m.top.$findnode("supportPanel").visible = false;
    if ((m.supback === "about")) {
      showabout();
    } else {
      showhome();
    }
  }
  return true;
}

function supportdraw(g) {
  let white, soft, grey, orange, gl, x, hi, t1, t2, t3, cfg, cw, ch, gap, cx0, i, $e0, c, cx, cy, qs, qx, qy, qp, ci, pl, tt, st, sh, h;
  clearnode(g);
  white = "0xFFFFFFFF";
  soft = "0xC8CCD2FF";
  grey = "0x8A8F98FF";
  orange = "0xFF8A24FF";
  gl = addposter(g, (-240), (-200), 900, 700, "pkg:/images/glow.png");
  gl.blendcolor = orange;
  gl.opacity = 0.16;
  x = 96;
  hi = addposter(g, x, 112, 44, 44, "pkg:/images/ic_heart.png");
  hi.blendcolor = orange;
  dttext(g, x, 172, 0, tx("APOYA EL PROYECTO"), orange, 14, "Bold");
  dttext(g, x, 194, 500, tx("¿Te gusta Smart IPTV MX?"), white, 34, "Bold");
  t1 = dttext(g, x, 250, 480, tx("La app es gratis y lo seguirá siendo. Si te gusta y quieres apoyar su desarrollo, puedes invitarme un café escaneando el código con tu celular."), soft, 18, "Regular");
  t1.wrap = true;
  t1.maxlines = 4;
  t1.linespacing = 6;
  t2 = dttext(g, x, 372, 480, tx("Cada apoyo, del tamaño que sea, me motiva a seguir mejorándola. ¡Gracias por estar aquí!"), white, 17, "SemiBold");
  t2.wrap = true;
  t2.maxlines = 3;
  t2.linespacing = 5;
  addrect(g, x, 454, 480, 1, "0xFFFFFF1F");
  t3 = dttext(g, x, 470, 480, tx("Apoyar es totalmente voluntario y no desbloquea funciones ni contenido. Smart IPTV MX es un reproductor: no incluye canales, películas ni listas."), grey, 14, "Regular");
  t3.wrap = true;
  t3.maxlines = 3;
  t3.linespacing = 4;
  dttext(g, x, 548, 480, tx("Hecho en México por un desarrollador independiente."), grey, 14, "SemiBold");
  cfg = supportcfg();
  cw = 280;
  ch = 400;
  gap = 24;
  cx0 = 640;
  for (i = 0, $e0 = (cfg.$count() - 1); i <= $e0; i++) {
    c = $ix(cfg, i);
    cx = (cx0 + (i * ((cw + gap))));
    cy = 120;
    dtbox(g, cx, cy, cw, ch, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.06);
    dtbox(g, cx, cy, cw, ch, "pkg:/images/rr_line.9.png", "0xFFFFFFFF", 0.09);
    qs = 220;
    qx = (cx + $int((((cw - qs)) / 2)));
    qy = (cy + 24);
    if ((c.url !== "")) {
      dtbox(g, (qx - 10), (qy - 10), (qs + 20), (qs + 20), "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 1.0);
      qp = $createobject("roSGNode", "Poster");
      qp.translation = [qx, qy];
      qp.width = qs;
      qp.height = qs;
      qp.loadwidth = (qs * 2);
      qp.loadheight = (qs * 2);
      qp.loaddisplaymode = "scaleToFit";
      qp.uri = c.img;
      g.$appendchild(qp);
    } else {
      dtbox(g, (qx - 10), (qy - 10), (qs + 20), (qs + 20), "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.06);
      ci = addposter(g, ((qx + (qs / 2)) - 26), (qy + 70), 52, 52, "pkg:/images/ic_qr.png");
      ci.blendcolor = grey;
      pl = dttext(g, qx, (qy + 136), qs, tx("Próximamente"), grey, 16, "SemiBold");
      pl.horizalign = "center";
    }
    tt = dttext(g, cx, (cy + 272), cw, c.t, white, 20, "Bold");
    tt.horizalign = "center";
    st = dttext(g, (cx + 12), (cy + 302), (cw - 24), c.s, soft, 14, "Regular");
    st.horizalign = "center";
    if ((c.short !== "")) {
      sh = dttext(g, (cx + 12), (cy + 334), (cw - 24), c.short, orange, 14, "SemiBold");
      sh.horizalign = "center";
    }
  }
  h = dttext(g, 0, 676, 1280, tx("Escanea con la cámara de tu celular     Atrás: regresar"), "0x7E838CFF", 15, "Regular");
  h.horizalign = "center";
}
// ---- components/mosaic.brs ----
function mosinit() {
  let vi, i, $e0, $e1, t;
  if ((m.mosready === true)) {
    return;
  }
  m.mosready = true;
  m.mospanel = $createobject("roSGNode", "Group");
  m.mospanel.visible = false;
  vi = 0;
  for (i = 0, $e0 = (m.top.$getchildcount() - 1); i <= $e0; i++) {
    if (m.top.$getchild(i).$issamenode(m.videoplayer)) {
      vi = i;
    }
  }
  m.top.$insertchild(m.mospanel, vi);
  m.mostiles = [];
  for (i = 0, $e1 = 3; i <= $e1; i++) {
    t = m.mospanel.$createchild("VideoTile");
    t.pid = (i + 1);
    t.visible = false;
    t.$observefield("state", "onMosTileState");
    m.mostiles.$push(t);
  }
  m.mosframes = m.mospanel.$createchild("Group");
  m.mosover = $createobject("roSGNode", "Group");
  m.mosover.visible = false;
  m.top.$insertchild(m.mosover, mosuiindex());
  m.mosbadges = m.mosover.$createchild("Group");
  m.mosui = m.mosover.$createchild("Group");
  m.mosui.id = "mosUi";
  m.mospickg = m.mosover.$createchild("Group");
  m.mosidle = $createobject("roSGNode", "Timer");
  m.mosidle.duration = 4.5;
  m.mosidle.repeat = false;
  m.mosidle.$observefield("fire", "onMosIdle");
  m.top.$appendchild(m.mosidle);
  m.mosfade = m.mosover.$createchild("Animation");
  m.mosfade.duration = 0.45;
  m.mosfade.easefunction = "outQuad";
  m.mosfadei = m.mosfade.$createchild("FloatFieldInterpolator");
  m.mosfadei.key = [0.0, 1.0];
  m.mosfadei.keyvalue = [1.0, 0.0];
  m.mosfadei.fieldtointerp = "mosUi.opacity";
  m.mostoastg = $createobject("roSGNode", "Group");
  m.top.$insertchild(m.mostoastg, mosuiindex());
  m.mostoastt = $createobject("roSGNode", "Timer");
  m.mostoastt.duration = 2.6;
  m.mostoastt.repeat = false;
  m.mostoastt.$observefield("fire", "onMosToastEnd");
  m.top.$appendchild(m.mostoastt);
  m.mosmode = "grid";
  m.mosfocus = 0;
  m.mosbig = 0;
  m.mosbtn = 0;
  m.mospickon = false;
  m.mosshown = false;
  mosload();
}

function mosuiindex() {
  let ui, i, $e2;
  ui = m.top.$findnode("uiLayer");
  for (i = 0, $e2 = (m.top.$getchildcount() - 1); i <= $e2; i++) {
    if (m.top.$getchild(i).$issamenode(ui)) {
      return i;
    }
  }
  return m.top.$getchildcount();
}

function mosload() {
  let arr, e;
  m.moslist = [];
  if ((m.sec == null)) {
    return;
  }
  if (m.sec.$exists("mosaic_list")) {
    arr = $parsejson(m.sec.$read("mosaic_list"));
    if (($type(arr) === "roArray")) {
      for (e of $iter(arr)) {
        if ((((($type(e) === "roAssociativeArray") && (e.u != null)) && (e.u !== "")) && (m.moslist.$count() < 4))) {
          m.moslist.$push(e);
        }
      }
    }
  }
  if (m.sec.$exists("mosaic_mode")) {
    m.mosmode = m.sec.$read("mosaic_mode");
  }
  if ((m.mosmode !== "focus")) {
    m.mosmode = "grid";
  }
}

function mossave() {
  let arr, e;
  arr = [];
  for (e of $iter(m.moslist)) {
    arr.$push({__proto__: $AAP, "t": e.t, "u": e.u, "f": e.f, "l": e.l, "i": e.i, "c": e.c, "x": e.x, "s": e.s});
  }
  m.sec.$write("mosaic_list", $formatjson(arr));
  m.sec.$write("mosaic_mode", m.mosmode);
  m.sec.$flush();
}

function mossub() {
  let n;
  if ((m.mosready !== true)) {
    mosinit();
  }
  n = m.moslist.$count();
  if ((n === 0)) {
    return tx("Hasta 4 a la vez");
  }
  if ((n === 1)) {
    return tx("1 canal listo");
  }
  return (n.$tostr() + tx(" canales listos"));
}

function showmosaic() {
  mosinit();
  if ((m.pip === true)) {
    stoppip();
  }
  if (m.videoplayer.visible) {
    stabreset();
    m.videoplayer.control = "stop";
    m.videoplayer.visible = false;
  }
  hidepanels();
  m.mode = "mosaic";
  m.topbar.visible = false;
  setbganim(false);
  bgmstop();
  m.mospanel.visible = true;
  m.mosover.visible = true;
  m.mospickon = false;
  clearnode(m.mospickg);
  if ((m.mosfocus >= mosslotcount())) {
    m.mosfocus = 0;
  }
  if ((m.mosbig >= m.moslist.$count())) {
    m.mosbig = 0;
  }
  m.mosshown = true;
  moslayout();
  mosstarttiles();
  mosdraw();
  capturekeys();
  moswake();
  if ((((m.mtdata == null) && (m.mtloading !== true)) && (m.catalogready === true))) {
    mtstart(true);
  }
}

function moshide() {
  let t;
  if ((m.mosready !== true)) {
    return;
  }
  if ((m.mosshown !== true)) {
    return;
  }
  m.mosshown = false;
  for (t of $iter(m.mostiles)) {
    t.control = "stop";
    t.visible = false;
  }
  m.mospanel.visible = false;
  m.mosover.visible = false;
  m.mospickon = false;
  clearnode(m.mospickg);
  m.mosidle.control = "stop";
}

function mosleave() {
  showhome();
  bgmstart();
}

function mosslotcount() {
  let n;
  n = m.moslist.$count();
  if ((n === 0)) {
    return 0;
  }
  if ((n < 4)) {
    return (n + 1);
  }
  return 4;
}

function moslayout() {
  let n, slots, rects, usefocus, i, $e3, $e4;
  n = m.moslist.$count();
  slots = mosslotcount();
  m.mosmap = [];
  rects = [];
  if ((slots === 0)) {
    m.mosrects = rects;
    return;
  }
  usefocus = (((m.mosmode === "focus") && (n >= 2)));
  if (usefocus) {
    if ((m.mosbig >= n)) {
      m.mosbig = 0;
    }
    m.mosmap.$push(m.mosbig);
    for (i = 0, $e3 = (n - 1); i <= $e3; i++) {
      if ((i !== m.mosbig)) {
        m.mosmap.$push(i);
      }
    }
  } else {
    for (i = 0, $e4 = (n - 1); i <= $e4; i++) {
      m.mosmap.$push(i);
    }
  }
  if ((n < 4)) {
    m.mosmap.$push((-1));
  }
  if ((slots === 2)) {
    rects = [[24, 189, 610, 343], [646, 189, 610, 343]];
  } else if ((slots === 3)) {
    rects = [[24, 129, 821, 462], [857, 129, 400, 225], [857, 366, 400, 225]];
  } else if (usefocus) {
    rects = [[26, 100, 924, 520], [962, 100, 294, 166], [962, 277, 294, 166], [962, 454, 294, 166]];
  } else {
    rects = [[47, 24, 587, 330], [646, 24, 587, 330], [47, 366, 587, 330], [646, 366, 587, 330]];
  }
  m.mosrects = rects;
}

function mositemat(slot) {
  if (((slot < 0) || (slot >= m.mosmap.$count()))) {
    return (-1);
  }
  return $ix(m.mosmap, slot);
}

function mosfocuseditem() {
  return mositemat(m.mosfocus);
}

function mosstarttiles() {
  let n, fi, i, $e5, t, e;
  n = m.moslist.$count();
  fi = mosfocuseditem();
  for (i = 0, $e5 = 3; i <= $e5; i++) {
    t = $ix(m.mostiles, i);
    if ((i < n)) {
      e = $ix(m.moslist, i);
      t.mute = ((i !== fi));
      t.hq = ((i === fi));
      if ((((t.url !== e.u) || (t.state === "none")) || (t.state === "error"))) {
        t.url = e.u;
        t.fmt = e.f;
        t.control = "play";
      }
    } else {
      t.control = "stop";
      t.visible = false;
      t.url = "";
    }
  }
  mosapplyrects();
}

function mosapplyrects() {
  let i, $e6, s, $e7, it, r, t;
  for (i = 0, $e6 = 3; i <= $e6; i++) {
    $ix(m.mostiles, i).visible = false;
  }
  for (s = 0, $e7 = (m.mosrects.$count() - 1); s <= $e7; s++) {
    it = mositemat(s);
    if ((it >= 0)) {
      r = $ix(m.mosrects, s);
      t = $ix(m.mostiles, it);
      t.translation = [$ix(r, 0), $ix(r, 1)];
      t.width = $ix(r, 2);
      t.height = $ix(r, 3);
      t.visible = true;
    }
  }
}

function mosgiveaudio() {
  let fi, i, $e8, t;
  fi = mosfocuseditem();
  for (i = 0, $e8 = (m.moslist.$count() - 1); i <= $e8; i++) {
    t = $ix(m.mostiles, i);
    t.mute = ((i !== fi));
    t.hq = ((i === fi));
  }
}

function mosdraw() {
  mosdrawframes();
  mosdrawover();
}

function mosdrawframes() {
  let g, s, $e9, r, it, foc, cx, cy, ring, plus, l1, l2;
  g = m.mosframes;
  clearnode(g);
  if ((m.moslist.$count() === 0)) {
    mosdrawempty(g);
    return;
  }
  for (s = 0, $e9 = (m.mosrects.$count() - 1); s <= $e9; s++) {
    r = $ix(m.mosrects, s);
    it = mositemat(s);
    foc = (((s === m.mosfocus) && (m.mospickon !== true)));
    if (foc) {
      dtbox(g, ($ix(r, 0) - 10), ($ix(r, 1) - 10), ($ix(r, 2) + 20), ($ix(r, 3) + 20), "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 0.16);
      dtbox(g, ($ix(r, 0) - 4), ($ix(r, 1) - 4), ($ix(r, 2) + 8), ($ix(r, 3) + 8), "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 1.0);
    } else {
      dtbox(g, ($ix(r, 0) - 1), ($ix(r, 1) - 1), ($ix(r, 2) + 2), ($ix(r, 3) + 2), "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.10);
    }
    if ((it < 0)) {
      dtbox(g, $ix(r, 0), $ix(r, 1), $ix(r, 2), $ix(r, 3), "pkg:/images/rr_fill.9.png", "0x101116FF", 1.0);
      cx = ($ix(r, 0) + ($ix(r, 2) / 2));
      cy = ($ix(r, 1) + ($ix(r, 3) / 2));
      ring = "0xFFFFFF33";
      if (foc) {
        ring = "0xFF8A24FF";
      }
      dtbox(g, (cx - 28), (cy - 44), 56, 56, "pkg:/images/rr_line.9.png", ring, 1.0);
      plus = dttext(g, (cx - 28), (cy - 37), 56, "+", "0xFFFFFFFF", 30, "Regular");
      plus.horizalign = "center";
      l1 = dttext(g, $ix(r, 0), (cy + 24), $ix(r, 2), tx("Agregar canal"), "0xFFFFFFFF", 18, "SemiBold");
      l1.horizalign = "center";
      if (($ix(r, 3) > 200)) {
        l2 = dttext(g, ($ix(r, 0) + 20), (cy + 50), ($ix(r, 2) - 40), moscountlabel(), "0x8A8F98FF", 14, "Regular");
        l2.horizalign = "center";
      }
    } else {
      addrect(g, $ix(r, 0), $ix(r, 1), $ix(r, 2), $ix(r, 3), "0x000000FF");
    }
  }
}

function moscountlabel() {
  return (m.moslist.$count().$tostr() + tx(" de 4 pantallas"));
}

function mosdrawempty(g) {
  let k, $e10, cxk, cyk, a, k1, t1, t2, btns, total, ws, b, tmp, w, x, i, $e11, foc, bg, ba, fg, ip, tip;
  dtbox(g, 240, 112, 800, 496, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.05);
  dtbox(g, 240, 112, 800, 496, "pkg:/images/rr_line.9.png", "0xFFFFFFFF", 0.10);
  for (k = 0, $e10 = 3; k <= $e10; k++) {
    cxk = (594 + (((k % 2)) * 50));
    cyk = (156 + ($int((k / 2)) * 32));
    a = 0.22;
    if ((k === 0)) {
      a = 1.0;
    }
    dtbox(g, cxk, cyk, 42, 24, "pkg:/images/rr_pill.9.png", "0xFF8A24FF", a);
  }
  k1 = dttext(g, 240, 240, 800, tx("MOSAICO"), "0xFF8A24FF", 14, "Bold");
  k1.horizalign = "center";
  t1 = dttext(g, 240, 262, 800, tx("Varios partidos a la vez"), "0xFFFFFFFF", 38, "Bold");
  t1.horizalign = "center";
  t2 = dttext(g, 300, 318, 680, tx("Hasta 4 canales en pantalla. El sonido sigue al cuadro que elijas."), "0xA8ADB5FF", 18, "Regular");
  t2.horizalign = "center";
  t2.wrap = true;
  t2.maxlines = 2;
  btns = mosemptybuttons();
  total = 0;
  ws = [];
  for (b of $iter(btns)) {
    tmp = dttext(g, (-3000), 0, 0, b.t, "0xFFFFFFFF", 18, "SemiBold");
    w = (dtw(tmp) + 76);
    g.$removechild(tmp);
    ws.$push(w);
    total = (total + w);
  }
  total = (total + (((btns.$count() - 1)) * 14));
  x = (640 - (total / 2));
  if ((m.mosbtn >= btns.$count())) {
    m.mosbtn = 0;
  }
  for (i = 0, $e11 = (btns.$count() - 1); i <= $e11; i++) {
    foc = ((i === m.mosbtn));
    bg = "0xFFFFFFFF";
    ba = 0.10;
    fg = "0xFFFFFFFF";
    if (foc) {
      ba = 1.0;
      fg = "0x0A0A0FFF";
    }
    dtbox(g, x, 402, $ix(ws, i), 56, "pkg:/images/rr_fill.9.png", bg, ba);
    ip = addposter(g, (x + 22), 418, 24, 24, (("pkg:/images/" + $ix(btns, i).ic) + ".png"));
    ip.blendcolor = fg;
    dttext(g, (x + 56), 419, ($ix(ws, i) - 62), $ix(btns, i).t, fg, 18, "SemiBold");
    x = ((x + $ix(ws, i)) + 14);
  }
  tip = dttext(g, 290, 500, 700, tx("También puedes agregarlos desde En vivo (mantén Atrás sobre un canal) o desde Partidos de hoy (mantén OK)."), "0x7E838CFF", 15, "Regular");
  tip.horizalign = "center";
  tip.wrap = true;
  tip.maxlines = 2;
}

function mosemptybuttons() {
  let b, nl;
  b = [];
  nl = moslivematches().$count();
  if ((nl > 0)) {
    b.$push({__proto__: $AAP, "t": (((tx("Partidos en vivo") + " (") + nl.$tostr()) + ")"), "ic": "ic_ball", "a": "fill"});
  }
  b.$push({__proto__: $AAP, "t": tx("Elegir canales"), "ic": "ic_live", "a": "pick"});
  return b;
}

function mosdrawover() {
  let g, n, lay, chip, tmp, cw, s, $e12, it, r, e, t, foc, small, nm, fs, sub2, tw, maxw, pw, tmp2, sw, ph, px, py, nl, st, msg, tmp3, mw, bx, by, mc, ml, ic, hint, fi, oktxt, tmp4, hw, hy, hl;
  clearnode(m.mosbadges);
  clearnode(m.mosui);
  g = m.mosui;
  n = m.moslist.$count();
  if ((n > 0)) {
    lay = tx("Cuadrícula");
    if (((m.mosmode === "focus") && (n >= 2))) {
      lay = tx("Enfoque");
    }
    chip = ((((tx("MOSAICO") + "   ") + n.$tostr()) + "/4   ·   ") + lay);
    tmp = dttext(g, (-3000), 0, 0, chip, "0xFFFFFFFF", 13, "Bold");
    cw = (dtw(tmp) + 28);
    g.$removechild(tmp);
    dtbox(g, 22, 4, cw, 26, "pkg:/images/rr_pill.9.png", "0x000000FF", 0.62);
    dttext(g, 36, 9, (cw - 20), chip, "0xFFFFFFFF", 13, "Bold");
  }
  for (s = 0, $e12 = (m.mosrects.$count() - 1); s <= $e12; s++) {
    it = mositemat(s);
    if (((it >= 0) && (it < n))) {
      r = $ix(m.mosrects, s);
      e = $ix(m.moslist, it);
      t = $ix(m.mostiles, it);
      foc = (((s === m.mosfocus) && (m.mospickon !== true)));
      small = (($ix(r, 2) < 420));
      nm = cleanglyphs(e.t);
      fs = 16;
      if (small) {
        fs = 14;
      }
      sub2 = mosnowtext(e);
      tmp = dttext(g, (-3000), 0, 0, nm, "0xFFFFFFFF", fs, "SemiBold");
      tw = dtw(tmp);
      g.$removechild(tmp);
      maxw = ($ix(r, 2) - 32);
      pw = (tw + 28);
      if ((sub2 !== "")) {
        tmp2 = dttext(g, (-3000), 0, 0, sub2, "0xFFFFFFFF", 12, "Regular");
        sw = (dtw(tmp2) + 28);
        g.$removechild(tmp2);
        if ((sw > pw)) {
          pw = sw;
        }
      }
      if ((pw > maxw)) {
        pw = maxw;
      }
      ph = 34;
      if ((sub2 !== "")) {
        ph = 50;
      }
      px = ($ix(r, 0) + 14);
      py = ((($ix(r, 1) + $ix(r, 3)) - ph) - 14);
      dtbox(g, px, py, pw, ph, "pkg:/images/rr_fill.9.png", "0x000000FF", 0.66);
      nl = dttext(g, (px + 14), (py + 8), (pw - 28), nm, "0xFFFFFFFF", fs, "SemiBold");
      if ((sub2 !== "")) {
        dttext(g, (px + 14), (py + 29), (pw - 28), sub2, "0xC8CCD2FF", 12, "Regular");
      }
      st = t.state;
      msg = "";
      if ((st === "buffering")) {
        msg = tx("Conectando...");
      }
      if ((st === "retry")) {
        msg = tx("Reconectando...");
      }
      if ((st === "error")) {
        msg = tx("Sin señal  ·  OK: reintentar");
      }
      if ((msg !== "")) {
        tmp3 = dttext(m.mosbadges, (-3000), 0, 0, msg, "0xFFFFFFFF", 15, "SemiBold");
        mw = (dtw(tmp3) + 36);
        m.mosbadges.$removechild(tmp3);
        bx = ($ix(r, 0) + ((($ix(r, 2) - mw)) / 2));
        by = (($ix(r, 1) + ($ix(r, 3) / 2)) - 18);
        dtbox(m.mosbadges, bx, by, mw, 36, "pkg:/images/rr_pill.9.png", "0x000000FF", 0.72);
        mc = "0xFFFFFFFF";
        if ((st === "error")) {
          mc = "0xFF8A24FF";
        }
        ml = dttext(m.mosbadges, bx, (by + 9), mw, msg, mc, 15, "SemiBold");
        ml.horizalign = "center";
      }
      if (foc) {
        dtbox(m.mosbadges, (($ix(r, 0) + $ix(r, 2)) - 52), ($ix(r, 1) + 12), 40, 30, "pkg:/images/rr_pill.9.png", "0xFF8A24FF", 1.0);
        ic = addposter(m.mosbadges, (($ix(r, 0) + $ix(r, 2)) - 44), ($ix(r, 1) + 15), 24, 24, "pkg:/images/ctl_audio.png");
        ic.blendcolor = "0x0A0A0FFF";
      }
    }
  }
  hint = "";
  if ((n === 0)) {
    hint = tx("Izquierda/Derecha: elegir     OK: continuar     Atrás: inicio");
  } else {
    fi = mosfocuseditem();
    if ((fi < 0)) {
      hint = tx("OK: agregar canal     Flechas: mover     Atrás: inicio");
    } else {
      oktxt = tx("OK: pantalla completa");
      if ((((m.mosmode === "focus") && (m.mosfocus > 0)) && (n >= 2))) {
        oktxt = tx("OK: poner en grande");
      }
      hint = ((((((oktxt + "     ") + tx("Mantén OK: diseño")) + "     ") + tx("Mantén Atrás: opciones")) + "     ") + tx("Atrás: inicio"));
      e = $ix(m.moslist, fi);
      if ((e.c != null)) {
        hint = ((hint + "     ") + tx("« »: cambiar canal"));
      }
    }
  }
  if ((hint !== "")) {
    tmp4 = dttext(g, (-3000), 0, 0, hint, "0xFFFFFFFF", 14, "Regular");
    hw = (dtw(tmp4) + 40);
    g.$removechild(tmp4);
    if ((hw > 1240)) {
      hw = 1240;
    }
    hy = 694;
    if ((n === 0)) {
      hy = 660;
    }
    dtbox(g, (640 - (hw / 2)), (hy - 8), hw, 30, "pkg:/images/rr_pill.9.png", "0x000000FF", 0.62);
    hl = dttext(g, (640 - (hw / 2)), (hy - 2), hw, hint, "0xC8CCD2FF", 14, "Regular");
    hl.horizalign = "center";
  }
}

function mosnowtext(e) {
  let id, nn;
  if (((e.s != null) && (e.s !== ""))) {
    return e.s;
  }
  id = "";
  if ((e.i != null)) {
    id = e.i;
  }
  nn = getnownext({__proto__: $AAP, "id": id, "title": e.t});
  if ((nn.cur != null)) {
    return ((fmttime(nn.cur.s) + "  ") + nn.cur.t);
  }
  return "";
}

function onmostilestate() {
  if (((m.mode === "mosaic") && (m.mosshown === true))) {
    mosdrawover();
  }
}

function moswake() {
  m.mosfade.control = "stop";
  m.mosui.opacity = 1.0;
  m.mosidle.control = "stop";
  if (((m.moslist.$count() > 0) && (m.mospickon !== true))) {
    m.mosidle.control = "start";
  }
}

function onmosidle() {
  if ((((m.mode !== "mosaic") || (m.mospickon === true)) || (m.uiopen === true))) {
    return;
  }
  m.mosfadei.keyvalue = [1.0, 0.0];
  m.mosfade.control = "start";
}

function mostoast(text) {
  let g, tmp, w, x, k, $e13;
  mosinit();
  g = m.mostoastg;
  clearnode(g);
  tmp = dttext(g, (-3000), 0, 0, text, "0xFFFFFFFF", 16, "SemiBold");
  w = (dtw(tmp) + 74);
  g.$removechild(tmp);
  x = (640 - (w / 2));
  dtbox(g, x, 26, w, 46, "pkg:/images/rr_fill.9.png", "0x0E0F13FF", 0.96);
  dtbox(g, x, 26, w, 46, "pkg:/images/rr_line.9.png", "0xFF8A24FF", 0.55);
  for (k = 0, $e13 = 3; k <= $e13; k++) {
    dtbox(g, ((x + 18) + (((k % 2)) * 11)), (38 + ($int((k / 2)) * 12)), 9, 9, "pkg:/images/rr_pill.9.png", "0xFF8A24FF", 1.0);
  }
  dttext(g, (x + 52), 39, (w - 60), text, "0xFFFFFFFF", 16, "SemiBold");
  g.visible = true;
  m.mostoastt.control = "stop";
  m.mostoastt.control = "start";
}

function onmostoastend() {
  m.mostoastg.visible = false;
}

function mosindexofurl(u) {
  let i, $e14;
  for (i = 0, $e14 = (m.moslist.$count() - 1); i <= $e14; i++) {
    if (($ix(m.moslist, i).u === u)) {
      return i;
    }
  }
  return (-1);
}

function mostoggle(e) {
  let k;
  mosinit();
  k = mosindexofurl(e.u);
  if ((k >= 0)) {
    m.moslist.$delete(k);
    mossave();
    return tx("Quitado del mosaico");
  }
  if ((m.moslist.$count() >= 4)) {
    return tx("Tu mosaico ya tiene 4 canales");
  }
  m.moslist.$push(e);
  mossave();
  return (((tx("Agregado al mosaico") + "  ·  ") + m.moslist.$count().$tostr()) + tx(" de 4"));
}

function mosaddfromlive() {
  let ci, cat, xi, ch;
  if ((m.root == null)) {
    return;
  }
  ci = m.categorylist.itemfocused;
  cat = m.root.$getchild(ci);
  if ((cat == null)) {
    return;
  }
  xi = m.channellist.itemfocused;
  ch = cat.$getchild(xi);
  if ((((ch == null) || (ch.url == null)) || (ch.url === ""))) {
    return;
  }
  mostoast(mostoggle(mosentryof(ch, ci, xi)));
}

function mosentryof(ch, ci, xi) {
  let fmt;
  fmt = ch.streamformat;
  if (((fmt == null) || (fmt === ""))) {
    fmt = "hls";
  }
  return {__proto__: $AAP, "t": displayname(ch), "u": ch.url, "f": fmt, "l": logoof(ch), "i": ch.id, "c": ci, "x": xi, "s": ""};
}

function mosaddfrommatch(mt, c) {
  mostoast(mostoggle(mosentryofmatch(mt, c)));
}

function mosentryofmatch(mt, c) {
  let ttl, fmt, lab;
  ttl = cleanglyphs(mt.full);
  if (((mt.h !== "") && (mt.a !== ""))) {
    ttl = ((cleanglyphs(mt.h) + " vs ") + cleanglyphs(mt.a));
  }
  fmt = c.f;
  if (((fmt == null) || (fmt === ""))) {
    fmt = "hls";
  }
  lab = "";
  if ((c.lab != null)) {
    lab = cleanglyphs(c.lab);
  }
  return {__proto__: $AAP, "t": ttl, "u": c.u, "f": fmt, "l": c.l, "i": "", "s": lab};
}

function moslivematches() {
  let out, now, mt, st;
  out = [];
  if ((m.mtdata == null)) {
    return out;
  }
  now = $createobject("roDateTime").$asseconds();
  for (mt of $iter(m.mtdata)) {
    st = mt.state;
    if ((st == null)) {
      st = "";
    }
    if (((st === "") || (mt.est === true))) {
      if ((now < (mt.start - 600))) {
        st = "pre";
      } else if ((now <= (mt.start + 7800))) {
        st = "in";
      } else {
        st = "post";
      }
    }
    if ((((st === "in") && (mt.ch != null)) && (mt.ch.$count() > 0))) {
      out.$push(mt);
    }
  }
  return out;
}

function mosfillmatches() {
  let added, mt, e;
  added = 0;
  for (mt of $iter(moslivematches())) {
    if ((m.moslist.$count() >= 4)) {
      break;
    }
    e = mosentryofmatch(mt, $ix(mt.ch, 0));
    if ((mosindexofurl(e.u) < 0)) {
      m.moslist.$push(e);
      added = (added + 1);
    }
  }
  mossave();
  m.mosfocus = 0;
  moslayout();
  mosstarttiles();
  mosdraw();
  moswake();
  if ((added === 0)) {
    mostoast(tx("No hay más partidos en vivo con canal en tu lista"));
  } else {
    if ((added === 1)) {
      mostoast(((tx("Listo: ") + "1") + tx(" partido en tu mosaico")));
    } else {
      mostoast(((tx("Listo: ") + added.$tostr()) + tx(" partidos en tu mosaico")));
    }
  }
}

function mosonmatches() {
  if (((m.mode !== "mosaic") || (m.mosshown !== true))) {
    return;
  }
  if ((m.mospickon === true)) {
    return;
  }
  if ((m.moslist.$count() === 0)) {
    mosdraw();
  } else {
    mosdrawover();
  }
}

function mosaickey(key) {
  let n, btns, it, fi, lay, e, d;
  if ((m.mospickon === true)) {
    return mospickkey(key);
  }
  moswake();
  n = m.moslist.$count();
  if ((key === "back")) {
    mosleave();
    return true;
  }
  if ((n === 0)) {
    btns = mosemptybuttons();
    if (((key === "left") && (m.mosbtn > 0))) {
      m.mosbtn = (m.mosbtn - 1);
    }
    if (((key === "right") && (m.mosbtn < (btns.$count() - 1)))) {
      m.mosbtn = (m.mosbtn + 1);
    }
    if ((key === "OK")) {
      if ((m.mosbtn >= btns.$count())) {
        m.mosbtn = 0;
      }
      if (($ix(btns, m.mosbtn).a === "fill")) {
        mosfillmatches();
      } else {
        mosopenpicker(0);
      }
      return true;
    }
    mosdrawframes();
    return true;
  }
  if (((((key === "left") || (key === "right")) || (key === "up")) || (key === "down"))) {
    mosmove(key);
    return true;
  }
  it = mosfocuseditem();
  if ((key === "OK")) {
    if ((it < 0)) {
      mosopenpicker(m.mosfocus);
    } else if (($ix(m.mostiles, it).state === "error")) {
      $ix(m.mostiles, it).control = "stop";
      mosstarttiles();
      mosdrawover();
    } else if ((((m.mosmode === "focus") && (n >= 2)) && (m.mosfocus > 0))) {
      m.mosbig = it;
      m.mosfocus = 0;
      moslayout();
      mosapplyrects();
      mosgiveaudio();
      mosdraw();
    } else {
      mosfullscreen(it);
    }
    return true;
  }
  if ((key === "play")) {
    if ((n < 2)) {
      mostoast(tx("Agrega otro canal para cambiar el diseño"));
      return true;
    }
    fi = it;
    if ((m.mosmode === "grid")) {
      m.mosmode = "focus";
      if ((fi >= 0)) {
        m.mosbig = fi;
      }
      m.mosfocus = 0;
    } else {
      m.mosmode = "grid";
      if ((fi >= 0)) {
        m.mosfocus = fi;
      } else {
        m.mosfocus = 0;
      }
    }
    mossave();
    moslayout();
    mosapplyrects();
    mosgiveaudio();
    mosdraw();
    lay = tx("Cuadrícula");
    if ((m.mosmode === "focus")) {
      lay = tx("Enfoque");
    }
    mostoast((tx("Diseño: ") + lay));
    return true;
  }
  if ((key === "options")) {
    if ((it < 0)) {
      mosopenpicker(m.mosfocus);
    } else {
      e = $ix(m.moslist, it);
      m.mosoptitem = it;
      uiask(cleanglyphs(e.t), [], [tx("Cambiar canal"), tx("Pantalla completa"), tx("Quitar del mosaico"), tx("Vaciar mosaico"), tx("Cancelar")], "onMosOpt");
    }
    return true;
  }
  if (((key === "rev") || (key === "fwd"))) {
    if ((it >= 0)) {
      d = 1;
      if ((key === "rev")) {
        d = (-1);
      }
      moszap(it, d);
    }
    return true;
  }
  return true;
}

function mosmove(key) {
  let cur, cx, cy, best, bestd, s, $e15, r, x, y, ok, dd;
  cur = $ix(m.mosrects, m.mosfocus);
  cx = ($ix(cur, 0) + ($ix(cur, 2) / 2));
  cy = ($ix(cur, 1) + ($ix(cur, 3) / 2));
  best = (-1);
  bestd = 999999;
  for (s = 0, $e15 = (m.mosrects.$count() - 1); s <= $e15; s++) {
    if ((s !== m.mosfocus)) {
      r = $ix(m.mosrects, s);
      x = ($ix(r, 0) + ($ix(r, 2) / 2));
      y = ($ix(r, 1) + ($ix(r, 3) / 2));
      ok = false;
      if (((key === "left") && (($ix(r, 0) + $ix(r, 2)) <= ($ix(cur, 0) + 4)))) {
        ok = true;
      }
      if (((key === "right") && ($ix(r, 0) >= (($ix(cur, 0) + $ix(cur, 2)) - 4)))) {
        ok = true;
      }
      if (((key === "up") && (($ix(r, 1) + $ix(r, 3)) <= ($ix(cur, 1) + 4)))) {
        ok = true;
      }
      if (((key === "down") && ($ix(r, 1) >= (($ix(cur, 1) + $ix(cur, 3)) - 4)))) {
        ok = true;
      }
      if (ok) {
        dd = ((((x - cx)) * ((x - cx))) + (((y - cy)) * ((y - cy))));
        if ((dd < bestd)) {
          bestd = dd;
          best = s;
        }
      }
    }
  }
  if ((best < 0)) {
    return;
  }
  m.mosfocus = best;
  mosgiveaudio();
  mosdraw();
}

function mosfullscreen(it) {
  let e, node;
  e = $ix(m.moslist, it);
  node = $createobject("roSGNode", "ContentNode");
  node.$setfields({__proto__: $AAP, "title": cleanglyphs(e.t), "url": e.u, "streamformat": e.f, "hdposterurl": e.l, "description": "live", "id": e.i});
  playnode(node, "mosaic");
}

function moszap(it, d) {
  let e, cat, cnt, xi, tries, $e16, ch;
  e = $ix(m.moslist, it);
  if (((e.c == null) || (m.root == null))) {
    return;
  }
  cat = m.root.$getchild(e.c);
  if ((cat == null)) {
    return;
  }
  cnt = cat.$getchildcount();
  if ((cnt === 0)) {
    return;
  }
  xi = e.x;
  for (tries = 1, $e16 = cnt; tries <= $e16; tries++) {
    xi = ((((xi + d) + cnt)) % cnt);
    ch = cat.$getchild(xi);
    if (((((ch != null) && (ch.url != null)) && (ch.url !== "")) && (mosindexofurl(ch.url) < 0))) {
      $six(m.moslist, it, mosentryof(ch, e.c, xi));
      mossave();
      mosstarttiles();
      mosdrawover();
      return;
    }
  }
}

function onmosopt() {
  let b, it, s, $e17;
  b = m.uibtn;
  it = m.mosoptitem;
  if ((((it == null) || (it < 0)) || (it >= m.moslist.$count()))) {
    capturekeys();
    return;
  }
  if ((b === 0)) {
    for (s = 0, $e17 = (m.mosmap.$count() - 1); s <= $e17; s++) {
      if (($ix(m.mosmap, s) === it)) {
        m.mosfocus = s;
      }
    }
    mosopenpicker(m.mosfocus);
    return;
  } else if ((b === 1)) {
    mosfullscreen(it);
    return;
  } else if ((b === 2)) {
    $ix(m.mostiles, it).control = "stop";
    m.moslist.$delete(it);
    mosrestartall();
    mostoast(tx("Quitado del mosaico"));
  } else if ((b === 3)) {
    m.moslist = [];
    mosrestartall();
  }
  capturekeys();
}

function mosrestartall() {
  let t;
  for (t of $iter(m.mostiles)) {
    t.control = "stop";
    t.url = "";
  }
  mossave();
  if ((m.mosbig >= m.moslist.$count())) {
    m.mosbig = 0;
  }
  moslayout();
  if ((m.mosfocus >= mosslotcount())) {
    m.mosfocus = 0;
  }
  mosstarttiles();
  mosdraw();
  moswake();
}

function mosopenpicker(slot) {
  let cats, lm, favn, f, i, $e18, c, nm, p;
  m.mospickslot = slot;
  m.mospickon = true;
  m.mosidle.control = "stop";
  m.mosfade.control = "stop";
  m.mosui.opacity = 1.0;
  cats = [];
  lm = moslivematches();
  if ((lm.$count() > 0)) {
    cats.$push({__proto__: $AAP, "t": tx("Partidos en vivo"), "k": "mt", "n": lm.$count()});
  }
  favn = 0;
  if ((m.favs != null)) {
    for (f of $iter(m.favs)) {
      if ((f.k === "live")) {
        favn = (favn + 1);
      }
    }
  }
  if ((favn > 0)) {
    cats.$push({__proto__: $AAP, "t": tx("Favoritos"), "k": "fav", "n": favn});
  }
  if ((m.root != null)) {
    for (i = 0, $e18 = (m.root.$getchildcount() - 1); i <= $e18; i++) {
      c = m.root.$getchild(i);
      nm = c.title;
      p = $instr(1, nm, "  (");
      if ((p > 0)) {
        nm = $left(nm, (p - 1));
      }
      cats.$push({__proto__: $AAP, "t": cleanglyphs(nm), "k": "cat", "i": i, "n": c.$getchildcount()});
    }
  }
  m.moscats = cats;
  m.moslm = lm;
  m.mospcol = "cats";
  m.mospcat = 0;
  m.mospcatfirst = 0;
  m.mospitem = 0;
  m.mospitemfirst = 0;
  if ((cats.$count() > 0)) {
    m.mospcol = "items";
  }
  if ((cats.$count() === 0)) {
    m.mospickon = false;
    mostoast(tx("Primero carga una lista en Mis listas"));
    return;
  }
  mosdrawframes();
  mosdrawpicker();
}

function mosclosepicker() {
  m.mospickon = false;
  clearnode(m.mospickg);
  mosdraw();
  moswake();
}

function mospickcount() {
  let c, n, f, cat;
  if ((m.moscats.$count() === 0)) {
    return 0;
  }
  c = $ix(m.moscats, m.mospcat);
  if ((c.k === "mt")) {
    return m.moslm.$count();
  }
  if ((c.k === "fav")) {
    n = 0;
    for (f of $iter(m.favs)) {
      if ((f.k === "live")) {
        n = (n + 1);
      }
    }
    return n;
  }
  cat = m.root.$getchild(c.i);
  if ((cat == null)) {
    return 0;
  }
  return cat.$getchildcount();
}

function mospickrow(i) {
  let c, mt, e, sc, lg, k, f, fmt, nm, cat, ch;
  c = $ix(m.moscats, m.mospcat);
  if ((c.k === "mt")) {
    mt = $ix(m.moslm, i);
    e = mosentryofmatch(mt, $ix(mt.ch, 0));
    sc = "";
    if ((((mt.hsc != null) && (mt.asc != null)) && (mt.hsc !== ""))) {
      sc = (((mt.hsc + " - ") + mt.asc) + "   ");
    }
    lg = "";
    if ((mt.league != null)) {
      lg = mt.league;
    }
    return {__proto__: $AAP, "e": e, "t": e.t, "s": (sc + lg), "l": e.l};
  }
  if ((c.k === "fav")) {
    k = 0;
    for (f of $iter(m.favs)) {
      if ((f.k === "live")) {
        if ((k === i)) {
          fmt = f.f;
          if (((fmt == null) || (fmt === ""))) {
            fmt = "hls";
          }
          nm = f.t;
          if (((f.n != null) && (f.n !== ""))) {
            nm = ((f.n + "   ") + f.t);
          }
          e = {__proto__: $AAP, "t": cleanglyphs(nm), "u": f.u, "f": fmt, "l": f.l, "i": f.i, "s": ""};
          return {__proto__: $AAP, "e": e, "t": e.t, "s": mosnowtext(e), "l": f.l};
        }
        k = (k + 1);
      }
    }
    return null;
  }
  cat = m.root.$getchild(c.i);
  ch = cat.$getchild(i);
  if ((ch == null)) {
    return null;
  }
  e = mosentryof(ch, c.i, i);
  return {__proto__: $AAP, "e": e, "t": e.t, "s": mosnowtext(e), "l": e.l};
}

function mosdrawpicker() {
  let g, slottxt, cats, visc, y, i, $e19, c, sel, fg, cl, n, visi, $e20, row, inmos, sg, tx0, tw, dot, h;
  g = m.mospickg;
  clearnode(g);
  addrect(g, 0, 0, 1280, 720, "0x00000066");
  addrect(g, 700, 0, 580, 720, "0x0B0C10F5");
  addrect(g, 700, 0, 2, 720, "0xFF8A24FF");
  slottxt = (tx("PANTALLA ") + ((m.mospickslot + 1)).$tostr());
  dttext(g, 732, 36, 400, slottxt, "0xFF8A24FF", 13, "Bold");
  dttext(g, 732, 56, 500, tx("Elegir canal"), "0xFFFFFFFF", 28, "Bold");
  cats = m.moscats;
  visc = 12;
  if ((m.mospcat < m.mospcatfirst)) {
    m.mospcatfirst = m.mospcat;
  }
  if ((m.mospcat >= (m.mospcatfirst + visc))) {
    m.mospcatfirst = ((m.mospcat - visc) + 1);
  }
  y = 112;
  for (i = m.mospcatfirst, $e19 = (cats.$count() - 1); i <= $e19; i++) {
    if ((i >= (m.mospcatfirst + visc))) {
      break;
    }
    c = $ix(cats, i);
    sel = ((i === m.mospcat));
    fg = "0xC8CCD2FF";
    if ((sel && (m.mospcol === "cats"))) {
      dtbox(g, 724, y, 196, 40, "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 1.0);
      fg = "0x0A0A0FFF";
    } else if (sel) {
      dtbox(g, 724, y, 196, 40, "pkg:/images/rr_fill.9.png", "0xFFFFFFFF", 0.10);
      fg = "0xFFFFFFFF";
    }
    dttext(g, 738, (y + 11), 140, fittext(c.t, 140), fg, 15, "SemiBold");
    cl = dttext(g, 860, (y + 12), 50, c.n.$tostr(), fg, 13, "Regular");
    cl.horizalign = "right";
    y = (y + 44);
  }
  n = mospickcount();
  visi = 9;
  if ((m.mospitem >= n)) {
    m.mospitem = (n - 1);
  }
  if ((m.mospitem < 0)) {
    m.mospitem = 0;
  }
  if ((m.mospitem < m.mospitemfirst)) {
    m.mospitemfirst = m.mospitem;
  }
  if ((m.mospitem >= (m.mospitemfirst + visi))) {
    m.mospitemfirst = ((m.mospitem - visi) + 1);
  }
  y = 112;
  for (i = m.mospitemfirst, $e20 = (n - 1); i <= $e20; i++) {
    if ((i >= (m.mospitemfirst + visi))) {
      break;
    }
    row = mospickrow(i);
    if ((row != null)) {
      sel = (((i === m.mospitem) && (m.mospcol === "items")));
      inmos = ((mosindexofurl(row.e.u) >= 0));
      fg = "0xFFFFFFFF";
      sg = "0x8A8F98FF";
      if (sel) {
        dtbox(g, 932, y, 328, 54, "pkg:/images/rr_fill.9.png", "0xFF8A24FF", 1.0);
        fg = "0x0A0A0FFF";
        sg = "0x0A0A0FB3";
      }
      if (((row.l != null) && (row.l !== ""))) {
        addposter(g, 944, (y + 9), 52, 36, row.l);
        tx0 = 1006;
      } else {
        tx0 = 946;
      }
      tw = (1250 - tx0);
      if (inmos) {
        tw = (tw - 26);
      }
      dttext(g, tx0, (y + 8), tw, row.t, fg, 15, "SemiBold");
      if ((row.s !== "")) {
        dttext(g, tx0, (y + 30), tw, row.s, sg, 12, "Regular");
      }
      if (inmos) {
        dot = addposter(g, 1228, (y + 17), 20, 20, "pkg:/images/check_circle.png");
      }
    }
    y = (y + 58);
  }
  if ((n === 0)) {
    dttext(g, 946, 130, 300, tx("Sin canales"), "0x8A8F98FF", 15, "Regular");
  }
  h = dttext(g, 724, 680, 540, tx("OK: elegir     Izquierda/Derecha: columnas     Atrás: cerrar"), "0x7E838CFF", 13, "Regular");
}

function mospickkey(key) {
  let n, row;
  if ((key === "back")) {
    mosclosepicker();
    return true;
  }
  if ((m.mospcol === "cats")) {
    if (((key === "up") && (m.mospcat > 0))) {
      m.mospcat = (m.mospcat - 1);
      m.mospitem = 0;
      m.mospitemfirst = 0;
    } else if (((key === "down") && (m.mospcat < (m.moscats.$count() - 1)))) {
      m.mospcat = (m.mospcat + 1);
      m.mospitem = 0;
      m.mospitemfirst = 0;
    } else if (((key === "right") || (key === "OK"))) {
      if ((mospickcount() > 0)) {
        m.mospcol = "items";
      }
    } else if ((key === "left")) {
      mosclosepicker();
      return true;
    }
  } else {
    n = mospickcount();
    if (((key === "up") && (m.mospitem > 0))) {
      m.mospitem = (m.mospitem - 1);
    } else if (((key === "down") && (m.mospitem < (n - 1)))) {
      m.mospitem = (m.mospitem + 1);
    } else if ((key === "rev")) {
      m.mospitem = (m.mospitem - 9);
      if ((m.mospitem < 0)) {
        m.mospitem = 0;
      }
    } else if ((key === "fwd")) {
      m.mospitem = (m.mospitem + 9);
      if ((m.mospitem > (n - 1))) {
        m.mospitem = (n - 1);
      }
    } else if ((key === "left")) {
      m.mospcol = "cats";
    } else if ((key === "OK")) {
      row = mospickrow(m.mospitem);
      if ((row != null)) {
        mospickchoose(row.e);
      }
      return true;
    }
  }
  mosdrawpicker();
  return true;
}

function mospickchoose(e) {
  let existing, it, s, $e21;
  existing = mosindexofurl(e.u);
  it = mositemat(m.mospickslot);
  if (((existing >= 0) && (existing !== it))) {
    mostoast(tx("Ese canal ya está en tu mosaico"));
    return;
  }
  if ((it >= 0)) {
    $six(m.moslist, it, e);
  } else {
    if ((m.moslist.$count() >= 4)) {
      return;
    }
    m.moslist.$push(e);
    it = (m.moslist.$count() - 1);
  }
  mossave();
  m.mospickon = false;
  clearnode(m.mospickg);
  moslayout();
  for (s = 0, $e21 = (m.mosmap.$count() - 1); s <= $e21; s++) {
    if (($ix(m.mosmap, s) === it)) {
      m.mosfocus = s;
    }
  }
  mosstarttiles();
  mosdraw();
  moswake();
}
return {"init": init, "loadplaylists": loadplaylists, "saveplaylists": saveplaylists, "epgof": epgof, "refreshlibrary": refreshlibrary, "updatelibrarystatus": updatelibrarystatus, "onlibraryselected": onlibraryselected, "startepg": startepg, "loadnextepg": loadnextepg, "onepgstatus": onepgstatus, "onepgloaded": onepgloaded, "setepgstatus": setepgstatus, "applyepgicons": applyepgicons, "applyepgiconsall": applyepgiconsall, "iconfor": iconfor, "logoof": logoof, "displayname": displayname, "getprogs": getprogs, "getnownext": getnownext, "progline": progline, "startadd": startadd, "startedit": startedit, "showkeyboard": showkeyboard, "kbhandle": kbhandle, "showoptions": showoptions, "onoptionsbutton": onoptionsbutton, "showconfirmdelete": showconfirmdelete, "ondeletebutton": ondeletebutton, "oncategoryfocused": oncategoryfocused, "oncategoryselected": oncategoryselected, "onchannelselected": onchannelselected, "currentitem": currentitem, "marktuned": marktuned, "tunechannel": tunechannel, "zap": zap, "replaylast": replaylast, "showbanner": showbanner, "bgmstart": bgmstart, "bgmstop": bgmstop, "onvideovisible": onvideovisible, "togglebgm": togglebgm, "onzaptimer": onzaptimer, "onclock": onclock, "initstability": initstability, "stabreset": stabreset, "stabismovie": stabismovie, "onvideostate": onvideostate, "onstalltimer": onstalltimer, "stabreconnect": stabreconnect, "onrecontimer": onrecontimer, "ontunetimeout": ontunetimeout, "tryaltformat": tryaltformat, "showoverlay": showoverlay, "hideoverlay": hideoverlay, "layoutoverlay": layoutoverlay, "retrycurrent": retrycurrent, "stopvideo": stopvideo, "openguide": openguide, "closeguidelayout": closeguidelayout, "closeguide": closeguide, "buildguide": buildguide, "updatetopinfo": updatetopinfo, "updateprogress": updateprogress, "fmtdur": fmtdur, "updatestrips": updatestrips, "updateclock": updateclock, "drawgrid": drawgrid, "fillrow": fillrow, "redrawrow": redrawrow, "refreshnowline": refreshnowline, "progatcursor": progatcursor, "focusedguideitem": focusedguideitem, "moveguiderow": moveguiderow, "moveprog": moveprog, "clampcursor": clampcursor, "ensurecursorvisible": ensurecursorvisible, "shiftwindow": shiftwindow, "alignhalfhour": alignhalfhour, "timetox": timetox, "playhighlighted": playhighlighted, "opencatpicker": opencatpicker, "drawcatpicker": drawcatpicker, "movepick": movepick, "acceptcategory": acceptcategory, "capturekeys": capturekeys, "clearnode": clearnode, "addrect": addrect, "addlabel": addlabel, "addposter": addposter, "emptycover": emptycover, "coverposter": coverposter, "fittext": fittext, "onkeyevent": onkeyevent, "onbginstate": onbginstate, "enterpip": enterpip, "leavepiplayout": leavepiplayout, "stoppip": stoppip, "applypiplayout": applypiplayout, "showhome": showhome, "showlists": showlists, "hidepanels": hidepanels, "setbganim": setbganim, "setbgfrozen": setbgfrozen, "settitle": settitle, "updatetopclock": updatetopclock, "updateactivechip": updateactivechip, "isincluded": isincluded, "activelists": activelists, "activeplaylist": activeplaylist, "loadactiveset": loadactiveset, "saveactiveset": saveactiveset, "toggleactive": toggleactive, "setactive": setactive, "includelist": includelist, "resetcatalog": resetcatalog, "reloadactive": reloadactive, "listslabel": listslabel, "opensection": opensection, "loadnextlist": loadnextlist, "oncontentprogress": oncontentprogress, "oncontentloaded": oncontentloaded, "mergecategory": mergecategory, "pruneempty": pruneempty, "mergetree": mergetree, "listhas": listhas, "showloadedsection": showloadedsection, "showlive": showlive, "applynowplaying": applynowplaying, "applynowplayingall": applynowplayingall, "showserieslist": showserieslist, "showmovies": showmovies, "showfavs": showfavs, "startsearch": startsearch, "foldtext": foldtext, "runsearch": runsearch, "gssrc": gssrc, "gsaddresult": gsaddresult, "gsreset": gsreset, "gsstart": gsstart, "ongstick": ongstick, "gstickwork": gstickwork, "showsearchresults": showsearchresults, "onsearchselected": onsearchselected, "searchkey": searchkey, "syncstars": syncstars, "favsync": favsync, "localip": localip, "showqr": showqr, "drawqr": drawqr, "stopqr": stopqr, "onqrstatus": onqrstatus, "onqrreceived": onqrreceived, "loadfavs": loadfavs, "savefavs": savefavs, "togglefavorite": togglefavorite, "favitems": favitems, "favtoitem": favtoitem, "drawmovies": drawmovies, "yearof": yearof, "movieskey": movieskey, "drawfavs": drawfavs, "favskey": favskey, "vodopen": vodopen, "playnode": playnode, "showtoast": showtoast, "hidetoast": hidetoast, "playchime": playchime, "onsfxstate": onsfxstate, "qrxor": qrxor, "qrmul": qrmul, "qrmatrix": qrmatrix, "qrrs": qrrs, "qrpush": qrpush, "qrset": qrset, "qrfinder": qrfinder, "qrformat": qrformat, "getattr": getattr, "normname": normname, "decodeentities": decodeentities, "pad2": pad2, "fmttime": fmttime, "fmttimelong": fmttimelong, "fmtday": fmtday, "cleanlogo": cleanlogo, "epgwantedof": epgwantedof, "initcontrols": initcontrols, "ctlfmt": ctlfmt, "ismovieitem": ismovieitem, "ctlduration": ctlduration, "ctlposition": ctlposition, "showcontrols": showcontrols, "restartctlhide": restartctlhide, "hidecontrols": hidecontrols, "ctlshownpos": ctlshownpos, "ctlbtnname": ctlbtnname, "ctlupdate": ctlupdate, "seekby": seekby, "scrub": scrub, "quickseek": quickseek, "ctlsay": ctlsay, "seekcommit": seekcommit, "togglepause": togglepause, "ctlactivate": ctlactivate, "ctlkey": ctlkey, "langname": langname, "audiotech": audiotech, "opentrackpanel": opentrackpanel, "drawtrackpanel": drawtrackpanel, "trackkey": trackkey, "bmkey": bmkey, "initbookmarks": initbookmarks, "bmposition": bmposition, "bmsave": bmsave, "bmprepare": bmprepare, "bmonplaying": bmonplaying, "onbmtick": onbmtick, "bmsavenow": bmsavenow, "greetingtext": greetingtext, "prefline": prefline, "showwelcome": showwelcome, "reshowwelcome": reshowwelcome, "welcomeaftertour": welcomeaftertour, "wdots": wdots, "wbutton": wbutton, "wcard": wcard, "drawwelcome": drawwelcome, "welcomekey": welcomekey, "markwelcomedone": markwelcomedone, "opendialog": opendialog, "ondialogclosed": ondialogclosed, "showexitdialog": showexitdialog, "onexitbutton": onexitbutton, "onexitclosed": onexitclosed, "doexit": doexit, "aboutemail": aboutemail, "aboutsections": aboutsections, "showabout": showabout, "aboutkey": aboutkey, "aboutversion": aboutversion, "aboutqrdraw": aboutqrdraw, "abwrap": abwrap, "abh": abh, "drawabout": drawabout, "wxinit": wxinit, "onwxtimer": onwxtimer, "wxrefresh": wxrefresh, "onwxloaded": onwxloaded, "wxupdatewidget": wxupdatewidget, "wxn": wxn, "wxd1": wxd1, "wxiconuri": wxiconuri, "wxtext": wxtext, "wxhour": wxhour, "wxclock": wxclock, "wxdayname": wxdayname, "wxdirname": wxdirname, "wxaqi": wxaqi, "wxuv": wxuv, "wxlabel": wxlabel, "openweather": openweather, "wxdraw": wxdraw, "wxcard": wxcard, "wxtint": wxtint, "wxmins": wxmins, "wxfloat": wxfloat, "wxstopanims": wxstopanims, "wxmeter": wxmeter, "wxdrawmain": wxdrawmain, "wxask": wxask, "wxshowpanel": wxshowpanel, "wxgeo": wxgeo, "onwxgeo": onwxgeo, "wxmessage": wxmessage, "wxdrawresults": wxdrawresults, "wxdrawunit": wxdrawunit, "wxsave": wxsave, "wxkey": wxkey, "i18nlangs": i18nlangs, "i18nvalid": i18nvalid, "i18ndetect": i18ndetect, "i18nload": i18nload, "tx": tx, "i18nlang": i18nlang, "i18n24h": i18n24h, "i18ndow3": i18ndow3, "i18nmon3": i18nmon3, "i18ndowfull": i18ndowfull, "i18ncompass": i18ncompass, "i18nhm": i18nhm, "epregexes": epregexes, "epparse": epparse, "eptrim": eptrim, "sortkey": sortkey, "seradd": seradd, "serfill": serfill, "serfilldirect": serfilldirect, "sereptitle": sereptitle, "mergeseries": mergeseries, "showepisodes": showepisodes, "reshowepisodes": reshowepisodes, "epinfo": epinfo, "epstr": epstr, "epfield": epfield, "epupdatebackground": epupdatebackground, "drawepisodes": drawepisodes, "episodeskey": episodeskey, "leaveepisodes": leaveepisodes, "i18ninit": i18ninit, "xmlcollect": xmlcollect, "xmlwalk": xmlwalk, "xmltranslate": xmltranslate, "langindexof": langindexof, "applylanguage": applylanguage, "showlang": showlang, "drawlang": drawlang, "langkey": langkey, "dstr": dstr, "xtesc": xtesc, "xthexval": xthexval, "xtunesc": xtunesc, "xtbase": xtbase, "xtparam": xtparam, "xtfromurl": xtfromurl, "xtinit": xtinit, "xtsave": xtsave, "xtpseudo": xtpseudo, "xtsetactive": xtsetactive, "xtclear": xtclear, "xthintmode": xthintmode, "showxtream": showxtream, "xtrefresh": xtrefresh, "xtselected": xtselected, "xtkey": xtkey, "xtoptions": xtoptions, "onxtoptions": onxtoptions, "xtconfirmdelete": xtconfirmdelete, "onxtdelete": onxtdelete, "xtstartadd": xtstartadd, "xtstartedit": xtstartedit, "xtask": xtask, "xtkeyboarddone": xtkeyboarddone, "xtfinish": xtfinish, "xtaddfromqr": xtaddfromqr, "onxtstatus": onxtstatus, "xtserid": xtserid, "xtloadseries": xtloadseries, "onxtseries": onxtseries, "letterof": letterof, "letterjump": letterjump, "vsletters": vsletters, "lettermapfor": lettermapfor, "drawmoviebar": drawmoviebar, "vsbutton": vsbutton, "barkey": barkey, "pickopen": pickopen, "drawpicker": drawpicker, "pickkey": pickkey, "vskeys": vskeys, "vsopen": vsopen, "vsclose": vsclose, "vsfold": vsfold, "vsensureindex": vsensureindex, "onvstick": onvstick, "vsrunquery": vsrunquery, "vsheadertext": vsheadertext, "vsnode": vsnode, "drawsearch": drawsearch, "vstype": vstype, "vsbackspace": vsbackspace, "vskey": vskey, "joinarr": joinarr, "cleancatname": cleancatname, "smartcase": smartcase, "splittitle": splittitle, "cleantitle": cleantitle, "audiolabel": audiolabel, "showdetail": showdetail, "reshowdetail": reshowdetail, "vodxtfromurl": vodxtfromurl, "ondetailinfo": ondetailinfo, "dtstr": dtstr, "dtfont": dtfont, "dttext": dttext, "dtw": dtw, "dtbox": dtbox, "dtphoto": dtphoto, "dtfullimage": dtfullimage, "fmtduration": fmtduration, "fmtrating": fmtrating, "fmtgenres": fmtgenres, "firstnames": firstnames, "dtbuildbackground": dtbuildbackground, "dtupdatebackground": dtupdatebackground, "dtsetimage": dtsetimage, "ondtimgstatus": ondtimgstatus, "drawdetail": drawdetail, "drawdetailbuttons": drawdetailbuttons, "detailkey": detailkey, "leavedetail": leavedetail, "homeinit": homeinit, "hometiles": hometiles, "homeutils": homeutils, "homeenter": homeenter, "homeoncatalog": homeoncatalog, "homepickfeatures": homepickfeatures, "homefeature": homefeature, "onfeattimer": onfeattimer, "homestepfeature": homestepfeature, "featinfofor": featinfofor, "homeshowfeature": homeshowfeature, "onfeatinfo": onfeatinfo, "homeheroimage": homeheroimage, "onheroload": onheroload, "herofadenow": herofadenow, "fmtnum": fmtnum, "drawherotext": drawherotext, "homeherolabels": homeherolabels, "drawherobuttons": drawherobuttons, "tilesub": tilesub, "drawhomebody": drawhomebody, "painthome": painthome, "movehome": movehome, "openhomecard": openhomecard, "homehaslists": homehaslists, "homestate": homestate, "drawheroloading": drawheroloading, "drawherowelcome": drawherowelcome, "homeonprogress": homeonprogress, "homesavefeat": homesavefeat, "homeloadfeat": homeloadfeat, "tutbuttons": tutbuttons, "tutkeyname": tutkeyname, "tutchapters": tutchapters, "showtutorial": showtutorial, "leavetutorial": leavetutorial, "tutdrawremote": tutdrawremote, "drawtutorial": drawtutorial, "tutkey": tutkey, "ontuttimer": ontuttimer, "tutquickchapter": tutquickchapter, "tutcurchapters": tutcurchapters, "tutmenuitems": tutmenuitems, "showquicktour": showquicktour, "startquicktour": startquicktour, "tutquickexit": tutquickexit, "tutdrawxtdemo": tutdrawxtdemo, "startintro": startintro, "onintrotimer": onintrotimer, "onintrooutstate": onintrooutstate, "introdone": introdone, "onintrobgm": onintrobgm, "introkey": introkey, "pcpin": pcpin, "pcisset": pcisset, "pcadulton": pcadulton, "pcadultcount": pcadultcount, "showparental": showparental, "askadultpin": askadultpin, "showadult": showadult, "pinopen": pinopen, "pinexit": pinexit, "pinkeys": pinkeys, "pinnow": pinnow, "pinkey": pinkey, "pinpress": pinpress, "pinsubmit": pinsubmit, "pinmenukey": pinmenukey, "pinwrap": pinwrap, "drawpin": drawpin, "drawpinmenu": drawpinmenu, "cleanglyphs": cleanglyphs, "mtcollect": mtcollect, "mtstartsoon": mtstartsoon, "onmtsoon": onmtsoon, "mtstart": mtstart, "mtreset": mtreset, "onmtresult": onmtresult, "mtmidutc": mtmidutc, "mttoday": mttoday, "mtrefreshview": mtrefreshview, "mtbuild": mtbuild, "mtcolof": mtcolof, "mtsetcol": mtsetcol, "mtdrawbtn": mtdrawbtn, "mtcounttoday": mtcounttoday, "livematchkey": livematchkey, "showmatches": showmatches, "onmttick": onmttick, "mtleave": mtleave, "mtlayers": mtlayers, "mtdraw": mtdraw, "mtdrawhead": mtdrawhead, "mtdrawrows": mtdrawrows, "mtdrawrow": mtdrawrow, "mtdrawfoot": mtdrawfoot, "mtdrawpicklayer": mtdrawpicklayer, "mtdrawchips": mtdrawchips, "mttile": mttile, "mtdrawpick": mtdrawpick, "mtcur": mtcur, "mtplay": mtplay, "matcheskey": matcheskey, "liveinfosoon": liveinfosoon, "onchannelfocused": onchannelfocused, "onliveinfotimer": onliveinfotimer, "livefocusedcat": livefocusedcat, "livewindow": livewindow, "liveinfodraw": liveinfodraw, "kbopen": kbopen, "kbclose": kbclose, "kbrows": kbrows, "kbdrawall": kbdrawall, "kbpaint": kbpaint, "kbdrawfield": kbdrawfield, "kbkey": kbkey, "kbnear": kbnear, "kbmove": kbmove, "kbpress": kbpress, "uiask": uiask, "uidraw": uidraw, "uipaint": uipaint, "dlgkey": dlgkey, "uifinish": uifinish, "uikey": uikey, "cwload": cwload, "cwsave": cwsave, "cwfor": cwfor, "cwbegin": cwbegin, "mts0": mts0, "cwtick": cwtick, "cwkind": cwkind, "cwitems": cwitems, "cwlayout": cwlayout, "cwdraw": cwdraw, "cwupdate": cwupdate, "cwkey": cwkey, "cwremove": cwremove, "cwplay": cwplay, "supportcfg": supportcfg, "showsupport": showsupport, "supportkey": supportkey, "supportdraw": supportdraw, "mosinit": mosinit, "mosuiindex": mosuiindex, "mosload": mosload, "mossave": mossave, "mossub": mossub, "showmosaic": showmosaic, "moshide": moshide, "mosleave": mosleave, "mosslotcount": mosslotcount, "moslayout": moslayout, "mositemat": mositemat, "mosfocuseditem": mosfocuseditem, "mosstarttiles": mosstarttiles, "mosapplyrects": mosapplyrects, "mosgiveaudio": mosgiveaudio, "mosdraw": mosdraw, "mosdrawframes": mosdrawframes, "moscountlabel": moscountlabel, "mosdrawempty": mosdrawempty, "mosemptybuttons": mosemptybuttons, "mosdrawover": mosdrawover, "mosnowtext": mosnowtext, "onmostilestate": onmostilestate, "moswake": moswake, "onmosidle": onmosidle, "mostoast": mostoast, "onmostoastend": onmostoastend, "mosindexofurl": mosindexofurl, "mostoggle": mostoggle, "mosaddfromlive": mosaddfromlive, "mosentryof": mosentryof, "mosaddfrommatch": mosaddfrommatch, "mosentryofmatch": mosentryofmatch, "moslivematches": moslivematches, "mosfillmatches": mosfillmatches, "mosonmatches": mosonmatches, "mosaickey": mosaickey, "mosmove": mosmove, "mosfullscreen": mosfullscreen, "moszap": moszap, "onmosopt": onmosopt, "mosrestartall": mosrestartall, "mosopenpicker": mosopenpicker, "mosclosepicker": mosclosepicker, "mospickcount": mospickcount, "mospickrow": mospickrow, "mosdrawpicker": mosdrawpicker, "mospickkey": mospickkey, "mospickchoose": mospickchoose};
});

$defineComponent({"name":"WeatherTask","extends":"Task","fields":[{"id":"op","type":"string"},{"id":"query","type":"string"},{"id":"lat","type":"string"},{"id":"lon","type":"string"},{"id":"unit","type":"string"},{"id":"result","type":"assocarray"}],"children":[]}, function (m) {
// ---- components/weathertask.brs ----
function init() {
  m.top.functionname = "runWeather";
}

function runweather() {
  if ((m.top.op === "geo")) {
    dogeo();
  } else {
    doload();
  }
}

function getjson(url) {
  let port, http, msg, s;
  port = $createobject("roMessagePort");
  http = $createobject("roUrlTransfer");
  http.$setmessageport(port);
  http.$setcertificatesfile("common:/certs/ca-bundle.crt");
  http.$initclientcertificates();
  http.$enableencodings(true);
  http.$seturl(url);
  if ((!http.$asyncgettostring())) {
    return null;
  }
  msg = $wait(15000, port);
  if (($type(msg) !== "roUrlEvent")) {
    http.$asynccancel();
    return null;
  }
  if ((msg.$getresponsecode() !== 200)) {
    return null;
  }
  s = msg.$getstring();
  if (((s == null) || (s === ""))) {
    return null;
  }
  return $parsejson(s);
}

function num(v, d) {
  let t;
  t = $type(v);
  if (((((((((t === "Integer") || (t === "roInt")) || (t === "Float")) || (t === "roFloat")) || (t === "Double")) || (t === "roDouble")) || (t === "LongInteger")) || (t === "roLongInteger"))) {
    return v;
  }
  return d;
}

function pick(arr, i, d) {
  if ((arr == null)) {
    return d;
  }
  if (($type(arr) !== "roArray")) {
    return d;
  }
  if (((i < 0) || (i >= arr.$count()))) {
    return d;
  }
  return num($ix(arr, i), d);
}

function pickstr(arr, i) {
  let v;
  if ((arr == null)) {
    return "";
  }
  if (($type(arr) !== "roArray")) {
    return "";
  }
  if (((i < 0) || (i >= arr.$count()))) {
    return "";
  }
  v = $ix(arr, i);
  if ((($type(v) === "roString") || ($type(v) === "String"))) {
    return v;
  }
  return "";
}

function dogeo() {
  let http, url, j, list, r, label, region, country, full;
  http = $createobject("roUrlTransfer");
  url = (((("https://geocoding-api.open-meteo.com/v1/search?name=" + http.$escape(m.top.query)) + "&count=8&language=") + wxlang()) + "&format=json");
  j = getjson(url);
  if ((j == null)) {
    m.top.result = {__proto__: $AAP, "ok": false, "list": []};
    return;
  }
  list = [];
  if ((j.results != null)) {
    for (r of $iter(j.results)) {
      if ((((r.latitude != null) && (r.longitude != null)) && (r.name != null))) {
        label = r.name;
        region = "";
        if (((r.admin1 != null) && (r.admin1 !== r.name))) {
          region = r.admin1;
        }
        country = "";
        if ((r.country != null)) {
          country = r.country;
        }
        full = label;
        if ((region !== "")) {
          full = ((full + ", ") + region);
        }
        if ((country !== "")) {
          full = ((full + ", ") + country);
        }
        list.$push({__proto__: $AAP, "label": full, "name": label, "lat": r.latitude.$tostr(), "lon": r.longitude.$tostr()});
      }
    }
  }
  m.top.result = {__proto__: $AAP, "ok": true, "list": list};
}

function doload() {
  let lat, lon, tu, ws, pu, url, fx, c, cur, hours, h, prefix, start, i, $e0, $e1, hh, days, d, $e2, aq, aqj, a;
  lat = m.top.lat;
  lon = m.top.lon;
  tu = "celsius";
  ws = "kmh";
  pu = "mm";
  if ((m.top.unit === "f")) {
    tu = "fahrenheit";
    ws = "mph";
    pu = "inch";
  }
  url = ((("https://api.open-meteo.com/v1/forecast?latitude=" + lat) + "&longitude=") + lon);
  url = (url + "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m,surface_pressure,cloud_cover");
  url = (url + "&hourly=temperature_2m,precipitation_probability,weather_code,is_day");
  url = (url + "&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_sum,precipitation_probability_max");
  url = ((((((url + "&timezone=auto&forecast_days=7&temperature_unit=") + tu) + "&wind_speed_unit=") + ws) + "&precipitation_unit=") + pu);
  fx = getjson(url);
  if (((((fx == null) || (fx.current == null)) || (fx.daily == null)) || (fx.hourly == null))) {
    m.top.result = {__proto__: $AAP, "ok": false};
    return;
  }
  c = fx.current;
  cur = {__proto__: $AAP, "t": num(c.temperature_2m, 0), "feel": num(c.apparent_temperature, 0), "hum": num(c.relative_humidity_2m, (-1)), "code": num(c.weather_code, 0), "isday": num(c.is_day, 1), "precip": num(c.precipitation, 0), "wind": num(c.wind_speed_10m, 0), "dir": num(c.wind_direction_10m, (-1)), "gust": num(c.wind_gusts_10m, 0), "pres": num(c.surface_pressure, 0), "cloud": num(c.cloud_cover, 0)};
  hours = [];
  h = fx.hourly;
  prefix = "";
  if ((c.time != null)) {
    prefix = $left(c.time, 13);
  }
  start = 0;
  if ((h.time != null)) {
    for (i = 0, $e0 = (h.time.$count() - 1); i <= $e0; i++) {
      if (($left($ix(h.time, i), 13) >= prefix)) {
        start = i;
        break;
      }
    }
    for (i = start, $e1 = (h.time.$count() - 1); i <= $e1; i++) {
      if ((hours.$count() >= 12)) {
        break;
      }
      hh = $int($val($mid($ix(h.time, i), 12, 2)));
      hours.$push({__proto__: $AAP, "h": hh, "t": pick(h.temperature_2m, i, 0), "code": pick(h.weather_code, i, 0), "pop": pick(h.precipitation_probability, i, 0), "day": pick(h.is_day, i, 1)});
    }
  }
  days = [];
  d = fx.daily;
  if ((d.time != null)) {
    for (i = 0, $e2 = (d.time.$count() - 1); i <= $e2; i++) {
      days.$push({__proto__: $AAP, "date": $ix(d.time, i), "code": pick(d.weather_code, i, 0), "max": pick(d.temperature_2m_max, i, 0), "min": pick(d.temperature_2m_min, i, 0), "pop": pick(d.precipitation_probability_max, i, 0), "psum": pick(d.precipitation_sum, i, 0), "uv": pick(d.uv_index_max, i, 0), "sunrise": pickstr(d.sunrise, i), "sunset": pickstr(d.sunset, i)});
    }
  }
  aq = null;
  aqj = getjson((((("https://air-quality-api.open-meteo.com/v1/air-quality?latitude=" + lat) + "&longitude=") + lon) + "&current=us_aqi,pm2_5,pm10&timezone=auto"));
  if (((aqj != null) && (aqj.current != null))) {
    a = aqj.current;
    aq = {__proto__: $AAP, "aqi": num(a.us_aqi, (-1)), "pm25": num(a.pm2_5, (-1)), "pm10": num(a.pm10, (-1))};
  }
  m.top.result = {__proto__: $AAP, "ok": true, "ts": $createobject("roDateTime").$asseconds(), "unit": m.top.unit, "cur": cur, "hours": hours, "days": days, "aq": aq};
}

function wxlang() {
  let l;
  l = m.global.lang;
  if (((l == null) || (l === ""))) {
    return "es";
  }
  return l;
}
return {"init": init, "runweather": runweather, "getjson": getjson, "num": num, "pick": pick, "pickstr": pickstr, "dogeo": dogeo, "doload": doload, "wxlang": wxlang};
});

$defineComponent({"name":"XtreamReader","extends":"Task","fields":[{"id":"host","type":"string"},{"id":"user","type":"string"},{"id":"pass","type":"string"},{"id":"op","type":"string","value":"catalog"},{"id":"serid","type":"string"},{"id":"favs","type":"assocarray"},{"id":"listepg","type":"string"},{"id":"direct","type":"boolean","value":"false"},{"id":"progress","type":"integer","value":"0"},{"id":"status","type":"string"},{"id":"content","type":"node"},{"id":"movies","type":"node"},{"id":"series","type":"node"},{"id":"adult","type":"node"},{"id":"wanted","type":"assocarray"},{"id":"epgurl","type":"string"},{"id":"result","type":"assocarray"}],"children":[]}, function (m) {
// ---- components/xtreamreader.brs ----
function init() {
  m.top.functionname = "xtRun";
}

function xtrun() {
  m.xtbig = false;
  if ((m.top.op === "series")) {
    xtrunseries();
  } else if ((m.top.op === "vodinfo")) {
    xtrunvodinfo();
  } else {
    xtruncatalog();
  }
}

function xthttp(url) {
  let http;
  http = $createobject("roUrlTransfer");
  http.$setcertificatesfile("common:/certs/ca-bundle.crt");
  http.$initclientcertificates();
  http.$enableencodings(true);
  http.$addheader("User-Agent", "Mozilla/5.0 (Linux; Roku) SmartIPTVMX");
  http.$seturl(url);
  return http;
}

function xtjson(url, maxbytes, waitms = 90000) {
  let lbl, fs, path, port, http, msg, code, st, txt, js, rx;
  m.xtbig = false;
  m.xttimeout = false;
  m.xtsmall = false;
  lbl = xtlabel(url);
  fs = $createobject("roFileSystem");
  path = "cachefs:/xt_resp.json";
  if (fs.$exists(path)) {
    fs.$delete(path);
  }
  port = $createobject("roMessagePort");
  http = xthttp(url);
  http.$setmessageport(port);
  if ((!http.$asyncgettofile(path))) {
    console.log("[XT] ", lbl, ": no se pudo iniciar la descarga");
    return null;
  }
  msg = $wait(waitms, port);
  if (($type(msg) !== "roUrlEvent")) {
    console.log("[XT] ", lbl, ": sin respuesta en ", $int((waitms / 1000)), " s");
    m.xttimeout = true;
    http.$asynccancel();
    if (fs.$exists(path)) {
      fs.$delete(path);
    }
    return null;
  }
  code = msg.$getresponsecode();
  if ((code !== 200)) {
    console.log("[XT] ", lbl, ": codigo ", code, " ", msg.$getfailurereason());
    if (fs.$exists(path)) {
      fs.$delete(path);
    }
    return null;
  }
  st = fs.$stat(path);
  if ((st == null)) {
    console.log("[XT] ", lbl, ": respuesta sin archivo");
    return null;
  }
  if (((maxbytes > 0) && (st.size > maxbytes))) {
    console.log("[XT] ", lbl, ": ", st.size, " bytes, muy grande, se pide por categoria");
    m.xtbig = true;
    fs.$delete(path);
    return null;
  }
  if ((st.size < 64)) {
    m.xtsmall = true;
  }
  txt = $readasciifile(path);
  fs.$delete(path);
  if (((txt == null) || (txt === ""))) {
    console.log("[XT] ", lbl, ": respuesta vacia (", st.size, " bytes)");
    return null;
  }
  if (($asc($left(txt, 1)) === 65279)) {
    txt = $mid(txt, 2);
  }
  js = $parsejson(txt);
  if ((js == null)) {
    rx = $createobject("roRegex", "[\\x01-\\x1F]", "");
    js = $parsejson(rx.$replaceall(txt, " "));
    if ((js == null)) {
      console.log("[XT] ", lbl, ": JSON invalido (", st.size, " bytes). Inicio: ", $left(txt, 100));
    } else {
      console.log("[XT] ", lbl, ": JSON reparado (", st.size, " bytes)");
    }
  } else if (($type(js) === "roArray")) {
    console.log("[XT] ", lbl, ": ", js.$count(), " elementos (", st.size, " bytes)");
  }
  txt = "";
  return js;
}

function xtlabel(url) {
  let a;
  a = $instr(1, url, "action=");
  if ((a > 0)) {
    return $mid(url, (a + 7));
  }
  return "login";
}

function xtfail(msg) {
  m.top.status = ("error:" + msg);
  m.top.content = $createobject("roSGNode", "ContentNode");
}

function xtadult(s) {
  let t, w;
  t = $lcase(s);
  if (($instr(1, t, "adult swim") > 0)) {
    return false;
  }
  for (w of $iter(["xxx", "adult", "porn", "erotic", "erotik", "erot", "erót", "playboy", "sexy", "hentai", "18+", "+18"])) {
    if (($instr(1, t, w) > 0)) {
      return true;
    }
  }
  return false;
}

function xtruncatalog() {
  let base, user, pass, ue, pe, api, auth, ui, st, liveext, af, hasm3, f, livefmt, favs, ctx, live, vod, ser, total;
  base = xtbase(m.top.host);
  user = m.top.user;
  pass = m.top.pass;
  if ((((base === "") || (user === "")) || (pass === ""))) {
    xtfail(tx("Faltan datos de la cuenta Xtream."));
    return;
  }
  ue = xtesc(user);
  pe = xtesc(pass);
  api = ((((base + "/player_api.php?username=") + ue) + "&password=") + pe);
  m.top.progress = 1;
  auth = xtjson(api, 0);
  if (($type(auth) !== "roAssociativeArray")) {
    xtfail(tx("No se pudo conectar con el servidor. Revisa la dirección y tu internet."));
    return;
  }
  ui = auth.user_info;
  if (($type(ui) !== "roAssociativeArray")) {
    xtfail(tx("Usuario o contraseña incorrectos."));
    return;
  }
  if ((dstr(ui.auth) === "0")) {
    xtfail(tx("Usuario o contraseña incorrectos."));
    return;
  }
  st = $lcase(dstr(ui.status));
  if (((st !== "") && (st !== "active"))) {
    xtfail((tx("La cuenta no está activa: ") + st));
    return;
  }
  liveext = "m3u8";
  af = ui.allowed_output_formats;
  if ((($type(af) === "roArray") && (af.$count() > 0))) {
    hasm3 = false;
    for (f of $iter(af)) {
      if (($lcase(dstr(f)) === "m3u8")) {
        hasm3 = true;
      }
    }
    if ((!hasm3)) {
      liveext = "ts";
    }
  }
  livefmt = "hls";
  if ((liveext === "ts")) {
    livefmt = "ts";
  }
  favs = m.top.favs;
  if ((favs == null)) {
    favs = {__proto__: $AAP};
  }
  ctx = {__proto__: $AAP, "base": base, "ue": ue, "pe": pe, "api": api, "liveext": liveext, "livefmt": livefmt, "favs": favs, "adultroot": $createobject("roSGNode", "ContentNode")};
  live = xtsection("live", ctx, 4, 40);
  vod = xtsection("vod", ctx, 40, 72);
  ser = xtsection("series", ctx, 72, 96);
  total = ((live.$getchildcount() + vod.$getchildcount()) + ser.$getchildcount());
  if ((total === 0)) {
    xtfail(tx("El servidor no devolvió canales, películas ni series."));
    return;
  }
  m.top.progress = 99;
  m.top.epgurl = ((((base + "/xmltv.php?username=") + ue) + "&password=") + pe);
  m.top.movies = vod;
  m.top.series = ser;
  m.top.adult = ctx.adultroot;
  m.top.wanted = epgwantedof(live);
  m.top.content = live;
}

function xtsection(kind, ctx, p0, p1) {
  let root, cata, stra, catname, order, cats, c, id, groups, adg, all, okn, failn, seq, n, i, $e0, u, part, pre;
  root = $createobject("roSGNode", "ContentNode");
  cata = "get_live_categories";
  stra = "get_live_streams";
  if ((kind === "vod")) {
    cata = "get_vod_categories";
    stra = "get_vod_streams";
  } else if ((kind === "series")) {
    cata = "get_series_categories";
    stra = "get_series";
  }
  catname = {__proto__: $AAP};
  $six(catname, "_", "Otros");
  order = [];
  cats = xtjson(((ctx.api + "&action=") + cata), 0);
  if (($type(cats) !== "roArray")) {
    $sleep(1500);
    cats = xtjson(((ctx.api + "&action=") + cata), 0);
  }
  if (($type(cats) === "roArray")) {
    for (c of $iter(cats)) {
      if (($type(c) === "roAssociativeArray")) {
        id = dstr(c.category_id);
        if (((id !== "") && (!catname.$doesexist(id)))) {
          $six(catname, id, dstr(c.category_name));
          order.$push(id);
        }
      }
    }
  }
  order.$push("_");
  m.top.progress = (p0 + $int((((p1 - p0)) * 0.2)));
  groups = {__proto__: $AAP};
  adg = {__proto__: $AAP};
  all = xtjson(((ctx.api + "&action=") + stra), 20000000, 180000);
  if (((($type(all) !== "roArray") && (!m.xtbig)) && (!m.xttimeout))) {
    $sleep(2000);
    all = xtjson(((ctx.api + "&action=") + stra), 20000000, 180000);
  }
  if (($type(all) === "roArray")) {
    xtadd(kind, all, groups, ctx, catname, adg);
    all = null;
  } else if ((order.$count() > 1)) {
    all = null;
    okn = 0;
    failn = 0;
    seq = 0;
    n = (order.$count() - 1);
    for (i = 0, $e0 = (n - 1); i <= $e0; i++) {
      u = ((((ctx.api + "&action=") + stra) + "&category_id=") + xtesc($ix(order, i)));
      part = xtjson(u, 0);
      if ((($type(part) !== "roArray") && (!m.xtsmall))) {
        $sleep(1500);
        part = xtjson(u, 0);
      }
      if ((($type(part) !== "roArray") && m.xtsmall)) {
        okn = (okn + 1);
        seq = 0;
      } else if (($type(part) === "roArray")) {
        xtadd(kind, part, groups, ctx, catname, adg);
        okn = (okn + 1);
        seq = 0;
      } else {
        failn = (failn + 1);
        seq = (seq + 1);
        if (((okn === 0) && (seq >= 3))) {
          break;
        }
        if ((seq >= 8)) {
          break;
        }
        $sleep(2500);
      }
      part = null;
      $sleep(150);
      m.top.progress = (p0 + $int((((p1 - p0)) * ((0.2 + ((0.7 * ((i + 1))) / n))))));
    }
    console.log("[XT] ", kind, " por categoria: ", okn, " bien, ", failn, " fallaron, de ", n);
  }
  xtfill(kind, root, groups, order, catname, ctx);
  pre = tx("TV en vivo");
  if ((kind === "vod")) {
    pre = tx("Películas");
  }
  if ((kind === "series")) {
    pre = tx("Series");
  }
  xtfill(kind, ctx.adultroot, adg, order, catname, ctx, (pre + " · "));
  m.top.progress = p1;
  return root;
}

function xtadd(kind, items, groups, ctx, catname, adg) {
  let it, cid, name, skip, e, sid, ext, f, dest;
  for (it of $iter(items)) {
    if (($type(it) === "roAssociativeArray")) {
      cid = dstr(it.category_id);
      if (((cid === "") || (!catname.$doesexist(cid)))) {
        cid = "_";
      }
      name = dstr(it.name);
      skip = xtadult($ix(catname, cid));
      if ((((kind === "live") && (!skip)) && xtadult(name))) {
        skip = true;
      }
      if (true) {
        e = null;
        sid = "";
        if ((kind === "series")) {
          sid = dstr(it.series_id);
          if ((name === "")) {
            name = tx("Sin titulo");
          }
          if ((sid !== "")) {
            e = {__proto__: $AAP, "t": name, "sid": sid, "l": cleanlogo(dstr(it.cover)), "k": sortkey(name)};
          }
        } else if ((kind === "vod")) {
          sid = dstr(it.stream_id);
          if ((name === "")) {
            name = tx("Sin titulo");
          }
          if ((sid !== "")) {
            ext = $lcase(dstr(it.container_extension));
            if ((ext === "")) {
              ext = "mp4";
            }
            f = "mp4";
            if ((ext === "mkv")) {
              f = "mkv";
            }
            e = {__proto__: $AAP, "t": name, "u": ((((((((ctx.base + "/movie/") + ctx.ue) + "/") + ctx.pe) + "/") + sid) + ".") + ext), "i": "", "l": cleanlogo(dstr(it.stream_icon)), "n": "", "f": f, "k": sortkey(name)};
          }
        } else {
          sid = dstr(it.stream_id);
          if ((name === "")) {
            name = tx("Canal sin nombre");
          }
          if ((sid !== "")) {
            e = {__proto__: $AAP, "t": name, "u": ((((((((ctx.base + "/live/") + ctx.ue) + "/") + ctx.pe) + "/") + sid) + ".") + ctx.liveext), "i": $lcase(dstr(it.epg_channel_id)), "l": cleanlogo(dstr(it.stream_icon)), "n": dstr(it.num), "f": ctx.livefmt, "k": ""};
          }
        }
        if ((e != null)) {
          dest = groups;
          if (skip) {
            dest = adg;
          }
          if ((!dest.$doesexist(cid))) {
            $six(dest, cid, []);
          }
          $ix(dest, cid).$push(e);
        }
      }
    }
  }
}

function xtfill(kind, root, groups, order, catname, ctx, prefix = "") {
  let cid, arr, name, cat, d, e, item, sr;
  for (cid of $iter(order)) {
    arr = $ix(groups, cid);
    groups.$delete(cid);
    if (((arr != null) && (arr.$count() > 0))) {
      if ((kind !== "live")) {
        arr.$sortby("k");
      }
      name = (prefix + $ix(catname, cid));
      cat = root.$createchild("ContentNode");
      cat.id = name;
      d = "movie";
      if ((kind === "live")) {
        d = "live";
      }
      for (e of $iter(arr)) {
        item = cat.$createchild("ContentNode");
        if ((kind === "series")) {
          item.$setfields({__proto__: $AAP, "title": e.t, "id": ("xt:" + e.sid), "hdposterurl": e.l, "description": "series", "shortdescriptionline1": ("xt:" + e.sid)});
        } else {
          sr = 0;
          if (ctx.favs.$doesexist(e.u)) {
            sr = 100;
          }
          item.$setfields({__proto__: $AAP, "title": e.t, "url": e.u, "id": e.i, "streamformat": e.f, "hdposterurl": e.l, "shortdescriptionline1": e.n, "description": d, "starrating": sr});
        }
      }
      cat.title = (((name + "  (") + cat.$getchildcount().$tostr()) + ")");
    }
  }
}

function xtrunseries() {
  let base, ue, pe, res, j, cover, inf, bd, raw, eps, key, arr, i, sr, list, ep, eid, ext, f, num, poster, eplot, edur, secs, et, pr;
  base = xtbase(m.top.host);
  ue = xtesc(m.top.user);
  pe = xtesc(m.top.pass);
  res = {__proto__: $AAP, "ok": false, "seasons": [], "info": {__proto__: $AAP}};
  j = xtjson(((((((base + "/player_api.php?username=") + ue) + "&password=") + pe) + "&action=get_series_info&series_id=") + xtesc(m.top.serid)), 0);
  if (($type(j) === "roAssociativeArray")) {
    cover = "";
    if (($type(j.info) === "roAssociativeArray")) {
      inf = j.info;
      cover = cleanlogo(dstr(inf.cover));
      bd = inf.backdrop_path;
      if (($type(bd) === "roArray")) {
        if ((bd.$count() > 0)) {
          bd = $ix(bd, 0);
        } else {
          bd = "";
        }
      }
      res.info = {__proto__: $AAP, "plot": xtfirst(inf, ["plot", "description"]), "cast": xtfirst(inf, ["cast", "actors"]), "director": xtfirst(inf, ["director"]), "genre": xtfirst(inf, ["genre"]), "date": xtfirst(inf, ["releaseDate", "releasedate", "release_date"]), "rating": xtfirst(inf, ["rating"]), "backdrop": cleanlogo(dstr(bd)), "cover": cover};
    }
    raw = [];
    eps = j.episodes;
    if (($type(eps) === "roAssociativeArray")) {
      for (key of $iter(eps)) {
        arr = $ix(eps, key);
        if (($type(arr) === "roArray")) {
          raw.$push({__proto__: $AAP, "s": $int($val(key)), "arr": arr});
        }
      }
    } else if (($type(eps) === "roArray")) {
      i = 0;
      for (arr of $iter(eps)) {
        i = (i + 1);
        if (($type(arr) === "roArray")) {
          raw.$push({__proto__: $AAP, "s": i, "arr": arr});
        }
      }
    }
    for (sr of $iter(raw)) {
      list = [];
      for (ep of $iter(sr.arr)) {
        if (($type(ep) === "roAssociativeArray")) {
          eid = dstr(ep.id);
          if ((eid !== "")) {
            ext = $lcase(dstr(ep.container_extension));
            if ((ext === "")) {
              ext = "mp4";
            }
            f = "mp4";
            if ((ext === "mkv")) {
              f = "mkv";
            }
            num = $int($val(dstr(ep.episode_num)));
            if ((num <= 0)) {
              num = (list.$count() + 1);
            }
            poster = "";
            eplot = "";
            edur = "";
            if (($type(ep.info) === "roAssociativeArray")) {
              poster = cleanlogo(dstr(ep.info.movie_image));
              eplot = xtfirst(ep.info, ["plot", "overview"]);
              edur = xtfirst(ep.info, ["duration"]);
              if ((edur === "")) {
                secs = $int($val(xtfirst(ep.info, ["duration_secs"])));
                if ((secs > 0)) {
                  edur = ((($idiv(secs, 3600)).$tostr() + ":") + ($idiv(((secs % 3600)), 60)).$tostr());
                }
              }
            }
            if ((poster === "")) {
              poster = cover;
            }
            et = dstr(ep.title);
            if (($instr(1, et, "&") > 0)) {
              et = decodeentities(et);
            }
            pr = epparse(et);
            if ((pr != null)) {
              et = pr.t;
            }
            list.$push({__proto__: $AAP, "e": num, "t": et, "u": ((((((((base + "/series/") + ue) + "/") + pe) + "/") + eid) + ".") + ext), "f": f, "l": poster, "p": eplot, "d": edur});
          }
        }
      }
      if ((list.$count() > 0)) {
        list.$sortby("e");
        res.seasons.$push({__proto__: $AAP, "s": sr.s, "eps": list});
      }
    }
    res.seasons.$sortby("s");
    if ((res.seasons.$count() > 0)) {
      res.ok = true;
    }
  }
  m.top.result = res;
}

function xtrunvodinfo() {
  let res, ut, user, pass, url, port, http, msg, j, inf, bd;
  res = {__proto__: $AAP, "ok": false};
  ut = $createobject("roUrlTransfer");
  user = ut.$unescape(m.top.user);
  pass = ut.$unescape(m.top.pass);
  if ((user == null)) {
    user = m.top.user;
  }
  if ((pass == null)) {
    pass = m.top.pass;
  }
  url = ((((((xtbase(m.top.host) + "/player_api.php?username=") + xtesc(user)) + "&password=") + xtesc(pass)) + "&action=get_vod_info&vod_id=") + xtesc(m.top.serid));
  port = $createobject("roMessagePort");
  http = xthttp(url);
  http.$setmessageport(port);
  if (http.$asyncgettostring()) {
    msg = $wait(20000, port);
    if (($type(msg) === "roUrlEvent")) {
      if ((msg.$getresponsecode() === 200)) {
        j = $parsejson(msg.$getstring());
        if (($type(j) === "roAssociativeArray")) {
          if (($type(j.info) === "roAssociativeArray")) {
            inf = j.info;
            res.plot = xtfirst(inf, ["plot", "description"]);
            res.cast = xtfirst(inf, ["cast", "actors"]);
            res.director = xtfirst(inf, ["director"]);
            res.genre = xtfirst(inf, ["genre"]);
            res.date = xtfirst(inf, ["releasedate", "release_date", "releaseDate"]);
            res.duration = xtfirst(inf, ["duration"]);
            res.rating = xtfirst(inf, ["rating"]);
            bd = inf.backdrop_path;
            if (($type(bd) === "roArray")) {
              if ((bd.$count() > 0)) {
                bd = $ix(bd, 0);
              } else {
                bd = "";
              }
            }
            res.backdrop = cleanlogo(dstr(bd));
            res.poster = cleanlogo(xtfirst(inf, ["movie_image", "cover_big"]));
            res.ok = true;
          }
        }
      }
    } else {
      http.$asynccancel();
    }
  }
  m.top.result = res;
}

function xtfirst(inf, keys) {
  let k, v;
  for (k of $iter(keys)) {
    v = dstr($ix(inf, k)).$trim();
    if ((((v !== "") && (v !== "0")) && ($lcase(v) !== "null"))) {
      if (($instr(1, v, "&") > 0)) {
        v = decodeentities(decodeentities(v));
      }
      return v;
    }
  }
  return "";
}
// ---- components/xtcommon.brs ----
function dstr(v) {
  let t;
  t = $type(v);
  if (((t === "roString") || (t === "String"))) {
    return v;
  }
  if (((((((((((t === "roInt") || (t === "Integer")) || (t === "roLongInteger")) || (t === "LongInteger")) || (t === "roFloat")) || (t === "Float")) || (t === "roDouble")) || (t === "Double")) || (t === "roBoolean")) || (t === "Boolean"))) {
    return v.$tostr();
  }
  return "";
}

function xtesc(s) {
  let ba, hex, out, i, $e0, b;
  ba = $createobject("roByteArray");
  ba.$fromasciistring(s);
  hex = "0123456789ABCDEF";
  out = "";
  for (i = 0, $e0 = (ba.$count() - 1); i <= $e0; i++) {
    b = $ix(ba, i);
    if ((((((((((b >= 48) && (b <= 57))) || (((b >= 65) && (b <= 90)))) || (((b >= 97) && (b <= 122)))) || (b === 45)) || (b === 46)) || (b === 95)) || (b === 126))) {
      out = (out + $chr(b));
    } else {
      out = (((out + "%") + $mid(hex, (($idiv(b, 16)) + 1), 1)) + $mid(hex, (((b % 16)) + 1), 1));
    }
  }
  return out;
}

function xthexval(c) {
  if (((c >= 48) && (c <= 57))) {
    return (c - 48);
  }
  if (((c >= 65) && (c <= 70))) {
    return (c - 55);
  }
  if (((c >= 97) && (c <= 102))) {
    return (c - 87);
  }
  return (-1);
}

function xtunesc(s) {
  let src, dst, n, i, b, used, hi, lo;
  src = $createobject("roByteArray");
  src.$fromasciistring(s);
  dst = $createobject("roByteArray");
  n = src.$count();
  i = 0;
  while ((i < n)) {
    b = $ix(src, i);
    used = false;
    if ((b === 37)) {
      if (((i + 2) < n)) {
        hi = xthexval($ix(src, (i + 1)));
        lo = xthexval($ix(src, (i + 2)));
        if (((hi >= 0) && (lo >= 0))) {
          dst.$push(((hi * 16) + lo));
          i = (i + 3);
          used = true;
        }
      }
    }
    if ((!used)) {
      dst.$push(b);
      i = (i + 1);
    }
  }
  return dst.$toasciistring();
}

function xtbase(h) {
  let s, low, q, done, tail;
  s = h.$trim();
  if ((s === "")) {
    return "";
  }
  low = $lcase(s);
  if ((($left(low, 7) !== "http://") && ($left(low, 8) !== "https://"))) {
    s = ("http://" + s);
  }
  q = $instr(1, s, "?");
  if ((q > 0)) {
    s = $left(s, (q - 1));
  }
  done = false;
  while ((!done)) {
    done = true;
    while ((($right(s, 1) === "/") && ($len(s) > 8))) {
      s = $left(s, ($len(s) - 1));
      done = false;
    }
    for (tail of $iter(["/player_api.php", "/get.php", "/xmltv.php", "/panel_api.php", "/c"])) {
      if (((($len(s) - $len(tail)) > 8) && ($lcase($right(s, $len(tail))) === tail))) {
        s = $left(s, ($len(s) - $len(tail)));
        done = false;
      }
    }
  }
  return s;
}

function xtparam(s, key) {
  let low, sep, p, st, en;
  low = $lcase(s);
  for (sep of $iter(["?", "&"])) {
    p = $instr(1, low, ((sep + $lcase(key)) + "="));
    if ((p > 0)) {
      st = ((p + $len(key)) + 2);
      en = $instr(st, s, "&");
      if ((en === 0)) {
        en = ($len(s) + 1);
      }
      return xtunesc($mid(s, st, (en - st)));
    }
  }
  return "";
}

function xtfromurl(s) {
  let u, p;
  u = xtparam(s, "username");
  p = xtparam(s, "password");
  if (((u === "") || (p === ""))) {
    return null;
  }
  return {__proto__: $AAP, "host": xtbase(s), "user": u, "pass": p};
}
// ---- components/utils.brs ----
function getattr(s, key) {
  let pat, p, okp, vstart, q, e, total, c;
  pat = (key + "=");
  p = $instr(1, s, pat);
  while ((p > 0)) {
    okp = false;
    if ((p === 1)) {
      okp = true;
    } else {
      okp = (($mid(s, (p - 1), 1) === " "));
    }
    if (okp) {
      break;
    }
    p = $instr((p + 1), s, pat);
  }
  if ((p === 0)) {
    return "";
  }
  vstart = (p + $len(pat));
  q = $mid(s, vstart, 1);
  if (((q === $chr(34)) || (q === "'"))) {
    e = $instr((vstart + 1), s, q);
    if ((e === 0)) {
      return "";
    }
    return $mid(s, (vstart + 1), ((e - vstart) - 1));
  }
  total = $len(s);
  e = vstart;
  while ((e <= total)) {
    c = $mid(s, e, 1);
    if (((c === " ") || (c === ","))) {
      break;
    }
    e = (e + 1);
  }
  return $mid(s, vstart, (e - vstart));
}

function normname(s) {
  let out, i, $e0, c, a;
  s = $lcase(s);
  out = "";
  for (i = 1, $e0 = $len(s); i <= $e0; i++) {
    c = $mid(s, i, 1);
    a = $asc(c);
    if (((((a >= 97) && (a <= 122))) || (((a >= 48) && (a <= 57))))) {
      out = (out + c);
    }
  }
  return out;
}

function decodeentities(s) {
  let p, semi, numstr, code, repl;
  p = $instr(1, s, "&#");
  while ((p > 0)) {
    semi = $instr(p, s, ";");
    if (((semi === 0) || ((semi - p) > 8))) {
      break;
    }
    numstr = $mid(s, (p + 2), ((semi - p) - 2));
    code = 0;
    if ((($left(numstr, 1) === "x") || ($left(numstr, 1) === "X"))) {
      code = $val($mid(numstr, 2), 16);
    } else {
      code = $val(numstr, 10);
    }
    repl = "";
    if ((code > 0)) {
      repl = $chr(code);
    }
    s = (($left(s, (p - 1)) + repl) + $mid(s, (semi + 1)));
    p = $instr((p + 1), s, "&#");
  }
  s = s.$replace("&lt;", "<");
  s = s.$replace("&gt;", ">");
  s = s.$replace("&quot;", $chr(34));
  s = s.$replace("&apos;", "'");
  s = s.$replace("&#39;", "'");
  s = s.$replace("&amp;", "&");
  return s;
}

function pad2(n) {
  if ((n < 10)) {
    return ("0" + n.$tostr());
  }
  return n.$tostr();
}

function fmttime(secs) {
  let dt;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  return i18nhm(dt.$gethours(), pad2(dt.$getminutes()), false);
}

function fmttimelong(secs) {
  let dt;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  return i18nhm(dt.$gethours(), pad2(dt.$getminutes()), true);
}

function fmtday(secs) {
  let dt, days, months;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  days = i18ndow3();
  months = i18nmon3();
  return (((($ix(days, dt.$getdayofweek()) + " ") + dt.$getdayofmonth().$tostr()) + " ") + $ix(months, (dt.$getmonth() - 1)));
}

function cleanlogo(u) {
  let low, base, q;
  u = u.$trim();
  if (((u === "") || ($len(u) > 2000))) {
    return "";
  }
  low = $lcase(u);
  if (($left(low, 4) !== "http")) {
    return "";
  }
  base = low;
  q = $instr(1, low, "?");
  if ((q > 0)) {
    base = $left(low, (q - 1));
  }
  if (($right(base, 4) === ".svg")) {
    return "";
  }
  return u;
}

function epgwantedof(root) {
  let wanted, i, $e1, cat, j, $e2, ch, cid, nk;
  wanted = {__proto__: $AAP};
  if ((root == null)) {
    return wanted;
  }
  for (i = 0, $e1 = (root.$getchildcount() - 1); i <= $e1; i++) {
    cat = root.$getchild(i);
    for (j = 0, $e2 = (cat.$getchildcount() - 1); j <= $e2; j++) {
      ch = cat.$getchild(j);
      cid = ch.id;
      if (((cid != null) && (cid !== ""))) {
        $six(wanted, $lcase(cid), true);
      }
      nk = normname(ch.title);
      if ((nk !== "")) {
        $six(wanted, nk, true);
      }
    }
  }
  return wanted;
}
// ---- components/series.brs ----
function epregexes() {
  let b;
  if ((m.eprx == null)) {
    b = "(?:^|[\\s\\.\\-_\\[\\(])";
    m.eprx = [{__proto__: $AAP, "rx": $createobject("roRegex", (b + "S(\\d{1,2})[\\s\\.\\-_]*E(\\d{1,3})(?!\\d)"), "i"), "strong": true}, {__proto__: $AAP, "rx": $createobject("roRegex", (b + "(?:(?:Season|Temporada|Temp)\\.?\\s*|T)(\\d{1,2})[\\s\\.\\-_,]*(?:Episode|Episodio|Cap\\w*|Ep|E)\\.?\\s*(\\d{1,3})(?!\\d)"), "i"), "strong": true}, {__proto__: $AAP, "rx": $createobject("roRegex", (b + "(\\d{1,2})x(\\d{1,3})(?![\\dp])"), "i"), "strong": false}];
  }
  return m.eprx;
}

function epparse(title) {
  let p, r, full, at, nm, rest;
  for (p of $iter(epregexes())) {
    r = p.rx.$match(title);
    if ((r.$count() >= 3)) {
      full = $ix(r, 0);
      at = $instr(1, title, full);
      if ((at > 0)) {
        nm = eptrim($left(title, (at - 1)));
        rest = eptrim($mid(title, (at + $len(full))));
        return {__proto__: $AAP, "name": nm, "s": $val($ix(r, 1)), "e": $val($ix(r, 2)), "t": rest, "strong": p.strong};
      }
    }
  }
  return null;
}

function eptrim(s) {
  let seps;
  s = s.$trim();
  seps = "-:|.,([_ ";
  while ((($len(s) > 0) && ($instr(1, seps, $left(s, 1)) > 0))) {
    s = $mid(s, 2).$trim();
  }
  while ((($len(s) > 0) && ($instr(1, seps, $right(s, 1)) > 0))) {
    s = $left(s, ($len(s) - 1)).$trim();
  }
  return s;
}

function sortkey(t) {
  let s, ff, tt, i, $e0, a;
  s = $lcase(t);
  ff = ["á", "é", "í", "ó", "ú", "ü", "ñ", "Á", "É", "Í", "Ó", "Ú", "Ü", "Ñ"];
  tt = ["a", "e", "i", "o", "u", "u", "n", "a", "e", "i", "o", "u", "u", "n"];
  for (i = 0, $e0 = (ff.$count() - 1); i <= $e0; i++) {
    s = s.$replace($ix(ff, i), $ix(tt, i));
  }
  while (($len(s) > 1)) {
    a = $asc($left(s, 1));
    if (((((a >= 48) && (a <= 57))) || (((a >= 97) && (a <= 122))))) {
      break;
    }
    s = $mid(s, 2);
  }
  return s;
}

function seradd(sd, order, gname, ep, entry) {
  let g, key, rec, sk, num;
  if ((!sd.$doesexist(gname))) {
    $six(sd, gname, {__proto__: $AAP, "order": [], "map": {__proto__: $AAP}});
    order.$push(gname);
  }
  g = $ix(sd, gname);
  key = $lcase(ep.name);
  if ((!g.map.$doesexist(key))) {
    $six(g.map, key, {__proto__: $AAP, "name": ep.name, "poster": "", "seasons": {__proto__: $AAP}, "snums": []});
    g.order.$push(key);
  }
  rec = $ix(g.map, key);
  if (((rec.poster === "") && (entry.l !== ""))) {
    rec.poster = entry.l;
  }
  sk = ep.s.$tostr();
  if ((!rec.seasons.$doesexist(sk))) {
    $six(rec.seasons, sk, []);
    rec.snums.$push(ep.s);
  }
  num = ep.e;
  if ((num <= 0)) {
    num = ($ix(rec.seasons, sk).$count() + 1);
  }
  $ix(rec.seasons, sk).$push({__proto__: $AAP, "e": num, "t": ep.t, "u": entry.u, "f": entry.f, "l": entry.l});
}

function serfill(root, sd, order) {
  let gname, g, arr, key, rec, cat, a, sn, s, season, eps, ep, item;
  for (gname of $iter(order)) {
    g = $ix(sd, gname);
    arr = [];
    for (key of $iter(g.order)) {
      rec = $ix(g.map, key);
      arr.$push({__proto__: $AAP, "k": sortkey(rec.name), "r": rec});
    }
    arr.$sortby("k");
    cat = root.$createchild("ContentNode");
    cat.id = gname;
    cat.title = (((gname + "  (") + arr.$count().$tostr()) + ")");
    for (a of $iter(arr)) {
      rec = a.r;
      sn = cat.$createchild("ContentNode");
      sn.title = rec.name;
      sn.id = $lcase(rec.name);
      sn.hdposterurl = rec.poster;
      sn.description = "series";
      rec.snums.$sort();
      for (s of $iter(rec.snums)) {
        season = sn.$createchild("ContentNode");
        season.id = s.$tostr();
        season.title = (tx("Temporada ") + s.$tostr());
        eps = $ix(rec.seasons, s.$tostr());
        eps.$sortby("e");
        for (ep of $iter(eps)) {
          item = season.$createchild("ContentNode");
          item.title = sereptitle(rec.name, s, ep);
          item.shortdescriptionline2 = ep.t;
          item.url = ep.u;
          item.streamformat = ep.f;
          item.hdposterurl = ep.l;
          item.shortdescriptionline1 = ep.e.$tostr();
          item.description = "movie";
        }
      }
    }
  }
}

function serfilldirect(root, sd, order, seen, favs) {
  let gname, g, arr, key, rec, cat, a, sn, s, eps, season, ep, u, sr, item;
  for (gname of $iter(order)) {
    g = $ix(sd, gname);
    sd.$delete(gname);
    if (((g == null) || ($lcase(gname) === "adultos"))) {
      continue;
    }
    arr = [];
    for (key of $iter(g.order)) {
      rec = $ix(g.map, key);
      arr.$push({__proto__: $AAP, "k": sortkey(rec.name), "r": rec});
    }
    arr.$sortby("k");
    cat = null;
    for (a of $iter(arr)) {
      rec = a.r;
      sn = null;
      rec.snums.$sort();
      for (s of $iter(rec.snums)) {
        eps = $ix(rec.seasons, s.$tostr());
        eps.$sortby("e");
        season = null;
        for (ep of $iter(eps)) {
          u = ep.u;
          if (((u !== "") && (!seen.$doesexist(u)))) {
            $six(seen, u, true);
            if ((cat == null)) {
              cat = root.$createchild("ContentNode");
              cat.id = gname;
            }
            if ((sn == null)) {
              sn = cat.$createchild("ContentNode");
              sn.$setfields({__proto__: $AAP, "title": rec.name, "id": $lcase(rec.name), "hdposterurl": rec.poster, "description": "series"});
            }
            if ((season == null)) {
              season = sn.$createchild("ContentNode");
              season.id = s.$tostr();
              season.title = (tx("Temporada ") + s.$tostr());
            }
            sr = 0;
            if (favs.$doesexist(u)) {
              sr = 100;
            }
            item = season.$createchild("ContentNode");
            item.$setfields({__proto__: $AAP, "title": sereptitle(rec.name, s, ep), "shortdescriptionline2": ep.t, "url": u, "streamformat": ep.f, "hdposterurl": ep.l, "shortdescriptionline1": ep.e.$tostr(), "description": "movie", "starrating": sr});
          }
        }
      }
    }
    if ((cat != null)) {
      cat.title = (((gname + "  (") + cat.$getchildcount().$tostr()) + ")");
    }
  }
}

function sereptitle(name, s, ep) {
  let t;
  t = ((((name + "  T") + s.$tostr()) + " E") + ep.e.$tostr());
  if ((ep.t !== "")) {
    t = ((t + " - ") + ep.t);
  }
  return t;
}
// ---- components/i18n.brs ----
function i18nlangs() {
  return [{__proto__: $AAP, "code": "es", "name": "Español", "flag": "pkg:/images/flag_es.png"}, {__proto__: $AAP, "code": "en", "name": "English", "flag": "pkg:/images/flag_en.png"}, {__proto__: $AAP, "code": "pt", "name": "Português", "flag": "pkg:/images/flag_pt.png"}, {__proto__: $AAP, "code": "fr", "name": "Français", "flag": "pkg:/images/flag_fr.png"}, {__proto__: $AAP, "code": "de", "name": "Deutsch", "flag": "pkg:/images/flag_de.png"}, {__proto__: $AAP, "code": "it", "name": "Italiano", "flag": "pkg:/images/flag_it.png"}];
}

function i18nvalid(code) {
  let l;
  for (l of $iter(i18nlangs())) {
    if ((l.code === code)) {
      return true;
    }
  }
  return false;
}

function i18ndetect() {
  let code, di, loc, c;
  code = "en";
  di = $createobject("roDeviceInfo");
  if ((di != null)) {
    loc = di.$getcurrentlocale();
    if (((loc != null) && ($len(loc) >= 2))) {
      c = $lcase($left(loc, 2));
      if (i18nvalid(c)) {
        code = c;
      }
    }
  }
  return code;
}

function i18nload(lang) {
  let d, txt, arr, p;
  d = $createobject("roAssociativeArray");
  d.$setmodecasesensitive();
  txt = $readasciifile((("pkg:/locale/" + lang) + ".json"));
  if (((txt != null) && (txt !== ""))) {
    arr = $parsejson(txt);
    if ((arr != null)) {
      for (p of $iter(arr)) {
        $six(d, $ix(p, 0), $ix(p, 1));
      }
    }
  }
  m.i18nd = d;
  m.i18nlang = lang;
}

function tx(s) {
  let lang, v;
  lang = m.global.lang;
  if ((lang == null)) {
    return s;
  }
  if ((lang === "es")) {
    return s;
  }
  if ((m.i18nlang == null)) {
    i18nload(lang);
  } else if ((m.i18nlang !== lang)) {
    i18nload(lang);
  }
  v = m.i18nd.$lookup(s);
  if ((v == null)) {
    return s;
  }
  return v;
}

function i18nlang() {
  let l;
  l = m.global.lang;
  if ((l == null)) {
    return "es";
  }
  return l;
}

function i18n24h() {
  let l;
  l = i18nlang();
  return (((l !== "es") && (l !== "en")));
}

function i18ndow3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  }
  if ((l === "pt")) {
    return ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
  }
  if ((l === "fr")) {
    return ["dim.", "lun.", "mar.", "mer.", "jeu.", "ven.", "sam."];
  }
  if ((l === "de")) {
    return ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
  }
  if ((l === "it")) {
    return ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
  }
  return ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
}

function i18nmon3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  }
  if ((l === "pt")) {
    return ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
  }
  if ((l === "fr")) {
    return ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
  }
  if ((l === "de")) {
    return ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];
  }
  if ((l === "it")) {
    return ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"];
  }
  return ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
}

function i18ndowfull() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  }
  if ((l === "pt")) {
    return ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
  }
  if ((l === "fr")) {
    return ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  }
  if ((l === "de")) {
    return ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
  }
  if ((l === "it")) {
    return ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"];
  }
  return ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
}

function i18ncompass() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  }
  if ((l === "pt")) {
    return ["N", "NE", "L", "SE", "S", "SO", "O", "NO"];
  }
  if ((l === "de")) {
    return ["N", "NO", "O", "SO", "S", "SW", "W", "NW"];
  }
  if ((l === "it")) {
    return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
  }
  return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
}

function i18nhm(h, mm, longfmt) {
  let hs, h12, l, suf;
  if (i18n24h()) {
    hs = h.$tostr();
    if ((h < 10)) {
      hs = ("0" + hs);
    }
    return ((hs + ":") + mm);
  }
  h12 = (h % 12);
  if ((h12 === 0)) {
    h12 = 12;
  }
  l = i18nlang();
  if ((l === "en")) {
    suf = " AM";
    if ((h >= 12)) {
      suf = " PM";
    }
    if ((!longfmt)) {
      suf = "a";
      if ((h >= 12)) {
        suf = "p";
      }
    }
    return (((h12.$tostr() + ":") + mm) + suf);
  }
  if (longfmt) {
    suf = " a. m.";
    if ((h >= 12)) {
      suf = " p. m.";
    }
  } else {
    suf = "a";
    if ((h >= 12)) {
      suf = "p";
    }
  }
  return (((h12.$tostr() + ":") + mm) + suf);
}
return {"init": init, "xtrun": xtrun, "xthttp": xthttp, "xtjson": xtjson, "xtlabel": xtlabel, "xtfail": xtfail, "xtadult": xtadult, "xtruncatalog": xtruncatalog, "xtsection": xtsection, "xtadd": xtadd, "xtfill": xtfill, "xtrunseries": xtrunseries, "xtrunvodinfo": xtrunvodinfo, "xtfirst": xtfirst, "dstr": dstr, "xtesc": xtesc, "xthexval": xthexval, "xtunesc": xtunesc, "xtbase": xtbase, "xtparam": xtparam, "xtfromurl": xtfromurl, "getattr": getattr, "normname": normname, "decodeentities": decodeentities, "pad2": pad2, "fmttime": fmttime, "fmttimelong": fmttimelong, "fmtday": fmtday, "cleanlogo": cleanlogo, "epgwantedof": epgwantedof, "epregexes": epregexes, "epparse": epparse, "eptrim": eptrim, "sortkey": sortkey, "seradd": seradd, "serfill": serfill, "serfilldirect": serfilldirect, "sereptitle": sereptitle, "i18nlangs": i18nlangs, "i18nvalid": i18nvalid, "i18ndetect": i18ndetect, "i18nload": i18nload, "tx": tx, "i18nlang": i18nlang, "i18n24h": i18n24h, "i18ndow3": i18ndow3, "i18nmon3": i18nmon3, "i18ndowfull": i18ndowfull, "i18ncompass": i18ncompass, "i18nhm": i18nhm};
});

