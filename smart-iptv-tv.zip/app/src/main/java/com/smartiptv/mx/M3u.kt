package com.smartiptv.mx

data class Channel(
    val name: String,
    val group: String,
    val url: String,
    val logo: String
)

object M3u {

    fun parse(text: String): List<Channel> {
        val out = ArrayList<Channel>()
        var name = ""
        var group = ""
        var logo = ""
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (line.startsWith("#EXTINF")) {
                group = attr(line, "group-title")
                logo = attr(line, "tvg-logo")
                val q = line.lastIndexOf('"')
                val comma = line.indexOf(',', if (q >= 0) q else 0)
                name = if (comma >= 0) line.substring(comma + 1).trim() else ""
                if (name.isEmpty()) name = attr(line, "tvg-name")
            } else if (!line.startsWith("#")) {
                if (line.startsWith("http://") || line.startsWith("https://")) {
                    out.add(
                        Channel(
                            if (name.isEmpty()) "Canal sin nombre" else name,
                            if (group.isEmpty()) "General" else group,
                            line,
                            logo
                        )
                    )
                }
                name = ""
                group = ""
                logo = ""
            }
        }
        return out
    }

    private fun attr(line: String, key: String): String {
        val k = "$key=\""
        val i = line.indexOf(k)
        if (i < 0) return ""
        val s = i + k.length
        val e = line.indexOf('"', s)
        if (e < 0) return ""
        return line.substring(s, e).trim()
    }
}
