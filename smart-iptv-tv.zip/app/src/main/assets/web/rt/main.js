// Equivalente a source/main.brs: crea la escena principal
'use strict';
$G.$onBrsError = function (e) { /* se registra en la consola */ };
$startApp('VideoListScene');
