package com.smartiptv.mx

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.UnrecognizedInputFormatException
import androidx.media3.ui.PlayerView
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity() {

    private val cBg = 0xFF090A0C.toInt()
    private val cCard = 0xFF17191D.toInt()
    private val cCardOn = 0xFF20232A.toInt()
    private val cLine = 0xFF2A2D33.toInt()
    private val cOrange = 0xFFFF6A00.toInt()
    private val cOrangeLight = 0xFFFFB067.toInt()
    private val cText = 0xFFF4F5F7.toInt()
    private val cMuted = 0xFF9CA0A8.toInt()

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private lateinit var store: Store

    private var playlists = ArrayList<Playlist>()
    private var catalog = Catalog(LinkedHashMap(), LinkedHashMap(), ArrayList())
    private val counts = ConcurrentHashMap<String, Int>()
    private var favs = ArrayList<Channel>()
    private val favKeys = HashSet<String>()
    private var searchIdx: List<Pair<String, Channel>>? = null

    private var screen = "home"
    private var backTo = "home"
    private var resumeHome = false
    private var server: LocalServer? = null

    // Navegacion
    private val browseGroup = HashMap<String, Int>()
    private val browsePos = HashMap<String, Int>()
    private var browseMode = "play"
    private var listMode = "toggle"
    private var favRemove = false
    private val picks = ArrayList<Channel>()

    // Reloj
    private var clockTime: TextView? = null
    private var clockDate: TextView? = null
    private val clockTick = object : Runnable {
        override fun run() {
            updateClock()
            if (clockTime != null) ui.postDelayed(this, 20000)
        }
    }

    // Reproduccion
    private var single: ExoPlayer? = null
    private var singleStream: Stream? = null
    private var playList: List<Channel> = emptyList()
    private var playIndex = 0
    private var playRoot: FrameLayout? = null
    private var infoView: TextView? = null
    private var audioDiag = ""
    private var ctlBar: View? = null
    private var ctlProgress: ProgressBar? = null
    private var ctlTime: TextView? = null
    private var ctlVisible = false
    private var panel: View? = null
    private val tileStreams = ArrayList<Stream>()

    private val hideInfo = Runnable { infoView?.visibility = View.GONE }
    private val hideCtl = Runnable { hideControls() }
    private val ctlTick = object : Runnable {
        override fun run() {
            updateCtl()
            if (ctlVisible) ui.postDelayed(this, 500)
        }
    }
    private val bmTick = object : Runnable {
        override fun run() {
            saveBookmark()
            ui.postDelayed(this, 10000)
        }
    }

    // ------------------------------------------------------------------
    // Ciclo de vida
    // ------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        root = FrameLayout(this)
        root.setBackgroundColor(cBg)
        setContentView(root)

        store = Store(this)
        playlists = store.playlists()
        favs = store.favorites()
        rebuildFavKeys()
        File(filesDir, "list.m3u").delete()

        if (playlists.isEmpty()) {
            showLists()
        } else {
            val l = label("Cargando tus listas...", 24f, cMuted)
            l.gravity = Gravity.CENTER
            setScreen(l)
            loadCatalog(emptySet()) { showHome() }
        }
    }

    override fun onStop() {
        super.onStop()
        if (screen == "player" || screen == "mosaic") {
            stopAll()
            resumeHome = true
        }
    }

    override fun onStart() {
        super.onStart()
        if (resumeHome) {
            resumeHome = false
            showHome()
        }
    }

    override fun onDestroy() {
        stopAll()
        server?.stop()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (screen) {
            "player" -> if (panel != null) closePanel() else reopen(backTo)
            "mosaic" -> showBrowse("live")
            "live", "movies", "favs", "search" -> showHome()
            "lists" -> if (playlists.isEmpty()) super.onBackPressed() else showHome()
            else -> super.onBackPressed()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (screen == "player" && single != null && panel == null) {
            val vod = playList[playIndex].vod
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> {
                    if (vod) openPanel() else zap(1)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                    if (vod) openPanel() else zap(-1)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    if (vod) seekBy(-10000) else openPanel()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    if (vod) seekBy(10000) else openPanel()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    if (vod) togglePause() else showInfo()
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                    togglePause()
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                    seekBy(30000)
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_REWIND -> {
                    seekBy(-30000)
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ------------------------------------------------------------------
    // Utilidades de interfaz
    // ------------------------------------------------------------------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun setScreen(v: View) {
        root.removeAllViews()
        root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(w, h, weight)
    }

    private fun spacer(): View {
        return View(this)
    }

    private fun rounded(color: Int, radius: Int, stroke: Int, strokeColor: Int): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(radius).toFloat()
        g.setColor(color)
        if (stroke > 0) g.setStroke(dp(stroke), strokeColor)
        return g
    }

    private fun button(text: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 17f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(22), dp(10), dp(22), dp(10))
        t.isFocusable = true
        t.isClickable = true
        fun paint(focused: Boolean) {
            t.background = rounded(
                if (focused) cOrange else cCard, 30, 2,
                if (focused) cOrangeLight else cLine
            )
            t.setTextColor(if (focused) cBg else cText)
        }
        paint(false)
        t.setOnFocusChangeListener { _, f -> paint(f) }
        t.setOnClickListener { onClick() }
        return t
    }

    private fun field(hint: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setSingleLine()
        e.textSize = 18f
        e.setTextColor(cText)
        e.setHintTextColor(cMuted)
        e.imeOptions = EditorInfo.IME_ACTION_DONE
        e.background = rounded(cCard, 14, 2, cLine)
        e.setPadding(dp(18), dp(10), dp(18), dp(10))
        return e
    }

    private fun icon(res: Int, sizeDp: Int, color: Int): ImageView {
        val v = ImageView(this)
        v.setImageResource(res)
        v.setColorFilter(color)
        v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return v
    }

    private fun listAdapter(items: List<String>, mark: (Int) -> Boolean): ArrayAdapter<String> {
        val ctx = this
        return object : ArrayAdapter<String>(ctx, android.R.layout.simple_list_item_1, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                val marked = mark(position)
                v.text = getItem(position) ?: ""
                v.setTextColor(if (marked) cOrangeLight else cText)
                v.textSize = 19f
                v.maxLines = 1
                v.ellipsize = TextUtils.TruncateAt.END
                v.setPadding(dp(18), dp(11), dp(18), dp(11))
                return v
            }
        }
    }

    private fun styleList(lv: ListView) {
        lv.divider = null
        lv.selector = ColorDrawable(0x66FF6A00)
        lv.isFocusable = true
        lv.itemsCanFocus = false
        lv.background = rounded(cCard, 18, 0, cCard)
    }

    private fun header(title: String, vararg extra: View): LinearLayout {
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo_mark)
        top.addView(logo, LinearLayout.LayoutParams(dp(84), dp(53)))
        val t = label(title, 24f, cText, true)
        t.setPadding(dp(16), 0, 0, 0)
        top.addView(t, lp(0, WRAP, 1f))
        for (v in extra) {
            val l = lp(WRAP, WRAP)
            l.leftMargin = dp(12)
            top.addView(v, l)
        }
        return top
    }

    private fun page(): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(52), dp(22), dp(52), dp(18))
        return col
    }

    private fun reopen(to: String) {
        when (to) {
            "live" -> showBrowse("live")
            "movies" -> showBrowse("movies")
            "favs" -> showFavs()
            "search" -> showSearch()
            "mosaic" -> showMosaic()
            "lists" -> showLists()
            else -> showHome()
        }
    }

    // ------------------------------------------------------------------
    // Datos: listas, favoritos
    // ------------------------------------------------------------------

    private fun rebuildFavKeys() {
        favKeys.clear()
        for (f in favs) favKeys.add(f.url)
    }

    private fun toggleFav(ch: Channel) {
        if (favKeys.contains(ch.url)) {
            favs.removeAll { it.url == ch.url }
        } else {
            favs.add(ch)
        }
        rebuildFavKeys()
        store.saveFavorites(favs)
    }

    private fun togglePick(ch: Channel) {
        if (picks.contains(ch)) {
            picks.remove(ch)
        } else if (picks.size < 4) {
            picks.add(ch)
        } else {
            toast("Máximo 4 canales en el mosaico")
        }
    }

    private fun download(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 40000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        if (c.responseCode !in 200..299) throw Exception("HTTP " + c.responseCode)
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** Lee (y si hace falta descarga) las listas activas y arma el catalogo. */
    private fun loadCatalog(force: Set<String>, done: () -> Unit) {
        val act = ArrayList(playlists.filter { it.active })
        Thread {
            val cats = ArrayList<Catalog>()
            val errs = ArrayList<String>()
            for (pl in act) {
                try {
                    val f = File(filesDir, "pl_" + pl.id + ".m3u")
                    if (force.contains(pl.id) || !f.exists()) {
                        try {
                            f.writeText(download(pl.url))
                        } catch (e: Exception) {
                            if (!f.exists()) throw e
                        }
                    }
                    val c = M3u.parse(f.readText(), pl.name)
                    counts[pl.id] = c.liveCount() + c.movieCount()
                    cats.add(c)
                } catch (e: Exception) {
                    errs.add(pl.name + ": " + (e.message ?: "error"))
                }
            }
            val merged = M3u.merge(cats)
            ui.post {
                catalog = merged
                searchIdx = null
                if (errs.isNotEmpty()) toast("No se pudo cargar " + errs.joinToString("; "))
                done()
            }
        }.start()
    }

    private fun addPlaylist(name: String, url: String, epg: String) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            toast("El enlace debe empezar con http:// o https://")
            return
        }
        if (playlists.size >= 10) {
            toast("Máximo 10 listas")
            return
        }
        val pl = Playlist(
            System.currentTimeMillis().toString(),
            if (name.isBlank()) "Lista " + (playlists.size + 1) else name.trim(),
            url.trim(), epg.trim(), true
        )
        playlists.add(pl)
        store.savePlaylists(playlists)
        toast("Descargando lista...")
        loadCatalog(setOf(pl.id)) {
            toast("Lista agregada")
            if (screen == "lists") showLists() else if (screen == "home") showHome()
        }
    }

    private fun refreshAll() {
        val ids = HashSet<String>()
        for (p in playlists) if (p.active) ids.add(p.id)
        if (ids.isEmpty()) {
            toast("No hay listas activas")
            return
        }
        toast("Actualizando listas...")
        loadCatalog(ids) {
            toast("Listas actualizadas")
            if (screen != "player" && screen != "mosaic") reopen(screen)
        }
    }

    private fun ensureServer() {
        if (server == null) {
            val s = LocalServer { n, u, e -> ui.post { addPlaylist(n, u, e) } }
            if (s.start()) server = s
        }
    }

    // ------------------------------------------------------------------
    // Inicio
    // ------------------------------------------------------------------

    private fun updateClock() {
        val c = Calendar.getInstance()
        val days = arrayOf("domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado")
        val months = arrayOf(
            "enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto",
            "septiembre", "octubre", "noviembre", "diciembre"
        )
        clockTime?.text = String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
        clockDate?.text = days[c.get(Calendar.DAY_OF_WEEK) - 1] + ", " + c.get(Calendar.DAY_OF_MONTH) +
            " de " + months[c.get(Calendar.MONTH)]
    }

    private fun homeCard(iconRes: Int, title: String, sub: String, isNew: Boolean, onClick: () -> Unit): View {
        val card = FrameLayout(this)
        card.isFocusable = true
        card.isClickable = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(22), dp(18), dp(22), dp(18))
        val ic = icon(iconRes, 40, cMuted)
        col.addView(ic)
        col.addView(spacer(), lp(WRAP, 0, 1f))
        col.addView(label(title, 22f, cText, true))
        col.addView(label(sub, 14f, cMuted))
        card.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        if (isNew) {
            val b = label("NUEVO", 12f, cBg, true)
            b.setPadding(dp(10), dp(4), dp(10), dp(4))
            b.background = rounded(cOrange, 8, 0, cOrange)
            val blp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END)
            blp.setMargins(0, dp(14), dp(14), 0)
            card.addView(b, blp)
        }
        fun paint(f: Boolean) {
            card.background = if (f) rounded(cCardOn, 22, 3, cOrange) else rounded(cCard, 22, 3, 0xFF23262B.toInt())
            ic.setColorFilter(if (f) cOrange else cMuted)
            card.animate().scaleX(if (f) 1.05f else 1f).scaleY(if (f) 1.05f else 1f).setDuration(140).start()
        }
        paint(false)
        card.setOnFocusChangeListener { _, f -> paint(f) }
        card.setOnClickListener { onClick() }
        return card
    }

    private fun showHome() {
        stopAll()
        screen = "home"

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(56), dp(26), dp(56), dp(20))

        // Barra superior
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo_mark)
        top.addView(logo, LinearLayout.LayoutParams(dp(96), dp(61)))
        val names = LinearLayout(this)
        names.orientation = LinearLayout.VERTICAL
        names.setPadding(dp(14), 0, 0, 0)
        names.addView(label("SMART IPTV MX", 20f, cText, true))
        names.addView(label("Tu TV, tus listas", 13f, cMuted))
        top.addView(names)
        top.addView(spacer(), lp(0, 1, 1f))

        val pill = LinearLayout(this)
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.isFocusable = true
        pill.isClickable = true
        pill.setPadding(dp(22), dp(10), dp(22), dp(10))
        val pi = icon(R.drawable.ic_search, 26, cOrangeLight)
        pill.addView(pi)
        val pt = label("Buscar canales, películas o partidos", 18f, cMuted)
        pt.setPadding(dp(14), 0, 0, 0)
        pill.addView(pt)
        fun paintPill(f: Boolean) {
            pill.background = rounded(cCard, 30, 2, if (f) cOrange else cLine)
            pt.setTextColor(if (f) cText else cMuted)
        }
        paintPill(false)
        pill.setOnFocusChangeListener { _, f -> paintPill(f) }
        pill.setOnClickListener { showSearch() }
        top.addView(pill, lp(dp(520), WRAP))
        top.addView(spacer(), lp(0, 1, 1f))

        val clock = LinearLayout(this)
        clock.orientation = LinearLayout.VERTICAL
        clock.gravity = Gravity.END
        val ct = label("", 30f, cText, true)
        val cd = label("", 13f, cMuted)
        clock.addView(ct)
        clock.addView(cd)
        clockTime = ct
        clockDate = cd
        updateClock()
        ui.postDelayed(clockTick, 20000)
        top.addView(clock)

        col.addView(top, lp(MATCH, WRAP))

        // Banner
        val banner = LinearLayout(this)
        banner.orientation = LinearLayout.VERTICAL
        banner.gravity = Gravity.CENTER_VERTICAL
        banner.setPadding(dp(36), dp(14), dp(36), dp(14))
        val bg = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xFF17191D.toInt(), 0xFF2B1608.toInt())
        )
        bg.cornerRadius = dp(26).toFloat()
        bg.setStroke(dp(1), 0xFF23262B.toInt())
        banner.background = bg
        banner.addView(label("BIENVENIDO DE NUEVO", 13f, 0xFFFF8A24.toInt(), true))
        banner.addView(label("TU ENTRETENIMIENTO, EN UN SOLO LUGAR", 28f, cText, true))
        banner.addView(
            label("Canales en vivo, películas y hasta 4 partidos al mismo tiempo.", 16f, 0xFFB6BAC2.toInt())
        )
        val bl = lp(MATCH, dp(124))
        bl.topMargin = dp(18)
        col.addView(banner, bl)

        // Tarjetas
        val activeCount = playlists.count { it.active }
        val row = LinearLayout(this)
        val cards = ArrayList<View>()
        cards.add(homeCard(R.drawable.ic_tv, "En vivo", catalog.liveCount().toString() + " canales", false) {
            browseMode = "play"
            showBrowse("live")
        })
        cards.add(homeCard(R.drawable.ic_film, "Películas", catalog.movieCount().toString() + " títulos", false) {
            browseMode = "play"
            showBrowse("movies")
        })
        cards.add(homeCard(R.drawable.ic_heart, "Favoritos", favs.size.toString() + " guardados", false) {
            showFavs()
        })
        cards.add(homeCard(R.drawable.ic_grid, "Mosaico", "Hasta 4 partidos", true) {
            if (picks.size >= 2) {
                showMosaic()
            } else {
                browseMode = "pick"
                showBrowse("live")
                toast("Pulsa OK en 2 a 4 canales y luego en \"Abrir mosaico\"")
            }
        })
        cards.add(homeCard(R.drawable.ic_list, "Mis listas", activeCount.toString() + " activas", false) {
            showLists()
        })
        for ((i, c) in cards.withIndex()) {
            val l = lp(0, MATCH, 1f)
            if (i > 0) l.leftMargin = dp(18)
            row.addView(c, l)
        }
        val rl = lp(MATCH, 0, 1f)
        rl.topMargin = dp(26)
        rl.bottomMargin = dp(22)
        rl.leftMargin = dp(6)
        rl.rightMargin = dp(6)
        col.addView(row, rl)

        // Pie
        val foot = LinearLayout(this)
        foot.gravity = Gravity.CENTER_VERTICAL
        foot.addView(
            label("◀ ▶ Moverse    OK Abrir    Atrás Salir", 14f, cMuted),
            lp(0, WRAP, 1f)
        )
        foot.addView(button("Cargar lista desde el celular") { showLists() })
        val rl2 = lp(WRAP, WRAP)
        rl2.leftMargin = dp(12)
        foot.addView(button("Actualizar") { refreshAll() }, rl2)
        col.addView(foot, lp(MATCH, WRAP))

        setScreen(col)
        cards[0].requestFocus()
    }

    // ------------------------------------------------------------------
    // En vivo y Peliculas
    // ------------------------------------------------------------------

    private fun modeText(mode: String, name: String): String =
        (if (browseMode == mode) "● " else "○ ") + name

    private fun showBrowse(kind: String) {
        stopAll()
        screen = kind
        val isLive = kind == "live"
        val map = if (isLive) catalog.live else catalog.movies

        val names = ArrayList<String>()
        names.add("Todos")
        names.addAll(map.keys)
        val labels = ArrayList<String>()
        for (n in names) {
            val c = if (n == "Todos") map.values.sumOf { it.size } else (map[n]?.size ?: 0)
            labels.add("$n  ($c)")
        }

        if (!isLive && browseMode == "pick") browseMode = "play"

        val col = page()
        val chips = ArrayList<View>()
        val playChip = button(modeText("play", "Ver")) { }
        val favChip = button(modeText("fav", "Favorito")) { }
        val pickChip = button(modeText("pick", "Mosaico")) { }
        val openBtn = button("Abrir mosaico (" + picks.size + "/4)") {
            if (picks.size < 2) {
                toast("Elige de 2 a 4 canales con el modo Mosaico")
            } else {
                showMosaic()
            }
        }
        fun refreshChips() {
            playChip.text = modeText("play", "Ver")
            favChip.text = modeText("fav", "Favorito")
            pickChip.text = modeText("pick", "Mosaico")
            openBtn.text = "Abrir mosaico (" + picks.size + "/4)"
        }
        playChip.setOnClickListener {
            browseMode = "play"
            refreshChips()
        }
        favChip.setOnClickListener {
            browseMode = "fav"
            refreshChips()
        }
        pickChip.setOnClickListener {
            browseMode = "pick"
            refreshChips()
        }
        chips.add(playChip)
        chips.add(favChip)
        if (isLive) {
            chips.add(pickChip)
            chips.add(openBtn)
        }
        col.addView(
            header(if (isLive) "En vivo" else "Películas", *chips.toTypedArray()),
            lp(MATCH, WRAP)
        )

        val gv = ListView(this)
        val cv = ListView(this)
        styleList(gv)
        styleList(cv)
        val body = LinearLayout(this)
        body.addView(gv, lp(0, MATCH, 1f))
        val cvl = lp(0, MATCH, 2f)
        cvl.leftMargin = dp(18)
        body.addView(cv, cvl)
        val bl = lp(MATCH, 0, 1f)
        bl.topMargin = dp(14)
        col.addView(body, bl)

        val hint = label(
            if (isLive) "OK: ver canal · modo Favorito: OK agrega o quita ♥ · modo Mosaico: OK elige hasta 4 canales"
            else "OK: ver película · modo Favorito: OK agrega o quita ♥",
            14f, cMuted
        )
        hint.setPadding(0, dp(8), 0, 0)
        col.addView(hint)
        setScreen(col)

        gv.adapter = listAdapter(labels) { false }

        var current: List<Channel> = emptyList()
        fun showGroup(i: Int) {
            browseGroup[kind] = i
            current = if (i == 0) {
                val all = ArrayList<Channel>()
                for (a in map.values) all.addAll(a)
                all
            } else {
                map[names[i]] ?: emptyList()
            }
            val shownList = current
            // Marcas de favorito y de mosaico delante del nombre
            val base = shownList.map { it.name }
            cv.adapter = object : ArrayAdapter<String>(this@MainActivity, android.R.layout.simple_list_item_1, base) {
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val v = super.getView(position, convertView, parent) as TextView
                    val ch = shownList[position]
                    val fav = favKeys.contains(ch.url)
                    val pk = picks.contains(ch)
                    v.text = (if (fav) "♥ " else "") + (if (pk) "▦ " else "") + ch.name
                    v.setTextColor(if (pk) cOrangeLight else if (fav) 0xFFFF8A24.toInt() else cText)
                    v.textSize = 19f
                    v.maxLines = 1
                    v.ellipsize = TextUtils.TruncateAt.END
                    v.setPadding(dp(18), dp(11), dp(18), dp(11))
                    return v
                }
            }
        }

        var startGroup = browseGroup[kind] ?: 0
        if (startGroup >= names.size) startGroup = 0
        showGroup(startGroup)
        gv.setSelection(startGroup)

        gv.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != (browseGroup[kind] ?: 0)) {
                    browsePos[kind] = 0
                    showGroup(pos)
                }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        fun marksChanged() {
            (cv.adapter as ArrayAdapter<*>).notifyDataSetChanged()
            refreshChips()
        }

        cv.onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ ->
            browsePos[kind] = pos
            val ch = current[pos]
            when (browseMode) {
                "fav" -> {
                    toggleFav(ch)
                    marksChanged()
                }
                "pick" -> {
                    togglePick(ch)
                    marksChanged()
                }
                else -> showPlayer(current, pos, kind)
            }
        }
        cv.onItemLongClickListener = AdapterView.OnItemLongClickListener { _, _, pos, _ ->
            toggleFav(current[pos])
            marksChanged()
            true
        }

        val sp = browsePos[kind] ?: 0
        if (sp > 0 && sp < current.size) cv.setSelection(sp)
        cv.requestFocus()
    }

    // ------------------------------------------------------------------
    // Favoritos
    // ------------------------------------------------------------------

    private fun showFavs() {
        stopAll()
        screen = "favs"
        val col = page()
        val rm = button("Quitar al pulsar OK: " + (if (favRemove) "SÍ" else "NO")) { }
        rm.setOnClickListener {
            favRemove = !favRemove
            rm.text = "Quitar al pulsar OK: " + (if (favRemove) "SÍ" else "NO")
        }
        col.addView(header("Favoritos", rm), lp(MATCH, WRAP))

        if (favs.isEmpty()) {
            val e = label(
                "Aún no tienes favoritos. En En vivo o Películas usa el modo Favorito y pulsa OK sobre un canal.",
                20f, cMuted
            )
            e.setPadding(0, dp(40), 0, 0)
            col.addView(e)
            setScreen(col)
            rm.requestFocus()
            return
        }

        val lv = ListView(this)
        styleList(lv)
        val shownList = ArrayList(favs)
        lv.adapter = listAdapter(shownList.map { it.name + (if (it.vod) "   · película" else "") }) { false }
        val ll = lp(MATCH, 0, 1f)
        ll.topMargin = dp(14)
        col.addView(lv, ll)
        setScreen(col)

        lv.onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ ->
            if (favRemove) {
                toggleFav(shownList[pos])
                showFavs()
            } else {
                showPlayer(shownList, pos, "favs")
            }
        }
        lv.requestFocus()
    }

    // ------------------------------------------------------------------
    // Buscador
    // ------------------------------------------------------------------

    private fun fold(s: String): String {
        val n = Normalizer.normalize(s, Normalizer.Form.NFD)
        return n.replace(Regex("\\p{M}+"), "").lowercase().trim()
    }

    private fun buildIndex(): List<Pair<String, Channel>> {
        val out = ArrayList<Pair<String, Channel>>()
        for (a in catalog.live.values) for (c in a) out.add(Pair(fold(c.name), c))
        for (a in catalog.movies.values) for (c in a) out.add(Pair(fold(c.name), c))
        return out
    }

    private fun showSearch() {
        stopAll()
        screen = "search"
        val idx = searchIdx ?: buildIndex()
        searchIdx = idx

        val col = page()
        val input = field("Escribe para buscar en tus listas...")
        input.textSize = 22f
        col.addView(header("Buscar"), lp(MATCH, WRAP))
        val il = lp(MATCH, WRAP)
        il.topMargin = dp(12)
        col.addView(input, il)

        val lv = ListView(this)
        styleList(lv)
        val ll = lp(MATCH, 0, 1f)
        ll.topMargin = dp(14)
        col.addView(lv, ll)
        val info = label("Escribe al menos 2 letras. Los resultados incluyen canales y películas.", 14f, cMuted)
        info.setPadding(0, dp(8), 0, 0)
        col.addView(info)
        setScreen(col)

        var results: List<Channel> = emptyList()
        val doSearch = Runnable {
            val q = fold(input.text.toString())
            if (q.length < 2) {
                results = emptyList()
                lv.adapter = listAdapter(emptyList()) { false }
            } else {
                val words = q.split(" ").filter { it.isNotEmpty() }
                val found = ArrayList<Channel>()
                for (p in idx) {
                    var ok = true
                    for (w in words) {
                        if (!p.first.contains(w)) {
                            ok = false
                            break
                        }
                    }
                    if (ok) {
                        found.add(p.second)
                        if (found.size >= 300) break
                    }
                }
                results = found
                lv.adapter = listAdapter(
                    found.map { it.name + "   · " + (if (it.vod) "película" else it.group) }
                ) { false }
                info.text = found.size.toString() + " resultados"
            }
        }
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                ui.removeCallbacks(doSearch)
                ui.postDelayed(doSearch, 300)
            }
        })
        lv.onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ ->
            if (pos < results.size) showPlayer(results, pos, "search")
        }
        input.requestFocus()
    }

    // ------------------------------------------------------------------
    // Mis listas
    // ------------------------------------------------------------------

    private fun showLists() {
        stopAll()
        screen = "lists"
        ensureServer()

        val col = page()
        val modeBtn = button("") { }
        fun modeLabel(): String = if (listMode == "toggle") "OK: activar / desactivar" else "OK: eliminar"
        modeBtn.text = modeLabel()
        modeBtn.setOnClickListener {
            listMode = if (listMode == "toggle") "delete" else "toggle"
            modeBtn.text = modeLabel()
        }
        val refresh = button("Actualizar todas") { refreshAll() }
        col.addView(header("Mis listas", modeBtn, refresh), lp(MATCH, WRAP))

        val srv = server
        val addr = if (srv != null) "http://" + LocalServer.localIp() + ":" + srv.port else "(servidor no disponible)"
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(14), dp(22), dp(14))
        box.background = rounded(cCard, 18, 1, cLine)
        box.addView(label("Agregar una lista desde tu celular (misma red Wi-Fi):", 16f, cMuted))
        box.addView(label(addr, 28f, cOrangeLight, true))
        val bl = lp(MATCH, WRAP)
        bl.topMargin = dp(12)
        col.addView(box, bl)

        val form = LinearLayout(this)
        form.gravity = Gravity.CENTER_VERTICAL
        val fName = field("Nombre")
        val fUrl = field("Enlace M3U (https://...)")
        val fEpg = field("Guía XMLTV (opcional)")
        form.addView(fName, lp(0, WRAP, 1f))
        val ul = lp(0, WRAP, 2f)
        ul.leftMargin = dp(10)
        form.addView(fUrl, ul)
        val el = lp(0, WRAP, 2f)
        el.leftMargin = dp(10)
        form.addView(fEpg, el)
        val add = button("Agregar") { addPlaylist(fName.text.toString(), fUrl.text.toString(), fEpg.text.toString()) }
        val al = lp(WRAP, WRAP)
        al.leftMargin = dp(10)
        form.addView(add, al)
        val fl = lp(MATCH, WRAP)
        fl.topMargin = dp(12)
        col.addView(form, fl)

        val lv = ListView(this)
        styleList(lv)
        val rows = playlists.map {
            (if (it.active) "● " else "○ ") + it.name + "   ·   " +
                (counts[it.id]?.toString() ?: "?") + " canales" + (if (it.active) "" else "   (desactivada)")
        }
        lv.adapter = listAdapter(rows) { false }
        val ll = lp(MATCH, 0, 1f)
        ll.topMargin = dp(14)
        col.addView(lv, ll)

        if (playlists.isEmpty()) {
            col.addView(
                label("Aún no tienes listas. Agrega una desde tu celular o escribe el enlace arriba.", 16f, cMuted)
            )
        }
        setScreen(col)

        lv.onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ ->
            val pl = playlists[pos]
            if (listMode == "delete") {
                playlists.removeAt(pos)
                File(filesDir, "pl_" + pl.id + ".m3u").delete()
                store.savePlaylists(playlists)
                loadCatalog(emptySet()) { showLists() }
            } else {
                pl.active = !pl.active
                store.savePlaylists(playlists)
                loadCatalog(emptySet()) { showLists() }
            }
        }
        if (playlists.isEmpty()) fUrl.requestFocus() else lv.requestFocus()
    }

    // ------------------------------------------------------------------
    // Reproductores
    // ------------------------------------------------------------------

    private fun buildPlayer(multi: Boolean): ExoPlayer {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(20000)
        val load = if (multi) {
            DefaultLoadControl.Builder().setBufferDurationsMs(2500, 8000, 1000, 2000).build()
        } else {
            DefaultLoadControl.Builder().setBufferDurationsMs(8000, 30000, 2000, 4000).build()
        }
        // La extension FFmpeg decodifica por software formatos de audio que la Chromecast no
        // maneja (MPEG-L2, AC3, E-AC3, DTS...), comunes en canales IPTV.
        val renderers = DefaultRenderersFactory(this)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        return ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(http))
            .setLoadControl(load)
            .build()
    }

    private fun capQuality(p: ExoPlayer, w: Int, h: Int) {
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setMaxVideoSize(w, h)
            .build()
    }

    /** Controla un reproductor: carga el canal, prueba HLS si hace falta y reintenta si se cae. */
    private inner class Stream(
        val p: ExoPlayer,
        val status: TextView?,
        val onAudio: (String) -> Unit
    ) : Player.Listener {
        var ch: Channel? = null
        var triedHls = false
        var retries = 0
        var resumeMs = 0L
        private val retry = Runnable { load(triedHls) }

        init {
            p.addListener(this)
        }

        fun play(c: Channel) {
            ch = c
            triedHls = false
            retries = 0
            ui.removeCallbacks(retry)
            load(false)
        }

        private fun load(hls: Boolean) {
            val c = ch ?: return
            status?.text = "Cargando..."
            status?.visibility = View.VISIBLE
            val b = MediaItem.Builder().setUri(c.url)
            if (hls) b.setMimeType(MimeTypes.APPLICATION_M3U8)
            p.setMediaItem(b.build())
            p.prepare()
            p.playWhenReady = true
        }

        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_READY) {
                status?.visibility = View.GONE
                retries = 0
                if (resumeMs > 0) {
                    p.seekTo(resumeMs)
                    resumeMs = 0
                }
            } else if (state == Player.STATE_BUFFERING) {
                status?.text = "Cargando..."
                status?.visibility = View.VISIBLE
            }
        }

        override fun onTracksChanged(tracks: Tracks) {
            var s = "sin audio"
            for (g in tracks.groups) {
                if (g.type == C.TRACK_TYPE_AUDIO && g.length > 0) {
                    val f = g.getTrackFormat(0)
                    val codec = (f.sampleMimeType ?: "?").removePrefix("audio/")
                    val chs = if (f.channelCount > 0) f.channelCount.toString() + "ch" else "?ch"
                    s = codec + " " + chs + (if (g.isTrackSupported(0)) "" else " NO SOPORTADO")
                    if (g.isSelected) break
                }
            }
            onAudio(s)
        }

        override fun onPlayerError(error: PlaybackException) {
            if (error.cause is UnrecognizedInputFormatException && !triedHls) {
                triedHls = true
                load(true)
                return
            }
            if (retries < 3) {
                retries++
                status?.text = "Sin señal, reintentando ($retries/3)..."
                status?.visibility = View.VISIBLE
                ui.postDelayed(retry, 4000)
            } else {
                status?.text = "Canal no disponible"
                status?.visibility = View.VISIBLE
            }
        }

        fun stop() {
            ui.removeCallbacks(retry)
        }
    }

    private fun stopAll() {
        saveBookmark()
        ui.removeCallbacks(hideInfo)
        ui.removeCallbacks(hideCtl)
        ui.removeCallbacks(ctlTick)
        ui.removeCallbacks(bmTick)
        ui.removeCallbacks(clockTick)
        clockTime = null
        clockDate = null
        singleStream?.stop()
        single?.release()
        single = null
        singleStream = null
        for (s in tileStreams) {
            s.stop()
            s.p.release()
        }
        tileStreams.clear()
        infoView = null
        ctlBar = null
        ctlProgress = null
        ctlTime = null
        ctlVisible = false
        panel = null
        playRoot = null
    }

    // ------------------------------------------------------------------
    // Reproductor a pantalla completa
    // ------------------------------------------------------------------

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%02d:%02d", m, sec)
    }

    private fun showPlayer(list: List<Channel>, index: Int, back: String) {
        stopAll()
        screen = "player"
        backTo = back
        playList = list
        playIndex = index

        val frame = FrameLayout(this)
        playRoot = frame
        val pv = PlayerView(this)
        pv.useController = false
        pv.isFocusable = false
        frame.addView(pv, FrameLayout.LayoutParams(MATCH, MATCH))

        val box = rounded(0xCC090A0C.toInt(), 14, 0, cBg)

        val info = label("", 22f, cText, true)
        info.setPadding(dp(18), dp(10), dp(18), dp(10))
        info.background = box
        val ilp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START)
        ilp.setMargins(dp(40), dp(32), 0, 0)
        frame.addView(info, ilp)
        infoView = info

        val status = label("", 24f, cText, true)
        status.setPadding(dp(22), dp(12), dp(22), dp(12))
        status.background = box
        frame.addView(status, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        // Barra de controles (peliculas)
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.VERTICAL
        bar.setPadding(dp(60), dp(30), dp(60), dp(30))
        bar.setBackgroundColor(0xB0090A0C.toInt())
        val time = label("", 20f, cText, true)
        val prog = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        prog.max = 1000
        prog.progressTintList = ColorStateList.valueOf(cOrange)
        val hint = label(
            "◀ ▶ saltar 10 s   ·   OK pausa / reproducir   ·   ▲ ▼ audio y subtítulos",
            14f, cMuted
        )
        bar.addView(time)
        bar.addView(prog, lp(MATCH, dp(10)))
        bar.addView(hint)
        bar.visibility = View.GONE
        frame.addView(bar, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        ctlBar = bar
        ctlProgress = prog
        ctlTime = time

        setScreen(frame)

        val p = buildPlayer(false)
        capQuality(p, 1920, 1080)
        pv.player = p
        single = p
        audioDiag = ""
        singleStream = Stream(p, status) { d ->
            audioDiag = d
            showInfo()
        }
        startChannel()
    }

    private fun startChannel() {
        val ch = playList[playIndex]
        val s = singleStream ?: return
        saveBookmark()
        ui.removeCallbacks(bmTick)
        if (ch.vod) {
            val resume = store.bookmark(ch.url)
            s.resumeMs = resume
            if (resume > 30000) toast("Continúas donde lo dejaste (" + fmt(resume) + ")")
            ui.postDelayed(bmTick, 10000)
        } else {
            s.resumeMs = 0
            hideControls()
        }
        showInfo()
        s.play(ch)
    }

    private fun showInfo() {
        val iv = infoView ?: return
        if (playList.isEmpty()) return
        iv.text = (playIndex + 1).toString() + "/" + playList.size + "   " + playList[playIndex].name +
            (if (audioDiag.isEmpty()) "" else "\nAudio: " + audioDiag)
        iv.visibility = View.VISIBLE
        ui.removeCallbacks(hideInfo)
        ui.postDelayed(hideInfo, 3500)
    }

    private fun zap(dir: Int) {
        if (playList.isEmpty()) return
        playIndex = (playIndex + dir + playList.size) % playList.size
        startChannel()
    }

    private fun saveBookmark() {
        val p = single ?: return
        if (playList.isEmpty() || playIndex >= playList.size) return
        val ch = playList[playIndex]
        if (!ch.vod) return
        val dur = p.duration
        val pos = p.currentPosition
        if (dur > 0 && pos > dur - 60000) {
            store.clearBookmark(ch.url)
        } else if (pos > 15000) {
            store.setBookmark(ch.url, pos)
        }
    }

    private fun showControls() {
        ctlBar?.visibility = View.VISIBLE
        ctlVisible = true
        ui.removeCallbacks(hideCtl)
        ui.postDelayed(hideCtl, 4500)
        ui.removeCallbacks(ctlTick)
        ui.post(ctlTick)
    }

    private fun hideControls() {
        ctlBar?.visibility = View.GONE
        ctlVisible = false
        ui.removeCallbacks(ctlTick)
    }

    private fun updateCtl() {
        val p = single ?: return
        val dur = p.duration
        val pos = p.currentPosition
        if (dur > 0) {
            ctlProgress?.progress = (pos * 1000 / dur).toInt()
            ctlTime?.text = fmt(pos) + " / " + fmt(dur) + (if (p.isPlaying) "" else "      pausa")
        } else {
            ctlTime?.text = fmt(pos)
        }
    }

    private fun togglePause() {
        val p = single ?: return
        if (p.isPlaying) p.pause() else p.play()
        showControls()
    }

    private fun seekBy(ms: Long) {
        val p = single ?: return
        val dur = p.duration
        var t = p.currentPosition + ms
        if (t < 0) t = 0
        if (dur > 0 && t > dur - 1000) t = dur - 1000
        p.seekTo(t)
        showControls()
    }

    // Panel de audio y subtitulos
    private fun trackName(f: androidx.media3.common.Format, n: Int): String {
        val lang = f.language
        if (lang != null && lang != "und") {
            val d = Locale(lang).displayLanguage
            if (d.isNotEmpty()) return d.replaceFirstChar { it.uppercase() }
        }
        val l = f.label
        if (l != null && l.isNotEmpty()) return l
        return "Pista $n"
    }

    private fun openPanel() {
        val p = single ?: return
        val frame = playRoot ?: return
        val items = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        val tracks = p.currentTracks

        var n = 0
        for (g in tracks.groups) {
            if (g.type != C.TRACK_TYPE_AUDIO) continue
            for (i in 0 until g.length) {
                n++
                val f = g.getTrackFormat(i)
                val sel = g.isTrackSelected(i)
                items.add("Audio: " + trackName(f, n) + (if (sel) "   ✓" else ""))
                val grp = g.mediaTrackGroup
                val idx = i
                actions.add {
                    p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                        .setOverrideForType(TrackSelectionOverride(grp, idx))
                        .build()
                }
            }
        }

        var anyText = false
        var textSel = false
        for (g in tracks.groups) {
            if (g.type == C.TRACK_TYPE_TEXT) {
                anyText = true
                for (i in 0 until g.length) if (g.isTrackSelected(i)) textSel = true
            }
        }
        if (anyText) {
            items.add("Subtítulos: desactivados" + (if (!textSel) "   ✓" else ""))
            actions.add {
                p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    .build()
            }
            var m = 0
            for (g in tracks.groups) {
                if (g.type != C.TRACK_TYPE_TEXT) continue
                for (i in 0 until g.length) {
                    m++
                    val f = g.getTrackFormat(i)
                    val sel = g.isTrackSelected(i)
                    items.add("Subtítulos: " + trackName(f, m) + (if (sel) "   ✓" else ""))
                    val grp = g.mediaTrackGroup
                    val idx = i
                    actions.add {
                        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                            .setOverrideForType(TrackSelectionOverride(grp, idx))
                            .build()
                    }
                }
            }
        }

        if (items.isEmpty()) {
            toast("Este contenido no tiene pistas de audio o subtítulos para elegir")
            return
        }

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(18), dp(18), dp(18))
        col.background = rounded(0xF0090A0C.toInt(), 20, 2, cLine)
        col.addView(label("Audio y subtítulos", 20f, cOrangeLight, true))
        val lv = ListView(this)
        lv.divider = null
        lv.selector = ColorDrawable(0x66FF6A00)
        lv.adapter = listAdapter(items) { false }
        val ll = lp(MATCH, 0, 1f)
        ll.topMargin = dp(10)
        col.addView(lv, ll)
        val flp = FrameLayout.LayoutParams(dp(480), MATCH, Gravity.END)
        flp.setMargins(0, dp(40), dp(40), dp(40))
        frame.addView(col, flp)
        panel = col
        lv.onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ ->
            actions[pos]()
            closePanel()
        }
        lv.requestFocus()
    }

    private fun closePanel() {
        val v = panel ?: return
        playRoot?.removeView(v)
        panel = null
    }

    // ------------------------------------------------------------------
    // Mosaico de 2 a 4 canales
    // ------------------------------------------------------------------

    private fun showMosaic() {
        stopAll()
        screen = "mosaic"
        val n = picks.size

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(18), dp(18), dp(18))

        val tiles = ArrayList<View>()
        val rows = (n + 1) / 2
        var idx = 0
        for (r in 0 until rows) {
            val row = LinearLayout(this)
            val inRow = if (r == rows - 1 && n % 2 == 1) 1 else 2
            for (k in 0 until inRow) {
                val tile = makeTile(idx)
                val l = lp(0, MATCH, 1f)
                l.setMargins(dp(6), dp(6), dp(6), dp(6))
                row.addView(tile, l)
                tiles.add(tile)
                idx++
            }
            col.addView(row, lp(MATCH, 0, 1f))
        }
        setScreen(col)

        for (s in tileStreams) capQuality(s.p, 854, 480)
        tiles[0].requestFocus()
    }

    private fun giveAudio(i: Int) {
        for (k in tileStreams.indices) {
            val p = tileStreams[k].p
            if (k == i) {
                p.volume = 1f
                capQuality(p, 1280, 720)
            } else {
                p.volume = 0f
                capQuality(p, 854, 480)
            }
        }
    }

    private fun makeTile(i: Int): FrameLayout {
        val ch = picks[i]
        val tile = FrameLayout(this)
        tile.isFocusable = true
        tile.isClickable = true

        val pv = PlayerView(this)
        pv.useController = false
        pv.isFocusable = false
        val inset = dp(4)
        val pvLp = FrameLayout.LayoutParams(MATCH, MATCH)
        pvLp.setMargins(inset, inset, inset, inset)
        tile.addView(pv, pvLp)

        val shade = rounded(0xCC090A0C.toInt(), 10, 0, cBg)

        val name = label(ch.name, 18f, cText, true)
        name.setPadding(dp(12), dp(6), dp(12), dp(6))
        name.background = shade
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        val nlp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START)
        nlp.setMargins(dp(14), 0, 0, dp(14))
        tile.addView(name, nlp)

        val badge = label("AUDIO", 14f, cBg, true)
        badge.setPadding(dp(12), dp(5), dp(12), dp(5))
        badge.background = rounded(cOrange, 10, 0, cOrange)
        badge.visibility = View.GONE
        val blp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END)
        blp.setMargins(0, dp(14), dp(14), 0)
        tile.addView(badge, blp)

        val status = label("", 20f, cText, true)
        status.setPadding(dp(16), dp(8), dp(16), dp(8))
        status.background = shade
        tile.addView(status, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        val p = buildPlayer(true)
        p.volume = 0f
        pv.player = p
        val stream = Stream(p, status) { d -> name.text = ch.name + "  ·  " + d }
        tileStreams.add(stream)

        fun paint(f: Boolean) {
            tile.background = rounded(cCard, 16, 4, if (f) cOrange else cLine)
        }
        paint(false)
        tile.setOnFocusChangeListener { _, f ->
            paint(f)
            badge.visibility = if (f) View.VISIBLE else View.GONE
            if (f) giveAudio(i)
        }
        tile.setOnClickListener { showPlayer(ArrayList(picks), i, "mosaic") }

        stream.play(ch)
        return tile
    }

    companion object {
        const val UA = "Mozilla/5.0 (Linux; Android 14; Chromecast) SmartIPTVMX/0.4"
    }
}
