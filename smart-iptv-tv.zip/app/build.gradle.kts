plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.smartiptv.mx"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.smartiptv.mx"
        minSdk = 24
        targetSdk = 34
        // Misma version que el canal de Roku (1.90)
        versionCode = 193
        versionName = "1.93"
    }

    // Llave fija: asi cada APK nuevo se instala encima del anterior sin borrar datos.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            isMinifyEnabled = false
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        // Lo exige el decodificador FFmpeg (igual que en la version anterior que si compilaba)
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
    val media3 = "1.3.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-exoplayer-dash:$media3")
    implementation("androidx.media3:media3-ui:$media3")
    // Decodificadores de audio por software (AC3, E-AC3, DTS, MP3...). La version debe coincidir con media3.
    implementation("org.jellyfin.media3:media3-ffmpeg-decoder:1.3.1+2")
}
