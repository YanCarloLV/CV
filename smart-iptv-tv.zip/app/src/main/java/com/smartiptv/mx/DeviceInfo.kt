package com.smartiptv.mx

import android.content.Context
import android.os.Build
import org.json.JSONObject
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

/** Datos del equipo (equivalente a roDeviceInfo). */
object DeviceInfo {

    fun json(ctx: Context): String {
        val loc = Locale.getDefault()
        val o = JSONObject()
        val country = if (loc.country.isNullOrEmpty()) "MX" else loc.country
        o.put("locale", loc.language + "_" + country)
        o.put("country", country)
        o.put("ip", localIp())
        o.put("model", (Build.MANUFACTURER + " " + Build.MODEL).trim())
        o.put("uuid", uuid(ctx))
        o.put("tz", TimeZone.getDefault().id)
        return o.toString()
    }

    private fun uuid(ctx: Context): String {
        val sp = ctx.getSharedPreferences("iptv", Context.MODE_PRIVATE)
        var id = sp.getString("uuid", null)
        if (id == null) {
            id = UUID.randomUUID().toString()
            sp.edit().putString("uuid", id).apply()
        }
        return id
    }

    /** IP de la TV en la red local (Wi-Fi o cable) para el codigo QR. */
    fun localIp(): String {
        var fallback = "0.0.0.0"
        try {
            val ifs = NetworkInterface.getNetworkInterfaces()
            while (ifs.hasMoreElements()) {
                val ni = ifs.nextElement()
                if (!ni.isUp || ni.isLoopback || ni.isVirtual) continue
                val name = ni.name.lowercase()
                val addrs = ni.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (a is Inet4Address && !a.isLoopbackAddress) {
                        val h = a.hostAddress ?: continue
                        if (name.startsWith("wlan") || name.startsWith("eth")) return h
                        if (fallback == "0.0.0.0") fallback = h
                    }
                }
            }
        } catch (e: Exception) {
        }
        return fallback
    }
}
