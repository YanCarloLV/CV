package com.smartiptv.mx

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.media3.ui.PlayerView
import org.json.JSONObject

/**
 * Smart IPTV MX para Google TV / Android TV.
 * La interfaz es la del canal de Roku (convertida a HTML) y se dibuja en un WebView
 * transparente; el video lo reproduce ExoPlayer debajo, en el recuadro que pide la interfaz.
 */
class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private lateinit var playerView: PlayerView
    private lateinit var player: VideoPlayer
    private lateinit var tiles: TilePlayers
    private var mainPlaying = false
    private var tilesActive = false
    private lateinit var server: LocalServer
    private val main = Handler(Looper.getMainLooper())
    private var pageReady = false

    // El control de Google TV no tiene los botones Play ni * del control de Roku:
    //  - mantener OK medio segundo  = Play
    //  - mantener Atras medio segundo = * (opciones)
    private var holdKey: String? = null
    private var holdLongSent = false
    private val holdRunnable = Runnable {
        val k = holdKey ?: return@Runnable
        holdLongSent = true
        val alt = if (k == "OK") "play" else "options"
        sendKey(alt, true)
        sendKey(alt, false)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawableResource(android.R.color.black)
        val prefs = getSharedPreferences("iptv", Context.MODE_PRIVATE)
        server = LocalServer(applicationContext, prefs)
        server.start()

        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        playerView = PlayerView(this)
        root.addView(playerView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        player = VideoPlayer(this, playerView) { json -> toJs("\$videoEvent($json)") }
        player.onPlayingChanged = { playing ->
            mainPlaying = playing
            keepScreen()
        }

        web = WebView(this)
        web.setBackgroundColor(Color.TRANSPARENT)
        web.isFocusable = true
        web.isFocusableInTouchMode = true
        web.isVerticalScrollBarEnabled = false
        web.isHorizontalScrollBarEnabled = false
        web.overScrollMode = View.OVER_SCROLL_NEVER
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.loadsImagesAutomatically = true
        s.useWideViewPort = false
        s.loadWithOverviewMode = false
        s.textZoom = 100
        s.setSupportZoom(false)
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true
            override fun onPageFinished(view: WebView, url: String) {
                pageReady = true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                android.util.Log.d("SmartIPTV", m.message() + " (" + m.sourceId() + ":" + m.lineNumber() + ")")
                return true
            }
        }
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // Mosaico: sus reproductores van debajo de la interfaz, igual que el principal
        tiles = TilePlayers(this, root, { root.indexOfChild(web) }) { json -> toJs("\$tileEvent($json)") }
        tiles.onActive = { on ->
            tilesActive = on
            keepScreen()
        }
        setContentView(root)
        hideSystemUi()
        web.requestFocus()
        web.loadUrl("http://127.0.0.1:" + server.port + "/index.html")
    }

    private fun keepScreen() {
        if (mainPlaying || tilesActive) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun hideSystemUi() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }

    private fun toJs(code: String) {
        main.post { if (pageReady) web.evaluateJavascript(code, null) }
    }

    private fun sendKey(key: String, press: Boolean) {
        if (!pageReady) return
        web.evaluateJavascript("window.\$key&&\$key('" + key + "'," + press + ")", null)
    }

    /** Nombres de las teclas como las manda el control de Roku. */
    private fun rokuKey(code: Int): String? = when (code) {
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> "up"
        KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> "down"
        KeyEvent.KEYCODE_DPAD_LEFT -> "left"
        KeyEvent.KEYCODE_DPAD_RIGHT -> "right"
        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_BUTTON_A -> "OK"
        KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_DEL -> "back"
        KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE,
        KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_BUTTON_X -> "play"
        KeyEvent.KEYCODE_MEDIA_REWIND, KeyEvent.KEYCODE_MEDIA_PREVIOUS, KeyEvent.KEYCODE_MEDIA_SKIP_BACKWARD,
        KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_BUTTON_L1 -> "rewind"
        KeyEvent.KEYCODE_MEDIA_FAST_FORWARD, KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_MEDIA_SKIP_FORWARD,
        KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_BUTTON_R1 -> "fastforward"
        KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_INFO, KeyEvent.KEYCODE_PROG_RED, KeyEvent.KEYCODE_STAR,
        KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_SETTINGS -> "options"
        KeyEvent.KEYCODE_LAST_CHANNEL, KeyEvent.KEYCODE_PROG_GREEN -> "replay"
        else -> null
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        val key = rokuKey(code) ?: return super.dispatchKeyEvent(event)
        val down = event.action == KeyEvent.ACTION_DOWN
        val holdable = (key == "OK" && (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER)) ||
            (key == "back" && code == KeyEvent.KEYCODE_BACK)
        if (holdable) {
            // se manda al soltar; si se mantiene medio segundo cuenta como Play / *
            if (down) {
                if (event.repeatCount == 0) {
                    main.removeCallbacks(holdRunnable)
                    holdKey = key
                    holdLongSent = false
                    main.postDelayed(holdRunnable, 550)
                }
            } else if (event.action == KeyEvent.ACTION_UP) {
                main.removeCallbacks(holdRunnable)
                if (!holdLongSent && holdKey == key) {
                    sendKey(key, true)
                    sendKey(key, false)
                }
                holdKey = null
            }
            return true
        }
        if (down) sendKey(key, true)
        else if (event.action == KeyEvent.ACTION_UP) sendKey(key, false)
        return true
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onStop() {
        super.onStop()
        player.pauseForBackground()
        tiles.pauseAll()
        toJs("window.\$appVisible&&\$appVisible(false)")
    }

    override fun onStart() {
        super.onStart()
        if (::player.isInitialized) player.resumeFromBackground()
        if (::tiles.isInitialized) tiles.resumeAll()
        toJs("window.\$appVisible&&\$appVisible(true)")
    }

    override fun onDestroy() {
        player.release()
        tiles.releaseAll()
        server.stop()
        web.destroy()
        super.onDestroy()
    }

    /** Funciones que la interfaz llama como Android.xxx(...) */
    inner class Bridge {
        private val prefs = getSharedPreferences("iptv", Context.MODE_PRIVATE)

        @JavascriptInterface
        fun regAll(): String = prefs.getString("registry", "{}") ?: "{}"

        @JavascriptInterface
        fun regSave(json: String) {
            prefs.edit().putString("registry", json).apply()
        }

        @JavascriptInterface
        fun deviceInfo(): String = DeviceInfo.json(this@MainActivity)

        @JavascriptInterface
        fun video(json: String) {
            main.post {
                val c = try {
                    JSONObject(json)
                } catch (e: Exception) {
                    null
                }
                if (c != null && c.optString("cmd") == "tile") tiles.command(c) else player.command(json)
            }
        }

        @JavascriptInterface
        fun exitApp() {
            main.post {
                player.stop()
                tiles.releaseAll()
                finish()
            }
        }

        @JavascriptInterface
        fun serverPort(): Int = server.port

        /** Lee un archivo de la interfaz (pkg:/...) sin pasar por la red. */
        @JavascriptInterface
        fun asset(path: String): String = try {
            if (path.contains("..")) "" else assets.open("web/$path").use { String(it.readBytes(), Charsets.UTF_8) }
        } catch (e: Exception) {
            ""
        }

        @JavascriptInterface
        fun appVersion(): String = try {
            JSONObject().put("v", packageManager.getPackageInfo(packageName, 0).versionName).toString()
        } catch (e: Exception) {
            "{}"
        }
    }
}
