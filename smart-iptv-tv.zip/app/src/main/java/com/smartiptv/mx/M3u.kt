package com.smartiptv.mx

data class Channel(
    val name: String,
    val group: String,
    val url: String,
    val logo: String = "",
    val id: String = "",
    val chno: String = "",
    val vod: Boolean = false,
    val list: String = ""
)

class Catalog(
    val live: LinkedHashMap<String, ArrayList<Channel>>,
    val movies: LinkedHashMap<String, ArrayList<Channel>>,
    val epgUrls: ArrayList<String>
) {
    fun liveCount(): Int = live.values.sumOf { it.size }
    fun movieCount(): Int = movies.values.sumOf { it.size }
}

/** Lectura de listas M3U y clasificacion por categorias (misma logica que la app de Roku). */
object M3u {

    private val STANDARD = listOf(
        "Deportes", "Noticias", "Entretenimiento", "Cine", "Series", "Infantil", "Música", "Documentales"
    )

    private val ADULT = listOf(
        "xxx", "adult", "porn", "erotic", "erotico", "erót", "playboy", "sexy", "18+",
        "hustler", "brazzers", "penthouse", "sextreme", "redlight", "dorcel"
    )

    private class Rule(val name: String, val words: List<String>)

    private val RULES = listOf(
        Rule(
            "Infantil", listOf(
                "infantil", "kids", "niños", "ninos", "cartoon", "disney", "nickelodeon", "nick jr", "nick ",
                "boomerang", "baby", "tooncast", "dibujos", "animaci", "anime", "junior", "peppa", "paw patrol"
            )
        ),
        Rule(
            "Deportes", listOf(
                "deport", "sport", "futbol", "fútbol", "soccer", "nba", "nfl", "mlb", "nhl", "ufc", "espn",
                "tudn", "dazn", "bein", "eurosport", "golf", "tenis", "tennis", "boxeo", "boxing", "wwe",
                "lucha libre", "motogp", "formula 1", "formula1", "nascar", "racing", "olimp", "laliga",
                "premier league", "champions", "bundesliga", "gol tv", "caliente tv"
            )
        ),
        Rule(
            "Noticias", listOf(
                "noticia", "news", "informa", "cnn", "bbc", "euronews", "jazeera", "france 24", "france24",
                "telesur", "milenio", "foro tv", "adn 40", "nmas", "hispantv", "bloomberg", "cnbc", "ntn24",
                "dw español", "dw news", "rt news", "24 horas", "cgtn", "nhk world", "wion", "noticiero",
                "reuters"
            )
        ),
        Rule(
            "Música", listOf(
                "musica", "música", "music", "mtv", "vevo", "radio", "hits", "reggaeton", "salsa", "cumbia",
                "norteñ", "concert", "karaoke", "ritmoson", "telehit", "vh1", "stingray", "bachata",
                "mariachi", "corridos", "ranchero", "rock"
            )
        ),
        Rule("Series", listOf("serie", "novela", "drama", "sitcom")),
        Rule(
            "Cine", listOf(
                "pelic", "pelí", "cine", "movie", "film", "hbo", "cinemax", "tcm", "paramount", "golden",
                "starz", "showtime", "estreno", "amc", "axn", "studio universal"
            )
        ),
        Rule(
            "Documentales", listOf(
                "document", "discovery", "history", "historia", "nat geo", "national geographic",
                "animal planet", "a&e", "ngc", "viajes", "travel", "ciencia", "science", "smithsonian",
                "planeta", "naturaleza", "nature", "investigation", "dmax", "explora"
            )
        ),
        Rule(
            "Entretenimiento", listOf(
                "entreten", "entertain", "variedad", "comedia", "comedy", "reality", "show", "adult swim",
                "lifestyle", "cocina", "food", "tlc", "telemundo", "televisa", "azteca", "estrellas",
                "univision", "unimas", "nu9ve", "canal 5", "lifetime", "fox", "tbs", "tnt", "hgtv", "hogar",
                "sony", "universal", "warner", "antena 3", "telecinco", "cuatro", "bravo", "multimedios"
            )
        )
    )

    private val CHANNEL_WORDS = listOf(
        "24/7", "24-7", "24h", "24 h", "en vivo", " tv", "tv ", "canal", "channel", "hbo", "cinemax",
        "cinecanal", "cinelatino", "studio universal", "tcm", "golden", "starz", "showtime", "paramount",
        "amc", "axn", "sony", "warner", "cine mexicano", "cine de oro", "cine clasico", "pasiones", "telehit"
    )

    private val YEAR = Regex("(?<![0-9])(19[3-9][0-9]|20[0-3][0-9])(?![0-9])")

    private class Pending(val entry: Channel, val group: String, val title: String)

    private fun any(text: String, words: List<String>): Boolean {
        for (w in words) if (text.contains(w)) return true
        return false
    }

    private fun attr(line: String, key: String): String {
        val k = "$key=\""
        val i = line.indexOf(k)
        if (i < 0) return ""
        val s = i + k.length
        val e = line.indexOf('"', s)
        if (e < 0) return ""
        return line.substring(s, e).trim()
    }

    private fun addTo(map: LinkedHashMap<String, ArrayList<Channel>>, name: String, ch: Channel) {
        var arr = map[name]
        if (arr == null) {
            arr = ArrayList()
            map[name] = arr
        }
        arr.add(ch)
    }

    private fun isChannelName(n: String): Boolean = any(n, CHANNEL_WORDS)

    private fun hasYear(t: String): Boolean = YEAR.containsMatchIn(t)

    /** "vod" (pelicula o serie), "live" (canal en vivo) o "maybe" (depende del grupo). */
    private fun vodKind(group: String, name: String, url: String, id: String): String {
        val u = url.lowercase()
        if (u.contains("/live/")) return "live"
        if (u.contains("/movie/") || u.contains("/series/") || u.contains("/vod/") ||
            u.contains("type=movie") || u.contains("type=series")
        ) return "vod"
        val path = u.substringBefore('?')
        if (path.endsWith(".mp4") || path.endsWith(".mkv")) return "vod"
        val g = group.lowercase()
        if (g.isEmpty()) return "live"
        if (any(g, listOf("deport", "noticia", "news", "infantil", "kids", "musica", "música", "radio"))) return "live"
        if (!any(
                g,
                listOf(
                    "pelic", "movie", "vod", "estreno", "halloween", "4k", "cine", "film", " fps",
                    "castellano", "latino", "subtit"
                )
            )
        ) return "live"
        if (id.isNotEmpty()) return "live"
        if (isChannelName(name.lowercase())) return "live"
        if (hasYear(name)) return "vod"
        return "maybe"
    }

    private fun classify(group: String, name: String): String {
        val g = group.lowercase()
        val n = name.lowercase()
        if (g.isNotEmpty()) {
            for (r in RULES) if (any(g, r.words)) return r.name
        }
        for (r in RULES) if (any(n, r.words)) return r.name
        val gt = group.trim()
        val lg = gt.lowercase()
        if (gt.isNotEmpty() && lg !in setOf("general", "undefined", "other", "otros", "sin categoria", "uncategorized", "unknown")) {
            return gt
        }
        return "Otros"
    }

    private fun orderLive(map: Map<String, ArrayList<Channel>>): LinkedHashMap<String, ArrayList<Channel>> {
        val out = LinkedHashMap<String, ArrayList<Channel>>()
        for (n in STANDARD) {
            val a = map[n]
            if (a != null) out[n] = a
        }
        for ((n, a) in map) {
            if (!out.containsKey(n) && n != "Otros" && n != "Adultos") out[n] = a
        }
        val otros = map["Otros"]
        if (otros != null) out["Otros"] = otros
        val adultos = map["Adultos"]
        if (adultos != null) out["Adultos"] = adultos
        return out
    }

    fun parse(text: String, listName: String): Catalog {
        val live = LinkedHashMap<String, ArrayList<Channel>>()
        val movies = LinkedHashMap<String, ArrayList<Channel>>()
        val epg = ArrayList<String>()
        val vodCount = HashMap<String, Int>()
        val pending = LinkedHashMap<String, ArrayList<Pending>>()

        var title = "Canal sin nombre"
        var group = ""
        var id = ""
        var logo = ""
        var chno = ""

        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (line.startsWith("#EXTM3U")) {
                for (key in listOf("url-tvg", "x-tvg-url", "tvg-url")) {
                    val v = attr(line, key)
                    if (v.isNotEmpty()) {
                        for (part in v.split(",")) {
                            val u = part.trim()
                            if (u.startsWith("http") && !epg.contains(u)) epg.add(u)
                        }
                        break
                    }
                }
            } else if (line.startsWith("#EXTINF:")) {
                title = ""
                val q = line.lastIndexOf('"')
                val comma = line.indexOf(',', if (q >= 0) q else 0)
                if (comma >= 0) title = line.substring(comma + 1).trim()
                if (title.isEmpty()) title = attr(line, "tvg-name")
                if (title.isEmpty()) title = "Canal sin nombre"
                group = attr(line, "group-title")
                id = attr(line, "tvg-id").lowercase()
                logo = attr(line, "tvg-logo")
                if (logo.isEmpty()) logo = attr(line, "logo")
                chno = attr(line, "tvg-chno")
            } else if (line.startsWith("#EXTGRP:")) {
                val g = line.substring(8).trim()
                if (g.isNotEmpty()) group = g
            } else if (line.startsWith("http://") || line.startsWith("https://")) {
                val both = group.lowercase() + " | " + title.lowercase()
                if (!both.contains("adult swim") && any(both, ADULT)) {
                    addTo(live, "Adultos", Channel(title, "Adultos", line, logo, id, chno, false, listName))
                } else {
                    val kind = vodKind(group, title, line, id)
                    var gname = group.trim()
                    if (gname.isEmpty()) gname = "Películas"
                    if (kind == "vod") {
                        addTo(movies, gname, Channel(title, gname, line, logo, id, chno, true, listName))
                        vodCount[gname] = (vodCount[gname] ?: 0) + 1
                    } else if (kind == "maybe") {
                        var arr = pending[gname]
                        if (arr == null) {
                            arr = ArrayList()
                            pending[gname] = arr
                        }
                        arr.add(Pending(Channel(title, gname, line, logo, id, chno, true, listName), group, title))
                    } else {
                        val cat = classify(group, title)
                        addTo(live, cat, Channel(title, cat, line, logo, id, chno, false, listName))
                    }
                }
                title = "Canal sin nombre"
                group = ""
                id = ""
                logo = ""
                chno = ""
            }
        }

        // Grupos de "peliculas" dudosos: si casi todo el grupo trae anio en el titulo son
        // peliculas; si no, son canales en vivo de peliculas y van a TV.
        for ((gname, arr) in pending) {
            val vodN = vodCount[gname] ?: 0
            for (p in arr) {
                if (vodN >= arr.size) {
                    addTo(movies, gname, p.entry)
                } else {
                    val cat = classify(p.group, p.title)
                    addTo(live, cat, p.entry.copy(group = cat, vod = false))
                }
            }
        }

        return Catalog(orderLive(live), movies, epg)
    }

    /** Junta varias listas activas en un solo catalogo. */
    fun merge(list: List<Catalog>): Catalog {
        val live = LinkedHashMap<String, ArrayList<Channel>>()
        val movies = LinkedHashMap<String, ArrayList<Channel>>()
        val epg = ArrayList<String>()
        for (c in list) {
            for ((n, a) in c.live) {
                var t = live[n]
                if (t == null) {
                    t = ArrayList()
                    live[n] = t
                }
                t.addAll(a)
            }
            for ((n, a) in c.movies) {
                var t = movies[n]
                if (t == null) {
                    t = ArrayList()
                    movies[n] = t
                }
                t.addAll(a)
            }
            for (u in c.epgUrls) if (!epg.contains(u)) epg.add(u)
        }
        return Catalog(orderLive(live), movies, epg)
    }
}
