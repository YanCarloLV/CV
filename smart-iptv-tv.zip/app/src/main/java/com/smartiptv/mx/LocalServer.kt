package com.smartiptv.mx

import java.io.BufferedInputStream
import java.io.InputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder

/**
 * Mini servidor dentro de la TV: el celular abre http://IP:puerto, pega el enlace
 * de su lista M3U y la TV la recibe. No necesita servidor externo.
 */
class LocalServer(private val onList: (String, String, String) -> Unit) {

    @Volatile
    private var running = false
    private var server: ServerSocket? = null
    var port = 0

    fun start(): Boolean {
        for (p in intArrayOf(8090, 8099, 8123, 0)) {
            try {
                val s = ServerSocket(p)
                server = s
                port = s.localPort
                break
            } catch (e: Exception) {
                server = null
            }
        }
        val s = server ?: return false
        running = true
        Thread {
            while (running) {
                try {
                    val c = s.accept()
                    handle(c)
                } catch (e: Exception) {
                    if (!running) break
                }
            }
        }.start()
        return true
    }

    fun stop() {
        running = false
        try {
            server?.close()
        } catch (e: Exception) {
        }
    }

    private fun handle(c: Socket) {
        try {
            c.soTimeout = 5000
            val input = BufferedInputStream(c.getInputStream())
            val reqLine = readLine(input) ?: return
            var len = 0
            while (true) {
                val h = readLine(input) ?: break
                if (h.isEmpty()) break
                if (h.lowercase().startsWith("content-length:")) {
                    len = h.substring(15).trim().toIntOrNull() ?: 0
                }
            }
            var body = ""
            if (reqLine.startsWith("POST") && len > 0) {
                val buf = ByteArray(minOf(len, 30000))
                var read = 0
                while (read < buf.size) {
                    val n = input.read(buf, read, buf.size - read)
                    if (n < 0) break
                    read += n
                }
                body = String(buf, 0, read, Charsets.UTF_8)
            }
            var msg = ""
            if (reqLine.startsWith("POST")) {
                val url = field(body, "url")
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    onList(field(body, "name"), url, field(body, "epg"))
                    msg = "Lista recibida. Mira tu TV. Puedes enviar otra."
                } else {
                    msg = "El enlace debe empezar con http:// o https://"
                }
            }
            val bytes = page(msg).toByteArray(Charsets.UTF_8)
            val head = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n" +
                "Content-Length: " + bytes.size + "\r\nConnection: close\r\n\r\n"
            val out = c.getOutputStream()
            out.write(head.toByteArray(Charsets.UTF_8))
            out.write(bytes)
            out.flush()
        } catch (e: Exception) {
        } finally {
            try {
                c.close()
            } catch (e: Exception) {
            }
        }
    }

    private fun readLine(i: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = i.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == 10) break
            if (b != 13) sb.append(b.toChar())
        }
        return sb.toString()
    }

    private fun field(body: String, key: String): String {
        for (pair in body.split("&")) {
            val eq = pair.indexOf('=')
            if (eq > 0 && pair.substring(0, eq) == key) {
                return try {
                    URLDecoder.decode(pair.substring(eq + 1), "UTF-8").trim()
                } catch (e: Exception) {
                    ""
                }
            }
        }
        return ""
    }

    private fun page(msg: String): String {
        val note = if (msg.isEmpty()) "" else "<p class='msg'>$msg</p>"
        return "<!doctype html><html lang='es'><head><meta charset='utf-8'>" +
            "<meta name='viewport' content='width=device-width,initial-scale=1'>" +
            "<title>Smart IPTV MX</title><style>" +
            "body{margin:0;background:#090A0C;color:#F4F5F7;font-family:system-ui,sans-serif;padding:24px}" +
            "h1{color:#FF8A24;font-size:26px;margin:0 0 6px}" +
            "p{color:#B6BAC2;line-height:1.5}" +
            "input[type=text],input[type=url]{width:100%;box-sizing:border-box;padding:16px;font-size:17px;" +
            "border-radius:12px;border:2px solid #2A2D33;background:#17191D;color:#F4F5F7;margin:6px 0 12px}" +
            "label{display:block;margin:6px 0;color:#B6BAC2}" +
            "button{width:100%;padding:16px;font-size:18px;font-weight:700;border:0;border-radius:12px;" +
            "background:#FF6A00;color:#090A0C;margin-top:8px}" +
            ".msg{color:#FFB067;font-weight:700}" +
            "</style></head><body><h1>Smart IPTV MX</h1>" +
            "<p>Agrega aqu&iacute; tu lista M3U y se cargar&aacute; en tu TV.</p>" + note +
            "<form method='post' action='/'>" +
            "<label>Nombre de la lista (opcional)</label>" +
            "<input type='text' name='name' placeholder='Mi lista'>" +
            "<label>Enlace de la lista M3U</label>" +
            "<input type='url' name='url' placeholder='https://...' required>" +
            "<label>Enlace de la gu&iacute;a XMLTV (opcional)</label>" +
            "<input type='url' name='epg' placeholder='https://...'>" +
            "<label><input type='checkbox' required> Estoy de acuerdo: soy responsable del contenido de mi " +
            "lista y esta app no incluye ni proporciona canales.</label>" +
            "<button type='submit'>Enviar a la TV</button></form></body></html>"
    }

    companion object {
        fun localIp(): String {
            try {
                val ifs = NetworkInterface.getNetworkInterfaces()
                while (ifs.hasMoreElements()) {
                    val ni = ifs.nextElement()
                    if (!ni.isUp || ni.isLoopback) continue
                    val addrs = ni.inetAddresses
                    while (addrs.hasMoreElements()) {
                        val a = addrs.nextElement()
                        if (a is Inet4Address && !a.isLoopbackAddress) {
                            val h = a.hostAddress
                            if (h != null) return h
                        }
                    }
                }
            } catch (e: Exception) {
            }
            return "0.0.0.0"
        }
    }
}
