package com.smartiptv.mx

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.FrameLayout
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import org.json.JSONObject

/**
 * Mosaico: hasta 4 canales a la vez, cada uno con su propio ExoPlayer.
 * Solo el cuadro elegido tiene sonido (y mejor calidad); los demas van en silencio
 * y a 480p para que la TV aguante los 4 videos juntos.
 * Igual que el reproductor principal usa la extension FFmpeg, que decodifica por software
 * el audio que la Chromecast no maneja sola (MPEG-L2, AC3, E-AC3, DTS...).
 */
class TilePlayers(
    private val ctx: Context,
    private val root: FrameLayout,
    private val insertAt: () -> Int,
    private val emit: (String) -> Unit
) {

    private val main = Handler(Looper.getMainLooper())
    private val tiles = HashMap<Int, Tile>()
    var onActive: ((Boolean) -> Unit)? = null

    private inner class Tile(val pid: Int) : Player.Listener {
        val view = PlayerView(ctx)
        var exo: ExoPlayer? = null
        var url = ""
        var format = ""
        var altTried = false
        var retries = 0
        var lastState = ""
        var mute = true
        var hq = false
        private val retry = Runnable { load() }

        init {
            view.useController = false
            view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            view.setShutterBackgroundColor(android.graphics.Color.BLACK)
            view.isFocusable = false
            view.visibility = View.GONE
            root.addView(view, insertAt(), FrameLayout.LayoutParams(1, 1))
        }

        fun play(u: String, f: String) {
            url = u
            format = f.lowercase()
            altTried = false
            retries = 0
            main.removeCallbacks(retry)
            load()
        }

        private fun build(): ExoPlayer {
            val rf = DefaultRenderersFactory(ctx)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
                .setEnableDecoderFallback(true)
            val http = DefaultHttpDataSource.Factory()
                .setUserAgent(LocalServer.USER_AGENT)
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(20000)
            val load = DefaultLoadControl.Builder().setBufferDurationsMs(2500, 8000, 1000, 2000).build()
            val p = ExoPlayer.Builder(ctx, rf)
                .setMediaSourceFactory(DefaultMediaSourceFactory(http))
                .setLoadControl(load)
                .build()
            p.addListener(this)
            view.player = p
            return p
        }

        private fun load() {
            if (url.isEmpty()) return
            val p = exo ?: build().also { exo = it }
            p.stop()
            p.clearMediaItems()
            val b = MediaItem.Builder().setUri(Uri.parse(url))
            val path = Uri.parse(url).path?.lowercase() ?: ""
            if (path.endsWith(".mpd")) b.setMimeType(MimeTypes.APPLICATION_MPD)
            else when (format) {
                "hls" -> b.setMimeType(MimeTypes.APPLICATION_M3U8)
                "ts" -> b.setMimeType(MimeTypes.VIDEO_MP2T)
            }
            p.setMediaItem(b.build())
            applyAudio()
            p.playWhenReady = true
            p.prepare()
            send("buffering")
        }

        fun applyAudio() {
            val p = exo ?: return
            p.volume = if (mute) 0f else 1f
            val (w, h) = if (hq) Pair(1280, 720) else Pair(854, 480)
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().setMaxVideoSize(w, h).build()
        }

        override fun onPlaybackStateChanged(state: Int) {
            when (state) {
                Player.STATE_READY -> {
                    retries = 0
                    send("playing")
                }
                Player.STATE_BUFFERING -> send("buffering")
                Player.STATE_ENDED -> scheduleRetry()
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            // Igual que en el canal: un enlace sin extension que falla como HLS se prueba como TS y al reves
            if (!altTried && (format == "hls" || format == "ts" || format.isEmpty())) {
                altTried = true
                val low = url.lowercase()
                if (format == "hls" && low.contains("/live/") && low.endsWith(".m3u8")) url = url.dropLast(5) + ".ts"
                else if (format == "ts" && low.contains("/live/") && low.endsWith(".ts")) url = url.dropLast(3) + ".m3u8"
                format = if (format == "hls") "ts" else "hls"
                load()
                return
            }
            scheduleRetry()
        }

        private fun scheduleRetry() {
            if (retries < 4) {
                retries++
                send("retry")
                main.removeCallbacks(retry)
                main.postDelayed(retry, (1500L * retries).coerceAtMost(6000L))
            } else {
                send("error")
            }
        }

        private fun send(st: String) {
            if (st == lastState) return
            lastState = st
            val o = JSONObject()
            o.put("pid", pid)
            o.put("state", st)
            emit(o.toString())
        }

        fun release() {
            main.removeCallbacks(retry)
            exo?.release()
            exo = null
            view.player = null
            root.removeView(view)
        }
    }

    fun command(c: JSONObject) {
        val pid = c.optInt("pid")
        if (pid <= 0) return
        when (c.optString("op")) {
            "play" -> {
                val t = tiles.getOrPut(pid) { Tile(pid) }
                t.mute = c.optBoolean("mute", true)
                t.hq = c.optBoolean("hq", false)
                t.play(c.optString("url"), c.optString("format"))
                onActive?.invoke(true)
            }
            "stop" -> {
                tiles.remove(pid)?.release()
                if (tiles.isEmpty()) onActive?.invoke(false)
            }
            "audio" -> tiles[pid]?.let {
                it.mute = c.optBoolean("mute", true)
                it.hq = c.optBoolean("hq", false)
                it.applyAudio()
            }
            "rect" -> tiles[pid]?.let { t ->
                val lp = t.view.layoutParams as FrameLayout.LayoutParams
                val w = c.optInt("w").coerceAtLeast(1)
                val h = c.optInt("h").coerceAtLeast(1)
                if (lp.width != w || lp.height != h || lp.leftMargin != c.optInt("x") || lp.topMargin != c.optInt("y")) {
                    lp.width = w
                    lp.height = h
                    lp.leftMargin = c.optInt("x")
                    lp.topMargin = c.optInt("y")
                    t.view.layoutParams = lp
                }
                t.view.visibility = if (c.optBoolean("visible")) View.VISIBLE else View.GONE
            }
        }
    }

    fun pauseAll() {
        for (t in tiles.values) t.exo?.pause()
    }

    fun resumeAll() {
        for (t in tiles.values) t.exo?.play()
    }

    fun releaseAll() {
        for (t in tiles.values) t.release()
        tiles.clear()
    }
}
