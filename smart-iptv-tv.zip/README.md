# Smart IPTV MX para Google TV (v0.1)

Reproductor IPTV para Android TV / Google TV con mosaico de 2 a 4 canales.
La app no incluye canales ni listas: el usuario carga su propia lista M3U.
