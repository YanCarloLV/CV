# Smart IPTV MX para Google TV / Android TV (v1.95)

Es el mismo canal de Roku (versión 1.90), migrado a Android TV.

## Cómo está hecho

- **Interfaz**: es el código BrightScript del canal de Roku, convertido automáticamente a
  JavaScript, más un motor pequeño que reproduce el SceneGraph de Roku en HTML a 1280x720.
  Por eso las pantallas, posiciones, colores, textos, idiomas, animaciones y la lógica
  (listas M3U, Xtream, guía EPG, QR, clima, partidos, control parental, favoritos,
  continuar viendo, reconexión automática...) son las mismas que en Roku.
- **Video**: ExoPlayer (Media3), con decodificadores de audio FFmpeg (AC3, E-AC3, DTS...).
  Va detrás de la interfaz, en el recuadro que la interfaz pide (pantalla completa, guía o
  miniatura en el menú de canales).
- **Servidor local** (`LocalServer.kt`): hace lo que en Roku hace el sistema: descargas
  (roUrlTransfer), archivos tmp:/ y cachefs:/, el registro y el servidor para el celular (QR).

## Mosaico (solo Google TV)

Normal: **3 canales + Centro de partidos** en el cuarto lugar (muchas listas no permiten 4
conexiones a la vez). Opción en el menú del cuadro: **4 videos** sin el panel.

- **Centro de partidos** (datos de ESPN, cada 20 s): marcador y minuto de *tus* partidos
  (los de los cuadros) y lo último de todas las ligas: goles, rojas, medios tiempos y finales.
  Con el panel elegido: Arriba/Abajo recorren las jugadas, OK pone ese partido en un cuadro
  (si tu lista lo pasa), mantener Atrás = opciones (Partidos de hoy, retraso de avisos, 4 videos).
- **Sin avisos encima del video** (los canales van atrasados y serían spoiler): cuando cae un
  gol o una roja en tus partidos, solo se marca en la barra de abajo (etiqueta GOL / ROJA).
  Cuando tu partido termina, una etiqueta discreta en el cuadro ofrece cambiarlo con OK.
- El marcador de tus partidos se muestra con 45 s de retraso para no adelantarse al canal
  (se puede cambiar: al momento, 30, 45, 60 o 90 s).
- Todo el mosaico (y la barra) queda dentro del área segura de la TV: las teles recortan un
  poco cada orilla de la imagen.
- **Barra de marcadores** abajo, por liga, que se desplaza sola (solo en el mosaico; la mueve
  la GPU, no gasta procesador).
- El sonido se queda en el último cuadro de video elegido. Todos los cuadros van en calidad
  reducida y fija: cambiar de cuadro no recarga ningún canal. Los canales arrancan
  escalonados y, si el proveedor no acepta más conexiones de tu cuenta, el cuadro lo avisa.
- Usa la misma extensión FFmpeg que el reproductor principal (audio MPEG-L2 / AC3 / E-AC3 / DTS).
- Inicio → tarjeta **Mosaico**. En vivo: mantener **Atrás** sobre un canal lo agrega o lo quita.
  Partidos de hoy: mantener **OK** sobre un partido lo agrega.
- Dentro del mosaico: flechas = mover, OK = pantalla completa, mantener OK = diseño
  (Cuadrícula / Enfoque), mantener Atrás = opciones, « » = canal anterior/siguiente.

El código está en `tools/extra/components/` (`mosaic.brs`, `mosfeed.brs`, `mosfeedtask.*`)
del kit de migración, y los cambios al canal de Roku en `tools/patches.js`.

## Fluidez (v1.93)

- Los brillos del fondo quedan fijos (en la Chromecast cada uno era una capa de pantalla
  completa que la GPU volvía a mezclar 60 veces por segundo, incluso con la app quieta).
- Las animaciones que se repiten (puntos que laten) van a 30 cuadros por segundo; las del foco
  y las transiciones siguen a 60. Las capas de GPU se liberan al terminar cada animación.
- Si se mantiene una flecha, las repeticiones que llegan mientras la interfaz aún dibuja la
  anterior se descartan (la lista no se sigue de largo).
- Las imágenes se decodifican antes de mostrarse.
- Video en vivo siempre a velocidad normal (ExoPlayer aceleraba o frenaba un poco el video para
  seguir el punto en vivo, y eso se veía como tironcitos) y recuperación silenciosa cuando el
  canal se queda atrás de la transmisión.

## Wi-Fi durante el video (v1.94)

Mientras hay un canal o el mosaico, la app pide al sistema el Wi-Fi en modo de alto
rendimiento / baja latencia (WifiLock, como YouTube) para que la Chromecast no lo ponga en
ahorro de energía, y el reproductor descarga de forma más pareja (buffer de 20 a 30 s en
lugar de ráfagas de 35 s). La app nunca escanea, apaga ni reconecta el Wi-Fi.

## Control remoto

| Roku | Google TV / Android TV |
|------|------------------------|
| Flechas, OK, Atrás | Flechas, OK, Atrás |
| Play/Pausa | Play/Pausa, o **mantener OK** medio segundo |
| * (opciones) | Menú, o **mantener Atrás** medio segundo |
| « » (rew / ff) | Rebobinar / Adelantar (o Anterior / Siguiente) |
| Repetición instantánea | Canal anterior (si el control lo tiene) |
| Canal + / – | Canal + / – (cambian de canal como Arriba/Abajo) |

## Compilar

El flujo de GitHub Actions (`.github/workflows/build.yml`) descomprime
`smart-iptv-tv.zip` y genera `smart-iptv-mx.apk` en Releases. El APK se firma con la misma
llave de siempre (`app/debug.keystore`), así que se instala encima de la versión anterior.

## Actualizar la interfaz desde el canal de Roku

La carpeta `assets/web` se genera con las herramientas del proyecto de migración
(`tools/package.sh <carpeta_del_canal_roku>`): convierte los `.brs`/`.xml` del canal y
copia imágenes, fuentes, sonidos y traducciones.
