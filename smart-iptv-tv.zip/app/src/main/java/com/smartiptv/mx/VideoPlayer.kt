package com.smartiptv.mx

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.FrameLayout
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import org.json.JSONObject

/**
 * Reproductor de video (equivalente al nodo Video de Roku). La interfaz lo controla
 * con comandos JSON y recibe el estado, la posicion y las pistas de audio/subtitulos.
 */
class VideoPlayer(private val ctx: Context, private val view: PlayerView, private val emit: (String) -> Unit) {

    private var exo: ExoPlayer? = null
    private val main = Handler(Looper.getMainLooper())
    private var lastState = ""
    private var stopped = true
    private var audioIds = ArrayList<Pair<Int, Int>>()
    private var textIds = ArrayList<Pair<Int, Int>>()
    var onPlayingChanged: ((Boolean) -> Unit)? = null

    private val ticker = object : Runnable {
        override fun run() {
            val p = exo
            if (p != null && !stopped) {
                val o = JSONObject()
                o.put("position", p.currentPosition / 1000.0)
                o.put("duration", durationSecs(p))
                emit(o.toString())
            }
            main.postDelayed(this, 500)
        }
    }

    init {
        view.useController = false
        view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        view.setShutterBackgroundColor(android.graphics.Color.BLACK)
        view.setKeepContentOnPlayerReset(false)
        view.visibility = View.GONE
        view.isFocusable = false
        main.post(ticker)
    }

    private fun build(): ExoPlayer {
        val rf = DefaultRenderersFactory(ctx)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(LocalServer.USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(20000)
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15000, 50000, 2000, 4000)
            .build()
        val p = ExoPlayer.Builder(ctx, rf)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .setLoadControl(load)
            .build()
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) = report()
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                report()
                onPlayingChanged?.invoke(isPlaying)
            }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) = report()
            override fun onPlayerError(error: PlaybackException) {
                if (stopped) return
                val o = JSONObject()
                o.put("error", error.errorCodeName + ": " + (error.message ?: ""))
                o.put("state", "error")
                lastState = "error"
                emit(o.toString())
            }
            override fun onTracksChanged(tracks: Tracks) = sendTracks(tracks)
        })
        view.player = p
        return p
    }

    private fun durationSecs(p: ExoPlayer): Double {
        if (p.isCurrentMediaItemLive) return 0.0
        val d = p.duration
        return if (d == C.TIME_UNSET || d <= 0) 0.0 else d / 1000.0
    }

    private fun report() {
        val p = exo ?: return
        if (stopped) return
        val st = when (p.playbackState) {
            Player.STATE_BUFFERING -> "buffering"
            Player.STATE_READY -> if (p.playWhenReady) "playing" else "paused"
            Player.STATE_ENDED -> "finished"
            else -> return
        }
        if (st == lastState) return
        lastState = st
        val o = JSONObject()
        o.put("state", st)
        o.put("position", p.currentPosition / 1000.0)
        o.put("duration", durationSecs(p))
        emit(o.toString())
    }

    private fun sendTracks(tracks: Tracks) {
        val audio = JSONArray()
        val text = JSONArray()
        audioIds.clear()
        textIds.clear()
        var selAudio = ""
        var selText = ""
        tracks.groups.forEachIndexed { gi, g ->
            for (ti in 0 until g.length) {
                val f = g.getTrackFormat(ti)
                val o = JSONObject()
                val lang = f.language ?: ""
                if (g.type == C.TRACK_TYPE_AUDIO) {
                    val id = (audioIds.size + 1).toString()
                    audioIds.add(Pair(gi, ti))
                    o.put("id", id)
                    o.put("lang", lang)
                    o.put("name", f.label ?: "")
                    o.put("format", f.sampleMimeType ?: "")
                    audio.put(o)
                    if (g.isTrackSelected(ti)) selAudio = id
                } else if (g.type == C.TRACK_TYPE_TEXT) {
                    val id = "t" + (textIds.size + 1)
                    textIds.add(Pair(gi, ti))
                    o.put("id", id)
                    o.put("lang", lang)
                    o.put("name", f.label ?: "")
                    text.put(o)
                    if (g.isTrackSelected(ti)) selText = id
                }
            }
        }
        val o = JSONObject()
        o.put("audioTracks", audio)
        o.put("subTracks", text)
        o.put("audioTrack", selAudio)
        o.put("subTrack", selText)
        emit(o.toString())
    }

    fun command(json: String) {
        val c = try {
            JSONObject(json)
        } catch (e: Exception) {
            return
        }
        when (c.optString("cmd")) {
            "play" -> play(c)
            "stop" -> stop()
            "pause" -> exo?.pause()
            "resume" -> exo?.play()
            "seek" -> exo?.seekTo((c.optDouble("pos", 0.0) * 1000).toLong().coerceAtLeast(0L))
            "audio" -> selectAudio(c.optString("track"))
            "subtitle" -> selectText(c.optString("track"))
            "captions" -> if (!c.optBoolean("on")) selectText("")
            "rect" -> rect(c)
        }
    }

    private fun play(c: JSONObject) {
        val url = c.optString("url")
        if (url.isEmpty()) return
        val p = exo ?: build().also { exo = it }
        stopped = false
        lastState = ""
        p.stop()
        p.clearMediaItems()
        val b = MediaItem.Builder().setUri(Uri.parse(url))
        val path = Uri.parse(url).path?.lowercase() ?: ""
        if (path.endsWith(".mpd")) b.setMimeType(MimeTypes.APPLICATION_MPD)
        else when (c.optString("format").lowercase()) {
            "hls" -> b.setMimeType(MimeTypes.APPLICATION_M3U8)
            "dash" -> b.setMimeType(MimeTypes.APPLICATION_MPD)
            "ts" -> b.setMimeType(MimeTypes.VIDEO_MP2T)
            "smooth", "ism" -> b.setMimeType(MimeTypes.APPLICATION_SS)
        }
        val start = (c.optDouble("start", 0.0) * 1000).toLong()
        if (start > 0) p.setMediaItem(b.build(), start) else p.setMediaItem(b.build())
        p.playWhenReady = true
        p.prepare()
        val o = JSONObject()
        o.put("state", "buffering")
        lastState = "buffering"
        emit(o.toString())
    }

    fun stop() {
        stopped = true
        lastState = "stopped"
        exo?.let {
            it.stop()
            it.clearMediaItems()
        }
    }

    private var resumeOnReturn = false

    fun pauseForBackground() {
        val p = exo ?: return
        resumeOnReturn = !stopped && p.playWhenReady
        p.pause()
    }

    fun resumeFromBackground() {
        if (resumeOnReturn && !stopped) exo?.play()
        resumeOnReturn = false
    }

    private fun selectAudio(id: String) {
        val p = exo ?: return
        val idx = (id.toIntOrNull() ?: return) - 1
        if (idx < 0 || idx >= audioIds.size) return
        val (gi, ti) = audioIds[idx]
        val g = p.currentTracks.groups.getOrNull(gi) ?: return
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, ti))
            .build()
    }

    private fun selectText(id: String) {
        val p = exo ?: return
        if (id.isEmpty() || !id.startsWith("t")) {
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .build()
            return
        }
        val idx = (id.substring(1).toIntOrNull() ?: return) - 1
        if (idx < 0 || idx >= textIds.size) return
        val (gi, ti) = textIds[idx]
        val g = p.currentTracks.groups.getOrNull(gi) ?: return
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, ti))
            .build()
    }

    private fun rect(c: JSONObject) {
        val visible = c.optBoolean("visible")
        val lp = view.layoutParams as FrameLayout.LayoutParams
        val w = c.optInt("w").coerceAtLeast(1)
        val h = c.optInt("h").coerceAtLeast(1)
        if (lp.width != w || lp.height != h || lp.leftMargin != c.optInt("x") || lp.topMargin != c.optInt("y")) {
            lp.width = w
            lp.height = h
            lp.leftMargin = c.optInt("x")
            lp.topMargin = c.optInt("y")
            view.layoutParams = lp
        }
        view.visibility = if (visible) View.VISIBLE else View.GONE
    }

    fun release() {
        main.removeCallbacks(ticker)
        exo?.release()
        exo = null
    }
}
