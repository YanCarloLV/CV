// SceneGraph de Roku dibujado con HTML (1280x720), para la pantalla principal.
'use strict';

var $STAGE_W = 1280, $STAGE_H = 720;
var $stageEl = null, $sceneNode = null, $globalNode = null;
var $NINE = $G.$NINE || {};

// ---------------------------------------------------------------
// Utilidades de dibujo
// ---------------------------------------------------------------
var $colorCache = Object.create(null);
function $css(c) {
  if (c == null) return 'rgba(255,255,255,1)';
  if (typeof c === 'number') {
    const v = c >>> 0;
    return 'rgba(' + ((v >>> 24) & 255) + ',' + ((v >>> 16) & 255) + ',' + ((v >>> 8) & 255) + ',' + (((v & 255) / 255).toFixed(3)) + ')';
  }
  const s = String(c);
  const hit = $colorCache[s];
  if (hit) return hit;
  let h = s.trim();
  let r = 255, g = 255, b = 255, a = 255;
  if (/^0x/i.test(h)) h = h.slice(2);
  else if (h[0] === '#') h = h.slice(1);
  if (h.length === 6) { r = parseInt(h.substr(0, 2), 16); g = parseInt(h.substr(2, 2), 16); b = parseInt(h.substr(4, 2), 16); }
  else if (h.length === 8) { r = parseInt(h.substr(0, 2), 16); g = parseInt(h.substr(2, 2), 16); b = parseInt(h.substr(4, 2), 16); a = parseInt(h.substr(6, 2), 16); }
  const out = 'rgba(' + r + ',' + g + ',' + b + ',' + (a / 255).toFixed(3) + ')';
  $colorCache[s] = out;
  return out;
}
function $isWhite(c) {
  if (c == null || c === '') return true;
  const s = String(c).toLowerCase();
  return s === '0xffffffff' || s === '#ffffff' || s === '#ffffffff' || s === '0xffffff';
}
function $uri(u) {
  if (!u) return '';
  u = String(u);
  if (u.startsWith('pkg:/')) return u.slice(5);
  if (u.startsWith('tmp:/') || u.startsWith('cachefs:/')) return $SRV + '/fs/raw?p=' + encodeURIComponent(u);
  if (u.startsWith('common:/')) return '';
  return u;
}

// Fuentes: las del sistema de Roku se dibujan con Inter (incluida en la app)
var $SYS_FONTS = {
  smallestsystemfont: [18, 'Inter-Regular'], smallestboldsystemfont: [18, 'Inter-Bold'],
  smallsystemfont: [22, 'Inter-Regular'], smallboldsystemfont: [22, 'Inter-Bold'],
  mediumsystemfont: [24, 'Inter-Regular'], mediumboldsystemfont: [24, 'Inter-Bold'],
  largesystemfont: [30, 'Inter-Regular'], largeboldsystemfont: [30, 'Inter-Bold'],
  extralargesystemfont: [36, 'Inter-Regular'], extralargeboldsystemfont: [36, 'Inter-Bold']
};
function $fontSpec(f) {
  if (f == null || f === '') return { size: 24, family: 'Inter-Regular' };
  if (typeof f === 'string') {
    const k = f.replace(/^font:/i, '').toLowerCase();
    const s = $SYS_FONTS[k] || [24, 'Inter-Regular'];
    return { size: s[0], family: s[1] };
  }
  if (f.$isnode) {
    const t = f.$t;
    const uri = String(t.get('uri') || '');
    let fam = 'Inter-Regular';
    const m = /([A-Za-z0-9_\-]+)\.(ttf|otf)$/i.exec(uri);
    if (m) fam = m[1];
    let size = t.get('size');
    if (!size) size = 24;
    return { size, family: fam };
  }
  return { size: 24, family: 'Inter-Regular' };
}
var $measureCtx = null;
function $measureText(text, spec) {
  if (!$measureCtx) $measureCtx = document.createElement('canvas').getContext('2d');
  $measureCtx.font = spec.size + 'px "' + spec.family + '"';
  return $measureCtx.measureText(String(text)).width;
}

// ---------------------------------------------------------------
// Nodo visual base (Group)
// ---------------------------------------------------------------
class $VNode extends $NodeBase {
  constructor(type) {
    super(type);
    this.el = document.createElement('div');
    this.el.className = 'n';
    this.el.$n = this;
  }
  defaults() { return $NODE_DEFAULTS[this.type] || $NODE_DEFAULTS[this.baseType || 'Group'] || $NODE_DEFAULTS.Group; }
  applyField(k, v) {
    switch (k) {
      case 'translation': case 'scale': case 'rotation': case 'scalerotatecenter':
        this.updateTransform(); break;
      case 'opacity': this.el.style.opacity = (v == null ? 1 : v); break;
      case 'visible': this.el.style.display = (v === false) ? 'none' : ''; this.visChanged(); if ($tiles.size) $holeSoon(); break;
      case 'clippingrect': this.updateClip(); break;
      case 'renderpass': case 'inheritparenttransform': case 'inheritparentopacity': case 'enablerendertracking': break;
    }
  }
  visChanged() { }
  updateTransform() {
    const tr = this.get('translation') || [0, 0];
    const sc = this.get('scale') || [1, 1];
    const rot = this.get('rotation') || 0;
    const c = this.get('scalerotatecenter') || [0, 0];
    let s = 'translate(' + (tr[0] || 0) + 'px,' + (tr[1] || 0) + 'px)';
    const sx = sc[0] == null ? 1 : sc[0], sy = sc[1] == null ? 1 : sc[1];
    if (sx !== 1 || sy !== 1 || rot) {
      s += ' translate(' + c[0] + 'px,' + c[1] + 'px)';
      if (rot) s += ' rotate(' + (-rot) + 'rad)';
      if (sx !== 1 || sy !== 1) s += ' scale(' + sx + ',' + sy + ')';
      s += ' translate(' + (-c[0]) + 'px,' + (-c[1]) + 'px)';
    }
    this.el.style.transform = s;
  }
  updateClip() {
    const r = this.get('clippingrect');
    if (!r || r.length < 4 || (r[2] === 0 && r[3] === 0)) { this.el.style.clipPath = ''; return; }
    const x = r[0], y = r[1], w = r[2], h = r[3];
    this.el.style.clipPath = 'polygon(' + x + 'px ' + y + 'px,' + (x + w) + 'px ' + y + 'px,' + (x + w) + 'px ' + (y + h) + 'px,' + x + 'px ' + (y + h) + 'px)';
  }
  containerFor() { return this.el; }
  childAdded(n, idx) {
    if (n.el) {
      const host = this.containerFor(n, idx);
      let before = null;
      for (let i = idx + 1; i < this.kids.length; i++) {
        const k = this.kids[i];
        if (k.el && k.el.parentNode === host) { before = k.el; break; }
      }
      host.insertBefore(n.el, before);
    }
    this.contentChanged();
  }
  childRemoved(n) {
    if (n.el && n.el.parentNode) n.el.parentNode.removeChild(n.el);
    this.contentChanged();
  }
  isShown() { let p = this; while (p) { if (p.f.visible === false) return false; p = p.parent; } return true; }
  ownSize() { return null; } // [w,h] de su propio contenido
  localRect() {
    let x1 = Infinity, y1 = Infinity, x2 = -Infinity, y2 = -Infinity;
    const own = this.ownSize();
    if (own) { x1 = 0; y1 = 0; x2 = own[0]; y2 = own[1]; }
    for (const c of this.kids) {
      if (!c.el || c.f.visible === false || !c.parentRect) continue;
      const r = c.parentRect();
      if (r.w === 0 && r.h === 0 && r.x === 0 && r.y === 0 && !c.kids.length && !c.ownSize()) continue;
      if (r.x < x1) x1 = r.x; if (r.y < y1) y1 = r.y;
      if (r.x + r.w > x2) x2 = r.x + r.w; if (r.y + r.h > y2) y2 = r.y + r.h;
    }
    if (x1 === Infinity) return { x: 0, y: 0, w: 0, h: 0 };
    return { x: x1, y: y1, w: x2 - x1, h: y2 - y1 };
  }
  parentRect() {
    const r = this.localRect();
    const tr = this.get('translation') || [0, 0];
    const sc = this.get('scale') || [1, 1];
    const c = this.get('scalerotatecenter') || [0, 0];
    const sx = sc[0] == null ? 1 : sc[0], sy = sc[1] == null ? 1 : sc[1];
    const x = tr[0] + c[0] + (r.x - c[0]) * sx;
    const y = tr[1] + c[1] + (r.y - c[1]) * sy;
    return { x, y, w: r.w * sx, h: r.h * sy };
  }
  boundingRect(local) {
    const r = local ? this.localRect() : this.parentRect();
    return $newAA({ x: r.x, y: r.y, width: r.w, height: r.h });
  }
}
$NODE_DEFAULTS.Group = { id: '', translation: [0, 0], scale: [1, 1], rotation: 0, scalerotatecenter: [0, 0], opacity: 1, visible: true, clippingrect: [0, 0, 0, 0], focusable: false };

class $RectNode extends $VNode {
  constructor(type) { super(type); this.el.className = 'n rect'; this.el.style.background = 'rgba(255,255,255,1)'; }
  applyField(k, v) {
    super.applyField(k, v);
    if (k === 'width') this.el.style.width = (v || 0) + 'px';
    else if (k === 'height') this.el.style.height = (v || 0) + 'px';
    else if (k === 'color') this.el.style.background = $css(v);
  }
  ownSize() { return [this.get('width') || 0, this.get('height') || 0]; }
}
$NODE_DEFAULTS.Rectangle = Object.assign({}, $NODE_DEFAULTS.Group, { width: 0, height: 0, color: '0xFFFFFFFF', blendingenabled: true });

// ---------------------------------------------------------------
// Poster (imagen)
// ---------------------------------------------------------------
var $imgCache = Object.create(null); // url -> {st:'ready'|'failed'|'loading', w, h, cbs}
function $loadImage(url, cb) {
  let e = $imgCache[url];
  if (e) {
    if (e.st === 'loading') e.cbs.push(cb); else cb(e);
    return;
  }
  e = $imgCache[url] = { st: 'loading', w: 0, h: 0, cbs: [cb] };
  const img = new Image();
  img.decoding = 'async';
  // se decodifica antes de mostrarla (fuera del hilo de dibujo): asi una imagen grande
  // (fondos, posters) no frena la animacion del foco al aparecer
  const done = () => { e.st = 'ready'; e.w = img.naturalWidth; e.h = img.naturalHeight; const c = e.cbs; e.cbs = []; c.forEach(f => f(e)); };
  img.onload = () => { if (img.decode) img.decode().then(done, done); else done(); };
  img.onerror = () => { e.st = 'failed'; const c = e.cbs; e.cbs = []; c.forEach(f => f(e)); setTimeout(() => { if ($imgCache[url] === e) delete $imgCache[url]; }, 60000); };
  img.src = url;
}
class $PosterNode extends $VNode {
  constructor(type) { super(type); this.el.className = 'n poster'; this.loadSeq = 0; this.curUrl = ''; }
  applyField(k, v) {
    super.applyField(k, v);
    switch (k) {
      case 'width': case 'height': this.sizeEl(); break;
      case 'uri': this.load(); break;
      case 'loaddisplaymode': case 'blendcolor': this.paint(); break;
      case 'failedbitmapuri': if (this.get('loadstatus') === 'failed') this.load(); break;
    }
  }
  sizeEl() {
    let w = this.get('width') || 0, h = this.get('height') || 0;
    if (!w && !h && this.nat) { w = this.nat[0]; h = this.nat[1]; }
    else if (!w && h && this.nat && this.nat[1]) w = h * this.nat[0] / this.nat[1];
    else if (w && !h && this.nat && this.nat[0]) h = w * this.nat[1] / this.nat[0];
    this.el.style.width = w + 'px';
    this.el.style.height = h + 'px';
  }
  ownSize() {
    let w = this.get('width') || 0, h = this.get('height') || 0;
    if (!w && !h && this.nat) { w = this.nat[0]; h = this.nat[1]; }
    return [w, h];
  }
  load() {
    const raw = this.get('uri') || '';
    const seq = ++this.loadSeq;
    if (!raw) { this.curUrl = ''; this.nat = null; this.paint(); this.set('loadstatus', 'none'); return; }
    const url = $uri(raw);
    this.set('loadstatus', 'loading');
    const nine = $NINE[url];
    const realUrl = nine ? nine.src : url;
    $loadImage(realUrl, (e) => {
      if (seq !== this.loadSeq) return;
      if (e.st === 'ready') {
        this.curUrl = realUrl; this.nine = nine || null;
        this.nat = nine ? [nine.w, nine.h] : [e.w, e.h];
        this.f.bitmapwidth = this.nat[0]; this.f.bitmapheight = this.nat[1];
        this.sizeEl(); this.paint();
        this.set('loadstatus', 'ready');
      } else {
        const fb = this.get('failedbitmapuri');
        if (fb && $uri(fb) !== url) {
          const furl = $uri(fb);
          $loadImage(furl, (e2) => {
            if (seq !== this.loadSeq) return;
            if (e2.st === 'ready') { this.curUrl = furl; this.nine = null; this.nat = [e2.w, e2.h]; this.sizeEl(); this.paint(); }
            this.set('loadstatus', 'failed');
          });
        } else {
          this.curUrl = ''; this.paint();
          this.set('loadstatus', 'failed');
        }
      }
    });
  }
  paint() {
    const s = this.el.style;
    const url = this.curUrl;
    const blend = this.get('blendcolor');
    s.backgroundImage = ''; s.backgroundColor = ''; s.webkitMaskImage = ''; s.maskImage = ''; s.borderImage = ''; s.webkitMaskBoxImage = ''; s.border = ''; s.borderRadius = '';
    s.backgroundBlendMode = '';
    if (!url) return;
    const q = 'url("' + url.replace(/"/g, '%22') + '")';
    if (this.nine) { $paintNine(s, this.nine, blend); return; }
    const mode = String(this.get('loaddisplaymode') || 'noScale').toLowerCase();
    let size = '100% 100%';
    if (mode === 'scaletofit' || mode === 'limitsize' || mode === 'scaletofitlimitsize') size = 'contain';
    else if (mode === 'scaletozoom') size = 'cover';
    s.backgroundImage = q;
    s.backgroundSize = size;
    s.backgroundPosition = 'center';
    s.backgroundRepeat = 'no-repeat';
    if (!$isWhite(blend)) {
      s.backgroundColor = $css(blend);
      s.backgroundBlendMode = 'multiply';
      s.webkitMaskImage = q; s.webkitMaskSize = size; s.webkitMaskPosition = 'center'; s.webkitMaskRepeat = 'no-repeat';
    }
  }
}
$NODE_DEFAULTS.Poster = Object.assign({}, $NODE_DEFAULTS.Group, { width: 0, height: 0, uri: '', loadwidth: 0, loadheight: 0, loaddisplaymode: 'noScale', blendcolor: '0xFFFFFFFF', loadstatus: 'none', bitmapwidth: 0, bitmapheight: 0, failedbitmapuri: '', loadingbitmapuri: '', loadsync: false, audioguidetext: '', bitmapmargins: null });

// Las imagenes 9-patch del canal son rectangulos redondeados blancos: se dibujan con CSS
function $paintNine(s, n, blend) {
  const col = $css(blend == null || blend === '' ? '0xFFFFFFFF' : blend);
  s.borderRadius = n.radius + 'px';
  if (n.kind === 'line') { s.border = '2px solid ' + col; s.backgroundColor = 'transparent'; }
  else { s.border = ''; s.backgroundColor = col; }
}

// ---------------------------------------------------------------
// Label
// ---------------------------------------------------------------
var $fontUsers = new WeakMap();
class $LabelNode extends $VNode {
  constructor(type) {
    super(type);
    this.el.className = 'n label';
    this.inner = document.createElement('div');
    this.inner.className = 'lt';
    this.el.appendChild(this.inner);
    this.styleText();
  }
  applyField(k, v, old) {
    super.applyField(k, v);
    switch (k) {
      case 'text': this.inner.textContent = v == null ? '' : String(v); break;
      case 'color': this.inner.style.color = $css(v); break;
      case 'font':
        if (old && old.$isnode) { const set = $fontUsers.get(old.$t); if (set) set.delete(this); }
        if (v && v.$isnode) { let set = $fontUsers.get(v.$t); if (!set) { set = new Set(); $fontUsers.set(v.$t, set); } set.add(this); }
        this.styleText(); break;
      case 'width': case 'height': case 'horizalign': case 'vertalign': case 'wrap': case 'numlines': case 'maxlines': case 'linespacing': case 'ellipsizeonboundary':
        this.styleText(); break;
    }
  }
  styleText() {
    const spec = $fontSpec(this.get('font'));
    this.spec = spec;
    const w = this.get('width') || 0, h = this.get('height') || 0;
    const wrap = !!this.get('wrap');
    const s = this.el.style, si = this.inner.style;
    const ls = this.get('linespacing');
    const lh = Math.round(spec.size * 1.25 + (ls ? ls : 0));
    this.lh = lh;
    si.fontFamily = '"' + spec.family + '"';
    si.fontSize = spec.size + 'px';
    si.lineHeight = lh + 'px';
    if (!this.f.color) si.color = $css(this.get('color'));
    s.width = w ? w + 'px' : '';
    s.height = h ? h + 'px' : '';
    const ha = String(this.get('horizalign') || 'left').toLowerCase();
    si.textAlign = ha === 'center' ? 'center' : (ha === 'right' ? 'right' : 'left');
    const va = String(this.get('vertalign') || 'top').toLowerCase();
    s.display = this.f.visible === false ? 'none' : 'flex';
    s.flexDirection = 'column';
    s.justifyContent = h ? (va === 'center' ? 'center' : (va === 'bottom' ? 'flex-end' : 'flex-start')) : 'flex-start';
    let lines = 0;
    const nl = this.get('numlines') || 0, ml = this.get('maxlines') || 0;
    if (wrap) {
      lines = nl || ml;
      if (!lines && h) lines = Math.max(1, Math.floor(h / lh));
      si.whiteSpace = 'pre-wrap';
      si.overflowWrap = 'break-word';
      if (lines) {
        si.display = '-webkit-box'; si.webkitLineClamp = String(lines); si.webkitBoxOrient = 'vertical'; si.overflow = 'hidden'; si.textOverflow = '';
      } else { si.display = 'block'; si.webkitLineClamp = ''; si.overflow = ''; }
      si.width = w ? w + 'px' : '';
    } else {
      si.whiteSpace = 'pre';
      si.display = 'block';
      si.webkitLineClamp = '';
      if (w) { si.overflow = 'hidden'; si.textOverflow = 'ellipsis'; si.width = w + 'px'; }
      else { si.overflow = ''; si.textOverflow = ''; si.width = ''; }
    }
  }
  visChanged() { this.el.style.display = this.f.visible === false ? 'none' : 'flex'; }
  ownSize() {
    const w = this.get('width') || 0;
    const h = this.get('height') || 0;
    const spec = this.spec || $fontSpec(this.get('font'));
    const text = String(this.get('text') || '');
    let tw = w;
    if (!w) tw = text === '' ? 0 : Math.ceil($measureText(text, spec));
    let th = h;
    if (!th) {
      if (text === '') th = 0;
      else if (this.get('wrap') && w) {
        const lines = Math.max(1, Math.ceil($measureText(text, spec) / w));
        const lim = this.get('numlines') || this.get('maxlines') || lines;
        th = Math.min(lines, lim) * this.lh;
      } else th = this.lh || Math.round(spec.size * 1.25);
    }
    return [tw, th];
  }
}
$NODE_DEFAULTS.Label = Object.assign({}, $NODE_DEFAULTS.Group, { text: '', color: '0xDDDDDDFF', font: 'font:MediumSystemFont', width: 0, height: 0, horizalign: 'left', vertalign: 'top', wrap: false, numlines: 0, maxlines: 0, linespacing: 0, ellipsizeonboundary: false, ellipsistext: '', truncateondelimiter: '', displaypartiallines: false });
$NODE_DEFAULTS.ScrollingLabel = $NODE_DEFAULTS.Label;

class $FontNode extends $NodeBase {
  applyField(k) {
    if (k === 'size' || k === 'uri') {
      const set = $fontUsers.get(this);
      if (set) for (const l of set) l.styleText();
    }
  }
}
$NODE_DEFAULTS.Font = { id: '', uri: '', size: 24 };

// ---------------------------------------------------------------
// Timer
// ---------------------------------------------------------------
class $TimerNode extends $NodeBase {
  constructor(type) { super(type); this.h = null; }
  applyField(k, v) {
    if (k !== 'control') return;
    const c = String(v || '').toLowerCase();
    if (c === 'start') this.start();
    else if (c === 'stop') this.stop();
  }
  start() {
    this.stop();
    const d = Math.max(0.001, Number(this.get('duration')) || 0.001) * 1000;
    this.h = setTimeout(() => {
      this.h = null;
      if (this.get('repeat')) this.start();
      this.set('fire', true, true);
      this.notify('fire', true);
    }, d);
  }
  stop() { if (this.h) { clearTimeout(this.h); this.h = null; } }
}
$NODE_DEFAULTS.Timer = { id: '', duration: 1, repeat: false, control: 'none', fire: null };

// ---------------------------------------------------------------
// Animaciones
// ---------------------------------------------------------------
var $EASE = {
  linear: t => t,
  inquad: t => t * t, outquad: t => t * (2 - t), inoutquad: t => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
  incubic: t => t * t * t, outcubic: t => (--t) * t * t + 1, inoutcubic: t => t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1,
  inquartic: t => t * t * t * t, outquartic: t => 1 - (--t) * t * t * t, inoutquartic: t => t < 0.5 ? 8 * t * t * t * t : 1 - 8 * (--t) * t * t * t,
  inquintic: t => t * t * t * t * t, outquintic: t => 1 + (--t) * t * t * t * t, inoutquintic: t => t < 0.5 ? 16 * t * t * t * t * t : 1 + 16 * (--t) * t * t * t * t,
  inexpo: t => t === 0 ? 0 : Math.pow(2, 10 * (t - 1)), outexpo: t => t === 1 ? 1 : 1 - Math.pow(2, -10 * t),
  inoutexpo: t => t === 0 ? 0 : t === 1 ? 1 : t < 0.5 ? Math.pow(2, 20 * t - 10) / 2 : (2 - Math.pow(2, -20 * t + 10)) / 2,
  outbounce: t => { const n1 = 7.5625, d1 = 2.75; if (t < 1 / d1) return n1 * t * t; if (t < 2 / d1) return n1 * (t -= 1.5 / d1) * t + 0.75; if (t < 2.5 / d1) return n1 * (t -= 2.25 / d1) * t + 0.9375; return n1 * (t -= 2.625 / d1) * t + 0.984375; }
};
var $activeAnims = new Set();
var $rafOn = false;
// Fluidez en TV: las animaciones que se repiten sin fin no necesitan 60 cuadros por segundo.
//  - Ambientales (se repiten y duran 6 s o mas, como los brillos del fondo): quedan fijas.
//    En la Chromecast cada brillo es una capa de pantalla completa que la GPU tiene que
//    volver a mezclar en cada cuadro; fijas se dibujan una sola vez junto con el fondo.
//  - Otras repetitivas (puntos que laten, barras): a 30 cuadros por segundo.
//  - Las de una sola vez (foco, entradas, desvanecidos) siguen a 60.
var $REPEAT_MS = 33;
function $animLoop(now) {
  if (!$activeAnims.size) { $rafOn = false; return; }
  let fast = false;
  for (const a of Array.from($activeAnims)) {
    if (a.slow) { if (now - (a.lastTick || 0) < $REPEAT_MS) continue; a.lastTick = now; }
    else fast = true;
    a.tick(now);
  }
  if (!$activeAnims.size) { $rafOn = false; return; }
  if (fast) requestAnimationFrame($animLoop);
  else setTimeout(() => requestAnimationFrame($animLoop), $REPEAT_MS - 4);
}
function $animWake() { if (!$rafOn) { $rafOn = true; requestAnimationFrame($animLoop); } }
// capas de GPU solo mientras la animacion corre (despues se dibujan junto con lo demas)
function $wcAdd(a, node) {
  if (!node || !node.el || a.frozen) return;
  if (!a.wc) a.wc = new Set();
  if (a.wc.has(node)) return;
  a.wc.add(node);
  node.$wc = (node.$wc || 0) + 1;
  if (node.$wc === 1) node.el.style.willChange = 'transform, opacity';
}
function $wcRelease(a) {
  if (!a.wc) return;
  for (const node of a.wc) {
    node.$wc = Math.max(0, (node.$wc || 1) - 1);
    if (!node.$wc && node.el) node.el.style.willChange = '';
  }
  a.wc = null;
}

class $AnimNode extends $NodeBase {
  applyField(k, v) {
    if (k !== 'control') return;
    const c = String(v || '').toLowerCase();
    if (c === 'start') this.startAnim();
    else if (c === 'stop') this.stopAnim(false);
    else if (c === 'finish') this.stopAnim(true);
    else if (c === 'pause') { if (this.running && !this.frozen) { this.pausedAt = performance.now(); $activeAnims.delete(this); this.set('state', 'paused'); } }
    else if (c === 'resume') { if (this.pausedAt) { this.t0 += performance.now() - this.pausedAt; this.pausedAt = 0; $activeAnims.add(this); $animWake(); this.set('state', 'running'); } }
  }
  startAnim() {
    const rep = !!this.get('repeat');
    const dur = Number(this.get('duration')) || 0;
    this.frozen = rep && dur >= 6;
    this.slow = rep && !this.frozen;
    this.lastTick = 0;
    $wcRelease(this);
    this.t0 = performance.now() + (Number(this.get('delay')) || 0) * 1000;
    this.pausedAt = 0;
    this.running = true;
    this.targets = null;
    this.apply(0, true);
    if (!this.frozen) { $activeAnims.add(this); $animWake(); }
    this.set('state', 'running');
  }
  stopAnim(finish) {
    if (!this.running) return;
    if (finish) this.apply(1, false);
    this.running = false;
    $activeAnims.delete(this);
    $wcRelease(this);
    this.set('state', 'stopped');
  }
  tick(now) {
    if (now < this.t0) return;
    const dur = Math.max(0.001, Number(this.get('duration')) || 0.001) * 1000;
    let t = (now - this.t0) / dur;
    if (t >= 1) {
      if (this.get('repeat')) {
        this.apply(1, false);
        this.t0 += dur * Math.floor(t);
        t = t - Math.floor(t);
        this.apply(t, false);
        return;
      }
      this.apply(1, false);
      this.running = false;
      $activeAnims.delete(this);
      $wcRelease(this);
      this.set('state', 'stopped');
      return;
    }
    this.apply(t, false);
  }
  apply(t, beforeStart) {
    const ef = $EASE[String(this.get('easefunction') || 'inOutCubic').toLowerCase()] || $EASE.inoutcubic;
    const f = ef(Math.max(0, Math.min(1, t)));
    for (const k of this.kids) if (k.interp) k.interp(f, this);
  }
}
$NODE_DEFAULTS.Animation = { id: '', duration: 1, delay: 0, repeat: false, easefunction: 'inOutCubic', control: 'none', state: 'stopped', optional: false, easeinpercent: 0.5, easeoutpercent: 0.5 };

class $GroupAnimNode extends $NodeBase {
  applyField(k, v) {
    if (k !== 'control') return;
    const c = String(v || '').toLowerCase();
    const kids = this.kids.filter(x => x instanceof $AnimNode || x instanceof $GroupAnimNode);
    if (c === 'start') {
      this.set('state', 'running');
      if (this.type === 'SequentialAnimation') this.runSeq(kids, 0);
      else {
        let left = kids.length;
        if (!left) { this.set('state', 'stopped'); return; }
        this.waiters = kids.map(kd => {
          const o = { handler: () => { if (kd.get('state') === 'stopped') { left--; if (left <= 0 && this.get('state') === 'running') this.set('state', 'stopped'); } } };
          return o;
        });
        for (const kd of kids) {
          kd.$watch = () => { if (kd.get('state') === 'stopped') { left--; if (left <= 0 && this.get('state') === 'running') this.set('state', 'stopped'); } };
          kd.set('control', 'start');
        }
      }
    } else {
      for (const kd of kids) kd.set('control', c);
      if (c === 'stop' || c === 'finish') this.set('state', 'stopped');
    }
  }
  runSeq(kids, i) {
    if (i >= kids.length) { this.set('state', 'stopped'); return; }
    const kd = kids[i];
    kd.$watch = () => { if (kd.get('state') === 'stopped' && this.get('state') === 'running') this.runSeq(kids, i + 1); };
    kd.set('control', 'start');
  }
}
$NODE_DEFAULTS.ParallelAnimation = { id: '', control: 'none', state: 'stopped', repeat: false };
$NODE_DEFAULTS.SequentialAnimation = $NODE_DEFAULTS.ParallelAnimation;
// aviso interno de fin de animacion hija
var $origNotify = $NodeBase.prototype.notify;
$NodeBase.prototype.notify = function (k, v) {
  if (k === 'state' && this.$watch) { const w = this.$watch; if (v === 'stopped') this.$watch = null; w(); }
  return $origNotify.call(this, k, v);
};

class $InterpNode extends $NodeBase {
  resolveTarget(anim) {
    const spec = String(this.get('fieldtointerp') || '');
    const dot = spec.lastIndexOf('.');
    if (dot < 0) return null;
    const id = spec.slice(0, dot), field = spec.slice(dot + 1).toLowerCase();
    let p = anim.parent, node = null;
    while (p && !node) { node = p.findById(id); p = p.parent; }
    if (node && node.el && (field === 'translation' || field === 'opacity' || field === 'scale')) $wcAdd(anim, node);
    return node ? { node, field } : null;
  }
  interp(f, anim) {
    if (!anim.targets) anim.targets = new Map();
    let tg = anim.targets.get(this);
    if (tg === undefined) { tg = this.resolveTarget(anim); anim.targets.set(this, tg); }
    if (!tg) return;
    const key = this.get('key') || [], kv = this.get('keyvalue') || [];
    if (!key.length || !kv.length) return;
    let ff = this.get('reverse') ? 1 - f : f;
    let i = 0;
    if (ff <= key[0]) { tg.node.proxy[tg.field] = this.val(kv[0], kv[0], 0); return; }
    if (ff >= key[key.length - 1]) { tg.node.proxy[tg.field] = this.val(kv[kv.length - 1], kv[kv.length - 1], 0); return; }
    while (i < key.length - 1 && !(ff >= key[i] && ff <= key[i + 1])) i++;
    const span = key[i + 1] - key[i];
    const lt = span > 0 ? (ff - key[i]) / span : 1;
    tg.node.proxy[tg.field] = this.val(kv[i], kv[Math.min(i + 1, kv.length - 1)], lt);
  }
  val(a, b, t) {
    if (this.type === 'Vector2DFieldInterpolator') return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
    if (this.type === 'ColorFieldInterpolator') {
      const pa = $rgba(a), pb = $rgba(b);
      const c = pa.map((x, j) => Math.round(x + (pb[j] - x) * t));
      return '0x' + c.map(x => x.toString(16).padStart(2, '0')).join('').toUpperCase();
    }
    return a + (b - a) * t;
  }
}
function $rgba(c) {
  let h = String(c);
  if (/^0x/i.test(h)) h = h.slice(2); else if (h[0] === '#') h = h.slice(1);
  if (h.length === 6) h += 'FF';
  return [0, 2, 4, 6].map(i => parseInt(h.substr(i, 2), 16) || 0);
}
$NODE_DEFAULTS.FloatFieldInterpolator = { id: '', key: [], keyvalue: [], fieldtointerp: '', reverse: false };
$NODE_DEFAULTS.Vector2DFieldInterpolator = $NODE_DEFAULTS.FloatFieldInterpolator;
$NODE_DEFAULTS.ColorFieldInterpolator = $NODE_DEFAULTS.FloatFieldInterpolator;

// ---------------------------------------------------------------
// Audio (sonido de fondo y efectos)
// ---------------------------------------------------------------
class $AudioNode extends $NodeBase {
  constructor(type) { super(type); this.a = null; $audioNodes.add(this); }
  applyField(k, v) {
    if (k === 'content') { this.stop(); this.a = null; }
    else if (k === 'loop') { if (this.a) this.a.loop = !!v; }
    else if (k === 'control') {
      const c = String(v || '').toLowerCase();
      if (c === 'play' || c === 'start') this.play();
      else if (c === 'stop') this.stop();
      else if (c === 'pause') { if (this.a) this.a.pause(); this.set('state', 'paused'); }
      else if (c === 'resume') { if (this.a) this.a.play().catch(() => { }); this.set('state', 'playing'); }
    }
  }
  ensure() {
    if (this.a) return this.a;
    const c = this.get('content');
    if (!c) return null;
    const url = $uri(c.url);
    if (!url) return null;
    const a = new Audio(url);
    a.loop = !!this.get('loop');
    a.addEventListener('playing', () => this.set('state', 'playing'));
    a.addEventListener('ended', () => { if (!a.loop) { this.set('state', 'finished'); } });
    a.addEventListener('error', () => this.set('state', 'error'));
    this.a = a;
    return a;
  }
  play() {
    const a = this.ensure();
    if (!a) return;
    try { a.currentTime = 0; } catch (e) { }
    this.set('state', 'buffering');
    const p = a.play();
    if (p && p.catch) p.catch(() => this.set('state', 'error'));
  }
  stop() { if (this.a) { this.a.pause(); try { this.a.currentTime = 0; } catch (e) { } } if (this.get('state') !== 'stopped') this.set('state', 'stopped'); }
}
$NODE_DEFAULTS.Audio = { id: '', content: null, control: 'none', state: 'none', loop: false, position: 0, duration: 0, mute: false };

// ---------------------------------------------------------------
// Video: lo reproduce la app nativa (ExoPlayer) detras de la pagina
// ---------------------------------------------------------------
var $videoNode = null;
function $nativeVideo(cmd) {
  try {
    if ($G.Android && $G.Android.video) $G.Android.video(JSON.stringify(cmd));
    else if ($G.$mockVideo) $G.$mockVideo(cmd);
  } catch (e) { console.error(e); }
}
class $VideoNode extends $VNode {
  constructor(type) {
    super(type);
    this.el.className = 'n video';
    $videoNode = this;
    this.f.state = 'none';
  }
  applyField(k, v) {
    super.applyField(k, v);
    switch (k) {
      case 'control': {
        const c = String(v || '').toLowerCase();
        if (c === 'play') this.play();
        else if (c === 'stop') { $nativeVideo({ cmd: 'stop' }); if (this.get('state') !== 'stopped' && this.get('state') !== 'none') this.setState('stopped'); }
        else if (c === 'pause') $nativeVideo({ cmd: 'pause' });
        else if (c === 'resume') $nativeVideo({ cmd: 'resume' });
        else if (c === 'prebuffer') { /* nada */ }
        break;
      }
      case 'seek': if (typeof v === 'number') $nativeVideo({ cmd: 'seek', pos: v }); break;
      case 'visible': case 'translation': case 'width': case 'height': this.layout(); break;
      case 'audiotrack': if (v != null && v !== '') $nativeVideo({ cmd: 'audio', track: String(v) }); break;
      case 'subtitletrack': $nativeVideo({ cmd: 'subtitle', track: String(v || '') }); break;
      case 'globalcaptionmode': $nativeVideo({ cmd: 'captions', on: String(v || '').toLowerCase() === 'on' }); break;
    }
  }
  play() {
    const c = this.get('content');
    if (!c) return;
    this.f.position = 0;
    this.f.duration = 0;
    $nativeVideo({ cmd: 'play', url: String(c.url || ''), format: String(c.streamformat || ''), live: !!c.live, start: Number(c.playstart || 0) || 0, title: String(c.title || '') });
    this.setState('buffering');
  }
  setState(s) { this.set('state', s); }
  layout() { $updateVideoHole(); }
  rect() {
    const tr = this.get('translation') || [0, 0];
    return [tr[0], tr[1], this.get('width') || 1280, this.get('height') || 720];
  }
}
$NODE_DEFAULTS.Video = Object.assign({}, $NODE_DEFAULTS.Group, { content: null, control: 'none', state: 'none', position: 0, duration: 0, width: 0, height: 0, enabletrickplay: true, enableui: true, audiotrack: '', availableaudiotracks: [], subtitletrack: '', availablesubtitletracks: [], globalcaptionmode: 'Off', errormsg: '', errorcode: 0, seek: -1, bufferingstatus: null, notificationinterval: 0.5, loop: false, mute: false });

// La app pasa a segundo plano (boton Inicio, protector de pantalla...)
var $audioNodes = new Set();
$G.$appVisible = function (on) {
  for (const a of $audioNodes) {
    if (!a.a) continue;
    if (!on) { a.wasPlaying = !a.a.paused; a.a.pause(); }
    else if (a.wasPlaying) { a.wasPlaying = false; a.a.play().catch(() => { }); }
  }
};

// Eventos que manda la app nativa
$G.$videoEvent = function (ev) {
  const v = $videoNode;
  if (!v) return;
  try {
    if (typeof ev === 'string') ev = JSON.parse(ev);
    if (ev.position != null) v.set('position', ev.position);
    if (ev.duration != null) v.set('duration', ev.duration);
    if (ev.audioTracks) v.set('availableaudiotracks', ev.audioTracks.map(t => $newAA({ track: t.id, language: t.lang || '', name: t.name || '', format: t.format || '' })));
    if (ev.subTracks) v.set('availablesubtitletracks', ev.subTracks.map(t => $newAA({ trackname: t.id, language: t.lang || '', description: t.name || '' })));
    if (ev.audioTrack != null) v.f.audiotrack = String(ev.audioTrack);
    if (ev.subTrack != null) v.f.subtitletrack = String(ev.subTrack);
    if (ev.error) { v.f.errormsg = String(ev.error); v.f.errorcode = -1; }
    if (ev.state) v.setState(ev.state);
  } catch (e) { $reportError(e); }
};

// ---------------------------------------------------------------
// Listas (MarkupList / LabelList)
// ---------------------------------------------------------------
class $ListNode extends $VNode {
  constructor(type) {
    super(type);
    this.el.className = 'n list';
    this.fp = document.createElement('div'); this.fp.className = 'n fbm';
    this.fb = document.createElement('div'); this.fb.className = 'n fbm';
    this.itemsEl = document.createElement('div'); this.itemsEl.className = 'n';
    this.el.appendChild(this.fp); this.el.appendChild(this.fb); this.el.appendChild(this.itemsEl);
    this.slots = [];
    this.focus = 0;
    this.topIdx = 0;
    this.watched = null;
  }
  count() { const c = this.get('content'); return c ? c.$t.kids.length : 0; }
  item(i) { const c = this.get('content'); return c ? c.$t.kids[i] : null; }
  applyField(k, v) {
    super.applyField(k, v);
    switch (k) {
      case 'content': {
        if (this.watched) this.watched.onContentChange = null;
        this.watched = v ? v.$t : null;
        if (this.watched) this.watched.onContentChange = () => this.contentEdited();
        this.focus = 0; this.topIdx = 0;
        this.render();
        if (this.count() > 0) { this.f.itemfocused = -1; this.set('itemfocused', 0); }
        break;
      }
      case 'jumptoitem': case 'animatetoitem':
        if (typeof v === 'number' && v >= 0) this.setFocusIdx(v, true); break;
      case 'itemsize': case 'numrows': case 'itemspacing': case 'itemcomponentname': case 'vertfocusanimationstyle':
        this.render(); break;
      case 'focusbitmapuri': case 'focusfootprintbitmapuri': case 'focusbitmapblendcolor': case 'focusfootprintblendcolor': case 'drawfocusfeedback':
        this.paintFocus(); break;
    }
  }
  contentEdited() {
    if (this.pendingEdit) return;
    this.pendingEdit = true;
    Promise.resolve().then(() => {
      this.pendingEdit = false;
      const n = this.count();
      if (this.focus >= n) this.focus = Math.max(0, n - 1);
      this.render();
    });
  }
  rows() { return Math.max(1, this.get('numrows') || 1); }
  isize() { const s = this.get('itemsize') || [0, 0]; return [s[0] || 0, s[1] || 0]; }
  gap() { const s = this.get('itemspacing') || [0, 0]; return s[1] || 0; }
  wraps() {
    const st = String(this.get('vertfocusanimationstyle') || (this.type === 'MarkupList' ? 'fixedFocusWrap' : 'floatingFocus')).toLowerCase();
    return st === 'fixedfocuswrap' && this.count() > this.rows();
  }
  setFocusIdx(i, jump) {
    const n = this.count();
    if (!n) return;
    if (i < 0) i = 0; if (i >= n) i = n - 1;
    const old = this.focus;
    this.focus = i;
    if (!this.wraps()) {
      const r = this.rows();
      if (jump && (i < this.topIdx || i >= this.topIdx + r)) this.topIdx = Math.max(0, Math.min(i, n - r));
      if (i < this.topIdx) this.topIdx = i;
      if (i >= this.topIdx + r) this.topIdx = i - r + 1;
      if (this.topIdx > Math.max(0, n - r)) this.topIdx = Math.max(0, n - r);
    } else this.topIdx = i;
    this.render();
    if (old !== i) { this.set('itemunfocused', old); }
    this.set('itemfocused', i);
  }
  move(d) {
    const n = this.count();
    if (!n) return false;
    let i = this.focus + d;
    if (this.wraps()) i = ((i % n) + n) % n;
    // como en Roku: en el borde de una lista sin vuelta, Arriba/Abajo pasan a la pantalla
    // (asi "Arriba" desde la primera categoria llega al boton Partidos de hoy)
    else { if (i < 0 || i >= n) { if (Math.abs(d) > 1) i = Math.max(0, Math.min(n - 1, i)); else return false; } }
    if (i === this.focus) return true;
    this.setFocusIdx(i, false);
    return true;
  }
  keyHandler(key, press) {
    if (!press) return false;
    switch (key) {
      case 'up': return this.move(-1);
      case 'down': return this.move(1);
      case 'rewind': return this.move(-this.rows());
      case 'fastforward': return this.move(this.rows());
      case 'OK':
        if (this.count() > 0) { this.set('itemselected', this.focus, true); this.notify('itemselected', this.focus); }
        return true;
    }
    return false;
  }
  ensureSlots(r) {
    const comp = this.type === 'LabelList' ? null : String(this.get('itemcomponentname') || '');
    if (this.slotComp !== comp) {
      for (const s of this.slots) if (s.el && s.el.parentNode) s.el.parentNode.removeChild(s.el);
      this.slots = [];
      this.slotComp = comp;
    }
    while (this.slots.length < r) {
      let s;
      if (comp) {
        const p = $createNode(comp);
        const t = p.$t;
        t.parent = this; // para isInFocusChain y busquedas
        s = { node: t, el: t.el, content: null };
      } else {
        const el = document.createElement('div');
        el.className = 'n label';
        const inner = document.createElement('div');
        inner.className = 'lt';
        el.appendChild(inner);
        s = { node: null, el, inner, content: null };
      }
      this.itemsEl.appendChild(s.el);
      this.slots.push(s);
    }
  }
  render() {
    const r = this.rows();
    const n = this.count();
    const [w, h] = this.isize();
    const gap = this.gap();
    this.ensureSlots(r);
    const wraps = this.wraps();
    const focused = this.inFocus();
    for (let s = 0; s < this.slots.length; s++) {
      const slot = this.slots[s];
      let idx = this.topIdx + s;
      if (wraps) idx = ((idx % n) + n) % n;
      const show = s < r && (wraps ? s < n : idx < n);
      slot.el.style.display = show ? '' : 'none';
      if (!show) continue;
      const y = s * (h + gap);
      const item = this.item(idx);
      if (slot.node) {
        const p = slot.node.proxy;
        slot.node.f.translation = [0, y]; slot.node.updateTransform();
        if (slot.node.get('width') !== w) p.width = w;
        if (slot.node.get('height') !== h) p.height = h;
        if (slot.content !== item) { slot.content = item; p.index = idx; p.itemcontent = item ? item.proxy : null; }
        const fp = idx === this.focus ? 1 : 0;
        if (slot.node.get('focuspercent') !== fp) p.focuspercent = fp;
        const ihf = idx === this.focus && focused;
        if (slot.node.get('itemhasfocus') !== ihf) p.itemhasfocus = ihf;
        if (slot.node.get('listhasfocus') !== focused) p.listhasfocus = focused;
      } else {
        const el = slot.el, inner = slot.inner;
        el.style.transform = 'translate(0px,' + y + 'px)';
        el.style.width = w + 'px'; el.style.height = h + 'px';
        el.style.display = 'flex'; el.style.flexDirection = 'column'; el.style.justifyContent = 'center';
        const spec = $fontSpec(idx === this.focus ? (this.get('focusedfont') || this.get('font')) : this.get('font'));
        inner.style.fontFamily = '"' + spec.family + '"'; inner.style.fontSize = spec.size + 'px';
        inner.style.whiteSpace = 'pre'; inner.style.overflow = 'hidden'; inner.style.textOverflow = 'ellipsis'; inner.style.padding = '0 12px';
        inner.style.color = $css(idx === this.focus && focused ? this.get('focusedcolor') : this.get('color'));
        inner.textContent = item ? String(item.get('title') || '') : '';
      }
    }
    this.paintFocus();
  }
  inFocus() { return $isInFocusChain(this); }
  onFocusChange() { this.render(); }
  paintFocus() {
    const n = this.count();
    const [w, h] = this.isize();
    const gap = this.gap();
    const focused = this.inFocus();
    const slot = this.wraps() ? 0 : (this.focus - this.topIdx);
    const y = slot * (h + gap);
    const draw = this.get('drawfocusfeedback') !== false && n > 0;
    const set = (el, uri, blend, on) => {
      const s = el.style;
      if (!on || !draw) { s.display = 'none'; return; }
      s.display = '';
      s.width = w + 'px'; s.height = h + 'px';
      s.transform = 'translate(0px,' + y + 'px)';
      const url = $uri(uri);
      const nine = $NINE[url];
      s.backgroundImage = ''; s.webkitMaskBoxImage = ''; s.backgroundColor = ''; s.webkitMaskImage = ''; s.backgroundBlendMode = ''; s.border = ''; s.borderRadius = '';
      if (!url) {
        if (this.type === 'LabelList') { s.backgroundColor = 'rgba(255,255,255,0.92)'; s.borderRadius = '6px'; }
        return;
      }
      if (nine) {
        $paintNine(s, nine, blend);
      } else {
        const q = 'url("' + url + '")';
        s.backgroundImage = q; s.backgroundSize = '100% 100%';
        if (!$isWhite(blend)) { s.backgroundColor = $css(blend); s.backgroundBlendMode = 'multiply'; s.webkitMaskImage = q; s.webkitMaskSize = '100% 100%'; }
      }
    };
    set(this.fb, this.get('focusbitmapuri'), this.get('focusbitmapblendcolor'), focused);
    set(this.fp, this.get('focusfootprintbitmapuri'), this.get('focusfootprintblendcolor'), !focused);
  }
  ownSize() { const [w, h] = this.isize(); const r = this.rows(); return [w, r * h + (r - 1) * this.gap()]; }
}
$NODE_DEFAULTS.MarkupList = Object.assign({}, $NODE_DEFAULTS.Group, { content: null, itemsize: [0, 0], itemspacing: [0, 0], numrows: 12, numcolumns: 1, itemcomponentname: '', focusbitmapuri: '', focusfootprintbitmapuri: '', focusbitmapblendcolor: '0xFFFFFFFF', focusfootprintblendcolor: '0xFFFFFFFF', drawfocusfeedback: true, vertfocusanimationstyle: 'fixedFocusWrap', itemfocused: -1, itemunfocused: -1, itemselected: -1, jumptoitem: 0, animatetoitem: 0, wrapdividerbitmapuri: '', currfocusfeedbackopacity: 1 });
$NODE_DEFAULTS.LabelList = Object.assign({}, $NODE_DEFAULTS.MarkupList, { vertfocusanimationstyle: 'floatingFocus', color: '0xDDDDDDFF', focusedcolor: '0x262626FF', font: 'font:MediumSystemFont', focusedfont: 'font:MediumBoldSystemFont', textverticaladjustment: 0 });

// ---------------------------------------------------------------
// Tareas: se ejecutan en un Web Worker (otro hilo, como en Roku)
// ---------------------------------------------------------------
class $TaskNode extends $NodeBase {
  constructor(type) { super(type); this.w = null; }
  applyField(k, v) {
    if (k === 'control') {
      const c = String(v || '').toLowerCase();
      if (c === 'run') this.run();
      else if (c === 'stop' || c === 'done') this.kill('stop');
    }
  }
  run() {
    this.kill(null);
    const fields = {};
    for (const k in this.f) { if (k === 'control') continue; fields[k] = $toWire(this.f[k]); }
    const g = {};
    for (const k in $globalNode.$t.f) g[k] = $toWire($globalNode.$t.f[k]);
    const w = new Worker('rt/worker.js');
    this.w = w;
    $G.$workers = ($G.$workers || 0) + 1;
    w.onmessage = (e) => {
      const d = e.data;
      if (d.type === 'set') this.set(d.k, $hydrate(d.v, false));
      else if (d.type === 'done') { if (this.w === w) { this.w = null; $G.$workers--; } w.terminate(); this.set('state', 'done'); }
      else if (d.type === 'error') { console.error('[TAREA ' + this.type + '] ' + d.msg); }
      else if (d.type === 'log') { console.log('[' + this.type + ']', d.msg); }
    };
    w.onerror = (e) => { console.error('[TAREA ' + this.type + '] ' + e.message); };
    this.set('state', 'run');
    w.postMessage({ type: 'run', comp: this.type, fields, global: g, srv: $SRV, manifest: $MANIFEST });
  }
  kill(state) {
    if (this.w) { this.w.terminate(); this.w = null; $G.$workers--; }
    if (state) this.set('state', state);
  }
}
$NODE_DEFAULTS.Task = { id: '', functionname: '', control: 'init', state: 'init' };

// ---------------------------------------------------------------
// Escena: separa lo que queda debajo del video y lo que va encima
// ---------------------------------------------------------------
class $SceneNode extends $VNode {
  constructor(type) {
    super(type);
    this.el.className = 'n scene';
    this.below = document.createElement('div'); this.below.className = 'n layer';
    this.above = document.createElement('div'); this.above.className = 'n layer';
    this.el.appendChild(this.below); this.el.appendChild(this.above);
  }
  containerFor(n, idx) {
    const vi = this.kids.findIndex(k => k instanceof $VideoNode);
    return (vi >= 0 && idx > vi) ? this.above : this.below;
  }
  childAdded(n, idx) {
    if (n instanceof $VideoNode) { this.el.insertBefore(n.el, this.above); this.contentChanged(); return; }
    super.childAdded(n, idx);
  }
}
$NODE_DEFAULTS.Scene = Object.assign({}, $NODE_DEFAULTS.Group, { backgroundcolor: '0x000000FF', backgrounduri: '', backexitsscene: true });

// ---------------------------------------------------------------
// Marquee (solo Google TV): barra de marcadores que se desplaza sola.
// Su contenido se arma como cualquier Group; el desplazamiento lo hace el
// compositor (Web Animations), sin trabajo por cuadro en JavaScript.
// refresh = true despues de cambiar el contenido (conserva la posicion).
// ---------------------------------------------------------------
class $MarqueeNode extends $VNode {
  constructor(type) {
    super(type);
    this.el.style.overflow = 'hidden';
    this.mover = document.createElement('div');
    this.mover.className = 'n';
    this.track = document.createElement('div');
    this.track.className = 'n';
    this.copies = document.createElement('div');
    this.copies.className = 'n';
    this.mover.appendChild(this.track);
    this.mover.appendChild(this.copies);
    this.el.appendChild(this.mover);
    this.anim = null; this.period = 0; this.pending = false;
  }
  containerFor() { return this.track; }
  applyField(k, v) {
    super.applyField(k, v);
    if (k === 'width') this.el.style.width = (v || 0) + 'px';
    else if (k === 'height') this.el.style.height = (v || 0) + 'px';
    else if (k === 'refresh' && v) this.soon();
    else if (k === 'running' && this.anim) { if (v === false) this.anim.pause(); else this.anim.play(); }
    else if (k === 'speed' && this.period) this.soon();
  }
  soon() {
    if (this.pending) return;
    this.pending = true;
    Promise.resolve().then(() => { this.pending = false; this.rebuild(); });
  }
  offsetNow() {
    if (!this.anim || !this.period) return 0;
    const sp = this.lastSpeed || 70;
    return (((this.anim.currentTime || 0) / 1000) * sp) % this.period;
  }
  rebuild() {
    const off = this.offsetNow();
    if (this.anim) { this.anim.cancel(); this.anim = null; }
    this.copies.textContent = '';
    this.mover.style.transform = '';
    let w = 0;
    for (const c of this.kids) {
      if (!c.el || c.f.visible === false || !c.parentRect) continue;
      const r = c.parentRect();
      if (r.x + r.w > w) w = r.x + r.w;
    }
    const vw = this.get('width') || 1280;
    if (w <= vw || w <= 0) { this.period = 0; return; } // cabe completo: no se mueve
    const gap = this.get('gap') || 80;
    const sp = Math.max(10, this.get('speed') || 70);
    const period = Math.round(w + gap);
    const n = Math.ceil(vw / period);
    for (let k = 1; k <= n; k++) {
      const d = document.createElement('div');
      d.className = 'n';
      d.style.transform = 'translate(' + (k * period) + 'px,0px)';
      for (const ch of this.track.childNodes) d.appendChild(ch.cloneNode(true));
      this.copies.appendChild(d);
    }
    this.period = period; this.lastSpeed = sp;
    if (!this.mover.animate) return;
    this.anim = this.mover.animate([{ transform: 'translateX(0px)' }, { transform: 'translateX(' + (-period) + 'px)' }],
      { duration: period / sp * 1000, iterations: Infinity, easing: 'linear' });
    this.anim.currentTime = (off % period) / sp * 1000;
    if (this.get('running') === false) this.anim.pause();
  }
}
$NODE_DEFAULTS.Marquee = Object.assign({}, $NODE_DEFAULTS.Group, { width: 1280, height: 34, speed: 70, gap: 80, refresh: false, running: true });

// ---------------------------------------------------------------
// Cuadros del mosaico: reproductores extra de la app nativa (hasta 4)
// ---------------------------------------------------------------
var $tiles = new Map(); // pid -> nodo
var $holeSent = Object.create(null); // ultimo mensaje mandado a cada reproductor
class $TileNode extends $VNode {
  constructor(type) { super(type); this.el.className = 'n video'; this.f.state = 'none'; }
  applyField(k, v, old) {
    super.applyField(k, v);
    const pid = this.get('pid');
    switch (k) {
      case 'pid':
        if (old) $tiles.delete(old);
        if (v) $tiles.set(v, this);
        break;
      case 'control': {
        const c = String(v || '').toLowerCase();
        if (c === 'play' || c === 'stop') delete $holeSent['t' + pid];
        if (c === 'play') {
          $nativeVideo({ cmd: 'tile', op: 'play', pid, url: String(this.get('url') || ''), format: String(this.get('fmt') || ''), mute: !!this.get('mute'), hq: !!this.get('hq') });
          this.set('state', 'buffering');
          $holeSoon();
        } else if (c === 'stop') {
          $nativeVideo({ cmd: 'tile', op: 'stop', pid });
          this.set('state', 'none');
          $holeSoon();
        }
        break;
      }
      case 'mute':
        // solo cambia el volumen: la calidad del cuadro es fija (cambiarla obligaba a recargar el canal)
        if (!!v !== !!old) $nativeVideo({ cmd: 'tile', op: 'audio', pid, mute: !!v });
        break;
      case 'visible': case 'translation': case 'width': case 'height': $holeSoon(); break;
    }
  }
  absRect() {
    let x = 0, y = 0, k = 1, p = this;
    const tr = this.get('translation') || [0, 0];
    x = tr[0]; y = tr[1];
    p = this.parent;
    while (p && p !== $sceneNode) {
      const t = p.get('translation') || [0, 0];
      const sc = p.get('scale') || [1, 1];
      x = t[0] + x * (sc[0] || 1); y = t[1] + y * (sc[1] || 1); k *= (sc[0] || 1);
      p = p.parent;
    }
    return [x, y, (this.get('width') || 0) * k, (this.get('height') || 0) * k];
  }
}
$NODE_DEFAULTS.VideoTile = Object.assign({}, $NODE_DEFAULTS.Group, { pid: 0, url: '', fmt: '', control: 'none', mute: true, hq: false, state: 'none', width: 0, height: 0 });

$G.$tileEvent = function (ev) {
  try {
    if (typeof ev === 'string') ev = JSON.parse(ev);
    const t = $tiles.get(ev.pid);
    if (t && ev.state) t.set('state', ev.state);
  } catch (e) { $reportError(e); }
};

var $holePending = false;
function $holeSoon() {
  if ($holePending) return;
  $holePending = true;
  Promise.resolve().then(() => { $holePending = false; $updateVideoHole(); });
}

var $holeCss = { clip: '', mi: '', ms: '', mp: '' };
function $sendIfChanged(key, msg) {
  const j = JSON.stringify(msg);
  if ($holeSent[key] === j) return;
  $holeSent[key] = j;
  $nativeVideo(msg);
}
function $updateVideoHole() {
  const v = $videoNode;
  const sc = $sceneNode;
  if (!v || !sc) return;
  const k = $stageScale;
  const px = (r) => ({ x: Math.round($stageOff[0] + r[0] * k), y: Math.round($stageOff[1] + r[1] * k), w: Math.round(r[2] * k), h: Math.round(r[3] * k) });
  const holes = [];
  const on = v.isShown();
  const r = v.rect();
  if (on) holes.push(r);
  for (const [pid, t] of $tiles) {
    const shown = t.isShown() && t.get('state') !== 'none';
    const tr = t.absRect();
    if (shown && tr[2] > 0 && tr[3] > 0) holes.push(tr);
    const tp = px(tr);
    $sendIfChanged('t' + pid, { cmd: 'tile', op: 'rect', pid, visible: shown, x: tp.x, y: tp.y, w: tp.w, h: tp.h });
  }
  // solo se toca el estilo si cambio (cada cambio obliga a redibujar toda la pantalla)
  let clip = '', mi = '', ms = '', mp = '';
  if (holes.length === 1) {
    const [x, y, w, h] = holes[0];
    clip = 'polygon(evenodd, 0 0, 1280px 0, 1280px 720px, 0 720px, 0 0, ' + x + 'px ' + y + 'px, ' + x + 'px ' + (y + h) + 'px, ' + (x + w) + 'px ' + (y + h) + 'px, ' + (x + w) + 'px ' + y + 'px, ' + x + 'px ' + y + 'px)';
  } else if (holes.length > 1) {
    // varias ventanas: capas de mascara combinadas con "xor"
    const g = 'linear-gradient(#000,#000)';
    mi = [g].concat(holes.map(() => g)).join(',');
    ms = ['1280px 720px'].concat(holes.map(h => h[2] + 'px ' + h[3] + 'px')).join(',');
    mp = ['0 0'].concat(holes.map(h => h[0] + 'px ' + h[1] + 'px')).join(',');
  }
  const c = $holeCss, st = sc.below.style;
  if (c.clip !== clip || c.mi !== mi || c.ms !== ms || c.mp !== mp) {
    c.clip = clip; c.mi = mi; c.ms = ms; c.mp = mp;
    st.clipPath = clip;
    st.webkitMaskImage = mi; st.webkitMaskSize = ms; st.webkitMaskPosition = mp;
    st.webkitMaskRepeat = mi ? 'no-repeat' : ''; st.webkitMaskComposite = mi ? 'xor' : '';
  }
  const m = px(r);
  $sendIfChanged('main', { cmd: 'rect', visible: on, x: m.x, y: m.y, w: m.w, h: m.h });
}

// ---------------------------------------------------------------
// Fabrica de nodos
// ---------------------------------------------------------------
var $BUILTIN = {
  Node: $NodeBase, ContentNode: $NodeBase, Font: $FontNode,
  Group: $VNode, LayoutGroup: $VNode, Rectangle: $RectNode, Poster: $PosterNode, Label: $LabelNode, ScrollingLabel: $LabelNode,
  Timer: $TimerNode, Animation: $AnimNode, ParallelAnimation: $GroupAnimNode, SequentialAnimation: $GroupAnimNode,
  FloatFieldInterpolator: $InterpNode, Vector2DFieldInterpolator: $InterpNode, ColorFieldInterpolator: $InterpNode,
  Audio: $AudioNode, Video: $VideoNode, VideoTile: $TileNode, Marquee: $MarqueeNode, MarkupList: $ListNode, LabelList: $ListNode, Task: $TaskNode, Scene: $SceneNode
};

var $NUM_FIELDS = new Set(['width', 'height', 'opacity', 'duration', 'delay', 'size', 'numrows', 'numcolumns', 'numlines', 'maxlines', 'loadwidth', 'loadheight', 'linespacing', 'rotation', 'port', 'progress', 'itemfocused', 'jumptoitem', 'starrating', 'playstart', 'textverticaladjustment']);
var $BOOL_FIELDS = new Set(['visible', 'repeat', 'wrap', 'enabletrickplay', 'enableui', 'loop', 'focusable', 'drawfocusfeedback', 'reverse', 'live', 'direct', 'espnok', 'mute', 'loadsync', 'optional']);
function $attrValue(k, v, ftypes) {
  const t = ftypes && ftypes[k];
  if (t) {
    if (t === 'string' || t === 'str' || t === 'uri') return v;
    if (t === 'integer' || t === 'int') return parseInt(v, 10) || 0;
    if (t === 'float' || t === 'time') return parseFloat(v) || 0;
    if (t === 'boolean' || t === 'bool') return String(v).toLowerCase() === 'true';
    if (t === 'array' || t === 'vector2d' || /array$/.test(t)) { try { return JSON.parse(v); } catch (e) { return []; } }
    return v;
  }
  if ($BOOL_FIELDS.has(k)) return String(v).toLowerCase() === 'true';
  if ($NUM_FIELDS.has(k)) return parseFloat(v) || 0;
  if (/^\s*\[.*\]\s*$/s.test(v)) { try { return JSON.parse(v); } catch (e) { return v; } }
  return v;
}
function $buildChildren(parentT, list) {
  for (const c of list) {
    const p = $createNode(c.type);
    const t = p.$t;
    $applyAttrs(t, c.attrs);
    if (c.children && c.children.length) $buildChildren(t, c.children);
    const role = c.attrs.role;
    if (role) parentT.set(role.toLowerCase(), p);
    else parentT.appendChild(p);
  }
}
function $applyAttrs(t, attrs) {
  for (const k in attrs) {
    if (k === 'role') continue;
    const lk = k.toLowerCase();
    t.set(lk, $attrValue(lk, attrs[k], t.ftypes), true);
  }
}

function $instantiate(name) {
  const comp = $COMPONENTS[name];
  const spec = comp.spec;
  const baseName = spec.extends;
  const baseCls = $BUILTIN[baseName] || ($COMPONENTS[baseName] ? null : $VNode);
  let t;
  if ($COMPONENTS[baseName]) t = $instantiate(baseName).$t;
  else t = new baseCls(name);
  t.type = name;
  t.baseType = baseName;
  // campos de interfaz
  if (!t.ftypes) t.ftypes = Object.create(null);
  for (const fd of spec.fields) {
    const k = fd.id.toLowerCase();
    t.ftypes[k] = (fd.type || 'string').toLowerCase();
    if (fd.alwaysNotify === 'true') { if (!t.always) t.always = Object.create(null); t.always[k] = true; }
    if (fd.value !== undefined) t.f[k] = $attrValue(k, fd.value, t.ftypes);
    else if (!(k in t.f) && !(k in t.defaults())) t.f[k] = $fieldDefault(fd.type || 'string');
  }
  // hijos del XML
  $buildChildren(t, spec.children);
  // ambito del script
  const m = $newAA();
  m.top = t.proxy;
  m.global = $globalNode;
  const scope = { m, fns: null, node: t };
  t.scope = scope;
  scope.fns = comp.factory(m);
  for (const fd of spec.fields) {
    if (fd.onChange) t.addObserver(fd.id, fd.onChange, scope, false);
  }
  if (scope.fns.init) $runInScope(scope, () => scope.fns.init());
  return t.proxy;
}

$createNode = function (type) {
  if ($COMPONENTS[type]) return $instantiate(type);
  const Cls = $BUILTIN[type];
  if (!Cls) { console.warn('Tipo de nodo desconocido: ' + type); return new $VNode(type).proxy; }
  return new Cls(type).proxy;
};

// ---------------------------------------------------------------
// Foco y control remoto
// ---------------------------------------------------------------
$G.$sceneSetFocus = function (n, on) {
  const old = $focusedNode;
  if (on) $focusedNode = n;
  else {
    let f = $focusedNode, inside = false;
    while (f) { if (f === n) { inside = true; break; } f = f.parent; }
    if (inside) $focusedNode = null;
  }
  if (old !== $focusedNode) $focusChanged(old, $focusedNode);
};
function $focusChanged(a, b) {
  const seen = new Set();
  for (const start of [a, b]) {
    let p = start;
    while (p) { if (!seen.has(p)) { seen.add(p); if (p.onFocusChange) p.onFocusChange(); } p = p.parent; }
  }
}

function $handleKey(key, press) {
  const start = $focusedNode || $sceneNode;
  if (!start) return false;
  if (start.keyHandler && start.isShown() && start.keyHandler(key, press)) return true;
  let p = start;
  while (p) {
    if (p.scope && p.scope.fns.onkeyevent) {
      const r = $runInScope(p.scope, () => p.scope.fns.onkeyevent(key, press));
      if (r === true) return true;
    }
    p = p.parent;
  }
  return false;
}
$G.$key = function (key, press) {
  const handled = $handleKey(key, press !== false);
  if (!handled && key === 'back' && press !== false) {
    // la escena no uso "atras": se sale de la app (igual que en Roku)
    if ($sceneNode && $sceneNode.get('backexitsscene') !== false) $exitApp();
  }
  return handled;
};
function $exitApp() {
  try { if ($G.Android && $G.Android.exitApp) $G.Android.exitApp(); else console.log('[salir de la app]'); } catch (e) { }
}

// ---------------------------------------------------------------
// Arranque
// ---------------------------------------------------------------
var $stageScale = 1, $stageOff = [0, 0];
// Ajusta la escena de 1280x720 a la pantalla. En Android el tamano real (en pixeles)
// lo da la app nativa: algunos WebView de TV reportan mal window.innerWidth al abrir.
function $fitStage() {
  if (!$stageEl) return;
  const dpr = window.devicePixelRatio || 1;
  let pxW = 0, pxH = 0;
  try {
    if ($G.Android && $G.Android.viewSize) {
      const v = JSON.parse($G.Android.viewSize());
      pxW = v.w; pxH = v.h;
    }
  } catch (e) { }
  if (!(pxW > 0 && pxH > 0)) {
    const de = document.documentElement;
    const cw = (de && de.clientWidth) || window.innerWidth, ch = (de && de.clientHeight) || window.innerHeight;
    pxW = cw * dpr; pxH = ch * dpr;
  }
  const kPx = Math.min(pxW / $STAGE_W, pxH / $STAGE_H);
  const offX = (pxW - $STAGE_W * kPx) / 2, offY = (pxH - $STAGE_H * kPx) / 2;
  $stageScale = kPx;
  $stageOff = [offX, offY];
  $stageEl.style.transform = 'translate(' + (offX / dpr) + 'px,' + (offY / dpr) + 'px) scale(' + (kPx / dpr) + ')';
  $updateVideoHole();
}
$G.$fitStage = $fitStage;

$G.$startApp = function (sceneName) {
  $stageEl = document.getElementById('stage');
  $globalNode = $createNode('Node');
  window.addEventListener('resize', $fitStage);
  const fams = ['Inter-Regular', 'Inter-SemiBold', 'Inter-Bold', 'Inter-ExtraLight'];
  Promise.all(fams.map(f => document.fonts.load('20px "' + f + '"').catch(() => null))).then(() => {
    const p = $createNode(sceneName);
    $sceneNode = p.$t;
    $stageEl.appendChild($sceneNode.el);
    $sceneNode.addObserver('exitrequested', (v) => { if (v === true) $exitApp(); }, null, false);
    $fitStage();
    // por si el WebView termina de acomodarse despues
    setTimeout($fitStage, 300); setTimeout($fitStage, 1500); setTimeout($fitStage, 4000);
    if (!$focusedNode) $G.$sceneSetFocus($sceneNode, true);
    // el codigo de Roku arranca en Main(): crea la escena y la muestra
  });
};
