// roStreamSocket / roSocketAddress para el servidor del QR.
// La app nativa abre el puerto en la red local y entrega cada peticion completa.
'use strict';
var $servers = [];
var $sockIds = 100;
class $SocketAddress {
  constructor() { this.$brsType = 'roSocketAddress'; this.port = 0; this.host = '0.0.0.0'; }
  $setaddress(s) { s = String(s); const i = s.lastIndexOf(':'); if (i < 0) return false; this.host = s.slice(0, i); this.port = Number(s.slice(i + 1)) || 0; return true; }
  $sethostname(h) { this.host = String(h); return true; }
  $gethostname() { return this.host; }
  $setport(p) { this.port = Number(p) || 0; return true; }
  $getport() { return this.port; }
  $getaddress() { return this.host + ':' + this.port; }
  $isaddressvalid() { return this.port > 0; }
}
class $SocketEvent {
  constructor(id) { this.$brsType = 'roSocketEvent'; this.id = id; }
  $getsocketid() { return this.id; }
}
class $StreamSocket {
  constructor() { this.$brsType = 'roStreamSocket'; this.id = $sockIds++; this.port = null; this.addr = null; this.isServer = false; this.pendingAccept = []; this.data = ''; this.out = ''; this.cid = null; this.closed = false; this.notify = false; }
  $setreuseaddr() { return true; }
  $setaddress(a) { this.addr = a; return !!a && a.port > 0; }
  $setsendtoaddress() { return true; }
  $setmessageport(p) { this.port = p; $installSockPoll(p); return true; }
  $notifyreadable(on) { this.notify = !!on; if (on && !this.isServer && this.data.length && this.port) this.port.q.push(new $SocketEvent(this.id)); return true; }
  $notifywritable() { return true; }
  $notifyexception() { return true; }
  $listen() {
    if (!this.addr) return false;
    const r = $xhr('GET', '/sock/listen?port=' + this.addr.port);
    if (r.status !== 200) return false;
    this.isServer = true;
    $servers.push(this);
    return true;
  }
  $getid() { return this.id; }
  $isreadable() { return this.isServer ? this.pendingAccept.length > 0 : this.data.length > 0; }
  $iswritable() { return true; }
  $isexception() { return false; }
  $isconnected() { return !this.closed; }
  $eok() { return true; }
  $eagain() { return false; }
  $status() { return 0; }
  $accept() {
    const c = this.pendingAccept.shift();
    if (!c) return null;
    const s = new $StreamSocket();
    s.cid = c.id;
    s.data = c.data || '';
    return s;
  }
  $receivestr(n) {
    const s = this.data.slice(0, n);
    this.data = this.data.slice(n);
    if (this.data.length && this.port && this.notify) this.port.q.push(new $SocketEvent(this.id));
    return s;
  }
  $receive(ba, start, len) { const s = this.$receivestr(len); const u = new TextEncoder().encode(s); for (let i = 0; i < u.length; i++) ba.$set(start + i, u[i]); return u.length; }
  $sendstr(s) { s = String(s); this.out += s; return s.length; }
  $send(ba, start, len) { this.out += new TextDecoder().decode(ba.a.subarray(start, start + len)); return len; }
  $close() {
    if (this.isServer) { $xhr('GET', '/sock/unlisten'); return true; }
    if (this.cid != null && !this.closed) { this.closed = true; $xhr('POST', '/sock/send?id=' + this.cid, new TextEncoder().encode(this.out)); }
    return true;
  }
}
function $installSockPoll(port) {
  if (port.$poll) return;
  port.$poll = function (ms) {
    const r = $xhr('GET', '/sock/poll?ms=' + (ms > 0 ? ms : 1000));
    if (r.status === 200 && r.text) {
      let d;
      try { d = JSON.parse(r.text); } catch (e) { return null; }
      const srv = $servers[$servers.length - 1];
      if (!srv) return null;
      srv.pendingAccept.push(d);
      return new $SocketEvent(srv.id);
    }
    return null;
  };
}
$G.$createSocket = function (kind) {
  kind = String(kind).toLowerCase();
  if (kind === 'rosocketaddress') return new $SocketAddress();
  return new $StreamSocket();
};
