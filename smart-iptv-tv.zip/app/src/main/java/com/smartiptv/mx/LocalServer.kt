package com.smartiptv.mx

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URL
import java.net.URLDecoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.GZIPInputStream
import java.util.zip.InflaterInputStream

/**
 * Servidor HTTP dentro de la app (solo 127.0.0.1). Hace lo que en Roku hace el sistema:
 *  - entrega la interfaz (assets/web)
 *  - /net   descarga listas, guias, clima, etc. (como roUrlTransfer, sin limites de CORS)
 *  - /fs    archivos tmp:/ y cachefs:/ (como roFileSystem)
 *  - /reg   registro de la app (como roRegistrySection)
 *  - /sock  servidor para el celular (QR), abierto en la red local
 */
class LocalServer(private val ctx: Context, private val prefs: SharedPreferences) {

    @Volatile
    private var running = false
    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()
    var port = 0
        private set

    private val tmpDir = File(ctx.cacheDir, "tmp")
    private val cacheFsDir = File(ctx.filesDir, "cachefs")

    fun start(): Boolean {
        tmpDir.deleteRecursively()
        tmpDir.mkdirs()
        cacheFsDir.mkdirs()
        val loop = InetAddress.getByName("127.0.0.1")
        for (p in intArrayOf(8780, 8781, 8782, 0)) {
            try {
                val s = ServerSocket()
                s.reuseAddress = true
                s.bind(InetSocketAddress(loop, p), 64)
                server = s
                port = s.localPort
                break
            } catch (e: Exception) {
                server = null
            }
        }
        val s = server ?: return false
        running = true
        Thread({
            while (running) {
                try {
                    val c = s.accept()
                    pool.execute { handle(c) }
                } catch (e: Exception) {
                    if (!running) break
                }
            }
        }, "local-server").start()
        return true
    }

    fun stop() {
        running = false
        try {
            server?.close()
        } catch (e: Exception) {
        }
        lanClose()
        pool.shutdownNow()
    }

    // ------------------------------------------------------------------
    // HTTP
    // ------------------------------------------------------------------
    private class Req(val method: String, val path: String, val query: Map<String, String>, val body: ByteArray)

    private fun handle(c: Socket) {
        try {
            c.soTimeout = 120000
            val input = BufferedInputStream(c.getInputStream())
            val out = c.getOutputStream()
            val req = readRequest(input) ?: return
            route(req, out)
            out.flush()
        } catch (e: Exception) {
        } finally {
            try {
                c.close()
            } catch (e: Exception) {
            }
        }
    }

    private fun readRequest(input: InputStream): Req? {
        val line = readLine(input) ?: return null
        val parts = line.split(" ")
        if (parts.size < 2) return null
        var len = 0
        while (true) {
            val h = readLine(input) ?: break
            if (h.isEmpty()) break
            val i = h.indexOf(':')
            if (i > 0 && h.substring(0, i).trim().equals("content-length", true)) {
                len = h.substring(i + 1).trim().toIntOrNull() ?: 0
            }
        }
        val body = ByteArray(len)
        var read = 0
        while (read < len) {
            val n = input.read(body, read, len - read)
            if (n < 0) break
            read += n
        }
        val target = parts[1]
        val q = target.indexOf('?')
        val path = if (q >= 0) target.substring(0, q) else target
        val query = HashMap<String, String>()
        if (q >= 0) {
            for (pair in target.substring(q + 1).split("&")) {
                if (pair.isEmpty()) continue
                val eq = pair.indexOf('=')
                val k = dec(if (eq >= 0) pair.substring(0, eq) else pair)
                val v = if (eq >= 0) dec(pair.substring(eq + 1)) else ""
                query[k] = v
            }
        }
        return Req(parts[0].uppercase(), dec(path), query, body)
    }

    private fun dec(s: String): String = try {
        URLDecoder.decode(s, "UTF-8")
    } catch (e: Exception) {
        s
    }

    private fun readLine(i: InputStream): String? {
        val sb = ByteArrayOutputStream()
        while (true) {
            val b = i.read()
            if (b < 0) return if (sb.size() == 0) null else sb.toString("UTF-8")
            if (b == 10) break
            if (b != 13) sb.write(b)
        }
        return sb.toString("UTF-8")
    }

    private fun head(out: OutputStream, code: Int, type: String, len: Long, extra: Map<String, String> = emptyMap()) {
        val sb = StringBuilder()
        sb.append("HTTP/1.1 ").append(code).append(if (code == 200) " OK" else " ERR").append("\r\n")
        sb.append("Content-Type: ").append(type).append("\r\n")
        if (len >= 0) sb.append("Content-Length: ").append(len).append("\r\n")
        sb.append(if (extra.containsKey("X-Cache")) "Cache-Control: max-age=86400\r\n" else "Cache-Control: no-store\r\n")
        sb.append("Access-Control-Allow-Origin: *\r\n")
        for ((k, v) in extra) sb.append(k).append(": ").append(v).append("\r\n")
        sb.append("Connection: close\r\n\r\n")
        out.write(sb.toString().toByteArray(Charsets.UTF_8))
    }

    private fun send(out: OutputStream, code: Int, body: ByteArray, type: String = "text/plain; charset=utf-8", extra: Map<String, String> = emptyMap()) {
        head(out, code, type, body.size.toLong(), extra)
        out.write(body)
    }

    private fun send(out: OutputStream, code: Int, text: String) = send(out, code, text.toByteArray(Charsets.UTF_8))

    private fun route(r: Req, out: OutputStream) {
        val p = r.path
        when {
            p == "/net" -> net(r, out)
            p.startsWith("/net/") -> netJobs(r, out)
            p.startsWith("/fs/") -> fs(r, out)
            p == "/reg/all" -> send(out, 200, prefs.getString("registry", "{}") ?: "{}")
            p == "/reg/save" -> {
                prefs.edit().putString("registry", String(r.body, Charsets.UTF_8)).apply()
                send(out, 200, "ok")
            }
            p == "/device" -> send(out, 200, DeviceInfo.json(ctx).toByteArray(Charsets.UTF_8), "application/json")
            p == "/sleep" -> {
                val ms = (r.query["ms"]?.toLongOrNull() ?: 0L).coerceIn(0L, 5000L)
                Thread.sleep(ms)
                send(out, 200, "")
            }
            p.startsWith("/sock/") -> sock(r, out)
            else -> asset(p, out)
        }
    }

    // ------------------------------------------------------------------
    // Archivos de la interfaz
    // ------------------------------------------------------------------
    private fun asset(path: String, out: OutputStream) {
        var p = path.trimStart('/')
        if (p.isEmpty()) p = "index.html"
        if (p.contains("..")) {
            send(out, 404, "no")
            return
        }
        try {
            val bytes = ctx.assets.open("web/$p").use { it.readBytes() }
            send(out, 200, bytes, mime(p), mapOf("X-Cache" to "1"))
        } catch (e: Exception) {
            send(out, 404, "no existe")
        }
    }

    private fun mime(p: String): String {
        val l = p.lowercase()
        return when {
            l.endsWith(".html") -> "text/html; charset=utf-8"
            l.endsWith(".js") -> "application/javascript; charset=utf-8"
            l.endsWith(".css") -> "text/css; charset=utf-8"
            l.endsWith(".png") -> "image/png"
            l.endsWith(".jpg") || l.endsWith(".jpeg") -> "image/jpeg"
            l.endsWith(".ttf") -> "font/ttf"
            l.endsWith(".mp3") -> "audio/mpeg"
            l.endsWith(".json") -> "application/json"
            l.endsWith(".svg") -> "image/svg+xml"
            else -> "application/octet-stream"
        }
    }

    // ------------------------------------------------------------------
    // Red (equivalente a roUrlTransfer)
    // ------------------------------------------------------------------
    private fun headersOf(q: Map<String, String>): Map<String, String> {
        val headers = HashMap<String, String>()
        try {
            val h = q["h"]
            if (!h.isNullOrEmpty()) {
                val o = JSONObject(h)
                for (k in o.keys()) headers[k] = o.getString(k)
            }
        } catch (e: Exception) {
        }
        return headers
    }

    private fun net(r: Req, out: OutputStream) {
        val url = r.query["u"] ?: ""
        val to = r.query["to"]
        val method = r.query["m"] ?: if (r.method == "POST") "POST" else "GET"
        var conn: HttpURLConnection? = null
        try {
            conn = open(url, headersOf(r.query), method, if (r.method == "POST") r.body else null)
            val code = conn.responseCode
            val stream: InputStream? = try {
                if (code >= 400) conn.errorStream else conn.inputStream
            } catch (e: Exception) {
                conn.errorStream
            }
            val body = decode(stream, conn.contentEncoding)
            if (to != null) {
                val f = vfs(to)
                if (f == null) {
                    send(out, 200, ByteArray(0), extra = mapOf("X-Net-Status" to "-1"))
                    return
                }
                if (code in 200..299 && body != null) {
                    f.parentFile?.mkdirs()
                    FileOutputStream(f).use { fo -> body.copyTo(fo, 65536) }
                } else body?.close()
                send(out, 200, ByteArray(0), extra = mapOf("X-Net-Status" to code.toString()))
            } else {
                head(out, 200, "text/plain; charset=utf-8", -1, mapOf("X-Net-Status" to code.toString()))
                body?.use { it.copyTo(out, 65536) }
            }
        } catch (e: Exception) {
            try {
                send(out, 200, ByteArray(0), extra = mapOf("X-Net-Status" to "-1"))
            } catch (e2: Exception) {
            }
        } finally {
            conn?.disconnect()
        }
    }

    // Descargas en segundo plano (AsyncGetToString / AsyncGetToFile de Roku): varias a la vez
    private class Job {
        @Volatile
        var done = false
        var status = 0
        var body: ByteArray? = null
        var task: java.util.concurrent.Future<*>? = null
    }

    private val jobs = ConcurrentHashMap<String, Job>()
    private val jobSeq = AtomicInteger(1)
    private val jobLock = Object()

    private fun jobRun(q: Map<String, String>, postBody: ByteArray?, job: Job) {
        var conn: HttpURLConnection? = null
        try {
            val method = q["m"] ?: if (postBody != null) "POST" else "GET"
            conn = open(q["u"] ?: "", headersOf(q), method, postBody)
            val code = conn.responseCode
            val stream: InputStream? = try {
                if (code >= 400) conn.errorStream else conn.inputStream
            } catch (e: Exception) {
                conn.errorStream
            }
            val body = decode(stream, conn.contentEncoding)
            val to = q["to"]
            if (to != null) {
                val f = vfs(to)
                if (f != null && code in 200..299 && body != null) {
                    f.parentFile?.mkdirs()
                    FileOutputStream(f).use { fo -> body.copyTo(fo, 65536) }
                } else body?.close()
            } else {
                job.body = body?.use { it.readBytes() }
            }
            job.status = code
        } catch (e: Exception) {
            job.status = -1
        } finally {
            conn?.disconnect()
            job.done = true
            synchronized(jobLock) { jobLock.notifyAll() }
        }
    }

    private fun netJobs(r: Req, out: OutputStream) {
        when (r.path) {
            "/net/start" -> {
                val id = jobSeq.getAndIncrement().toString()
                val job = Job()
                jobs[id] = job
                val q = HashMap(r.query)
                val body = if (r.method == "POST") r.body else null
                job.task = pool.submit { jobRun(q, body, job) }
                send(out, 200, id)
            }
            "/net/wait" -> {
                val ids = (r.query["ids"] ?: "").split(",").filter { it.isNotEmpty() }
                val ms = (r.query["ms"]?.toLongOrNull() ?: 1000L).coerceIn(1L, 600000L)
                val end = System.currentTimeMillis() + ms
                var found: String? = null
                synchronized(jobLock) {
                    while (true) {
                        found = ids.firstOrNull { jobs[it]?.done == true }
                        if (found != null) break
                        val left = end - System.currentTimeMillis()
                        if (left <= 0) break
                        jobLock.wait(minOf(left, 250L))
                    }
                }
                val id = found
                if (id == null) send(out, 200, "")
                else send(out, 200, "{\"id\":\"" + id + "\",\"status\":" + (jobs[id]?.status ?: -1) + "}")
            }
            "/net/result" -> {
                val job = jobs.remove(r.query["id"] ?: "")
                send(out, 200, job?.body ?: ByteArray(0))
            }
            "/net/cancel" -> {
                val job = jobs.remove(r.query["id"] ?: "")
                job?.task?.cancel(true)
                send(out, 200, "ok")
            }
            else -> send(out, 404, "")
        }
    }

    private fun decode(s: InputStream?, enc: String?): InputStream? {
        if (s == null) return null
        return when (enc?.lowercase()) {
            "gzip" -> GZIPInputStream(s, 65536)
            "deflate" -> InflaterInputStream(s)
            else -> s
        }
    }

    /** Abre la conexion siguiendo redirecciones (tambien de http a https y al reves). */
    private fun open(start: String, headers: Map<String, String>, method: String, body: ByteArray?): HttpURLConnection {
        var url = start
        var hops = 0
        while (true) {
            val c = URL(url).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 15000
            c.readTimeout = 180000
            c.requestMethod = method
            c.setRequestProperty("User-Agent", USER_AGENT)
            c.setRequestProperty("Accept-Encoding", "gzip, deflate")
            c.setRequestProperty("Accept", "*/*")
            for ((k, v) in headers) c.setRequestProperty(k, v)
            if (body != null && method != "GET") {
                c.doOutput = true
                c.outputStream.use { it.write(body) }
            }
            val code = c.responseCode
            if (code in 300..399 && hops < 8) {
                val loc = c.getHeaderField("Location")
                if (loc != null) {
                    url = URL(URL(url), loc).toString()
                    c.disconnect()
                    hops++
                    continue
                }
            }
            return c
        }
    }

    // ------------------------------------------------------------------
    // Archivos tmp:/ y cachefs:/
    // ------------------------------------------------------------------
    private fun vfs(p: String?): File? {
        if (p == null) return null
        val m = Regex("^(tmp|cachefs):/?(.*)$").find(p) ?: return null
        val name = m.groupValues[2].replace(Regex("[^A-Za-z0-9._\\-]"), "_")
        if (name.isEmpty()) return null
        return File(if (m.groupValues[1] == "tmp") tmpDir else cacheFsDir, name)
    }

    private fun fs(r: Req, out: OutputStream) {
        val f = vfs(r.query["p"])
        if (f == null) {
            send(out, 400, "ruta no valida")
            return
        }
        when (r.path) {
            "/fs/read", "/fs/raw" -> {
                if (!f.exists()) {
                    send(out, 404, "")
                    return
                }
                val size = f.length()
                val off = (r.query["o"]?.toLongOrNull() ?: 0L).coerceAtLeast(0L)
                var n = r.query["n"]?.toLongOrNull() ?: -1L
                if (n < 0 || off + n > size) n = (size - off).coerceAtLeast(0L)
                val type = if (r.path == "/fs/raw") mime(f.name) else "application/octet-stream"
                head(out, 200, type, n)
                RandomAccessFile(f, "r").use { raf ->
                    raf.seek(off)
                    val buf = ByteArray(65536)
                    var left = n
                    while (left > 0) {
                        val k = raf.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (k < 0) break
                        out.write(buf, 0, k)
                        left -= k
                    }
                }
            }
            "/fs/write" -> {
                f.parentFile?.mkdirs()
                FileOutputStream(f, r.query["a"] != null).use { it.write(r.body) }
                send(out, 200, "ok")
            }
            "/fs/stat" -> if (f.exists()) send(out, 200, "{\"size\":" + f.length() + "}") else send(out, 404, "")
            "/fs/delete" -> if (f.exists() && f.delete()) send(out, 200, "ok") else send(out, 404, "")
            "/fs/list" -> send(out, 200, "[]")
            "/fs/gunzip" -> {
                val o = vfs(r.query["o"])
                if (o == null || !f.exists()) {
                    send(out, 500, "no se pudo descomprimir la guia .gz")
                    return
                }
                try {
                    GZIPInputStream(FileInputStream(f), 65536).use { gin ->
                        FileOutputStream(o).use { fo -> gin.copyTo(fo, 65536) }
                    }
                    send(out, 200, "ok")
                } catch (e: Exception) {
                    o.delete()
                    send(out, 500, "no se pudo descomprimir la guia .gz")
                }
            }
            else -> send(out, 404, "")
        }
    }

    // ------------------------------------------------------------------
    // Servidor para el celular (red local). La logica de las paginas es la del
    // canal de Roku (qrserver.brs), que corre en la interfaz y responde aqui.
    // ------------------------------------------------------------------
    private var lan: ServerSocket? = null
    private var lanPort = 0
    private val lanQueue = LinkedBlockingQueue<JSONObject>()
    private val lanConns = ConcurrentHashMap<Int, Socket>()
    private val lanIds = AtomicInteger(1)

    @Synchronized
    private fun lanListen(p: Int): Boolean {
        if (lan != null && lanPort == p && !lan!!.isClosed) return true
        lanClose()
        return try {
            val s = ServerSocket()
            s.reuseAddress = true
            s.bind(InetSocketAddress(p), 16)
            lan = s
            lanPort = p
            Thread({ lanLoop(s) }, "qr-server").start()
            true
        } catch (e: Exception) {
            false
        }
    }

    @Synchronized
    private fun lanClose() {
        try {
            lan?.close()
        } catch (e: Exception) {
        }
        lan = null
        lanPort = 0
    }

    private fun lanLoop(s: ServerSocket) {
        while (!s.isClosed) {
            val c = try {
                s.accept()
            } catch (e: Exception) {
                break
            }
            pool.execute {
                try {
                    c.soTimeout = 15000
                    val input = c.getInputStream()
                    val buf = ByteArrayOutputStream()
                    val tmp = ByteArray(4096)
                    while (buf.size() < 40000) {
                        val n = input.read(tmp)
                        if (n < 0) break
                        buf.write(tmp, 0, n)
                        val str = buf.toString("ISO-8859-1")
                        if (str.contains("\r\n\r\n")) break
                    }
                    val id = lanIds.getAndIncrement()
                    lanConns[id] = c
                    val o = JSONObject()
                    o.put("id", id)
                    o.put("data", buf.toString("UTF-8"))
                    lanQueue.put(o)
                    // si nadie responde en 20 s se cierra
                    pool.execute {
                        try {
                            Thread.sleep(20000)
                            lanConns.remove(id)?.close()
                        } catch (e: Exception) {
                        }
                    }
                } catch (e: Exception) {
                    try {
                        c.close()
                    } catch (e2: Exception) {
                    }
                }
            }
        }
    }

    private fun sock(r: Req, out: OutputStream) {
        when (r.path) {
            "/sock/listen" -> {
                val p = r.query["port"]?.toIntOrNull() ?: 0
                if (p > 0 && lanListen(p)) send(out, 200, "ok") else send(out, 500, "ocupado")
            }
            "/sock/unlisten" -> {
                lanClose()
                send(out, 200, "ok")
            }
            "/sock/poll" -> {
                val ms = (r.query["ms"]?.toLongOrNull() ?: 1000L).coerceIn(10L, 5000L)
                val item = lanQueue.poll(ms, TimeUnit.MILLISECONDS)
                if (item == null) {
                    send(out, 200, "")
                    return
                }
                try {
                    send(out, 200, item.toString())
                } catch (e: Exception) {
                    lanQueue.put(item) // la interfaz ya no escuchaba: se guarda para la siguiente
                }
            }
            "/sock/send" -> {
                val id = r.query["id"]?.toIntOrNull() ?: 0
                val c = lanConns.remove(id)
                if (c != null) {
                    try {
                        c.getOutputStream().write(r.body)
                        c.getOutputStream().flush()
                    } catch (e: Exception) {
                    }
                    try {
                        c.close()
                    } catch (e: Exception) {
                    }
                }
                send(out, 200, "ok")
            }
            else -> send(out, 404, "")
        }
    }

    companion object {
        /** Igual que el de Roku: algunos servidores IPTV solo aceptan reproductores conocidos. */
        const val USER_AGENT = "Roku/DVP-14.0 (14.0.0.4130-46)"
    }
}
