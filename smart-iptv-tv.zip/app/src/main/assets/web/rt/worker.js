// Runtime BrightScript compartido (pantalla principal y tareas en segundo plano).
/* eslint-disable no-unused-vars */
'use strict';

var $G = (typeof self !== 'undefined') ? self : globalThis;
var $IS_WORKER = (typeof WorkerGlobalScope !== 'undefined') && (self instanceof WorkerGlobalScope);

// ---------------------------------------------------------------
// Arreglos asociativos (roAssociativeArray): claves sin distinguir mayusculas
// ---------------------------------------------------------------
var $AAP = Object.create(null);
function $defm(proto, name, fn) {
  Object.defineProperty(proto, name, { value: fn, enumerable: false, writable: true, configurable: true });
}
function $isAA(o) { return o !== null && typeof o === 'object' && Object.getPrototypeOf(o) === $AAP; }
function $newAA(src) {
  const o = Object.create($AAP);
  if (src) for (const k in src) o[k] = src[k];
  return o;
}
function $akey(o, k) { return (typeof k === 'string' && !o.$cs) ? k.toLowerCase() : k; }
$defm($AAP, '$count', function () { let n = 0; for (const k in this) n++; return n; });
$defm($AAP, '$doesexist', function (k) { return $akey(this, k) in this; });
$defm($AAP, '$delete', function (k) { k = $akey(this, k); const had = k in this; delete this[k]; return had; });
$defm($AAP, '$keys', function () { return Object.keys(this).sort(); });
$defm($AAP, '$items', function () { return Object.keys(this).sort().map(k => $newAA({ key: k, value: this[k] })); });
$defm($AAP, '$lookup', function (k) { return this[$akey(this, k)]; });
$defm($AAP, '$lookupci', function (k) { return this[$akey(this, k)]; });
$defm($AAP, '$addreplace', function (k, v) { this[$akey(this, k)] = v; });
$defm($AAP, '$append', function (o) { if (o) for (const k in o) this[k] = o[k]; });
$defm($AAP, '$clear', function () { for (const k in this) delete this[k]; });
$defm($AAP, '$isempty', function () { for (const k in this) return false; return true; });
$defm($AAP, '$setmodecasesensitive', function () { Object.defineProperty(this, '$cs', { value: true, enumerable: false }); });
$defm($AAP, '$ifassociativearray', function () { return this; });
$defm($AAP, '$isnext', function () { return false; });
$defm($AAP, 'toString', function () { return '<Component: roAssociativeArray>'; });

// Convierte objetos planos (JSON, mensajes entre hilos) a AA de forma recursiva
function $hydrate(v, lower) {
  if (v === null || typeof v !== 'object') return v;
  if (Array.isArray(v)) { for (let i = 0; i < v.length; i++) v[i] = $hydrate(v[i], lower); return v; }
  if (v.__node) return $Node.fromWire(v);
  if (v instanceof Uint8Array || v instanceof ArrayBuffer) return v;
  const o = Object.create($AAP);
  for (const k in v) o[lower ? k.toLowerCase() : k] = $hydrate(v[k], lower);
  return o;
}

// ---------------------------------------------------------------
// Acceso con indice: a[i], aa["clave"], nodo["campo"]
// ---------------------------------------------------------------
function $ix(o, k) {
  if (typeof k === 'string') {
    if (o == null) throw new TypeError('indice sobre invalid: ' + k);
    if (!o.$cs) k = k.toLowerCase();
    return o[k];
  }
  if (o instanceof $ByteArray) return o.a[k];
  if (typeof k === 'number' && Array.isArray(o)) return o[k];
  return o[k];
}
function $six(o, k, v) {
  if (typeof k === 'string' && !o.$cs) k = k.toLowerCase();
  if (o instanceof $ByteArray) { o.$set(k, v); return; }
  o[k] = v;
}
function $iter(o) {
  if (o == null) return [];
  if (Array.isArray(o)) return o.slice();
  if (o instanceof $ByteArray) return Array.from(o.a.subarray(0, o.n));
  if ($isAA(o)) return Object.keys(o);
  if (o.$isnode) return o.$getchildren(-1, 0);
  if (typeof o === 'string') return [o];
  if (o.$iterate) return o.$iterate();
  return Object.keys(o);
}
function $callv(f, args) {
  if (typeof f !== 'function') throw new TypeError('no es una funcion');
  return f.apply(null, args);
}
function $idiv(a, b) { return Math.trunc(a / b); }
function $and(a, b) { return (typeof a === 'number' && typeof b === 'number') ? (a & b) : (a && b); }
function $or(a, b) { return (typeof a === 'number' && typeof b === 'number') ? (a | b) : (a || b); }
function $not(a) { return typeof a === 'number' ? ~a : !a; }
function $err(v) { if (v instanceof Error) return v; const e = new Error(typeof v === 'string' ? v : (v && v.message) || 'error'); return e; }
function $dim() {
  const dims = Array.from(arguments);
  const mk = (d) => { const a = []; if (d < dims.length - 1) for (let i = 0; i <= dims[d]; i++) a.push(mk(d + 1)); return a; };
  return mk(0);
}
function $attr(o, a) { return o && o.$getattributes ? o.$getattributes()[a] : undefined; }

// ---------------------------------------------------------------
// Metodos de String / Number / Boolean / Array
// ---------------------------------------------------------------
const SP = String.prototype, NP = Number.prototype, BP = Boolean.prototype, AP = Array.prototype;
$defm(SP, '$len', function () { return this.length; });
$defm(SP, '$tostr', function () { return String(this); });
$defm(SP, '$getstring', function () { return String(this); });
$defm(SP, '$trim', function () { return this.replace(/^[\s\u0000- ]+|[\s\u0000- ]+$/g, ''); });
$defm(SP, '$replace', function (a, b) { if (a === '') return String(this); return this.split(a).join(b); });
$defm(SP, '$split', function (sep) {
  const s = String(this);
  if (s === '') return [];
  if (sep === '') return Array.from(s);
  return s.split(sep);
});
$defm(SP, '$tokenize', function (delims) {
  const out = []; let cur = '';
  for (const ch of String(this)) { if (delims.indexOf(ch) >= 0) { if (cur !== '') out.push(cur); cur = ''; } else cur += ch; }
  if (cur !== '') out.push(cur);
  return out;
});
$defm(SP, '$instr', function (a, b) {
  if (b === undefined) return this.indexOf(a);
  return this.indexOf(b, a);
});
$defm(SP, '$left', function (n) { return n <= 0 ? '' : this.substr(0, n); });
$defm(SP, '$right', function (n) { return n <= 0 ? '' : this.substr(Math.max(0, this.length - n)); });
$defm(SP, '$mid', function (s, n) { if (s < 0) s = 0; return n === undefined ? this.substr(s) : (n <= 0 ? '' : this.substr(s, n)); });
$defm(SP, '$lcase', function () { return this.toLowerCase(); });
$defm(SP, '$ucase', function () { return this.toUpperCase(); });
$defm(SP, '$toint', function () { const v = parseInt(this, 10); return isNaN(v) ? 0 : v; });
$defm(SP, '$tofloat', function () { const v = parseFloat(this); return isNaN(v) ? 0 : v; });
$defm(SP, '$startswith', function (s, p) { return this.startsWith(s, p || 0); });
$defm(SP, '$endswith', function (s) { return this.endsWith(s); });
$defm(SP, '$isempty', function () { return this.length === 0; });
$defm(SP, '$escape', function () { return $urlEscape(String(this)); });
$defm(SP, '$encodeuri', function () { return encodeURI(String(this)); });
$defm(SP, '$encodeuricomponent', function () { return encodeURIComponent(String(this)); });
$defm(SP, '$decodeuri', function () { try { return decodeURI(String(this)); } catch (e) { return String(this); } });
$defm(SP, '$decodeuricomponent', function () { try { return decodeURIComponent(String(this)); } catch (e) { return String(this); } });
$defm(SP, '$unescape', function () { try { return decodeURIComponent(String(this).replace(/\+/g, ' ')); } catch (e) { return String(this); } });
$defm(SP, '$getentityencode', function () { return String(this).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;'); });
$defm(SP, '$ifstring', function () { return this; });
$defm(SP, '$arg', function () { return String(this); });
$defm(NP, '$tostr', function (fmt) {
  if (fmt) return $sprintf(fmt, Number(this));
  return $numStr(Number(this));
});
$defm(NP, '$getint', function () { return Math.trunc(this); });
$defm(BP, '$tostr', function () { return this.valueOf() ? 'true' : 'false'; });
$defm(AP, '$count', function () { return this.length; });
$defm(AP, '$push', function (v) { this.push(v); });
$defm(AP, '$pop', function () { return this.length ? this.pop() : null; });
$defm(AP, '$shift', function () { return this.length ? this.shift() : null; });
$defm(AP, '$unshift', function (v) { this.unshift(v); });
$defm(AP, '$peek', function () { return this.length ? this[this.length - 1] : null; });
$defm(AP, '$delete', function (i) { if (i < 0 || i >= this.length) return false; this.splice(i, 1); return true; });
$defm(AP, '$clear', function () { this.length = 0; });
$defm(AP, '$append', function (o) { if (o) for (const v of o) this.push(v); });
$defm(AP, '$isempty', function () { return this.length === 0; });
$defm(AP, '$getentry', function (i) { return this[i]; });
$defm(AP, '$setentry', function (i, v) { this[i] = v; });
$defm(AP, '$join', function (s) { return this.join(s); });
$defm(AP, '$reverse', function () { this.reverse(); });
$defm(AP, '$addtail', function (v) { this.push(v); });
$defm(AP, '$addhead', function (v) { this.unshift(v); });
$defm(AP, '$removehead', function () { return this.length ? this.shift() : null; });
$defm(AP, '$removetail', function () { return this.length ? this.pop() : null; });
$defm(AP, '$gethead', function () { return this.length ? this[0] : null; });
$defm(AP, '$gettail', function () { return this.length ? this[this.length - 1] : null; });
$defm(AP, '$slice', function (a, b) { return this.slice(a, b); });
function $cmpBrs(a, b, ci) {
  const ta = typeof a, tb = typeof b;
  const rank = (t) => t === 'number' ? 0 : (t === 'string' ? 1 : 2);
  if (rank(ta) !== rank(tb)) return rank(ta) - rank(tb);
  if (ta === 'string') {
    if (ci) { a = a.toLowerCase(); b = b.toLowerCase(); }
    return a < b ? -1 : (a > b ? 1 : 0);
  }
  if (ta === 'number') return a - b;
  return 0;
}
$defm(AP, '$sort', function (flags) {
  flags = (flags || '').toLowerCase();
  const ci = flags.indexOf('i') >= 0, rev = flags.indexOf('r') >= 0;
  const idx = this.map((v, i) => [v, i]);
  idx.sort((x, y) => $cmpBrs(x[0], y[0], ci) || (x[1] - y[1]));
  for (let i = 0; i < idx.length; i++) this[i] = idx[i][0];
  if (rev) this.reverse();
});
$defm(AP, '$sortby', function (field, flags) {
  flags = (flags || '').toLowerCase();
  const ci = flags.indexOf('i') >= 0, rev = flags.indexOf('r') >= 0;
  field = String(field).toLowerCase();
  const get = (o) => (o != null && typeof o === 'object') ? o[field] : undefined;
  const idx = this.map((v, i) => [v, i, get(v)]);
  idx.sort((x, y) => {
    const ax = x[2], ay = y[2];
    if (ax === undefined && ay !== undefined) return 1;
    if (ay === undefined && ax !== undefined) return -1;
    return $cmpBrs(ax, ay, ci) || (x[1] - y[1]);
  });
  for (let i = 0; i < idx.length; i++) this[i] = idx[i][0];
  if (rev) this.reverse();
});
$defm(AP, '$ifarray', function () { return this; });

function $numStr(n) {
  if (Number.isInteger(n)) return String(n);
  if (!isFinite(n)) return n > 0 ? 'inf' : (n < 0 ? '-inf' : 'nan');
  // BrightScript Float: ~7 cifras significativas
  let s = String(parseFloat(n.toPrecision(7)));
  if (s.indexOf('e') >= 0) s = n.toPrecision(7);
  return s;
}
function $sprintf(fmt, v) {
  return fmt.replace(/%(0?)(\d*)(?:\.(\d+))?([dfsxX])/g, (all, z, w, p, t) => {
    let s;
    if (t === 'd') s = String(Math.trunc(v));
    else if (t === 'f') s = Number(v).toFixed(p === undefined ? 6 : Number(p));
    else if (t === 'x') s = (v >>> 0).toString(16);
    else if (t === 'X') s = (v >>> 0).toString(16).toUpperCase();
    else s = String(v);
    const width = Number(w || 0);
    while (s.length < width) s = (z ? '0' : ' ') + s;
    return s;
  });
}

// ---------------------------------------------------------------
// Funciones globales
// ---------------------------------------------------------------
function $len(s) { return s == null ? 0 : String(s).length; }
function $left(s, n) { return n <= 0 ? '' : String(s).substr(0, n); }
function $right(s, n) { s = String(s); return n <= 0 ? '' : s.substr(Math.max(0, s.length - n)); }
function $mid(s, start, n) {
  s = String(s);
  let st = start - 1;
  if (st < 0) st = 0;
  if (n === undefined) return s.substr(st);
  if (n <= 0) return '';
  return s.substr(st, n);
}
function $instr(start, s, sub) {
  if (sub === undefined) { sub = s; s = start; start = 1; }
  if (s == null) return 0;
  s = String(s);
  if (start < 1) start = 1;
  if (sub === '') return start <= s.length + 1 ? start : 0;
  return s.indexOf(sub, start - 1) + 1;
}
function $lcase(s) { return String(s).toLowerCase(); }
function $ucase(s) { return String(s).toUpperCase(); }
function $str(n) { const s = $numStr(n); return n >= 0 ? ' ' + s : s; }
function $stri(n, radix) { return radix ? Math.trunc(n).toString(radix) : String(Math.trunc(n)); }
function $val(s, radix) {
  if (s == null) return 0;
  s = String(s).trim();
  if (radix) { const v = parseInt(s, radix); return isNaN(v) ? 0 : v; }
  if (/^&h/i.test(s)) return parseInt(s.slice(2), 16) || 0;
  const m = /^[+\-]?(\d+\.?\d*|\.\d+)([eE][+\-]?\d+)?/.exec(s);
  return m ? Number(m[0]) : 0;
}
function $strtoi(s, radix) { const v = parseInt(String(s).trim(), radix || 10); return isNaN(v) ? 0 : v; }
function $int(x) { return Math.floor(x); }
function $fix(x) { return Math.trunc(x); }
function $cint(x) { return Math.round(x); }
function $cdbl(x) { return Number(x); }
function $csng(x) { return Number(x); }
function $abs(x) { return Math.abs(x); }
function $sqr(x) { return Math.sqrt(x); }
function $exp(x) { return Math.exp(x); }
function $log(x) { return Math.log(x); }
function $atn(x) { return Math.atan(x); }
function $cos(x) { return Math.cos(x); }
function $sin(x) { return Math.sin(x); }
function $tan(x) { return Math.tan(x); }
function $sgn(x) { return x > 0 ? 1 : (x < 0 ? -1 : 0); }
function $rnd(n) { if (!n) return Math.random(); return 1 + Math.floor(Math.random() * n); }
function $chr(c) { return String.fromCodePoint(c); }
function $asc(s) { s = String(s); if (s === '') return 0; return s.codePointAt(0); }
function $string(n, ch) { if (typeof ch === 'number') ch = String.fromCharCode(ch); return n > 0 ? ch.charAt(0).repeat(n) : ''; }
function $stringi(n, c) { return $string(n, String.fromCharCode(c)); }
function $substitute(fmt) { const a = Array.from(arguments).slice(1); return String(fmt).replace(/\{(\d)\}/g, (x, i) => a[i] == null ? '' : String(a[i])); }
function $tr(s) { return s; }
function $box(v) { return v; }
function $isvalid(v) { return v != null; }
function $rungarbagecollector() { return $newAA(); }
function $getglobalaa() { return $G.$curM || $newAA(); }
function $getinterface(o, name) { return o; }
function $sleep(ms) { const end = Date.now() + ms; if ($IS_WORKER) { try { const x = new XMLHttpRequest(); x.open('GET', $SRV + '/sleep?ms=' + ms, false); x.send(); } catch (e) { } } while (Date.now() < end) { /* espera */ } }
var $T0 = Date.now();
function $uptime() { return (Date.now() - $T0) / 1000; }

function $type(v, ver) {
  if (v === undefined) return ver === 3 ? '<uninitialized>' : 'Invalid';
  if (v === null) return ver === 3 ? 'Invalid' : 'roInvalid';
  if (typeof v === 'string') return 'roString';
  if (typeof v === 'number') return Number.isInteger(v) ? 'roInt' : 'roFloat';
  if (typeof v === 'boolean') return 'roBoolean';
  if (typeof v === 'function') return 'roFunction';
  if (Array.isArray(v)) return 'roArray';
  if ($isAA(v)) return 'roAssociativeArray';
  if (v.$isnode) return 'roSGNode';
  if (v.$brsType) return v.$brsType;
  return 'roAssociativeArray';
}

function $formatjson(v) {
  const conv = (x) => {
    if (x === undefined || x === null) return null;
    if (typeof x !== 'object') return x;
    if (Array.isArray(x)) return x.map(conv);
    if (x.$isnode) return null;
    const o = {};
    for (const k in x) o[k] = conv(x[k]);
    return o;
  };
  try { return JSON.stringify(conv(v)); } catch (e) { return ''; }
}
function $parsejson(s, flags) {
  if (s == null || s === '') return null;
  let v;
  try { v = JSON.parse(String(s)); } catch (e) { return null; }
  return $hydrate(v, true);
}

function $urlEscape(s) {
  return encodeURIComponent(s).replace(/[!'()*]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase());
}

// ---------------------------------------------------------------
// roDateTime / roTimespan
// ---------------------------------------------------------------
class $DateTime {
  constructor() { this.$brsType = 'roDateTime'; this.ms = Date.now(); this.local = false; }
  _d() { return new Date(this.ms + (this.local ? -new Date(this.ms).getTimezoneOffset() * 60000 : 0)); }
  $mark() { this.ms = Date.now(); this.local = false; }
  $asseconds() { return Math.floor(this.ms / 1000); }
  $assecondslong() { return Math.floor(this.ms / 1000); }
  $fromseconds(s) { this.ms = s * 1000; this.local = false; }
  $fromsecondslong(s) { this.ms = s * 1000; this.local = false; }
  $tolocaltime() { if (!this.local) { this.ms += -new Date(this.ms).getTimezoneOffset() * 60000; } this.local = true; }
  $getyear() { return new Date(this.ms).getUTCFullYear(); }
  $getmonth() { return new Date(this.ms).getUTCMonth() + 1; }
  $getdayofmonth() { return new Date(this.ms).getUTCDate(); }
  $gethours() { return new Date(this.ms).getUTCHours(); }
  $getminutes() { return new Date(this.ms).getUTCMinutes(); }
  $getseconds() { return new Date(this.ms).getUTCSeconds(); }
  $getmilliseconds() { return new Date(this.ms).getUTCMilliseconds(); }
  $getdayofweek() { return new Date(this.ms).getUTCDay(); }
  $getweekday() { return ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][new Date(this.ms).getUTCDay()]; }
  $getlastdayofmonth() { const d = new Date(this.ms); return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate(); }
  $gettimezoneoffset() { return new Date().getTimezoneOffset(); }
  $fromiso8601string(s) {
    s = String(s || '').trim();
    let t = Date.parse(/[zZ]|[+\-]\d\d:?\d\d$/.test(s) ? s : s + 'Z');
    if (isNaN(t)) t = 0;
    this.ms = t; this.local = false;
  }
  $toisostring() { return new Date(this.ms).toISOString().replace(/\.\d{3}Z$/, 'Z'); }
  $asdatestring(fmt) {
    const d = new Date(this.ms);
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    if (fmt === 'short-date') return (d.getUTCMonth() + 1) + '/' + d.getUTCDate() + '/' + String(d.getUTCFullYear()).slice(2);
    return days[d.getUTCDay()] + ' ' + months[d.getUTCMonth()] + ' ' + d.getUTCDate() + ', ' + d.getUTCFullYear();
  }
  $asdatestringnolocale(fmt) { return this.$asdatestring(fmt); }
}
class $Timespan {
  constructor() { this.$brsType = 'roTimespan'; this.t = performance.now(); }
  $mark() { this.t = performance.now(); }
  $totalmilliseconds() { return Math.floor(performance.now() - this.t); }
  $totalseconds() { return Math.floor((performance.now() - this.t) / 1000); }
  $getsecondstoiso8601date(s) { return Math.floor((Date.parse(s) - Date.now()) / 1000); }
}

// ---------------------------------------------------------------
// roRegex
// ---------------------------------------------------------------
class $Regex {
  constructor(pat, flags) {
    this.$brsType = 'roRegex';
    flags = String(flags || '');
    let f = '';
    if (flags.indexOf('i') >= 0) f += 'i';
    if (flags.indexOf('m') >= 0) f += 'm';
    if (flags.indexOf('s') >= 0) f += 's';
    // PCRE -> JS: \x{..} no se usa; (?i) no se usa
    this.src = String(pat);
    this.f = f;
    this.re = new RegExp(this.src, f);
    this.reg = new RegExp(this.src, f + 'g');
  }
  $ismatch(s) { this.re.lastIndex = 0; return this.re.test(String(s)); }
  $match(s) {
    const r = this.re.exec(String(s));
    if (!r) return [];
    return Array.from(r, x => x === undefined ? '' : x);
  }
  $matchall(s) {
    const out = [];
    for (const r of String(s).matchAll(this.reg)) out.push(Array.from(r, x => x === undefined ? '' : x));
    return out;
  }
  _repl(r) { return String(r).replace(/\$/g, '$$$$').replace(/\\(\d)/g, '$$$1'); }
  $replace(s, r) { return String(s).replace(this.re, this._repl(r)); }
  $replaceall(s, r) { return String(s).replace(this.reg, this._repl(r)); }
  $split(s) { return String(s).split(this.re); }
}

// ---------------------------------------------------------------
// roByteArray
// ---------------------------------------------------------------
class $ByteArray {
  constructor() { this.$brsType = 'roByteArray'; this.a = new Uint8Array(64); this.n = 0; }
  _ensure(n) { if (n > this.a.length) { let c = this.a.length; while (c < n) c *= 2; const b = new Uint8Array(c); b.set(this.a.subarray(0, this.n)); this.a = b; } }
  _setBytes(u8) { this.a = u8.length ? u8 : new Uint8Array(64); this.n = u8.length; }
  $set(i, v) { this._ensure(i + 1); this.a[i] = v & 255; if (i >= this.n) this.n = i + 1; }
  $count() { return this.n; }
  $push(v) { this._ensure(this.n + 1); this.a[this.n++] = v & 255; }
  $pop() { return this.n ? this.a[--this.n] : null; }
  $clear() { this.n = 0; }
  $getentry(i) { return this.a[i]; }
  $setresize(n) { this._ensure(n); }
  $fromasciistring(s) { this._setBytes(new TextEncoder().encode(String(s))); }
  $toasciistring() { return new TextDecoder('utf-8').decode(this.a.subarray(0, this.n)); }
  $tohexstring() { let s = ''; for (let i = 0; i < this.n; i++) s += (this.a[i] < 16 ? '0' : '') + this.a[i].toString(16).toUpperCase(); return s; }
  $fromhexstring(h) { h = String(h); const u = new Uint8Array(h.length >> 1); for (let i = 0; i < u.length; i++) u[i] = parseInt(h.substr(i * 2, 2), 16); this._setBytes(u); }
  $tobase64string() { let s = ''; for (let i = 0; i < this.n; i++) s += String.fromCharCode(this.a[i]); return btoa(s); }
  $frombase64string(b) { let s; try { s = atob(String(b)); } catch (e) { s = ''; } const u = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); this._setBytes(u); }
  $getsignedbyte(i) { const v = this.a[i]; return v > 127 ? v - 256 : v; }
  $getcrc32(start, len) {
    start = start || 0; len = len === undefined ? this.n - start : len;
    let c, crc = 0xFFFFFFFF;
    for (let i = start; i < start + len; i++) {
      c = (crc ^ this.a[i]) & 0xFF;
      for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xEDB88320 : c >>> 1;
      crc = (crc >>> 8) ^ c;
    }
    return (crc ^ 0xFFFFFFFF) | 0;
  }
  $readfile(path, offset, len) {
    const r = $fsRead(path, offset || 0, len === undefined ? -1 : len);
    if (r == null) return false;
    this._setBytes(r);
    return true;
  }
  $writefile(path, start, len) { start = start || 0; len = len === undefined ? this.n - start : len; return $fsWrite(path, this.a.subarray(start, start + len), false); }
  $appendfile(path, start, len) { start = start || 0; len = len === undefined ? this.n - start : len; return $fsWrite(path, this.a.subarray(start, start + len), true); }
  $iterate() { return Array.from(this.a.subarray(0, this.n)); }
}

// ---------------------------------------------------------------
// roEVPDigest (md5 / sha1 / sha256 simplificado: solo md5)
// ---------------------------------------------------------------
function $md5(bytes) {
  function add(x, y) { const l = (x & 0xFFFF) + (y & 0xFFFF); return (((x >> 16) + (y >> 16) + (l >> 16)) << 16) | (l & 0xFFFF); }
  function rol(n, c) { return (n << c) | (n >>> (32 - c)); }
  function cmn(q, a, b, x, s, t) { return add(rol(add(add(a, q), add(x, t)), s), b); }
  function ff(a, b, c, d, x, s, t) { return cmn((b & c) | ((~b) & d), a, b, x, s, t); }
  function gg(a, b, c, d, x, s, t) { return cmn((b & d) | (c & (~d)), a, b, x, s, t); }
  function hh(a, b, c, d, x, s, t) { return cmn(b ^ c ^ d, a, b, x, s, t); }
  function ii(a, b, c, d, x, s, t) { return cmn(c ^ (b | (~d)), a, b, x, s, t); }
  const n = bytes.length;
  const nblk = ((n + 8) >> 6) + 1;
  const x = new Array(nblk * 16).fill(0);
  for (let i = 0; i < n; i++) x[i >> 2] |= bytes[i] << ((i % 4) * 8);
  x[n >> 2] |= 0x80 << ((n % 4) * 8);
  x[nblk * 16 - 2] = n * 8;
  let a = 1732584193, b = -271733879, c = -1732584194, d = 271733878;
  for (let i = 0; i < x.length; i += 16) {
    const oa = a, ob = b, oc = c, od = d;
    a = ff(a, b, c, d, x[i], 7, -680876936); d = ff(d, a, b, c, x[i + 1], 12, -389564586); c = ff(c, d, a, b, x[i + 2], 17, 606105819); b = ff(b, c, d, a, x[i + 3], 22, -1044525330);
    a = ff(a, b, c, d, x[i + 4], 7, -176418897); d = ff(d, a, b, c, x[i + 5], 12, 1200080426); c = ff(c, d, a, b, x[i + 6], 17, -1473231341); b = ff(b, c, d, a, x[i + 7], 22, -45705983);
    a = ff(a, b, c, d, x[i + 8], 7, 1770035416); d = ff(d, a, b, c, x[i + 9], 12, -1958414417); c = ff(c, d, a, b, x[i + 10], 17, -42063); b = ff(b, c, d, a, x[i + 11], 22, -1990404162);
    a = ff(a, b, c, d, x[i + 12], 7, 1804603682); d = ff(d, a, b, c, x[i + 13], 12, -40341101); c = ff(c, d, a, b, x[i + 14], 17, -1502002290); b = ff(b, c, d, a, x[i + 15], 22, 1236535329);
    a = gg(a, b, c, d, x[i + 1], 5, -165796510); d = gg(d, a, b, c, x[i + 6], 9, -1069501632); c = gg(c, d, a, b, x[i + 11], 14, 643717713); b = gg(b, c, d, a, x[i], 20, -373897302);
    a = gg(a, b, c, d, x[i + 5], 5, -701558691); d = gg(d, a, b, c, x[i + 10], 9, 38016083); c = gg(c, d, a, b, x[i + 15], 14, -660478335); b = gg(b, c, d, a, x[i + 4], 20, -405537848);
    a = gg(a, b, c, d, x[i + 9], 5, 568446438); d = gg(d, a, b, c, x[i + 14], 9, -1019803690); c = gg(c, d, a, b, x[i + 3], 14, -187363961); b = gg(b, c, d, a, x[i + 8], 20, 1163531501);
    a = gg(a, b, c, d, x[i + 13], 5, -1444681467); d = gg(d, a, b, c, x[i + 2], 9, -51403784); c = gg(c, d, a, b, x[i + 7], 14, 1735328473); b = gg(b, c, d, a, x[i + 12], 20, -1926607734);
    a = hh(a, b, c, d, x[i + 5], 4, -378558); d = hh(d, a, b, c, x[i + 8], 11, -2022574463); c = hh(c, d, a, b, x[i + 11], 16, 1839030562); b = hh(b, c, d, a, x[i + 14], 23, -35309556);
    a = hh(a, b, c, d, x[i + 1], 4, -1530992060); d = hh(d, a, b, c, x[i + 4], 11, 1272893353); c = hh(c, d, a, b, x[i + 7], 16, -155497632); b = hh(b, c, d, a, x[i + 10], 23, -1094730640);
    a = hh(a, b, c, d, x[i + 13], 4, 681279174); d = hh(d, a, b, c, x[i], 11, -358537222); c = hh(c, d, a, b, x[i + 3], 16, -722521979); b = hh(b, c, d, a, x[i + 6], 23, 76029189);
    a = hh(a, b, c, d, x[i + 9], 4, -640364487); d = hh(d, a, b, c, x[i + 12], 11, -421815835); c = hh(c, d, a, b, x[i + 15], 16, 530742520); b = hh(b, c, d, a, x[i + 2], 23, -995338651);
    a = ii(a, b, c, d, x[i], 6, -198630844); d = ii(d, a, b, c, x[i + 7], 10, 1126891415); c = ii(c, d, a, b, x[i + 14], 15, -1416354905); b = ii(b, c, d, a, x[i + 5], 21, -57434055);
    a = ii(a, b, c, d, x[i + 12], 6, 1700485571); d = ii(d, a, b, c, x[i + 3], 10, -1894986606); c = ii(c, d, a, b, x[i + 10], 15, -1051523); b = ii(b, c, d, a, x[i + 1], 21, -2054922799);
    a = ii(a, b, c, d, x[i + 8], 6, 1873313359); d = ii(d, a, b, c, x[i + 15], 10, -30611744); c = ii(c, d, a, b, x[i + 6], 15, -1560198380); b = ii(b, c, d, a, x[i + 13], 21, 1309151649);
    a = ii(a, b, c, d, x[i + 4], 6, -145523070); d = ii(d, a, b, c, x[i + 11], 10, -1120210379); c = ii(c, d, a, b, x[i + 2], 15, 718787259); b = ii(b, c, d, a, x[i + 9], 21, -343485551);
    a = add(a, oa); b = add(b, ob); c = add(c, oc); d = add(d, od);
  }
  let s = '';
  for (const w of [a, b, c, d]) for (let j = 0; j < 4; j++) s += ((w >> (j * 8)) & 255).toString(16).padStart(2, '0');
  return s;
}
class $EVPDigest {
  constructor() { this.$brsType = 'roEVPDigest'; this.buf = []; }
  $setup(alg) { this.buf = []; return 0; }
  $reinit() { this.buf = []; return 0; }
  $update(ba) { for (let i = 0; i < ba.n; i++) this.buf.push(ba.a[i]); }
  $final() { const r = $md5(this.buf); this.buf = []; return r; }
  $process(ba) { return $md5(Array.from(ba.a.subarray(0, ba.n))); }
}

// ---------------------------------------------------------------
// Servidor local de la app (en Android lo da la app nativa)
// ---------------------------------------------------------------
var $SRV = (typeof location !== 'undefined') ? location.origin : '';

function $xhr(method, path, body, binary, timeoutMs) {
  const x = new XMLHttpRequest();
  x.open(method, $SRV + path, false);
  if (binary && $IS_WORKER) x.responseType = 'arraybuffer';
  if (binary && !$IS_WORKER) x.overrideMimeType('text/plain; charset=x-user-defined');
  if ($IS_WORKER && timeoutMs) { try { x.timeout = timeoutMs; } catch (e) { } }
  try { x.send(body === undefined ? null : body); } catch (e) { return { status: 0, text: '', bytes: null, headers: '', timedout: !!(e && e.name === 'TimeoutError') }; }
  let bytes = null, text = '';
  if (binary) {
    if ($IS_WORKER) bytes = new Uint8Array(x.response || new ArrayBuffer(0));
    else { const t = x.responseText || ''; bytes = new Uint8Array(t.length); for (let i = 0; i < t.length; i++) bytes[i] = t.charCodeAt(i) & 255; }
  } else text = x.responseText;
  return { status: x.status, text, bytes, headers: x.getAllResponseHeaders ? x.getAllResponseHeaders() : '' };
}

// Sistema de archivos virtual (tmp:/, cachefs:/) guardado por la app nativa
function $isPkg(p) { return /^pkg:\//i.test(String(p || '')); }
function $pkgUrl(p) { return '/' + String(p).replace(/^pkg:\/+/i, ''); }
function $fsRead(path, offset, len) {
  if ($isPkg(path)) {
    const r = $xhr('GET', $pkgUrl(path), undefined, true);
    if (r.status !== 200) return null;
    const o = offset || 0;
    return r.bytes.subarray(o, len == null || len < 0 ? r.bytes.length : Math.min(r.bytes.length, o + len));
  }
  const r = $xhr('GET', '/fs/read?p=' + encodeURIComponent(path) + '&o=' + (offset || 0) + '&n=' + (len == null ? -1 : len), undefined, true);
  if (r.status !== 200) return null;
  return r.bytes;
}
function $fsWrite(path, u8, append) {
  const r = $xhr('POST', '/fs/write?p=' + encodeURIComponent(path) + (append ? '&a=1' : ''), u8);
  return r.status === 200;
}
function $readasciifile(path) {
  if ($isPkg(path)) {
    if (!$IS_WORKER && $G.Android && $G.Android.asset) { try { return $G.Android.asset(String(path).replace(/^pkg:\/+/i, '')) || ''; } catch (e) { return ''; } }
    const rp = $xhr('GET', $pkgUrl(path)); return rp.status === 200 ? rp.text : '';
  }
  const r = $xhr('GET', '/fs/read?p=' + encodeURIComponent(path) + '&o=0&n=-1');
  return r.status === 200 ? r.text : '';
}
function $writeasciifile(path, text) { return $fsWrite(path, new TextEncoder().encode(String(text)), false); }
function $deletefile(path) { return $xhr('GET', '/fs/delete?p=' + encodeURIComponent(path)).status === 200; }
function $copyfile(a, b) { const d = $fsRead(a, 0, -1); return d ? $fsWrite(b, d, false) : false; }
function $movefile(a, b) { const ok = $copyfile(a, b); if (ok) $deletefile(a); return ok; }
function $listdir(p) { const r = $xhr('GET', '/fs/list?p=' + encodeURIComponent(p)); try { return JSON.parse(r.text); } catch (e) { return []; } }
function $createdirectory() { return true; }
class $FileSystem {
  constructor() { this.$brsType = 'roFileSystem'; }
  $exists(p) { if ($isPkg(p)) return $xhr('GET', $pkgUrl(p)).status === 200; return $xhr('GET', '/fs/stat?p=' + encodeURIComponent(p)).status === 200; }
  $delete(p) { return $deletefile(p); }
  $stat(p) {
    const r = $xhr('GET', '/fs/stat?p=' + encodeURIComponent(p));
    if (r.status !== 200) return null;
    try { const o = JSON.parse(r.text); return $newAA({ size: o.size, type: 'file', permissions: 'rw' }); } catch (e) { return null; }
  }
  $getdirectorylisting(p) { return $listdir(p); }
  $createdirectory() { return true; }
  $getvolumelist() { return ['tmp:', 'cachefs:']; }
  $getvolumeinfo() { return $newAA({ freespace: 1e9 }); }
  $copyfile(a, b) { return $copyfile(a, b); }
  $rename(a, b) { return $movefile(a, b); }
}

// ---------------------------------------------------------------
// roMessagePort / roUrlTransfer (solo en tareas)
// ---------------------------------------------------------------
class $MessagePort {
  constructor() { this.$brsType = 'roMessagePort'; this.q = []; this.jobs = null; }
  $getmessage() { return this.q.length ? this.q.shift() : null; }
  $peekmessage() { return this.q.length ? this.q[0] : null; }
  $waitmessage(ms) { return $wait(ms, this); }
}
var $xferId = 1;
class $UrlEvent {
  constructor(xfer, r) { this.$brsType = 'roUrlEvent'; this.x = xfer; this.r = r; }
  $getresponsecode() { return this.r.status !== 0 ? this.r.status : -28; }
  $getstring() { return this.r.text || ''; }
  $getfailurereason() { return this.r.status > 0 ? (this.r.status >= 400 ? 'HTTP ' + this.r.status : '') : 'Timeout was reached'; }
  $getsourceidentity() { return this.x.id; }
  $getint() { return 1; }
  $getresponseheaders() { return $newAA(); }
  $gettargetipaddress() { return ''; }
}
class $UrlTransfer {
  constructor() { this.$brsType = 'roUrlTransfer'; this.url = ''; this.headers = {}; this.port = null; this.id = $xferId++; this.method = 'GET'; this.timeout = 0; }
  $seturl(u) { this.url = String(u); }
  $geturl() { return this.url; }
  $setcertificatesfile() { }
  $initclientcertificates() { }
  $enableencodings() { }
  $enablepeerverification() { }
  $enablehostverification() { }
  $retainbodyonerror() { }
  $enablecookies() { }
  $setminimumtransferrate() { }
  $setconnectiontimeout(s) { this.timeout = s * 1000; }
  $addheader(k, v) { this.headers[k] = v; }
  $setheaders(h) { for (const k in h) this.headers[k] = h[k]; }
  $setrequest(m) { this.method = String(m || 'GET').toUpperCase(); }
  $getrequest() { return this.method; }
  $setmessageport(p) { this.port = p; }
  $setport(p) { this.port = p; }
  $getidentity() { return this.id; }
  $escape(s) { return $urlEscape(String(s)); }
  $unescape(s) { try { return decodeURIComponent(String(s).replace(/\+/g, ' ')); } catch (e) { return String(s); } }
  $urlencode(s) { return $urlEscape(String(s)); }
  _q(extra) {
    let q = '/net?u=' + encodeURIComponent(this.url);
    const hk = Object.keys(this.headers);
    if (hk.length) q += '&h=' + encodeURIComponent(JSON.stringify(this.headers));
    if (this.method !== 'GET') q += '&m=' + this.method;
    if (extra) q += extra;
    return q;
  }
  _do(toFile, body, tmo) {
    const r = $xhr(body !== undefined && body !== null ? 'POST' : 'GET', this._q(toFile ? '&to=' + encodeURIComponent(toFile) : ''), body === null ? undefined : body, false, tmo > 0 ? tmo : (this.timeout || 0));
    if (r.timedout) return { status: 0, text: '', timedout: true };
    if (toFile && r.status === 200) { /* el archivo quedo guardado del lado nativo */ }
    let st = r.status;
    const hs = /x-net-status:\s*(-?\d+)/i.exec(r.headers || '');
    if (hs) st = Number(hs[1]);
    return { status: st, text: toFile ? '' : r.text };
  }
  $gettostring() { const r = this._do(null); return r.status >= 200 && r.status < 300 ? r.text : (r.status > 0 ? r.text : ''); }
  $gettofile(path) { return this._do(path).status; }
  $postfromstring(s) { return this._do(null, String(s)).status; }
  // Las descargas "async" las hace la app nativa en paralelo (igual que Roku)
  _start(kind, path, body) {
    if (!this.port) return false;
    const q = this._q(path ? '&to=' + encodeURIComponent(path) : '').replace('/net?', '/net/start?');
    const r = $xhr(body !== undefined ? 'POST' : 'GET', q, body);
    if (r.status !== 200 || !r.text) return false;
    const id = String(r.text).trim();
    if (!this.port.jobs) this.port.jobs = new Map();
    this.port.jobs.set(id, { x: this, kind });
    this.job = id;
    return true;
  }
  $asyncgettostring() { return this._start('str'); }
  $asyncgettofile(path) { return this._start('file', path); }
  $asyncpostfromstring(s) { return this._start('str', null, String(s)); }
  $asynccancel() {
    if (this.job && this.port && this.port.jobs) { this.port.jobs.delete(this.job); $xhr('GET', '/net/cancel?id=' + this.job); }
    this.job = null;
    return true;
  }
  $asynchead() { return this.$asyncgettostring(); }
}
// wait(ms, port): espera el siguiente evento (descarga terminada, socket, campo...)
function $wait(ms, port) {
  if (port == null) { if (ms > 0) $sleep(ms); return null; }
  if (port.q.length) return port.q.shift();
  if (port.jobs && port.jobs.size) {
    const ids = Array.from(port.jobs.keys()).join(',');
    const r = $xhr('GET', '/net/wait?ids=' + ids + '&ms=' + (ms > 0 ? ms : 600000));
    if (r.status !== 200 || !r.text) return null;
    let d;
    try { d = JSON.parse(r.text); } catch (e) { return null; }
    const job = port.jobs.get(String(d.id));
    if (!job) return null;
    port.jobs.delete(String(d.id));
    job.x.job = null;
    let text = '';
    if (job.kind === 'str') { const b = $xhr('GET', '/net/result?id=' + d.id); text = b.text; }
    else $xhr('GET', '/net/cancel?id=' + d.id);
    return new $UrlEvent(job.x, { status: d.status, text });
  }
  if (port.$poll) { const m = port.$poll(ms); if (m) return m; return null; }
  if (ms > 0) $sleep(Math.min(ms, 50));
  return null;
}

// ---------------------------------------------------------------
// roRegistrySection / roDeviceInfo / roAppInfo
// ---------------------------------------------------------------
var $REG = null;
function $regLoad() {
  if ($REG) return $REG;
  $REG = {};
  try {
    if (!$IS_WORKER && $G.Android && $G.Android.regAll) $REG = JSON.parse($G.Android.regAll()) || {};
    else { const r = $xhr('GET', '/reg/all'); $REG = JSON.parse(r.text || '{}'); }
  } catch (e) { $REG = {}; }
  return $REG;
}
function $regSave() {
  const js = JSON.stringify($REG || {});
  try {
    if (!$IS_WORKER && $G.Android && $G.Android.regSave) $G.Android.regSave(js);
    else $xhr('POST', '/reg/save', js);
  } catch (e) { }
}
class $RegistrySection {
  constructor(name) { this.$brsType = 'roRegistrySection'; this.name = String(name); }
  _s() { const r = $regLoad(); if (!r[this.name]) r[this.name] = {}; return r[this.name]; }
  $read(k) { const s = this._s(); return Object.prototype.hasOwnProperty.call(s, k) ? s[k] : ''; }
  $write(k, v) { this._s()[k] = String(v); return true; }
  $delete(k) { const s = this._s(); const had = Object.prototype.hasOwnProperty.call(s, k); delete s[k]; return had; }
  $exists(k) { return Object.prototype.hasOwnProperty.call(this._s(), k); }
  $flush() { $regSave(); return true; }
  $getkeylist() { return Object.keys(this._s()); }
  $readmulti(keys) { const o = $newAA(); for (const k of keys) if (this.$exists(k)) o[k.toLowerCase()] = this.$read(k); return o; }
  $writemulti(aa) { for (const k in aa) this.$write(k, aa[k]); return true; }
}
class $Registry {
  constructor() { this.$brsType = 'roRegistry'; }
  $getsectionlist() { return Object.keys($regLoad()); }
  $delete(sec) { delete $regLoad()[sec]; $regSave(); return true; }
  $flush() { $regSave(); return true; }
}
var $DEV = null;
function $devInfo() {
  if ($DEV) return $DEV;
  let d = {};
  try {
    if (!$IS_WORKER && $G.Android && $G.Android.deviceInfo) d = JSON.parse($G.Android.deviceInfo());
    else { const r = $xhr('GET', '/device'); d = JSON.parse(r.text || '{}'); }
  } catch (e) { d = {}; }
  const nav = (typeof navigator !== 'undefined') ? navigator : {};
  const lang = (nav.language || 'es-MX').replace('-', '_');
  $DEV = Object.assign({ locale: lang, country: (lang.split('_')[1] || 'MX'), ip: '127.0.0.1', model: 'Google TV', uuid: '0000', tz: (Intl.DateTimeFormat().resolvedOptions().timeZone || 'America/Mexico_City'), w: 1920, h: 1080 }, d);
  return $DEV;
}
class $DeviceInfo {
  constructor() { this.$brsType = 'roDeviceInfo'; }
  $getcurrentlocale() { return $devInfo().locale; }
  $getpreferredcaptionlanguage() { return $devInfo().locale.slice(0, 2); }
  $getcountrycode() { return $devInfo().country; }
  $getusercountrycode() { return $devInfo().country; }
  $getipaddrs() { return $newAA({ eth0: $devInfo().ip }); }
  $getexternalip() { return ''; }
  $getmodel() { return $devInfo().model; }
  $getmodeldisplayname() { return $devInfo().model; }
  $getmodeldetails() { return $newAA({ vendorname: 'Android', modelnumber: $devInfo().model }); }
  $getfriendlyname() { return $devInfo().model; }
  $getversion() { return '13.0.0'; }
  $getosversion() { return $newAA({ major: '13', minor: '0', revision: '0', build: '0' }); }
  $getchannelclientid() { return $devInfo().uuid; }
  $getrandomuuid() { return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c => (c ^ Math.random() * 16 >> c / 4).toString(16)); }
  $getdisplaysize() { return $newAA({ w: 1280, h: 720 }); }
  $getuiresolution() { return $newAA({ width: 1280, height: 720, name: 'HD' }); }
  $getdisplaymode() { return '720p'; }
  $getvideomode() { return '1080p'; }
  $getdisplaytype() { return 'HDTV'; }
  $gettimezone() { return $devInfo().tz; }
  $getclockformat() { return '12h'; }
  $getlinkstatus() { return true; }
  $getinternetstatus() { return true; }
  $getconnectiontype() { return 'WiFiConnection'; }
  $getconnectioninfo() { return $newAA({ type: 'WiFiConnection', name: 'wlan0', ip: $devInfo().ip, ssid: '', gateway: '' }); }
  $getgeneralmemorylevel() { return 'normal'; }
  $isrideenabled() { return false; }
  $setmessageport() { }
  $enablelinkstatusevent() { }
  $enableinternetstatusevent() { }
  $getaudiooutputchannel() { return 'Stereo'; }
  $getfeatures() { return []; }
  $hasfeature() { return false; }
  $getcaptionsmode() { return 'Off'; }
  $getcaptionsoption() { return ''; }
  $getdrmInfo() { return $newAA(); }
  $isautoplayenabled() { return true; }
  $getuidevice() { return 'tv'; }
}
var $MANIFEST = $G.$MANIFEST || { title: 'Smart IPTV MX', major_version: '1', minor_version: '90', build_version: '00000' };
class $AppInfo {
  constructor() { this.$brsType = 'roAppInfo'; }
  $getid() { return 'dev'; }
  $isdev() { return false; }
  $getversion() { return $MANIFEST.major_version + '.' + $MANIFEST.minor_version + '.' + $MANIFEST.build_version; }
  $gettitle() { return $MANIFEST.title; }
  $getsubtitle() { return $MANIFEST.subtitle || ''; }
  $getvalue(k) { return $MANIFEST[String(k).toLowerCase()] || ''; }
  $getdevid() { return 'dev'; }
}

// ---------------------------------------------------------------
// Nodos (base sin dibujo): ContentNode y compania
// ---------------------------------------------------------------
var $NODE_DEFAULTS = {
  Node: { id: '', focusable: false, focusedchild: null, change: null },
  ContentNode: {
    title: '', url: '', description: '', hdposterurl: '', sdposterurl: '', fhdposterurl: '', shortdescriptionline1: '',
    shortdescriptionline2: '', starrating: 0, streamformat: '', releasedate: '', rating: '', playstart: 0,
    length: 0, contenttype: '', live: false, categories: '', actors: '', director: '', titleseason: '',
    episodenumber: '', hdbackgroundimageurl: '', textoverlayul: '', textoverlayur: '', textoverlaybody: ''
  }
};
var $FIELD_TYPES = {};
var $curScope = null;

class $NodeBase {
  constructor(type) {
    this.type = type;
    this.f = Object.create(null);
    this.kids = [];
    this.parent = null;
    this.obs = null;
    this.ftypes = null;     // tipos declarados por interfaz/addFields
    this.always = null;     // campos alwaysNotify
    this.proxy = new Proxy(this, $NodeHandler);
  }
  defaults() { return $NODE_DEFAULTS[this.type] || $NODE_DEFAULTS[$nodeBaseType(this.type)] || {}; }
  get(k) {
    if (k in this.f) return this.f[k];
    const d = this.defaults();
    if (k in d) { const v = d[k]; return Array.isArray(v) ? v.slice() : v; }
    const nd = $NODE_DEFAULTS.Node;
    if (k in nd) return nd[k];
    return undefined;
  }
  set(k, v, quiet) {
    v = this.coerce(k, v);
    const old = this.f[k];
    this.f[k] = v;
    this.applyField(k, v, old);
    if (quiet) return;
    if (old !== v || (this.always && this.always[k]) || (typeof v === 'object' && v !== null)) this.notify(k, v);
  }
  coerce(k, v) {
    const t = this.ftypes && this.ftypes[k];
    if (!t) return v;
    switch (t) {
      case 'string': case 'str': return v == null ? '' : (typeof v === 'string' ? v : String(v));
      case 'integer': case 'int': return typeof v === 'number' ? Math.trunc(v) : (typeof v === 'string' ? $val(v) | 0 : (v ? 1 : 0));
      case 'float': return typeof v === 'number' ? v : Number(v) || 0;
      case 'boolean': case 'bool': return typeof v === 'string' ? v.toLowerCase() === 'true' : !!v;
      default: return v;
    }
  }
  applyField() { }
  notify(k, v) {
    if (!this.obs) return;
    const list = this.obs[k];
    if (!list || !list.length) return;
    for (const o of list.slice()) {
      if (o.dead) continue;
      $dispatchObserver(o, this.proxy, k, v);
    }
  }
  addObserver(k, handler, scope, scoped, infoFields) {
    k = String(k).toLowerCase();
    if (!this.obs) this.obs = Object.create(null);
    if (!this.obs[k]) this.obs[k] = [];
    this.obs[k].push({ handler, scope, scoped, info: infoFields });
    return true;
  }
  removeObservers(k, scope, onlyScoped) {
    k = String(k).toLowerCase();
    if (!this.obs || !this.obs[k]) return;
    this.obs[k] = this.obs[k].filter(o => {
      const kill = onlyScoped ? (o.scope === scope) : true;
      if (kill) o.dead = true;
      return !kill;
    });
  }
  // ---- arbol ----
  appendChild(c) {
    if (!c) return false;
    const n = c.$t;
    if (n.parent) n.parent.removeChildImpl(n);
    n.parent = this;
    this.kids.push(n);
    this.childAdded(n, this.kids.length - 1);
    return true;
  }
  insertChildImpl(n, idx) {
    if (n.parent) n.parent.removeChildImpl(n);
    n.parent = this;
    if (idx < 0) idx = 0;
    if (idx > this.kids.length) idx = this.kids.length;
    this.kids.splice(idx, 0, n);
    this.childAdded(n, idx);
  }
  removeChildImpl(n) {
    const i = this.kids.indexOf(n);
    if (i < 0) return false;
    this.kids.splice(i, 1);
    n.parent = null;
    this.childRemoved(n, i);
    return true;
  }
  childAdded() { this.contentChanged(); }
  childRemoved() { this.contentChanged(); }
  contentChanged() { let p = this; while (p) { if (p.onContentChange) p.onContentChange(); p = p.parent; } }
  findById(id) {
    const low = String(id).toLowerCase();
    const stack = [this];
    while (stack.length) {
      const n = stack.shift();
      const nid = n.f.id;
      if (nid !== undefined && nid !== '' && String(nid).toLowerCase() === low) return n;
      for (const c of n.kids) stack.push(c);
    }
    return null;
  }
  toWire() {
    const f = {};
    for (const k in this.f) {
      const v = this.f[k];
      f[k] = $toWire(v);
    }
    return { __node: 1, type: this.type, f, ft: this.ftypes, k: this.kids.map(c => c.toWire()) };
  }
}
function $toWire(v) {
  if (v === null || typeof v !== 'object') return v;
  if (v.$isnode) return v.$t.toWire();
  if (Array.isArray(v)) return v.map($toWire);
  if (v instanceof Uint8Array) return v;
  if (v.$brsType) return null;
  const o = {};
  for (const k in v) o[k] = $toWire(v[k]);
  return o;
}
function $nodeBaseType(t) { return ($G.$COMP_EXTENDS && $G.$COMP_EXTENDS[t]) || t; }

// Metodos de nodo que ve el codigo BrightScript (node.$metodo)
var $NodeMethods = {
  $findnode(id) { const n = this.findById(id); return n ? n.proxy : null; },
  $getchild(i) { const n = this.kids[i]; return n ? n.proxy : null; },
  $getchildcount() { return this.kids.length; },
  $getchildren(count, start) { start = start || 0; const end = (count == null || count < 0) ? this.kids.length : start + count; return this.kids.slice(start, end).map(n => n.proxy); },
  $appendchild(c) { return this.appendChild(c); },
  $appendchildren(arr) { for (const c of arr) this.appendChild(c); return true; },
  $insertchild(c, i) { if (!c) return false; this.insertChildImpl(c.$t, i); return true; },
  $insertchildren(arr, i) { for (const c of arr) this.insertChildImpl(c.$t, i++); return true; },
  $removechild(c) { return c ? this.removeChildImpl(c.$t) : false; },
  $removechildren(arr) { for (const c of arr) if (c) this.removeChildImpl(c.$t); return true; },
  $removechildindex(i) { const n = this.kids[i]; return n ? this.removeChildImpl(n) : false; },
  $removechildrenindex(count, i) { for (let k = 0; k < count && this.kids[i]; k++) this.removeChildImpl(this.kids[i]); return true; },
  $replacechild(c, i) { const old = this.kids[i]; if (old) this.removeChildImpl(old); this.insertChildImpl(c.$t, i); return true; },
  $createchild(type) { const c = $createNode(type); if (!c) return null; this.appendChild(c); return c; },
  $getparent() { return this.parent ? this.parent.proxy : null; },
  $getscene() { let p = this; while (p.parent) p = p.parent; return p.proxy; },
  $clone(deep) { return $cloneNode(this, deep); },
  $clonenode(deep) { return $cloneNode(this, deep); },
  $issamenode(o) { return o != null && o.$isnode && o.$t === this; },
  $subtype() { return this.type; },
  $getid() { return this.get('id'); },
  $hasfield(k) { k = String(k).toLowerCase(); return (k in this.f) || (k in this.defaults()) || (this.ftypes && k in this.ftypes); },
  $getfield(k) { return this.proxy[String(k).toLowerCase()]; },
  $setfield(k, v) { this.proxy[String(k).toLowerCase()] = v; return true; },
  $getfields() { const o = $newAA(); for (const k in this.defaults()) o[k] = this.get(k); for (const k in this.f) o[k] = this.f[k]; return o; },
  $setfields(aa) { if (!aa) return true; for (const k in aa) this.proxy[k.toLowerCase()] = aa[k]; return true; },
  $addfield(k, type, always) { k = String(k).toLowerCase(); if (!this.ftypes) this.ftypes = Object.create(null); this.ftypes[k] = String(type).toLowerCase(); if (always) { if (!this.always) this.always = Object.create(null); this.always[k] = true; } if (!(k in this.f)) this.f[k] = $fieldDefault(type); return true; },
  $addfields(aa) {
    if (!aa) return true;
    for (const k in aa) {
      const v = aa[k];
      if (!this.ftypes) this.ftypes = Object.create(null);
      if (!(k in this.ftypes)) this.ftypes[k] = $guessType(v);
      this.set(k, v, true);
    }
    return true;
  },
  $removefield(k) { delete this.f[String(k).toLowerCase()]; return true; },
  $observefield(k, h, info) { return this.addObserver(k, h, $curScope, false, info); },
  $observefieldscoped(k, h, info) { return this.addObserver(k, h, $curScope, true, info); },
  $unobservefield(k) { this.removeObservers(k, $curScope, false); return true; },
  $unobservefieldscoped(k) { this.removeObservers(k, $curScope, true); return true; },
  $callfunc(name) {
    const args = Array.from(arguments).slice(1);
    const sc = this.scope;
    if (!sc) return null;
    const fn = sc.fns[String(name).toLowerCase()];
    if (!fn) return null;
    return $runInScope(sc, () => fn.apply(null, args));
  },
  $signalbeacon() { },
  $update(aa, add) { this.proxy.$setfields(aa); return true; },
  $count() { return this.kids.length; },
  $getall() { return this.kids.map(n => n.proxy); },
  $ifsgnodechildren() { return this.proxy; },
  $isinfocuschain() { return $isInFocusChain(this); },
  $hasfocus() { return $focusedNode === this; },
  $setfocus(on) { $setFocus(this, on); return true; },
  $getfocusednode() { return null; },
  $boundingrect() { return this.boundingRect ? this.boundingRect(false) : $newAA({ x: 0, y: 0, width: 0, height: 0 }); },
  $localboundingrect() { return this.boundingRect ? this.boundingRect(true) : $newAA({ x: 0, y: 0, width: 0, height: 0 }); },
  $sceneboundingrect() { return this.boundingRect ? this.boundingRect(false) : $newAA({ x: 0, y: 0, width: 0, height: 0 }); },
  $isnode: true
};
function $fieldDefault(type) {
  switch (String(type).toLowerCase()) {
    case 'string': case 'str': case 'uri': return '';
    case 'integer': case 'int': case 'float': case 'time': return 0;
    case 'boolean': case 'bool': return false;
    case 'array': case 'intarray': case 'floatarray': case 'stringarray': case 'boolarray': case 'nodearray': case 'vector2d': return [];
    case 'assocarray': return $newAA();
    default: return null;
  }
}
function $guessType(v) {
  if (typeof v === 'string') return 'string';
  if (typeof v === 'number') return Number.isInteger(v) ? 'integer' : 'float';
  if (typeof v === 'boolean') return 'boolean';
  if (Array.isArray(v)) return 'array';
  if (v && v.$isnode) return 'node';
  return 'assocarray';
}

var $focusedNode = null;
function $setFocus(n, on) { if ($G.$sceneSetFocus) return $G.$sceneSetFocus(n, on); if (on) $focusedNode = n; else if ($focusedNode === n) $focusedNode = null; }
function $isInFocusChain(n) { let f = $focusedNode; while (f) { if (f === n) return true; f = f.parent; } return false; }

var $NodeHandler = {
  get(t, k) {
    if (typeof k !== 'string') return undefined;
    if (k === '$t') return t;
    if (k.charCodeAt(0) === 36) { // '$'
      const fn = $NodeMethods[k] || (t.methods && t.methods[k]);
      if (fn) return typeof fn === 'function' ? fn.bind(t) : fn;
      return undefined;
    }
    if (k === 'toString') return () => '<Component: roSGNode:' + t.type + '>';
    return t.get(k.toLowerCase());
  },
  set(t, k, v) {
    if (typeof k !== 'string') return false;
    t.set(k.toLowerCase(), v);
    return true;
  },
  has(t, k) { return typeof k === 'string' && (k in t.f || k in t.defaults()); },
  ownKeys(t) { return Object.keys(t.f); },
  getOwnPropertyDescriptor(t, k) { if (k in t.f) return { value: t.f[k], enumerable: true, configurable: true, writable: true }; return undefined; }
};

function $cloneNode(n, deep) {
  const c = $createNode(n.type);
  const t = c.$t;
  if (n.ftypes) t.ftypes = Object.assign(Object.create(null), n.ftypes);
  for (const k in n.f) t.set(k, n.f[k], true);
  if (deep) for (const k of n.kids) t.appendChild($cloneNode(k, true));
  return c;
}

// Nodo creado desde el "cable" (mensaje de una tarea)
var $Node = {
  fromWire(w) {
    const p = $createNode(w.type);
    const t = p.$t;
    if (w.ft) t.ftypes = Object.assign(Object.create(null), w.ft);
    for (const k in w.f) t.f[k] = $hydrate(w.f[k], false);
    for (const k of w.k) { const cp = $Node.fromWire(k); const ct = cp.$t; ct.parent = t; t.kids.push(ct); }
    if (t.afterWire) t.afterWire();
    return p;
  }
};

function $dispatchObserver(o, nodeProxy, field, value) {
  if (typeof o.handler === 'function') { try { o.handler(value, nodeProxy, field); } catch (e) { $reportError(e); } return; }
  if (typeof o.handler === 'string') {
    const sc = o.scope;
    if (!sc) return;
    const fn = sc.fns[o.handler.toLowerCase()];
    if (!fn) { console.warn('observer sin funcion: ' + o.handler); return; }
    const ev = new $NodeEvent(nodeProxy, field, value, o.info);
    $runInScope(sc, () => (fn.length > 0 ? fn(ev) : fn()));
  } else if (o.handler && o.handler.$brsType === 'roMessagePort') {
    o.handler.q.push(new $NodeEvent(nodeProxy, field, value, o.info));
    if (o.handler.$wake) o.handler.$wake();
  }
}
class $NodeEvent {
  constructor(node, field, data, info) { this.$brsType = 'roSGNodeEvent'; this.n = node; this.fld = field; this.d = data; this.info = info; }
  $getdata() { return this.d; }
  $getfield() { return this.fld; }
  $getrosgnode() { return this.n; }
  $getnode() { return this.n ? this.n.id : ''; }
  $getinfo() { const o = $newAA(); if (this.info && this.n) for (const k of this.info) o[k.toLowerCase()] = this.n[k.toLowerCase()]; return o; }
}

function $runInScope(sc, f) {
  const prev = $curScope;
  $curScope = sc;
  try { return f(); } catch (e) { $reportError(e); return undefined; } finally { $curScope = prev; }
}
function $reportError(e) {
  console.error('[BRS] ' + (e && e.stack ? e.stack : e));
  if ($G.$onBrsError) $G.$onBrsError(e);
}

// Registro de componentes (XML) y fabricas
var $COMPONENTS = {};
var $COMP_EXTENDS = {};
$G.$COMP_EXTENDS = $COMP_EXTENDS;
function $defineComponent(spec, factory) {
  $COMPONENTS[spec.name] = { spec, factory };
  $COMP_EXTENDS[spec.name] = spec.extends;
}

// En el hilo principal scene.js reemplaza $createNode por uno que dibuja.
function $createNodeBase(type) {
  const n = new $NodeBase(type);
  return n.proxy;
}
var $createNode = function (type) { return $createNodeBase(type); };

function $createobject(kind, a, b) {
  switch (String(kind).toLowerCase()) {
    case 'rosgnode': return $createNode(a);
    case 'roassociativearray': return $newAA();
    case 'roarray': case 'rolist': return [];
    case 'rodatetime': return new $DateTime();
    case 'rotimespan': return new $Timespan();
    case 'roregex': return new $Regex(a, b);
    case 'robytearray': return new $ByteArray();
    case 'roevpdigest': return new $EVPDigest();
    case 'rofilesystem': return new $FileSystem();
    case 'rourltransfer': return new $UrlTransfer();
    case 'romessageport': return new $MessagePort();
    case 'roregistrysection': return new $RegistrySection(a);
    case 'roregistry': return new $Registry();
    case 'rodeviceinfo': return new $DeviceInfo();
    case 'roappinfo': return new $AppInfo();
    case 'rostring': return '';
    case 'roint': case 'rointeger': return 0;
    case 'rostreamsocket': case 'rosocketaddress': return $G.$createSocket ? $G.$createSocket(kind) : null;
    case 'roinput': return { $brsType: 'roInput', $setmessageport() { } };
    default:
      console.warn('CreateObject no soportado: ' + kind);
      return null;
  }
}

// roStreamSocket / roSocketAddress para el servidor del QR.
// La app nativa abre el puerto en la red local y entrega cada peticion completa.
'use strict';
var $servers = [];
var $sockIds = 100;
class $SocketAddress {
  constructor() { this.$brsType = 'roSocketAddress'; this.port = 0; this.host = '0.0.0.0'; }
  $setaddress(s) { s = String(s); const i = s.lastIndexOf(':'); if (i < 0) return false; this.host = s.slice(0, i); this.port = Number(s.slice(i + 1)) || 0; return true; }
  $sethostname(h) { this.host = String(h); return true; }
  $gethostname() { return this.host; }
  $setport(p) { this.port = Number(p) || 0; return true; }
  $getport() { return this.port; }
  $getaddress() { return this.host + ':' + this.port; }
  $isaddressvalid() { return this.port > 0; }
}
class $SocketEvent {
  constructor(id) { this.$brsType = 'roSocketEvent'; this.id = id; }
  $getsocketid() { return this.id; }
}
class $StreamSocket {
  constructor() { this.$brsType = 'roStreamSocket'; this.id = $sockIds++; this.port = null; this.addr = null; this.isServer = false; this.pendingAccept = []; this.data = ''; this.out = ''; this.cid = null; this.closed = false; this.notify = false; }
  $setreuseaddr() { return true; }
  $setaddress(a) { this.addr = a; return !!a && a.port > 0; }
  $setsendtoaddress() { return true; }
  $setmessageport(p) { this.port = p; $installSockPoll(p); return true; }
  $notifyreadable(on) { this.notify = !!on; if (on && !this.isServer && this.data.length && this.port) this.port.q.push(new $SocketEvent(this.id)); return true; }
  $notifywritable() { return true; }
  $notifyexception() { return true; }
  $listen() {
    if (!this.addr) return false;
    const r = $xhr('GET', '/sock/listen?port=' + this.addr.port);
    if (r.status !== 200) return false;
    this.isServer = true;
    $servers.push(this);
    return true;
  }
  $getid() { return this.id; }
  $isreadable() { return this.isServer ? this.pendingAccept.length > 0 : this.data.length > 0; }
  $iswritable() { return true; }
  $isexception() { return false; }
  $isconnected() { return !this.closed; }
  $eok() { return true; }
  $eagain() { return false; }
  $status() { return 0; }
  $accept() {
    const c = this.pendingAccept.shift();
    if (!c) return null;
    const s = new $StreamSocket();
    s.cid = c.id;
    s.data = c.data || '';
    return s;
  }
  $receivestr(n) {
    const s = this.data.slice(0, n);
    this.data = this.data.slice(n);
    if (this.data.length && this.port && this.notify) this.port.q.push(new $SocketEvent(this.id));
    return s;
  }
  $receive(ba, start, len) { const s = this.$receivestr(len); const u = new TextEncoder().encode(s); for (let i = 0; i < u.length; i++) ba.$set(start + i, u[i]); return u.length; }
  $sendstr(s) { s = String(s); this.out += s; return s.length; }
  $send(ba, start, len) { this.out += new TextDecoder().decode(ba.a.subarray(start, start + len)); return len; }
  $close() {
    if (this.isServer) { $xhr('GET', '/sock/unlisten'); return true; }
    if (this.cid != null && !this.closed) { this.closed = true; $xhr('POST', '/sock/send?id=' + this.cid, new TextEncoder().encode(this.out)); }
    return true;
  }
}
function $installSockPoll(port) {
  if (port.$poll) return;
  port.$poll = function (ms) {
    const r = $xhr('GET', '/sock/poll?ms=' + (ms > 0 ? ms : 1000));
    if (r.status === 200 && r.text) {
      let d;
      try { d = JSON.parse(r.text); } catch (e) { return null; }
      const srv = $servers[$servers.length - 1];
      if (!srv) return null;
      srv.pendingAccept.push(d);
      return new $SocketEvent(srv.id);
    }
    return null;
  };
}
$G.$createSocket = function (kind) {
  kind = String(kind).toLowerCase();
  if (kind === 'rosocketaddress') return new $SocketAddress();
  return new $StreamSocket();
};

// Generado por tools/build.js a partir del canal de Roku. No editar a mano.
$defineComponent({"name":"ContentReader","extends":"Task","fields":[{"id":"contenturi","type":"string"},{"id":"content","type":"node"},{"id":"movies","type":"node"},{"id":"series","type":"node"},{"id":"adult","type":"node"},{"id":"wanted","type":"assocarray"},{"id":"epgurl","type":"string"},{"id":"listepg","type":"string"},{"id":"favs","type":"assocarray"},{"id":"direct","type":"boolean","value":"false"},{"id":"progress","type":"integer","value":"0"}],"children":[]}, function (m) {
// ---- components/contentreader.brs ----
function init() {
  m.top.functionname = "getcontent";
}

function getcontent() {
  let rootnode, url, fs, path, filesize, code, st, usefile, alllines, m3utext, rules, groups, appearance, moviegroups, movieorder, epgurl, curtitle, curgroup, curid, curlogo, curchno, grpvod, serdata, serorder, pending, pendingorder, adultgroups, adultorder, offset, more, chunksize, lastpct, lines, n, islast, ba, used, grow, i, text, pct, rawline, line, commaat, grp, bar, entry, both, agname, lu, ep, kind, gname, sg, arr, vodn, p, ordered, standard, movieroot, seriesroot, seen, favs, epgforitems;
  rootnode = $createobject("roSGNode", "ContentNode");
  url = m.top.contenturi;
  if (((url == null) || (url === ""))) {
    m.top.content = rootnode;
    return;
  }
  fs = $createobject("roFileSystem");
  path = "cachefs:/iptv_list.m3u";
  if (fs.$exists(path)) {
    fs.$delete(path);
  }
  filesize = 0;
  code = newhttp(url).$gettofile(path);
  if ((code === 200)) {
    st = fs.$stat(path);
    if ((st != null)) {
      filesize = st.size;
    }
  }
  usefile = ((filesize > 0));
  alllines = [];
  if ((!usefile)) {
    if (fs.$exists(path)) {
      fs.$delete(path);
    }
    m3utext = newhttp(url).$gettostring();
    if (((m3utext == null) || (m3utext === ""))) {
      m.top.content = rootnode;
      return;
    }
    m3utext = m3utext.$replace($chr(13), "");
    alllines = m3utext.$split($chr(10));
    m3utext = "";
  }
  rules = buildrules();
  groups = {__proto__: $AAP};
  appearance = [];
  moviegroups = {__proto__: $AAP};
  movieorder = [];
  epgurl = "";
  curtitle = tx("Canal sin nombre");
  curgroup = "";
  curid = "";
  curlogo = "";
  curchno = "";
  grpvod = {__proto__: $AAP};
  serdata = {__proto__: $AAP};
  serorder = [];
  pending = {__proto__: $AAP};
  pendingorder = [];
  adultgroups = {__proto__: $AAP};
  adultorder = [];
  offset = 0;
  more = true;
  chunksize = 262144;
  lastpct = (-1);
  while (more) {
    lines = alllines;
    more = false;
    if (usefile) {
      n = chunksize;
      islast = (((offset + n) >= filesize));
      if (islast) {
        n = (filesize - offset);
      }
      lines = [];
      ba = $createobject("roByteArray");
      if ((((n > 0) && ba.$readfile(path, offset, n)) && (ba.$count() > 0))) {
        used = ba.$count();
        grow = false;
        if ((!islast)) {
          i = (used - 1);
          while (((i >= 0) && ($ix(ba, i) !== 10))) {
            i = (i - 1);
          }
          if (((i >= 0) && ((i + 1) < used))) {
            used = (i + 1);
            ba = $createobject("roByteArray");
            ba.$readfile(path, offset, used);
          } else if ((i < 0)) {
            grow = true;
          }
        }
        if (grow) {
          chunksize = (chunksize * 2);
          more = true;
        } else {
          text = ba.$toasciistring();
          offset = (offset + used);
          text = text.$replace($chr(13), "");
          lines = text.$split($chr(10));
          if ((offset < filesize)) {
            more = true;
          }
          pct = $int(((offset / filesize) * 100));
          if ((pct > 99)) {
            pct = 99;
          }
          if ((pct !== lastpct)) {
            lastpct = pct;
            m.top.progress = pct;
          }
        }
      }
    }
    for (rawline of $iter(lines)) {
      line = rawline.$trim();
      if (($asc($left(line, 1)) === 65279)) {
        line = $mid(line, 2);
      }
      if (($left(line, 7) === "#EXTM3U")) {
        epgurl = firsturl(getattr(line, "url-tvg"));
        if ((epgurl === "")) {
          epgurl = firsturl(getattr(line, "x-tvg-url"));
        }
        if ((epgurl === "")) {
          epgurl = firsturl(getattr(line, "tvg-url"));
        }
      } else if (($left(line, 8) === "#EXTINF:")) {
        curtitle = "";
        commaat = titlecommapos(line);
        if ((commaat > 0)) {
          curtitle = $mid(line, (commaat + 1)).$trim();
        }
        if ((curtitle === "")) {
          curtitle = getattr(line, "tvg-name");
        }
        if ((curtitle === "")) {
          curtitle = tx("Canal sin nombre");
        }
        curgroup = getattr(line, "group-title");
        curid = $lcase(getattr(line, "tvg-id"));
        curlogo = cleanlogo(decodeentities(getattr(line, "tvg-logo")));
        if ((curlogo === "")) {
          curlogo = cleanlogo(decodeentities(getattr(line, "logo")));
        }
        curchno = getattr(line, "tvg-chno").$trim();
      } else if (($left(line, 8) === "#EXTGRP:")) {
        grp = $mid(line, 9).$trim();
        if ((grp !== "")) {
          curgroup = grp;
        }
      } else if ((($left(line, 4) === "http") || ($left(line, 4) === "rtmp"))) {
        bar = $instr(1, line, "|");
        if (((bar > 0) && ($instr(bar, line, "=") > 0))) {
          line = $left(line, (bar - 1)).$trim();
        }
        entry = {__proto__: $AAP, "t": curtitle, "u": line, "i": curid, "f": detectformat(line), "l": curlogo, "n": curchno};
        both = (($lcase(curgroup) + " | ") + $lcase(curtitle));
        if ((($instr(1, both, "adult swim") === 0) && matchany(both, rules.adult))) {
          agname = curgroup.$trim();
          if ((agname === "")) {
            agname = "Adultos";
          }
          lu = $lcase(line);
          entry.d = "live";
          if ((((($instr(1, lu, "/movie/") > 0) || ($instr(1, lu, "/series/") > 0)) || (entry.f === "mp4")) || (entry.f === "mkv"))) {
            entry.d = "movie";
          }
          addtogroup(adultgroups, adultorder, agname, entry);
        } else {
          ep = seriesof(curgroup, curtitle, line);
          kind = "live";
          if ((ep == null)) {
            kind = vodkind(curgroup, curtitle, line, curid);
          }
          gname = curgroup.$trim();
          if ((gname === "")) {
            gname = "Peliculas";
          }
          if ((ep != null)) {
            sg = gname;
            if ((sg === "")) {
              sg = "Series";
            }
            if ((ep.name === "")) {
              ep.name = sg;
            }
            seradd(serdata, serorder, sg, ep, entry);
          } else if ((kind === "vod")) {
            addtogroup(moviegroups, movieorder, gname, entry);
            if (grpvod.$doesexist(gname)) {
              $six(grpvod, gname, ($ix(grpvod, gname) + 1));
            } else {
              $six(grpvod, gname, 1);
            }
          } else if ((kind === "maybe")) {
            if ((!pending.$doesexist(gname))) {
              $six(pending, gname, []);
              pendingorder.$push(gname);
            }
            $ix(pending, gname).$push({__proto__: $AAP, "e": entry, "g": curgroup, "t": curtitle});
          } else {
            addtogroup(groups, appearance, classify(curgroup, curtitle, rules), entry);
          }
        }
        curtitle = tx("Canal sin nombre");
        curgroup = "";
        curid = "";
        curlogo = "";
        curchno = "";
      }
    }
  }
  if ((usefile && fs.$exists(path))) {
    fs.$delete(path);
  }
  for (gname of $iter(pendingorder)) {
    arr = $ix(pending, gname);
    vodn = 0;
    if (grpvod.$doesexist(gname)) {
      vodn = $ix(grpvod, gname);
    }
    for (p of $iter(arr)) {
      if ((vodn >= arr.$count())) {
        addtogroup(moviegroups, movieorder, gname, p.e);
      } else {
        addtogroup(groups, appearance, classify(p.g, p.t, rules), p.e);
      }
    }
  }
  ordered = [];
  standard = ["Deportes", "Noticias", "Entretenimiento", "Cine", "Series", "Infantil", "Música", "Documentales"];
  for (n of $iter(standard)) {
    if (groups.$doesexist(n)) {
      ordered.$push(n);
    }
  }
  for (n of $iter(appearance)) {
    if ((((!isin(ordered, n)) && (n !== "Otros")) && (n !== "Adultos"))) {
      ordered.$push(n);
    }
  }
  if (groups.$doesexist("Otros")) {
    ordered.$push("Otros");
  }
  if (groups.$doesexist("Adultos")) {
    ordered.$push("Adultos");
  }
  movieroot = $createobject("roSGNode", "ContentNode");
  seriesroot = $createobject("roSGNode", "ContentNode");
  if ((m.top.direct === true)) {
    seen = {__proto__: $AAP};
    favs = m.top.favs;
    if ((favs == null)) {
      favs = {__proto__: $AAP};
    }
    epgforitems = m.top.listepg;
    if ((epgforitems === "")) {
      epgforitems = epgurl;
    }
    filltreedirect(rootnode, groups, ordered, "live", seen, favs, epgforitems);
    filltreedirect(movieroot, moviegroups, movieorder, "movie", seen, favs, epgforitems);
    serfilldirect(seriesroot, serdata, serorder, seen, favs);
  } else {
    filltree(rootnode, groups, ordered, "live");
    filltree(movieroot, moviegroups, movieorder, "movie");
    serfill(seriesroot, serdata, serorder);
  }
  m.top.series = seriesroot;
  m.top.adult = buildadult(adultgroups, adultorder);
  m.top.movies = movieroot;
  m.top.epgurl = epgurl;
  m.top.wanted = epgwantedof(rootnode);
  m.top.content = rootnode;
}

function buildadult(ag, order) {
  let root, n, arr, cat, e, item;
  root = $createobject("roSGNode", "ContentNode");
  for (n of $iter(order)) {
    arr = $ix(ag, n);
    ag.$delete(n);
    if (((arr != null) && (arr.$count() > 0))) {
      cat = root.$createchild("ContentNode");
      cat.id = n;
      for (e of $iter(arr)) {
        item = cat.$createchild("ContentNode");
        item.$setfields({__proto__: $AAP, "title": e.t, "url": e.u, "id": e.i, "streamformat": e.f, "hdposterurl": e.l, "description": e.d});
      }
      cat.title = (((n + "  (") + cat.$getchildcount().$tostr()) + ")");
    }
  }
  return root;
}

function addtogroup(groups, appearance, name, entry) {
  if ((!groups.$doesexist(name))) {
    $six(groups, name, []);
    appearance.$push(name);
  }
  $ix(groups, name).$push(entry);
}

function newhttp(url) {
  let http;
  http = $createobject("roUrlTransfer");
  http.$setcertificatesfile("common:/certs/ca-bundle.crt");
  http.$initclientcertificates();
  http.$enableencodings(true);
  http.$seturl(url);
  return http;
}

function filltreedirect(rootnode, groups, ordered, kind, seen, favs, epg) {
  let n, arr, ch, catnode, u, sr, item;
  for (n of $iter(ordered)) {
    arr = $ix(groups, n);
    groups.$delete(n);
    if (((arr == null) || ($lcase(n) === "adultos"))) {
      continue;
    }
    if ((kind === "movie")) {
      for (ch of $iter(arr)) {
        ch.k = sortkey(ch.t);
      }
      arr.$sortby("k");
    }
    catnode = null;
    for (ch of $iter(arr)) {
      u = ch.u;
      if (((u === "") || (!seen.$doesexist(u)))) {
        if ((u !== "")) {
          $six(seen, u, true);
        }
        if ((catnode == null)) {
          catnode = rootnode.$createchild("ContentNode");
          catnode.id = n;
        }
        sr = 0;
        if (((u !== "") && favs.$doesexist(u))) {
          sr = 100;
        }
        item = catnode.$createchild("ContentNode");
        item.$setfields({__proto__: $AAP, "title": ch.t, "url": u, "id": ch.i, "streamformat": ch.f, "hdposterurl": ch.l, "shortdescriptionline1": ch.n, "shortdescriptionline2": epg, "description": kind, "starrating": sr});
      }
    }
    if ((catnode != null)) {
      catnode.title = (((n + "  (") + catnode.$getchildcount().$tostr()) + ")");
    }
  }
}

function filltree(rootnode, groups, ordered, kind) {
  let n, arr, ch, catnode, item;
  for (n of $iter(ordered)) {
    arr = $ix(groups, n);
    if ((kind === "movie")) {
      for (ch of $iter(arr)) {
        ch.k = sortkey(ch.t);
      }
      arr.$sortby("k");
    }
    catnode = rootnode.$createchild("ContentNode");
    catnode.id = n;
    catnode.title = (((n + "  (") + arr.$count().$tostr()) + ")");
    for (ch of $iter(arr)) {
      item = catnode.$createchild("ContentNode");
      item.title = ch.t;
      item.url = ch.u;
      item.id = ch.i;
      item.streamformat = ch.f;
      item.hdposterurl = ch.l;
      item.shortdescriptionline1 = ch.n;
      item.description = kind;
    }
  }
}

function vodkind(group, name, url, id) {
  let u, fmt, g;
  u = $lcase(url);
  if (($instr(1, u, "/live/") > 0)) {
    return "live";
  }
  if (($instr(1, u, "/movie/") > 0)) {
    return "vod";
  }
  if (($instr(1, u, "/series/") > 0)) {
    return "vod";
  }
  if (($instr(1, u, "/vod/") > 0)) {
    return "vod";
  }
  if (($instr(1, u, "type=movie") > 0)) {
    return "vod";
  }
  if (($instr(1, u, "type=series") > 0)) {
    return "vod";
  }
  fmt = detectformat(url);
  if (((fmt === "mp4") || (fmt === "mkv"))) {
    return "vod";
  }
  g = $lcase(group);
  if ((g === "")) {
    return "live";
  }
  if (matchany(g, ["deport", "noticia", "news", "infantil", "kids", "musica", ($chr(109) + "úsica"), "radio"])) {
    return "live";
  }
  if ((!matchany(g, ["pelic", "movie", "vod", "estreno", "halloween", "4k", "cine", "film", " fps", "castellano", "latino", "subtit"]))) {
    return "live";
  }
  if ((id !== "")) {
    return "live";
  }
  if (ischannelname($lcase(name))) {
    return "live";
  }
  if (hasyear(name)) {
    return "vod";
  }
  return "maybe";
}

function ischannelname(n) {
  return matchany(n, ["24/7", "24-7", "24h", "24 h", "en vivo", " tv", "tv ", "canal", "channel", "hbo", "cinemax", "cinecanal", "cinelatino", "studio universal", "tcm", "golden", "starz", "showtime", "paramount", "amc", "axn", "sony", "warner", "cine mexicano", "cine de oro", "cine clasico", "pasiones", "telehit"]);
}

function hasyear(t) {
  let n, i, $e0, c, okl, okr, alldigits, k, $e1, d;
  n = $len(t);
  if ((n < 4)) {
    return false;
  }
  for (i = 1, $e0 = (n - 3); i <= $e0; i++) {
    c = $mid(t, i, 4);
    if ((((($left(c, 2) === "19") || ($left(c, 2) === "20"))) && ($val(c) > 1929))) {
      okl = ((i === 1));
      if ((!okl)) {
        okl = ((($asc($mid(t, (i - 1), 1)) < 48) || ($asc($mid(t, (i - 1), 1)) > 57)));
      }
      okr = (((i + 3) === n));
      if ((!okr)) {
        okr = ((($asc($mid(t, (i + 4), 1)) < 48) || ($asc($mid(t, (i + 4), 1)) > 57)));
      }
      if (((okl && okr) && ($right($left(c, 4), 1) >= "0"))) {
        alldigits = true;
        for (k = 1, $e1 = 4; k <= $e1; k++) {
          d = $asc($mid(c, k, 1));
          if (((d < 48) || (d > 57))) {
            alldigits = false;
          }
        }
        if (alldigits) {
          return true;
        }
      }
    }
  }
  return false;
}

function classify(group, name, rules) {
  let g, n, both, r, gt, lg;
  g = $lcase(group);
  n = $lcase(name);
  both = ((g + " | ") + n);
  if (($instr(1, both, "adult swim") === 0)) {
    if (matchany(both, rules.adult)) {
      return "Adultos";
    }
  }
  if ((g !== "")) {
    for (r of $iter(rules.list)) {
      if (matchany(g, r.words)) {
        return r.name;
      }
    }
  }
  for (r of $iter(rules.list)) {
    if (matchany(n, r.words)) {
      return r.name;
    }
  }
  gt = group.$trim();
  lg = $lcase(gt);
  if (((((((((gt !== "") && (lg !== "general")) && (lg !== "undefined")) && (lg !== "other")) && (lg !== "otros")) && (lg !== "sin categoria")) && (lg !== "uncategorized")) && (lg !== "unknown"))) {
    return gt;
  }
  return "Otros";
}

function matchany(text, words) {
  let w;
  for (w of $iter(words)) {
    if (($instr(1, text, w) > 0)) {
      return true;
    }
  }
  return false;
}

function isin(arr, value) {
  let v;
  for (v of $iter(arr)) {
    if ((v === value)) {
      return true;
    }
  }
  return false;
}

function buildrules() {
  let rules;
  rules = {__proto__: $AAP};
  rules.adult = ["xxx", "adult", "porn", "erotic", "erotico", "erót", "erÓt", "playboy", "sexy", "18+", "hustler", "brazzers", "penthouse", "sextreme", "redlight", "dorcel"];
  rules.list = [{__proto__: $AAP, "name": "Infantil", "words": ["infantil", "kids", "niños", "niÑos", "ninos", "cartoon", "disney", "nickelodeon", "nick jr", "nick ", "boomerang", "baby", "tooncast", "dibujos", "animaci", "anime", "junior", "peppa", "paw patrol"]}, {__proto__: $AAP, "name": "Deportes", "words": ["deport", "sport", "futbol", "fútbol", "fÚtbol", "soccer", "nba", "nfl", "mlb", "nhl", "ufc", "espn", "tudn", "dazn", "bein", "eurosport", "golf", "tenis", "tennis", "boxeo", "boxing", "wwe", "lucha libre", "motogp", "formula 1", "formula1", "nascar", "racing", "olimp", "laliga", "premier league", "champions", "bundesliga", "gol tv", "caliente tv"]}, {__proto__: $AAP, "name": "Noticias", "words": ["noticia", "news", "informa", "cnn", "bbc", "euronews", "jazeera", "france 24", "france24", "telesur", "milenio", "foro tv", "adn 40", "nmas", "hispantv", "bloomberg", "cnbc", "ntn24", "dw español", "dw news", "rt news", "24 horas", "cgtn", "nhk world", "wion", "noticiero", "reuters"]}, {__proto__: $AAP, "name": "Música", "words": ["musica", "música", "mÚsica", "music", "mtv", "vevo", "radio", "hits", "reggaeton", "salsa", "cumbia", "norteñ", "norteÑ", "concert", "karaoke", "ritmoson", "telehit", "vh1", "stingray", "bachata", "mariachi", "corridos", "ranchero", "rock"]}, {__proto__: $AAP, "name": "Series", "words": ["serie", "novela", "drama", "sitcom"]}, {__proto__: $AAP, "name": "Cine", "words": ["pelic", "pelí", "pelÍ", "cine", "movie", "film", "hbo", "cinemax", "tcm", "paramount", "golden", "starz", "showtime", "estreno", "amc", "axn", "studio universal"]}, {__proto__: $AAP, "name": "Documentales", "words": ["document", "discovery", "history", "historia", "nat geo", "national geographic", "animal planet", "a&e", "ngc", "viajes", "travel", "ciencia", "science", "smithsonian", "planeta", "naturaleza", "nature", "investigation", "dmax", "explora"]}, {__proto__: $AAP, "name": "Entretenimiento", "words": ["entreten", "entertain", "variedad", "comedia", "comedy", "reality", "show", "adult swim", "lifestyle", "cocina", "food", "tlc", "telemundo", "televisa", "azteca", "estrellas", "univision", "unimas", "nu9ve", "canal 5", "lifetime", "fox", "tbs", "tnt", "hgtv", "hogar", "sony", "universal", "warner", "antena 3", "telecinco", "cuatro", "bravo", "multimedios"]}];
  return rules;
}

function titlecommapos(s) {
  let inq, i, $e2, c;
  inq = false;
  for (i = 1, $e2 = $len(s); i <= $e2; i++) {
    c = $mid(s, i, 1);
    if ((c === $chr(34))) {
      inq = (!inq);
    } else if (((c === ",") && (!inq))) {
      return i;
    }
  }
  return 0;
}

function lastpos(s, ch) {
  let result, i, $e3;
  result = 0;
  for (i = 1, $e3 = $len(s); i <= $e3; i++) {
    if (($mid(s, i, 1) === ch)) {
      result = i;
    }
  }
  return result;
}

function firsturl(s) {
  let commaat;
  s = s.$trim();
  commaat = $instr(1, s, ",");
  if ((commaat > 0)) {
    s = $left(s, (commaat - 1));
  }
  return s.$trim();
}

function detectformat(url) {
  let u, qpos;
  u = $lcase(url);
  qpos = $instr(1, u, "?");
  if ((qpos > 0)) {
    u = $left(u, (qpos - 1));
  }
  if (($right(u, 4) === ".mp4")) {
    return "mp4";
  }
  if (($right(u, 4) === ".mkv")) {
    return "mkv";
  }
  if (($right(u, 3) === ".ts")) {
    return "ts";
  }
  return "hls";
}

function seriesof(group, title, url) {
  let u, fmt, vodfmt, gl, sergroup, serurl, ep, nm;
  u = $lcase(url);
  if (($instr(1, u, "/live/") > 0)) {
    return null;
  }
  fmt = detectformat(url);
  vodfmt = (((fmt === "mp4") || (fmt === "mkv")));
  gl = $lcase(group);
  sergroup = (((($instr(1, gl, "serie") > 0) || ($instr(1, gl, "season") > 0)) || ($instr(1, gl, "temporada") > 0)));
  serurl = ((($instr(1, u, "/series/") > 0) || ($instr(1, u, "type=series") > 0)));
  ep = epparse(title);
  if ((ep != null)) {
    if ((((ep.strong || sergroup) || serurl) || vodfmt)) {
      return ep;
    }
    return null;
  }
  if ((((serurl || ((sergroup && vodfmt)))) && (!ischannelname($lcase(title))))) {
    nm = group.$trim();
    if ((nm === "")) {
      nm = "Series";
    }
    return {__proto__: $AAP, "name": nm, "s": 1, "e": 0, "t": title, "strong": false};
  }
  return null;
}
// ---- components/utils.brs ----
function getattr(s, key) {
  let pat, p, okp, vstart, q, e, total, c;
  pat = (key + "=");
  p = $instr(1, s, pat);
  while ((p > 0)) {
    okp = false;
    if ((p === 1)) {
      okp = true;
    } else {
      okp = (($mid(s, (p - 1), 1) === " "));
    }
    if (okp) {
      break;
    }
    p = $instr((p + 1), s, pat);
  }
  if ((p === 0)) {
    return "";
  }
  vstart = (p + $len(pat));
  q = $mid(s, vstart, 1);
  if (((q === $chr(34)) || (q === "'"))) {
    e = $instr((vstart + 1), s, q);
    if ((e === 0)) {
      return "";
    }
    return $mid(s, (vstart + 1), ((e - vstart) - 1));
  }
  total = $len(s);
  e = vstart;
  while ((e <= total)) {
    c = $mid(s, e, 1);
    if (((c === " ") || (c === ","))) {
      break;
    }
    e = (e + 1);
  }
  return $mid(s, vstart, (e - vstart));
}

function normname(s) {
  let out, i, $e0, c, a;
  s = $lcase(s);
  out = "";
  for (i = 1, $e0 = $len(s); i <= $e0; i++) {
    c = $mid(s, i, 1);
    a = $asc(c);
    if (((((a >= 97) && (a <= 122))) || (((a >= 48) && (a <= 57))))) {
      out = (out + c);
    }
  }
  return out;
}

function decodeentities(s) {
  let p, semi, numstr, code, repl;
  p = $instr(1, s, "&#");
  while ((p > 0)) {
    semi = $instr(p, s, ";");
    if (((semi === 0) || ((semi - p) > 8))) {
      break;
    }
    numstr = $mid(s, (p + 2), ((semi - p) - 2));
    code = 0;
    if ((($left(numstr, 1) === "x") || ($left(numstr, 1) === "X"))) {
      code = $val($mid(numstr, 2), 16);
    } else {
      code = $val(numstr, 10);
    }
    repl = "";
    if ((code > 0)) {
      repl = $chr(code);
    }
    s = (($left(s, (p - 1)) + repl) + $mid(s, (semi + 1)));
    p = $instr((p + 1), s, "&#");
  }
  s = s.$replace("&lt;", "<");
  s = s.$replace("&gt;", ">");
  s = s.$replace("&quot;", $chr(34));
  s = s.$replace("&apos;", "'");
  s = s.$replace("&#39;", "'");
  s = s.$replace("&amp;", "&");
  return s;
}

function pad2(n) {
  if ((n < 10)) {
    return ("0" + n.$tostr());
  }
  return n.$tostr();
}

function fmttime(secs) {
  let dt;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  return i18nhm(dt.$gethours(), pad2(dt.$getminutes()), false);
}

function fmttimelong(secs) {
  let dt;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  return i18nhm(dt.$gethours(), pad2(dt.$getminutes()), true);
}

function fmtday(secs) {
  let dt, days, months;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  days = i18ndow3();
  months = i18nmon3();
  return (((($ix(days, dt.$getdayofweek()) + " ") + dt.$getdayofmonth().$tostr()) + " ") + $ix(months, (dt.$getmonth() - 1)));
}

function cleanlogo(u) {
  let low, base, q;
  u = u.$trim();
  if (((u === "") || ($len(u) > 2000))) {
    return "";
  }
  low = $lcase(u);
  if (($left(low, 4) !== "http")) {
    return "";
  }
  base = low;
  q = $instr(1, low, "?");
  if ((q > 0)) {
    base = $left(low, (q - 1));
  }
  if (($right(base, 4) === ".svg")) {
    return "";
  }
  return u;
}

function epgwantedof(root) {
  let wanted, i, $e1, cat, j, $e2, ch, cid, nk;
  wanted = {__proto__: $AAP};
  if ((root == null)) {
    return wanted;
  }
  for (i = 0, $e1 = (root.$getchildcount() - 1); i <= $e1; i++) {
    cat = root.$getchild(i);
    for (j = 0, $e2 = (cat.$getchildcount() - 1); j <= $e2; j++) {
      ch = cat.$getchild(j);
      cid = ch.id;
      if (((cid != null) && (cid !== ""))) {
        $six(wanted, $lcase(cid), true);
      }
      nk = normname(ch.title);
      if ((nk !== "")) {
        $six(wanted, nk, true);
      }
    }
  }
  return wanted;
}
// ---- components/series.brs ----
function epregexes() {
  let b;
  if ((m.eprx == null)) {
    b = "(?:^|[\\s\\.\\-_\\[\\(])";
    m.eprx = [{__proto__: $AAP, "rx": $createobject("roRegex", (b + "S(\\d{1,2})[\\s\\.\\-_]*E(\\d{1,3})(?!\\d)"), "i"), "strong": true}, {__proto__: $AAP, "rx": $createobject("roRegex", (b + "(?:(?:Season|Temporada|Temp)\\.?\\s*|T)(\\d{1,2})[\\s\\.\\-_,]*(?:Episode|Episodio|Cap\\w*|Ep|E)\\.?\\s*(\\d{1,3})(?!\\d)"), "i"), "strong": true}, {__proto__: $AAP, "rx": $createobject("roRegex", (b + "(\\d{1,2})x(\\d{1,3})(?![\\dp])"), "i"), "strong": false}];
  }
  return m.eprx;
}

function epparse(title) {
  let p, r, full, at, nm, rest;
  for (p of $iter(epregexes())) {
    r = p.rx.$match(title);
    if ((r.$count() >= 3)) {
      full = $ix(r, 0);
      at = $instr(1, title, full);
      if ((at > 0)) {
        nm = eptrim($left(title, (at - 1)));
        rest = eptrim($mid(title, (at + $len(full))));
        return {__proto__: $AAP, "name": nm, "s": $val($ix(r, 1)), "e": $val($ix(r, 2)), "t": rest, "strong": p.strong};
      }
    }
  }
  return null;
}

function eptrim(s) {
  let seps;
  s = s.$trim();
  seps = "-:|.,([_ ";
  while ((($len(s) > 0) && ($instr(1, seps, $left(s, 1)) > 0))) {
    s = $mid(s, 2).$trim();
  }
  while ((($len(s) > 0) && ($instr(1, seps, $right(s, 1)) > 0))) {
    s = $left(s, ($len(s) - 1)).$trim();
  }
  return s;
}

function sortkey(t) {
  let s, ff, tt, i, $e0, a;
  s = $lcase(t);
  ff = ["á", "é", "í", "ó", "ú", "ü", "ñ", "Á", "É", "Í", "Ó", "Ú", "Ü", "Ñ"];
  tt = ["a", "e", "i", "o", "u", "u", "n", "a", "e", "i", "o", "u", "u", "n"];
  for (i = 0, $e0 = (ff.$count() - 1); i <= $e0; i++) {
    s = s.$replace($ix(ff, i), $ix(tt, i));
  }
  while (($len(s) > 1)) {
    a = $asc($left(s, 1));
    if (((((a >= 48) && (a <= 57))) || (((a >= 97) && (a <= 122))))) {
      break;
    }
    s = $mid(s, 2);
  }
  return s;
}

function seradd(sd, order, gname, ep, entry) {
  let g, key, rec, sk, num;
  if ((!sd.$doesexist(gname))) {
    $six(sd, gname, {__proto__: $AAP, "order": [], "map": {__proto__: $AAP}});
    order.$push(gname);
  }
  g = $ix(sd, gname);
  key = $lcase(ep.name);
  if ((!g.map.$doesexist(key))) {
    $six(g.map, key, {__proto__: $AAP, "name": ep.name, "poster": "", "seasons": {__proto__: $AAP}, "snums": []});
    g.order.$push(key);
  }
  rec = $ix(g.map, key);
  if (((rec.poster === "") && (entry.l !== ""))) {
    rec.poster = entry.l;
  }
  sk = ep.s.$tostr();
  if ((!rec.seasons.$doesexist(sk))) {
    $six(rec.seasons, sk, []);
    rec.snums.$push(ep.s);
  }
  num = ep.e;
  if ((num <= 0)) {
    num = ($ix(rec.seasons, sk).$count() + 1);
  }
  $ix(rec.seasons, sk).$push({__proto__: $AAP, "e": num, "t": ep.t, "u": entry.u, "f": entry.f, "l": entry.l});
}

function serfill(root, sd, order) {
  let gname, g, arr, key, rec, cat, a, sn, s, season, eps, ep, item;
  for (gname of $iter(order)) {
    g = $ix(sd, gname);
    arr = [];
    for (key of $iter(g.order)) {
      rec = $ix(g.map, key);
      arr.$push({__proto__: $AAP, "k": sortkey(rec.name), "r": rec});
    }
    arr.$sortby("k");
    cat = root.$createchild("ContentNode");
    cat.id = gname;
    cat.title = (((gname + "  (") + arr.$count().$tostr()) + ")");
    for (a of $iter(arr)) {
      rec = a.r;
      sn = cat.$createchild("ContentNode");
      sn.title = rec.name;
      sn.id = $lcase(rec.name);
      sn.hdposterurl = rec.poster;
      sn.description = "series";
      rec.snums.$sort();
      for (s of $iter(rec.snums)) {
        season = sn.$createchild("ContentNode");
        season.id = s.$tostr();
        season.title = (tx("Temporada ") + s.$tostr());
        eps = $ix(rec.seasons, s.$tostr());
        eps.$sortby("e");
        for (ep of $iter(eps)) {
          item = season.$createchild("ContentNode");
          item.title = sereptitle(rec.name, s, ep);
          item.shortdescriptionline2 = ep.t;
          item.url = ep.u;
          item.streamformat = ep.f;
          item.hdposterurl = ep.l;
          item.shortdescriptionline1 = ep.e.$tostr();
          item.description = "movie";
        }
      }
    }
  }
}

function serfilldirect(root, sd, order, seen, favs) {
  let gname, g, arr, key, rec, cat, a, sn, s, eps, season, ep, u, sr, item;
  for (gname of $iter(order)) {
    g = $ix(sd, gname);
    sd.$delete(gname);
    if (((g == null) || ($lcase(gname) === "adultos"))) {
      continue;
    }
    arr = [];
    for (key of $iter(g.order)) {
      rec = $ix(g.map, key);
      arr.$push({__proto__: $AAP, "k": sortkey(rec.name), "r": rec});
    }
    arr.$sortby("k");
    cat = null;
    for (a of $iter(arr)) {
      rec = a.r;
      sn = null;
      rec.snums.$sort();
      for (s of $iter(rec.snums)) {
        eps = $ix(rec.seasons, s.$tostr());
        eps.$sortby("e");
        season = null;
        for (ep of $iter(eps)) {
          u = ep.u;
          if (((u !== "") && (!seen.$doesexist(u)))) {
            $six(seen, u, true);
            if ((cat == null)) {
              cat = root.$createchild("ContentNode");
              cat.id = gname;
            }
            if ((sn == null)) {
              sn = cat.$createchild("ContentNode");
              sn.$setfields({__proto__: $AAP, "title": rec.name, "id": $lcase(rec.name), "hdposterurl": rec.poster, "description": "series"});
            }
            if ((season == null)) {
              season = sn.$createchild("ContentNode");
              season.id = s.$tostr();
              season.title = (tx("Temporada ") + s.$tostr());
            }
            sr = 0;
            if (favs.$doesexist(u)) {
              sr = 100;
            }
            item = season.$createchild("ContentNode");
            item.$setfields({__proto__: $AAP, "title": sereptitle(rec.name, s, ep), "shortdescriptionline2": ep.t, "url": u, "streamformat": ep.f, "hdposterurl": ep.l, "shortdescriptionline1": ep.e.$tostr(), "description": "movie", "starrating": sr});
          }
        }
      }
    }
    if ((cat != null)) {
      cat.title = (((gname + "  (") + cat.$getchildcount().$tostr()) + ")");
    }
  }
}

function sereptitle(name, s, ep) {
  let t;
  t = ((((name + "  T") + s.$tostr()) + " E") + ep.e.$tostr());
  if ((ep.t !== "")) {
    t = ((t + " - ") + ep.t);
  }
  return t;
}
// ---- components/i18n.brs ----
function i18nlangs() {
  return [{__proto__: $AAP, "code": "es", "name": "Español", "flag": "pkg:/images/flag_es.png"}, {__proto__: $AAP, "code": "en", "name": "English", "flag": "pkg:/images/flag_en.png"}, {__proto__: $AAP, "code": "pt", "name": "Português", "flag": "pkg:/images/flag_pt.png"}, {__proto__: $AAP, "code": "fr", "name": "Français", "flag": "pkg:/images/flag_fr.png"}, {__proto__: $AAP, "code": "de", "name": "Deutsch", "flag": "pkg:/images/flag_de.png"}, {__proto__: $AAP, "code": "it", "name": "Italiano", "flag": "pkg:/images/flag_it.png"}];
}

function i18nvalid(code) {
  let l;
  for (l of $iter(i18nlangs())) {
    if ((l.code === code)) {
      return true;
    }
  }
  return false;
}

function i18ndetect() {
  let code, di, loc, c;
  code = "en";
  di = $createobject("roDeviceInfo");
  if ((di != null)) {
    loc = di.$getcurrentlocale();
    if (((loc != null) && ($len(loc) >= 2))) {
      c = $lcase($left(loc, 2));
      if (i18nvalid(c)) {
        code = c;
      }
    }
  }
  return code;
}

function i18nload(lang) {
  let d, txt, arr, p;
  d = $createobject("roAssociativeArray");
  d.$setmodecasesensitive();
  txt = $readasciifile((("pkg:/locale/" + lang) + ".json"));
  if (((txt != null) && (txt !== ""))) {
    arr = $parsejson(txt);
    if ((arr != null)) {
      for (p of $iter(arr)) {
        $six(d, $ix(p, 0), $ix(p, 1));
      }
    }
  }
  m.i18nd = d;
  m.i18nlang = lang;
}

function tx(s) {
  let lang, v;
  lang = m.global.lang;
  if ((lang == null)) {
    return s;
  }
  if ((lang === "es")) {
    return s;
  }
  if ((m.i18nlang == null)) {
    i18nload(lang);
  } else if ((m.i18nlang !== lang)) {
    i18nload(lang);
  }
  v = m.i18nd.$lookup(s);
  if ((v == null)) {
    return s;
  }
  return v;
}

function i18nlang() {
  let l;
  l = m.global.lang;
  if ((l == null)) {
    return "es";
  }
  return l;
}

function i18n24h() {
  let l;
  l = i18nlang();
  return (((l !== "es") && (l !== "en")));
}

function i18ndow3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  }
  if ((l === "pt")) {
    return ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
  }
  if ((l === "fr")) {
    return ["dim.", "lun.", "mar.", "mer.", "jeu.", "ven.", "sam."];
  }
  if ((l === "de")) {
    return ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
  }
  if ((l === "it")) {
    return ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
  }
  return ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
}

function i18nmon3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  }
  if ((l === "pt")) {
    return ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
  }
  if ((l === "fr")) {
    return ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
  }
  if ((l === "de")) {
    return ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];
  }
  if ((l === "it")) {
    return ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"];
  }
  return ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
}

function i18ndowfull() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  }
  if ((l === "pt")) {
    return ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
  }
  if ((l === "fr")) {
    return ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  }
  if ((l === "de")) {
    return ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
  }
  if ((l === "it")) {
    return ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"];
  }
  return ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
}

function i18ncompass() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  }
  if ((l === "pt")) {
    return ["N", "NE", "L", "SE", "S", "SO", "O", "NO"];
  }
  if ((l === "de")) {
    return ["N", "NO", "O", "SO", "S", "SW", "W", "NW"];
  }
  if ((l === "it")) {
    return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
  }
  return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
}

function i18nhm(h, mm, longfmt) {
  let hs, h12, l, suf;
  if (i18n24h()) {
    hs = h.$tostr();
    if ((h < 10)) {
      hs = ("0" + hs);
    }
    return ((hs + ":") + mm);
  }
  h12 = (h % 12);
  if ((h12 === 0)) {
    h12 = 12;
  }
  l = i18nlang();
  if ((l === "en")) {
    suf = " AM";
    if ((h >= 12)) {
      suf = " PM";
    }
    if ((!longfmt)) {
      suf = "a";
      if ((h >= 12)) {
        suf = "p";
      }
    }
    return (((h12.$tostr() + ":") + mm) + suf);
  }
  if (longfmt) {
    suf = " a. m.";
    if ((h >= 12)) {
      suf = " p. m.";
    }
  } else {
    suf = "a";
    if ((h >= 12)) {
      suf = "p";
    }
  }
  return (((h12.$tostr() + ":") + mm) + suf);
}
return {"init": init, "getcontent": getcontent, "buildadult": buildadult, "addtogroup": addtogroup, "newhttp": newhttp, "filltreedirect": filltreedirect, "filltree": filltree, "vodkind": vodkind, "ischannelname": ischannelname, "hasyear": hasyear, "classify": classify, "matchany": matchany, "isin": isin, "buildrules": buildrules, "titlecommapos": titlecommapos, "lastpos": lastpos, "firsturl": firsturl, "detectformat": detectformat, "seriesof": seriesof, "getattr": getattr, "normname": normname, "decodeentities": decodeentities, "pad2": pad2, "fmttime": fmttime, "fmttimelong": fmttimelong, "fmtday": fmtday, "cleanlogo": cleanlogo, "epgwantedof": epgwantedof, "epregexes": epregexes, "epparse": epparse, "eptrim": eptrim, "sortkey": sortkey, "seradd": seradd, "serfill": serfill, "serfilldirect": serfilldirect, "sereptitle": sereptitle, "i18nlangs": i18nlangs, "i18nvalid": i18nvalid, "i18ndetect": i18ndetect, "i18nload": i18nload, "tx": tx, "i18nlang": i18nlang, "i18n24h": i18n24h, "i18ndow3": i18ndow3, "i18nmon3": i18nmon3, "i18ndowfull": i18ndowfull, "i18ncompass": i18ncompass, "i18nhm": i18nhm};
});

$defineComponent({"name":"EpgReader","extends":"Task","fields":[{"id":"epgurl","type":"string"},{"id":"wanted","type":"assocarray"},{"id":"status","type":"string"},{"id":"result","type":"assocarray"}],"children":[]}, function (m) {
// ---- components/epgreader.brs ----
function init() {
  m.top.functionname = "readGuide";
}

function readguide() {
  let result, url, nowcache, cachepath, sig, hit, path, fs, http, code, stat, size, ba, kind, parts, msg, nowsecs, chunksize, carry, partpath, psize, offset, n, chunk, text, resume, total, key, arr;
  result = {__proto__: $AAP, "ok": false, "message": "", "programs": {__proto__: $AAP}, "names": {__proto__: $AAP}, "icons": {__proto__: $AAP}, "count": 0, "updated": 0};
  url = m.top.epgurl;
  if (((url == null) || (url === ""))) {
    result.message = tx("esta lista no trae URL de guia");
    m.top.result = result;
    return;
  }
  nowcache = $createobject("roDateTime").$asseconds();
  cachepath = epgcachepath(url);
  sig = "0";
  if ((m.top.wanted != null)) {
    sig = m.top.wanted.$count().$tostr();
  }
  hit = epgcacheload(cachepath, sig, nowcache);
  if ((hit != null)) {
    m.top.status = tx("Guia: lista (cargada desde la memoria)");
    m.top.result = hit;
    return;
  }
  path = "tmp:/epg_guide.xml";
  fs = $createobject("roFileSystem");
  if (fs.$exists(path)) {
    fs.$delete(path);
  }
  http = $createobject("roUrlTransfer");
  http.$setcertificatesfile("common:/certs/ca-bundle.crt");
  http.$initclientcertificates();
  http.$enableencodings(true);
  http.$seturl(url);
  code = http.$gettofile(path);
  if ((code !== 200)) {
    result.message = ((tx("no se pudo descargar (codigo ") + code.$tostr()) + ")");
    m.top.result = result;
    return;
  }
  stat = fs.$stat(path);
  if ((stat == null)) {
    result.message = tx("no se pudo leer el archivo descargado");
    m.top.result = result;
    return;
  }
  size = stat.size;
  ba = $createobject("roByteArray");
  kind = filekind(path);
  parts = null;
  if ((kind === "gzip")) {
    parts = gunziptoparts(path);
    fs.$delete(path);
    if ((parts == null)) {
      msg = tx("no se pudo descomprimir la guia .gz");
      if (((m.gzerr != null) && (m.gzerr !== ""))) {
        msg = m.gzerr;
      }
      result.message = msg;
      m.top.result = result;
      return;
    }
  } else if ((kind !== "xml")) {
    fs.$delete(path);
    result.message = tx("el archivo de guia no parece un XML");
    m.top.result = result;
    return;
  } else {
    if ((size > 60000000)) {
      fs.$delete(path);
      result.message = tx("el archivo de guia es demasiado grande");
      m.top.result = result;
      return;
    }
    parts = [];
    parts.$push(path);
  }
  m.dt = $createobject("roDateTime");
  nowsecs = m.dt.$asseconds();
  m.minend = (nowsecs - 1800);
  m.maxstart = (nowsecs + 129600);
  m.wanted = m.top.wanted;
  if ((m.wanted == null)) {
    m.wanted = {__proto__: $AAP};
  }
  m.interest = {__proto__: $AAP};
  m.names = {__proto__: $AAP};
  m.programs = {__proto__: $AAP};
  m.icons = {__proto__: $AAP};
  m.top.status = tx("Guia: leyendo programacion...");
  chunksize = 262144;
  carry = "";
  for (partpath of $iter(parts)) {
    stat = fs.$stat(partpath);
    if ((stat == null)) {
      break;
    }
    psize = stat.size;
    offset = 0;
    while ((offset < psize)) {
      n = chunksize;
      if (((offset + n) > psize)) {
        n = (psize - offset);
      }
      chunk = $createobject("roByteArray");
      if ((!chunk.$readfile(partpath, offset, n))) {
        break;
      }
      offset = (offset + n);
      text = (carry + chunk.$toasciistring());
      resume = processtext(text);
      carry = $mid(text, resume);
    }
    fs.$delete(partpath);
  }
  total = 0;
  for (key of $iter(m.programs)) {
    arr = $ix(m.programs, key);
    arr.$sortby("s");
    total = (total + arr.$count());
  }
  if ((total === 0)) {
    result.message = tx("la guia no trae programacion para los canales de tu lista (revisa los tvg-id)");
    m.top.result = result;
    return;
  }
  result.ok = true;
  result.programs = m.programs;
  result.names = m.names;
  result.icons = m.icons;
  result.count = m.programs.$count();
  result.updated = nowsecs;
  epgcachesave(cachepath, sig, nowsecs, total, m.programs, m.names, m.icons);
  m.top.result = result;
}

function epgcachepath(url) {
  let ba, dg;
  ba = $createobject("roByteArray");
  ba.$fromasciistring(url);
  dg = $createobject("roEVPDigest");
  dg.$setup("md5");
  return (("cachefs:/epg_" + dg.$process(ba)) + ".json");
}

function epgcacheload(path, sig, nowsecs) {
  let fs, st, txt, d, age, names, icons;
  fs = $createobject("roFileSystem");
  if ((!fs.$exists(path))) {
    return null;
  }
  st = fs.$stat(path);
  if ((st == null)) {
    return null;
  }
  if (((st.size < 30) || (st.size > 16000000))) {
    fs.$delete(path);
    return null;
  }
  txt = $readasciifile(path);
  if (((txt == null) || (txt === ""))) {
    return null;
  }
  d = $parsejson(txt);
  txt = null;
  if (((d == null) || ($type(d) !== "roAssociativeArray"))) {
    return null;
  }
  if ((((!d.$doesexist("sig")) || (!d.$doesexist("updated"))) || (!d.$doesexist("programs")))) {
    return null;
  }
  if ((d.sig !== sig)) {
    return null;
  }
  age = (nowsecs - d.updated);
  if (((age < (-300)) || (age > 21600))) {
    return null;
  }
  if ((($type(d.programs) !== "roAssociativeArray") || (d.programs.$count() === 0))) {
    return null;
  }
  names = {__proto__: $AAP};
  icons = {__proto__: $AAP};
  if ((d.$doesexist("names") && ($type(d.names) === "roAssociativeArray"))) {
    names = d.names;
  }
  if ((d.$doesexist("icons") && ($type(d.icons) === "roAssociativeArray"))) {
    icons = d.icons;
  }
  return {__proto__: $AAP, "ok": true, "message": "", "programs": d.programs, "names": names, "icons": icons, "count": d.programs.$count(), "updated": d.updated};
}

function epgcachesave(path, sig, nowsecs, total, programs, names, icons) {
  let js;
  if ((total > 45000)) {
    return;
  }
  js = $formatjson({__proto__: $AAP, "v": 1, "sig": sig, "updated": nowsecs, "programs": programs, "names": names, "icons": icons});
  if (((js === "") || ($len(js) > 15000000))) {
    return;
  }
  $writeasciifile(path, js);
}

function processtext(text) {
  let p, cpos, gpos, ischannel, closepos;
  p = 1;
  while (true) {
    cpos = $instr(p, text, "<channel ");
    gpos = $instr(p, text, "<programme ");
    if (((cpos === 0) && (gpos === 0))) {
      break;
    }
    ischannel = false;
    if (((cpos > 0) && (((gpos === 0) || (cpos < gpos))))) {
      ischannel = true;
    }
    if (ischannel) {
      closepos = $instr(cpos, text, "</channel>");
      if ((closepos === 0)) {
        return cpos;
      }
      handlechannel($mid(text, cpos, ((closepos - cpos) + 10)));
      p = (closepos + 10);
    } else {
      closepos = $instr(gpos, text, "</programme>");
      if ((closepos === 0)) {
        return gpos;
      }
      handleprogramme($mid(text, gpos, ((closepos - gpos) + 12)));
      p = (closepos + 12);
    }
  }
  return p;
}

function handlechannel(block) {
  let gt, head, id, iswanted, namekeys, p, a, g, b, raw, nm, nk, icon;
  gt = $instr(1, block, ">");
  if ((gt === 0)) {
    return;
  }
  head = $left(block, gt);
  id = $lcase(getattr(head, "id"));
  if ((id === "")) {
    return;
  }
  iswanted = m.wanted.$doesexist(id);
  namekeys = [];
  p = 1;
  while (true) {
    a = $instr(p, block, "<display-name");
    if ((a === 0)) {
      break;
    }
    g = $instr(a, block, ">");
    if ((g === 0)) {
      break;
    }
    b = $instr(g, block, "</display-name>");
    if ((b === 0)) {
      break;
    }
    raw = $mid(block, (g + 1), ((b - g) - 1));
    nm = decodeentities(raw.$trim());
    nk = normname(nm);
    if ((nk !== "")) {
      namekeys.$push(nk);
      if (m.wanted.$doesexist(nk)) {
        iswanted = true;
      }
    }
    p = (b + 15);
  }
  if (iswanted) {
    $six(m.interest, id, true);
    icon = channelicon(block);
    if ((icon !== "")) {
      $six(m.icons, id, icon);
    }
    for (nk of $iter(namekeys)) {
      $six(m.names, nk, id);
    }
  }
}

function channelicon(block) {
  let ip, close;
  ip = $instr(1, block, "<icon");
  if ((ip === 0)) {
    return "";
  }
  close = $instr(ip, block, ">");
  if ((close === 0)) {
    return "";
  }
  return cleanlogo(decodeentities(getattr($mid(block, ip, ((close - ip) + 1)), "src")));
}

function handleprogramme(block) {
  let gt, head, chan, s, e, t, d;
  gt = $instr(1, block, ">");
  if ((gt === 0)) {
    return;
  }
  head = $left(block, gt);
  chan = $lcase(getattr(head, "channel"));
  if ((chan === "")) {
    return;
  }
  if ((!m.interest.$doesexist(chan))) {
    return;
  }
  s = parsexmltvtime(getattr(head, "start"));
  e = parsexmltvtime(getattr(head, "stop"));
  if ((s === 0)) {
    return;
  }
  if ((e === 0)) {
    e = (s + 1800);
  }
  if (((e < m.minend) || (s > m.maxstart))) {
    return;
  }
  t = tagtext(block, "title");
  if ((t === "")) {
    t = tx("Sin titulo");
  }
  d = tagtext(block, "desc");
  if (($len(d) > 260)) {
    d = ($left(d, 257) + "...");
  }
  if ((!m.programs.$doesexist(chan))) {
    $six(m.programs, chan, []);
  }
  $ix(m.programs, chan).$push({__proto__: $AAP, "s": s, "e": e, "t": t, "d": d});
}

function tagtext(block, tag) {
  let p, gt, closepos, txt;
  p = $instr(1, block, ("<" + tag));
  if ((p === 0)) {
    return "";
  }
  gt = $instr(p, block, ">");
  if ((gt === 0)) {
    return "";
  }
  closepos = $instr(gt, block, (("</" + tag) + ">"));
  if ((closepos === 0)) {
    return "";
  }
  txt = $mid(block, (gt + 1), ((closepos - gt) - 1));
  return decodeentities(txt.$trim());
}

function parsexmltvtime(str) {
  let base, offstr, sp, rest, sec, iso, secs, sign, hh, mm, off;
  if ((str === "")) {
    return 0;
  }
  base = str;
  offstr = "";
  sp = $instr(1, str, " ");
  if ((sp > 0)) {
    base = $left(str, (sp - 1));
    rest = $mid(str, (sp + 1));
    offstr = rest.$trim();
  }
  if (($len(base) < 12)) {
    return 0;
  }
  sec = "00";
  if (($len(base) >= 14)) {
    sec = $mid(base, 13, 2);
  }
  iso = ((((((((((($left(base, 4) + "-") + $mid(base, 5, 2)) + "-") + $mid(base, 7, 2)) + "T") + $mid(base, 9, 2)) + ":") + $mid(base, 11, 2)) + ":") + sec) + "Z");
  m.dt.$fromiso8601string(iso);
  secs = m.dt.$asseconds();
  if (($len(offstr) >= 5)) {
    sign = $left(offstr, 1);
    hh = $val($mid(offstr, 2, 2), 10);
    mm = $val($mid(offstr, 4, 2), 10);
    off = ((hh * 3600) + (mm * 60));
    if ((sign === "-")) {
      secs = (secs + off);
    } else if ((sign === "+")) {
      secs = (secs - off);
    }
  }
  return secs;
}
// ---- components/gunzip.brs ----
function filekind(path) {
  let ba, n, i, c;
  ba = $createobject("roByteArray");
  if ($not(ba.$readfile(path, 0, 80))) {
    return "other";
  }
  n = ba.$count();
  if ($and($and((n >= 2), ($ix(ba, 0) === 31)), ($ix(ba, 1) === 139))) {
    return "gzip";
  }
  i = 0;
  while ((i < n)) {
    c = $ix(ba, i);
    if ($and($and($and((c !== 32), (c !== 9)), (c !== 10)), (c !== 13))) {
      break;
    }
    i = (i + 1);
  }
  if ($and($and($and(((i + 2) < n), ($ix(ba, i) === 239)), ($ix(ba, (i + 1)) === 187)), ($ix(ba, (i + 2)) === 191))) {
    i = (i + 3);
  }
  if ($and((i < n), ($ix(ba, i) === 60))) {
    return "xml";
  }
  return "other";
}

function gunziptoparts(srcpath) {
  let fs, stat, i, $e0, oldp, $e1;
  m.gzerr = "";
  m.gzpath = srcpath;
  fs = $createobject("roFileSystem");
  stat = fs.$stat(srcpath);
  if ((stat == null)) {
    m.gzerr = "no se pudo leer la guia comprimida";
    return null;
  }
  m.gzsize = stat.size;
  if ((m.gzsize < 10)) {
    m.gzerr = "el archivo .gz esta vacio o incompleto";
    return null;
  }
  if ((m.gzsize > 25000000)) {
    m.gzerr = "la guia comprimida es demasiado grande";
    return null;
  }
  for (i = 0, $e0 = 250; i <= $e0; i++) {
    oldp = ("tmp:/epgp" + i.$tostr());
    if (fs.$exists(oldp)) {
      fs.$delete(oldp);
    }
  }
  m.gzpos = 0;
  m.gzcachepos = 0;
  m.gzcachelen = 0;
  m.gzcache = $createobject("roByteArray");
  m.gzbuf = 0;
  m.gzn = 0;
  m.winpos = 0;
  m.totalout = 0;
  m.outcount = 0;
  m.out = $createobject("roByteArray");
  m.partseq = 0;
  m.partpaths = [];
  m.win = $createobject("roByteArray");
  for (i = 0, $e1 = 32767; i <= $e1; i++) {
    m.win.$push(0);
  }
  gzinittables();
  m.top.status = "Guia: descomprimiendo .gz...";
  if ($not(gzheader())) {
    return gzfail();
  }
  if ($not(gzblocks())) {
    return gzfail();
  }
  if ($not(gzflush())) {
    return gzfail();
  }
  if ((m.gzerr !== "")) {
    return gzfail();
  }
  if ((m.totalout === 0)) {
    m.gzerr = "la guia comprimida no traia datos";
    return gzfail();
  }
  return m.partpaths;
}

function gzfail() {
  let fs, p;
  fs = $createobject("roFileSystem");
  if ((m.partpaths != null)) {
    for (p of $iter(m.partpaths)) {
      if (fs.$exists(p)) {
        fs.$delete(p);
      }
    }
  }
  return null;
}

function gzinittables() {
  m.lenbase = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
  m.lenextra = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
  m.distbase = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
  m.distextra = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];
  m.clorder = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];
}

function gzpull() {
  let n, b;
  if ((m.gzcachepos >= m.gzcachelen)) {
    if ((m.gzpos >= m.gzsize)) {
      return (-1);
    }
    n = 8192;
    if (((m.gzpos + n) > m.gzsize)) {
      n = (m.gzsize - m.gzpos);
    }
    m.gzcache = $createobject("roByteArray");
    if ($not(m.gzcache.$readfile(m.gzpath, m.gzpos, n))) {
      return (-1);
    }
    m.gzpos = (m.gzpos + n);
    m.gzcachelen = n;
    m.gzcachepos = 0;
  }
  b = $ix(m.gzcache, m.gzcachepos);
  m.gzcachepos = (m.gzcachepos + 1);
  return b;
}

function gzbits(n) {
  let b, mask, v;
  if ((m.gzerr !== "")) {
    return (-1);
  }
  while ((m.gzn < n)) {
    b = gzpull();
    if ((b < 0)) {
      m.gzerr = "la guia .gz esta cortada";
      return (-1);
    }
    m.gzbuf = (m.gzbuf + ((b << m.gzn)));
    m.gzn = (m.gzn + 8);
  }
  if ((n === 0)) {
    return 0;
  }
  mask = (((1 << n)) - 1);
  v = $and(m.gzbuf, mask);
  m.gzbuf = (m.gzbuf >> n);
  m.gzn = (m.gzn - n);
  return v;
}

function gzpeek(n) {
  let b, mask;
  if ((m.gzerr !== "")) {
    return (-1);
  }
  while ((m.gzn < n)) {
    b = gzpull();
    if ((b < 0)) {
      m.gzerr = "la guia .gz esta cortada";
      return (-1);
    }
    m.gzbuf = (m.gzbuf + ((b << m.gzn)));
    m.gzn = (m.gzn + 8);
  }
  mask = (((1 << n)) - 1);
  return $and(m.gzbuf, mask);
}

function gzalign() {
  m.gzbuf = 0;
  m.gzn = 0;
}

function gzemit(b) {
  $six(m.win, m.winpos, b);
  m.winpos = (m.winpos + 1);
  if ((m.winpos === 32768)) {
    m.winpos = 0;
  }
  $six(m.out, m.outcount, b);
  m.outcount = (m.outcount + 1);
  m.totalout = (m.totalout + 1);
  if ((m.totalout > 60000000)) {
    m.gzerr = "la guia descomprimida es demasiado grande";
    return false;
  }
  if ((m.outcount >= 262144)) {
    return gzflush();
  }
  return true;
}

function gzflush() {
  let path, mb;
  if ((m.outcount <= 0)) {
    return true;
  }
  path = ("tmp:/epgp" + m.partseq.$tostr());
  m.partseq = (m.partseq + 1);
  if ($not(m.out.$writefile(path))) {
    m.gzerr = "no hubo espacio para descomprimir la guia";
    return false;
  }
  m.partpaths.$push(path);
  m.out = $createobject("roByteArray");
  m.outcount = 0;
  mb = $idiv(m.totalout, 1000000);
  m.top.status = (("Guia: descomprimiendo .gz (" + mb.$tostr()) + " MB)...");
  return true;
}

function gzwinbyte(dist) {
  let idx;
  idx = (m.winpos - dist);
  while ((idx < 0)) {
    idx = (idx + 32768);
  }
  return $ix(m.win, idx);
}

function gznewtree() {
  let t;
  t = {__proto__: $AAP};
  t.l = [(-1)];
  t.r = [(-1)];
  t.s = [(-1)];
  return t;
}

function gzaddnode(t) {
  t.l.$push((-1));
  t.r.$push((-1));
  t.s.$push((-1));
  return (t.s.$count() - 1);
}

function gzbuildtree(lengths) {
  let bl, i, $e2, $e3, l, nextc, $e4, code, b, $e5, t, sym, $e6, c, idx, bit, $e7, bb, leaf, fast, $e8, ok, consumed, bitpos, $e9;
  bl = [];
  for (i = 0, $e2 = 15; i <= $e2; i++) {
    bl.$push(0);
  }
  for (i = 0, $e3 = (lengths.$count() - 1); i <= $e3; i++) {
    l = $ix(lengths, i);
    if ((l > 0)) {
      $six(bl, l, ($ix(bl, l) + 1));
    }
  }
  nextc = [];
  for (i = 0, $e4 = 15; i <= $e4; i++) {
    nextc.$push(0);
  }
  code = 0;
  $six(bl, 0, 0);
  for (b = 1, $e5 = 15; b <= $e5; b++) {
    code = (((code + $ix(bl, (b - 1)))) << 1);
    $six(nextc, b, code);
  }
  t = gznewtree();
  for (sym = 0, $e6 = (lengths.$count() - 1); sym <= $e6; sym++) {
    l = $ix(lengths, sym);
    if ((l > 0)) {
      c = $ix(nextc, l);
      $six(nextc, l, (c + 1));
      idx = 0;
      for (bit = (l - 1), $e7 = 0; bit >= $e7; bit--) {
        bb = $and(((c >> bit)), 1);
        if ((bit === 0)) {
          if ((bb === 0)) {
            if (($ix(t.l, idx) < 0)) {
              $six(t.l, idx, gzaddnode(t));
            }
            leaf = $ix(t.l, idx);
          } else {
            if (($ix(t.r, idx) < 0)) {
              $six(t.r, idx, gzaddnode(t));
            }
            leaf = $ix(t.r, idx);
          }
          $six(t.s, leaf, sym);
        } else {
          if ((bb === 0)) {
            if (($ix(t.l, idx) < 0)) {
              $six(t.l, idx, gzaddnode(t));
            }
            idx = $ix(t.l, idx);
          } else {
            if (($ix(t.r, idx) < 0)) {
              $six(t.r, idx, gzaddnode(t));
            }
            idx = $ix(t.r, idx);
          }
        }
      }
    }
  }
  fast = [];
  for (i = 0, $e8 = 4095; i <= $e8; i++) {
    idx = 0;
    ok = true;
    consumed = 0;
    for (bitpos = 0, $e9 = 11; bitpos <= $e9; bitpos++) {
      if (($ix(t.s, idx) >= 0)) {
        break;
      }
      bb = $and(((i >> bitpos)), 1);
      if ((bb === 0)) {
        idx = $ix(t.l, idx);
      } else {
        idx = $ix(t.r, idx);
      }
      consumed = (bitpos + 1);
      if ((idx < 0)) {
        ok = false;
        break;
      }
    }
    if ($and($and(ok, (idx >= 0)), ($ix(t.s, idx) >= 0))) {
      fast.$push(((consumed * 65536) + $ix(t.s, idx)));
    } else {
      fast.$push((-1));
    }
  }
  t.f = fast;
  return t;
}

function gzdecode(t) {
  let p, e, nbits, idx, guard, $e10, b;
  p = gzpeek(12);
  if ((p < 0)) {
    return (-1);
  }
  e = $ix(t.f, p);
  if ((e >= 0)) {
    nbits = $idiv(e, 65536);
    if ($and((gzbits(nbits) < 0), (nbits > 0))) {
      return (-1);
    }
    return (e % 65536);
  }
  idx = 0;
  for (guard = 1, $e10 = 16; guard <= $e10; guard++) {
    if (($ix(t.s, idx) >= 0)) {
      return $ix(t.s, idx);
    }
    b = gzbits(1);
    if ((b < 0)) {
      return (-1);
    }
    if ((b === 0)) {
      idx = $ix(t.l, idx);
    } else {
      idx = $ix(t.r, idx);
    }
    if ((idx < 0)) {
      m.gzerr = "no se pudo descomprimir la guia .gz";
      return (-1);
    }
  }
  m.gzerr = "no se pudo descomprimir la guia .gz";
  return (-1);
}

function gzfixedlit() {
  let a, i, $e11, $e12, $e13, $e14;
  a = [];
  for (i = 0, $e11 = 143; i <= $e11; i++) {
    a.$push(8);
  }
  for (i = 144, $e12 = 255; i <= $e12; i++) {
    a.$push(9);
  }
  for (i = 256, $e13 = 279; i <= $e13; i++) {
    a.$push(7);
  }
  for (i = 280, $e14 = 287; i <= $e14; i++) {
    a.$push(8);
  }
  return a;
}

function gzfixeddist() {
  let a, i, $e15;
  a = [];
  for (i = 0, $e15 = 31; i <= $e15; i++) {
    a.$push(5);
  }
  return a;
}

function gzblock(lit, dist) {
  let sym, li, extra, length, ds, dex, d, i, $e16;
  while ((m.gzerr === "")) {
    sym = gzdecode(lit);
    if ((sym < 0)) {
      return false;
    }
    if ((sym < 256)) {
      if ($not(gzemit(sym))) {
        return false;
      }
    } else if ((sym === 256)) {
      return true;
    } else {
      if ($or((sym < 257), (sym > 285))) {
        m.gzerr = "no se pudo descomprimir la guia .gz";
        return false;
      }
      li = (sym - 257);
      extra = gzbits($ix(m.lenextra, li));
      if ((extra < 0)) {
        return false;
      }
      length = ($ix(m.lenbase, li) + extra);
      ds = gzdecode(dist);
      if ($or((ds < 0), (ds > 29))) {
        m.gzerr = "no se pudo descomprimir la guia .gz";
        return false;
      }
      dex = gzbits($ix(m.distextra, ds));
      if ((dex < 0)) {
        return false;
      }
      d = ($ix(m.distbase, ds) + dex);
      for (i = 1, $e16 = length; i <= $e16; i++) {
        if ($not(gzemit(gzwinbyte(d)))) {
          return false;
        }
      }
    }
  }
  return false;
}

function gzheader() {
  let flg, i, $e17, xlen, xlen2, $e18, c;
  if ($or((gzbits(8) !== 31), (gzbits(8) !== 139))) {
    m.gzerr = "el archivo no es un .gz valido";
    return false;
  }
  if ((gzbits(8) !== 8)) {
    m.gzerr = "ese .gz usa un metodo que la TV no puede abrir";
    return false;
  }
  flg = gzbits(8);
  if ((flg < 0)) {
    return false;
  }
  for (i = 1, $e17 = 6; i <= $e17; i++) {
    if ((gzbits(8) < 0)) {
      return false;
    }
  }
  if ((($and(flg, 4)) !== 0)) {
    xlen = gzbits(8);
    xlen2 = gzbits(8);
    if ($or((xlen < 0), (xlen2 < 0))) {
      return false;
    }
    xlen = (xlen + (xlen2 * 256));
    for (i = 1, $e18 = xlen; i <= $e18; i++) {
      if ((gzbits(8) < 0)) {
        return false;
      }
    }
  }
  if ((($and(flg, 8)) !== 0)) {
    c = gzbits(8);
    if ((c < 0)) {
      return false;
    }
    while ((c > 0)) {
      c = gzbits(8);
      if ((c < 0)) {
        return false;
      }
    }
  }
  if ((($and(flg, 16)) !== 0)) {
    c = gzbits(8);
    if ((c < 0)) {
      return false;
    }
    while ((c > 0)) {
      c = gzbits(8);
      if ((c < 0)) {
        return false;
      }
    }
  }
  if ((($and(flg, 2)) !== 0)) {
    if ($or((gzbits(8) < 0), (gzbits(8) < 0))) {
      return false;
    }
  }
  return (m.gzerr === "");
}

function gzblocks() {
  let bfinal, btype, ln, ln2, i, $e19, by, hlit, hdist, hclen, cl, $e20, $e21, v, clt, total, lens, $e22, filled, prev, s, rep, k, $e23, $e24, $e25, litlens, $e26, distlens, $e27;
  while ((m.gzerr === "")) {
    bfinal = gzbits(1);
    btype = gzbits(2);
    if ($or((bfinal < 0), (btype < 0))) {
      return false;
    }
    if ((btype === 0)) {
      gzalign();
      ln = gzbits(8);
      ln2 = gzbits(8);
      if ($or($or($or((ln < 0), (ln2 < 0)), (gzbits(8) < 0)), (gzbits(8) < 0))) {
        return false;
      }
      ln = (ln + (ln2 * 256));
      for (i = 1, $e19 = ln; i <= $e19; i++) {
        by = gzbits(8);
        if ((by < 0)) {
          return false;
        }
        if ($not(gzemit(by))) {
          return false;
        }
      }
    } else if ((btype === 1)) {
      if ((m.fixedlittree == null)) {
        m.fixedlittree = gzbuildtree(gzfixedlit());
        m.fixeddisttree = gzbuildtree(gzfixeddist());
      }
      if ($not(gzblock(m.fixedlittree, m.fixeddisttree))) {
        return false;
      }
    } else if ((btype === 2)) {
      hlit = (gzbits(5) + 257);
      hdist = (gzbits(5) + 1);
      hclen = (gzbits(4) + 4);
      if ((m.gzerr !== "")) {
        return false;
      }
      cl = [];
      for (i = 0, $e20 = 18; i <= $e20; i++) {
        cl.$push(0);
      }
      for (i = 0, $e21 = (hclen - 1); i <= $e21; i++) {
        v = gzbits(3);
        if ((v < 0)) {
          return false;
        }
        $six(cl, $ix(m.clorder, i), v);
      }
      clt = gzbuildtree(cl);
      total = (hlit + hdist);
      lens = [];
      for (i = 0, $e22 = (total - 1); i <= $e22; i++) {
        lens.$push(0);
      }
      filled = 0;
      prev = 0;
      while ((filled < total)) {
        s = gzdecode(clt);
        if ((s < 0)) {
          return false;
        }
        if ((s < 16)) {
          $six(lens, filled, s);
          prev = s;
          filled = (filled + 1);
        } else if ((s === 16)) {
          rep = (gzbits(2) + 3);
          if ((rep < 3)) {
            return false;
          }
          if (((filled + rep) > total)) {
            m.gzerr = "no se pudo descomprimir la guia .gz";
            return false;
          }
          for (k = 1, $e23 = rep; k <= $e23; k++) {
            $six(lens, filled, prev);
            filled = (filled + 1);
          }
        } else if ((s === 17)) {
          rep = (gzbits(3) + 3);
          if ((rep < 3)) {
            return false;
          }
          if (((filled + rep) > total)) {
            m.gzerr = "no se pudo descomprimir la guia .gz";
            return false;
          }
          for (k = 1, $e24 = rep; k <= $e24; k++) {
            $six(lens, filled, 0);
            filled = (filled + 1);
          }
        } else if ((s === 18)) {
          rep = (gzbits(7) + 11);
          if ((rep < 11)) {
            return false;
          }
          if (((filled + rep) > total)) {
            m.gzerr = "no se pudo descomprimir la guia .gz";
            return false;
          }
          for (k = 1, $e25 = rep; k <= $e25; k++) {
            $six(lens, filled, 0);
            filled = (filled + 1);
          }
        } else {
          m.gzerr = "no se pudo descomprimir la guia .gz";
          return false;
        }
      }
      litlens = [];
      for (i = 0, $e26 = (hlit - 1); i <= $e26; i++) {
        litlens.$push($ix(lens, i));
      }
      distlens = [];
      for (i = 0, $e27 = (hdist - 1); i <= $e27; i++) {
        distlens.$push($ix(lens, (hlit + i)));
      }
      if ($not(gzblock(gzbuildtree(litlens), gzbuildtree(distlens)))) {
        return false;
      }
    } else {
      m.gzerr = "no se pudo descomprimir la guia .gz";
      return false;
    }
    if ((bfinal === 1)) {
      return true;
    }
  }
  return false;
}
// ---- components/utils.brs ----
function getattr(s, key) {
  let pat, p, okp, vstart, q, e, total, c;
  pat = (key + "=");
  p = $instr(1, s, pat);
  while ((p > 0)) {
    okp = false;
    if ((p === 1)) {
      okp = true;
    } else {
      okp = (($mid(s, (p - 1), 1) === " "));
    }
    if (okp) {
      break;
    }
    p = $instr((p + 1), s, pat);
  }
  if ((p === 0)) {
    return "";
  }
  vstart = (p + $len(pat));
  q = $mid(s, vstart, 1);
  if (((q === $chr(34)) || (q === "'"))) {
    e = $instr((vstart + 1), s, q);
    if ((e === 0)) {
      return "";
    }
    return $mid(s, (vstart + 1), ((e - vstart) - 1));
  }
  total = $len(s);
  e = vstart;
  while ((e <= total)) {
    c = $mid(s, e, 1);
    if (((c === " ") || (c === ","))) {
      break;
    }
    e = (e + 1);
  }
  return $mid(s, vstart, (e - vstart));
}

function normname(s) {
  let out, i, $e0, c, a;
  s = $lcase(s);
  out = "";
  for (i = 1, $e0 = $len(s); i <= $e0; i++) {
    c = $mid(s, i, 1);
    a = $asc(c);
    if (((((a >= 97) && (a <= 122))) || (((a >= 48) && (a <= 57))))) {
      out = (out + c);
    }
  }
  return out;
}

function decodeentities(s) {
  let p, semi, numstr, code, repl;
  p = $instr(1, s, "&#");
  while ((p > 0)) {
    semi = $instr(p, s, ";");
    if (((semi === 0) || ((semi - p) > 8))) {
      break;
    }
    numstr = $mid(s, (p + 2), ((semi - p) - 2));
    code = 0;
    if ((($left(numstr, 1) === "x") || ($left(numstr, 1) === "X"))) {
      code = $val($mid(numstr, 2), 16);
    } else {
      code = $val(numstr, 10);
    }
    repl = "";
    if ((code > 0)) {
      repl = $chr(code);
    }
    s = (($left(s, (p - 1)) + repl) + $mid(s, (semi + 1)));
    p = $instr((p + 1), s, "&#");
  }
  s = s.$replace("&lt;", "<");
  s = s.$replace("&gt;", ">");
  s = s.$replace("&quot;", $chr(34));
  s = s.$replace("&apos;", "'");
  s = s.$replace("&#39;", "'");
  s = s.$replace("&amp;", "&");
  return s;
}

function pad2(n) {
  if ((n < 10)) {
    return ("0" + n.$tostr());
  }
  return n.$tostr();
}

function fmttime(secs) {
  let dt;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  return i18nhm(dt.$gethours(), pad2(dt.$getminutes()), false);
}

function fmttimelong(secs) {
  let dt;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  return i18nhm(dt.$gethours(), pad2(dt.$getminutes()), true);
}

function fmtday(secs) {
  let dt, days, months;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  days = i18ndow3();
  months = i18nmon3();
  return (((($ix(days, dt.$getdayofweek()) + " ") + dt.$getdayofmonth().$tostr()) + " ") + $ix(months, (dt.$getmonth() - 1)));
}

function cleanlogo(u) {
  let low, base, q;
  u = u.$trim();
  if (((u === "") || ($len(u) > 2000))) {
    return "";
  }
  low = $lcase(u);
  if (($left(low, 4) !== "http")) {
    return "";
  }
  base = low;
  q = $instr(1, low, "?");
  if ((q > 0)) {
    base = $left(low, (q - 1));
  }
  if (($right(base, 4) === ".svg")) {
    return "";
  }
  return u;
}

function epgwantedof(root) {
  let wanted, i, $e1, cat, j, $e2, ch, cid, nk;
  wanted = {__proto__: $AAP};
  if ((root == null)) {
    return wanted;
  }
  for (i = 0, $e1 = (root.$getchildcount() - 1); i <= $e1; i++) {
    cat = root.$getchild(i);
    for (j = 0, $e2 = (cat.$getchildcount() - 1); j <= $e2; j++) {
      ch = cat.$getchild(j);
      cid = ch.id;
      if (((cid != null) && (cid !== ""))) {
        $six(wanted, $lcase(cid), true);
      }
      nk = normname(ch.title);
      if ((nk !== "")) {
        $six(wanted, nk, true);
      }
    }
  }
  return wanted;
}
// ---- components/i18n.brs ----
function i18nlangs() {
  return [{__proto__: $AAP, "code": "es", "name": "Español", "flag": "pkg:/images/flag_es.png"}, {__proto__: $AAP, "code": "en", "name": "English", "flag": "pkg:/images/flag_en.png"}, {__proto__: $AAP, "code": "pt", "name": "Português", "flag": "pkg:/images/flag_pt.png"}, {__proto__: $AAP, "code": "fr", "name": "Français", "flag": "pkg:/images/flag_fr.png"}, {__proto__: $AAP, "code": "de", "name": "Deutsch", "flag": "pkg:/images/flag_de.png"}, {__proto__: $AAP, "code": "it", "name": "Italiano", "flag": "pkg:/images/flag_it.png"}];
}

function i18nvalid(code) {
  let l;
  for (l of $iter(i18nlangs())) {
    if ((l.code === code)) {
      return true;
    }
  }
  return false;
}

function i18ndetect() {
  let code, di, loc, c;
  code = "en";
  di = $createobject("roDeviceInfo");
  if ((di != null)) {
    loc = di.$getcurrentlocale();
    if (((loc != null) && ($len(loc) >= 2))) {
      c = $lcase($left(loc, 2));
      if (i18nvalid(c)) {
        code = c;
      }
    }
  }
  return code;
}

function i18nload(lang) {
  let d, txt, arr, p;
  d = $createobject("roAssociativeArray");
  d.$setmodecasesensitive();
  txt = $readasciifile((("pkg:/locale/" + lang) + ".json"));
  if (((txt != null) && (txt !== ""))) {
    arr = $parsejson(txt);
    if ((arr != null)) {
      for (p of $iter(arr)) {
        $six(d, $ix(p, 0), $ix(p, 1));
      }
    }
  }
  m.i18nd = d;
  m.i18nlang = lang;
}

function tx(s) {
  let lang, v;
  lang = m.global.lang;
  if ((lang == null)) {
    return s;
  }
  if ((lang === "es")) {
    return s;
  }
  if ((m.i18nlang == null)) {
    i18nload(lang);
  } else if ((m.i18nlang !== lang)) {
    i18nload(lang);
  }
  v = m.i18nd.$lookup(s);
  if ((v == null)) {
    return s;
  }
  return v;
}

function i18nlang() {
  let l;
  l = m.global.lang;
  if ((l == null)) {
    return "es";
  }
  return l;
}

function i18n24h() {
  let l;
  l = i18nlang();
  return (((l !== "es") && (l !== "en")));
}

function i18ndow3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  }
  if ((l === "pt")) {
    return ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
  }
  if ((l === "fr")) {
    return ["dim.", "lun.", "mar.", "mer.", "jeu.", "ven.", "sam."];
  }
  if ((l === "de")) {
    return ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
  }
  if ((l === "it")) {
    return ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
  }
  return ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
}

function i18nmon3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  }
  if ((l === "pt")) {
    return ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
  }
  if ((l === "fr")) {
    return ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
  }
  if ((l === "de")) {
    return ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];
  }
  if ((l === "it")) {
    return ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"];
  }
  return ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
}

function i18ndowfull() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  }
  if ((l === "pt")) {
    return ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
  }
  if ((l === "fr")) {
    return ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  }
  if ((l === "de")) {
    return ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
  }
  if ((l === "it")) {
    return ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"];
  }
  return ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
}

function i18ncompass() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  }
  if ((l === "pt")) {
    return ["N", "NE", "L", "SE", "S", "SO", "O", "NO"];
  }
  if ((l === "de")) {
    return ["N", "NO", "O", "SO", "S", "SW", "W", "NW"];
  }
  if ((l === "it")) {
    return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
  }
  return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
}

function i18nhm(h, mm, longfmt) {
  let hs, h12, l, suf;
  if (i18n24h()) {
    hs = h.$tostr();
    if ((h < 10)) {
      hs = ("0" + hs);
    }
    return ((hs + ":") + mm);
  }
  h12 = (h % 12);
  if ((h12 === 0)) {
    h12 = 12;
  }
  l = i18nlang();
  if ((l === "en")) {
    suf = " AM";
    if ((h >= 12)) {
      suf = " PM";
    }
    if ((!longfmt)) {
      suf = "a";
      if ((h >= 12)) {
        suf = "p";
      }
    }
    return (((h12.$tostr() + ":") + mm) + suf);
  }
  if (longfmt) {
    suf = " a. m.";
    if ((h >= 12)) {
      suf = " p. m.";
    }
  } else {
    suf = "a";
    if ((h >= 12)) {
      suf = "p";
    }
  }
  return (((h12.$tostr() + ":") + mm) + suf);
}
// ---- override gunzip.js ----
// La descompresion .gz la hace la app nativa (mucho mas rapido que en BrightScript)
function gunziptoparts(srcpath) {
  const dst = srcpath + '.xml';
  const r = $xhr('GET', '/fs/gunzip?p=' + encodeURIComponent(srcpath) + '&o=' + encodeURIComponent(dst));
  if (r.status !== 200) { m.gzerr = r.text || ''; return null; }
  return [dst];
}

return {"init": init, "readguide": readguide, "epgcachepath": epgcachepath, "epgcacheload": epgcacheload, "epgcachesave": epgcachesave, "processtext": processtext, "handlechannel": handlechannel, "channelicon": channelicon, "handleprogramme": handleprogramme, "tagtext": tagtext, "parsexmltvtime": parsexmltvtime, "filekind": filekind, "gunziptoparts": gunziptoparts, "gzfail": gzfail, "gzinittables": gzinittables, "gzpull": gzpull, "gzbits": gzbits, "gzpeek": gzpeek, "gzalign": gzalign, "gzemit": gzemit, "gzflush": gzflush, "gzwinbyte": gzwinbyte, "gznewtree": gznewtree, "gzaddnode": gzaddnode, "gzbuildtree": gzbuildtree, "gzdecode": gzdecode, "gzfixedlit": gzfixedlit, "gzfixeddist": gzfixeddist, "gzblock": gzblock, "gzheader": gzheader, "gzblocks": gzblocks, "getattr": getattr, "normname": normname, "decodeentities": decodeentities, "pad2": pad2, "fmttime": fmttime, "fmttimelong": fmttimelong, "fmtday": fmtday, "cleanlogo": cleanlogo, "epgwantedof": epgwantedof, "i18nlangs": i18nlangs, "i18nvalid": i18nvalid, "i18ndetect": i18ndetect, "i18nload": i18nload, "tx": tx, "i18nlang": i18nlang, "i18n24h": i18n24h, "i18ndow3": i18ndow3, "i18nmon3": i18nmon3, "i18ndowfull": i18ndowfull, "i18ncompass": i18ncompass, "i18nhm": i18nhm};
});

$defineComponent({"name":"MatchesTask","extends":"Task","fields":[{"id":"items","type":"array"},{"id":"result","type":"array"},{"id":"espnOk","type":"boolean","value":"false"},{"id":"only","type":"array"},{"id":"okLeagues","type":"array"}],"children":[]}, function (m) {
// ---- components/matchestask.brs ----
function init() {
  m.top.functionname = "mtRun";
}

function mtrun() {
  try {
    mtruninner();
  } catch (e) {
    console.log("[MT] error: ", e.message);
    m.top.result = [];
  }
}

function mtruninner() {
  let items, now, nowu, loc, tzoff, locsecs, midlocal, midutc, parsed, it, p, lgs, only, want, id, sel, lg, evs, today, ev, ls, lab, out;
  items = m.top.items;
  if ((items == null)) {
    items = [];
  }
  now = $createobject("roDateTime");
  nowu = now.$asseconds();
  loc = $createobject("roDateTime");
  loc.$tolocaltime();
  tzoff = (loc.$asseconds() - nowu);
  locsecs = (nowu + tzoff);
  midlocal = (locsecs - ((locsecs % 86400)));
  midutc = (midlocal - tzoff);
  m.mtmon = loc.$getmonth();
  m.mtday = loc.$getdayofmonth();
  parsed = [];
  for (it of $iter(items)) {
    p = null;
    try {
      p = mtparse(mts(it.t), mts(it.g));
    } catch (e) {
      p = null;
    }
    if ((p == null)) {
      p = {__proto__: $AAP, "mins": (-1), "mon": 0, "day": 0, "league": "", "rest": mts(it.t), "chan": "", "sport": "soccer", "home": "", "away": "", "pair": ""};
    }
    if ((p != null)) {
      p.it = it;
      p.w = mtdeleet(mtnorm(mts(it.t), true)).$split(" ");
      p.t = p.w.$join("");
      parsed.$push(p);
    }
  }
  lgs = mtleagues();
  only = m.top.only;
  if (((only != null) && (only.$count() > 0))) {
    want = {__proto__: $AAP};
    for (id of $iter(only)) {
      $six(want, id, true);
    }
    sel = [];
    for (lg of $iter(lgs)) {
      if (want.$doesexist(lg.id)) {
        sel.$push(lg);
      }
    }
    if ((sel.$count() > 0)) {
      lgs = sel;
    }
  }
  m.oknames = [];
  evs = mtfetchleagues(lgs, mtymd((midlocal + 43200)));
  m.top.okleagues = m.oknames;
  m.top.espnok = ((evs.$count() > 0));
  if ((evs.$count() === 0)) {
    m.top.result = mtlistmode(parsed, tzoff, midutc);
    return;
  }
  today = [];
  for (ev of $iter(evs)) {
    ls = (ev.start + tzoff);
    if (((ev.state === "in") || (((ls >= midlocal) && (ls < (midlocal + 86400)))))) {
      ev.ch = [];
      today.$push(ev);
    }
  }
  for (p of $iter(parsed)) {
    ev = mtfind(p, today);
    if ((ev != null)) {
      lab = p.chan;
      if ((lab === "")) {
        lab = p.it.g;
      }
      ev.ch.$push({__proto__: $AAP, "t": p.it.t, "u": p.it.u, "f": p.it.f, "l": p.it.l, "lab": lab});
    }
  }
  out = [];
  for (ev of $iter(today)) {
    out.$push({__proto__: $AAP, "k": ("e" + ev.id), "start": ev.start, "est": false, "sport": "soccer", "league": ev.league, "lglogo": ev.lglogo, "prio": ev.prio, "lid": ev.lid, "h": ev.h, "a": ev.a, "hl": ev.hl, "al": ev.al, "hsc": ev.hsc, "asc": ev.asc, "state": ev.state, "detail": ev.detail, "full": ((ev.h + " vs ") + ev.a), "ch": ev.ch});
  }
  console.log("[MT] hoy: ", out.$count(), " partidos oficiales");
  m.top.result = out;
}

function mtprio(id) {
  let lgs, i, $e0;
  lgs = mtleagues();
  for (i = 0, $e0 = (lgs.$count() - 1); i <= $e0; i++) {
    if (($ix(lgs, i).id === id)) {
      return (i + 1);
    }
  }
  return 99;
}

function mtleagues() {
  return [{__proto__: $AAP, "id": "mex.1", "n": "Liga MX"}, {__proto__: $AAP, "id": "uefa.champions", "n": "Champions League"}, {__proto__: $AAP, "id": "eng.1", "n": "Premier League"}, {__proto__: $AAP, "id": "esp.1", "n": "LaLiga"}, {__proto__: $AAP, "id": "ita.1", "n": "Serie A"}, {__proto__: $AAP, "id": "ger.1", "n": "Bundesliga"}, {__proto__: $AAP, "id": "fra.1", "n": "Ligue 1"}, {__proto__: $AAP, "id": "ned.1", "n": "Eredivisie"}, {__proto__: $AAP, "id": "por.1", "n": "Liga Portugal"}, {__proto__: $AAP, "id": "uefa.europa", "n": "Europa League"}, {__proto__: $AAP, "id": "uefa.europa.conf", "n": "Conference League"}, {__proto__: $AAP, "id": "usa.1", "n": "MLS"}, {__proto__: $AAP, "id": "concacaf.champions", "n": "Concacaf Champions Cup"}, {__proto__: $AAP, "id": "concacaf.leagues.cup", "n": "Leagues Cup"}, {__proto__: $AAP, "id": "conmebol.libertadores", "n": "Copa Libertadores"}, {__proto__: $AAP, "id": "conmebol.sudamericana", "n": "Copa Sudamericana"}, {__proto__: $AAP, "id": "arg.1", "n": "Liga Argentina"}, {__proto__: $AAP, "id": "bra.1", "n": "Brasileirão"}, {__proto__: $AAP, "id": "mex.2", "n": "Liga de Expansión MX"}, {__proto__: $AAP, "id": "mex.w.1", "n": "Liga MX Femenil"}, {__proto__: $AAP, "id": "eng.2", "n": "Championship"}, {__proto__: $AAP, "id": "esp.copa_del_rey", "n": "Copa del Rey"}, {__proto__: $AAP, "id": "eng.fa", "n": "FA Cup"}, {__proto__: $AAP, "id": "fifa.world", "n": "Mundial 2026"}, {__proto__: $AAP, "id": "fifa.worldq.concacaf", "n": "Eliminatorias Concacaf"}, {__proto__: $AAP, "id": "fifa.worldq.conmebol", "n": "Eliminatorias Conmebol"}, {__proto__: $AAP, "id": "fifa.worldq.uefa", "n": "Eliminatorias UEFA"}, {__proto__: $AAP, "id": "uefa.nations", "n": "Nations League"}, {__proto__: $AAP, "id": "concacaf.nations.league", "n": "Nations League Concacaf"}, {__proto__: $AAP, "id": "fifa.friendly", "n": "Amistosos"}];
}

function mtfetchleagues(leagues, ymd) {
  let evs, seen, base, i, okn, port, reqs, n, lg, h, pending, clock, msg, rq, js, logo, l0, lg0, rl, before, k, $e1, id;
  evs = [];
  seen = {__proto__: $AAP};
  base = "https://site.api.espn.com/apis/site/v2/sports/soccer/";
  i = 0;
  okn = 0;
  while ((i < leagues.$count())) {
    port = $createobject("roMessagePort");
    reqs = {__proto__: $AAP};
    n = 0;
    while (((i < leagues.$count()) && (n < 8))) {
      lg = $ix(leagues, i);
      h = $createobject("roUrlTransfer");
      h.$setcertificatesfile("common:/certs/ca-bundle.crt");
      h.$initclientcertificates();
      h.$enableencodings(true);
      h.$setmessageport(port);
      h.$seturl((((base + lg.id) + "/scoreboard?dates=") + ymd));
      if (h.$asyncgettostring()) {
        $six(reqs, h.$getidentity().$tostr(), {__proto__: $AAP, "h": h, "lg": lg, "p": mtprio(lg.id), "done": false});
        n = (n + 1);
      }
      i = (i + 1);
    }
    pending = n;
    clock = $createobject("roTimespan");
    while (((pending > 0) && (clock.$totalmilliseconds() < 20000))) {
      msg = $wait(1000, port);
      if (($type(msg) === "roUrlEvent")) {
        rq = $ix(reqs, msg.$getsourceidentity().$tostr());
        if (((rq != null) && (!rq.done))) {
          rq.done = true;
          pending = (pending - 1);
          if ((msg.$getresponsecode() === 200)) {
            js = null;
            try {
              js = $parsejson(msg.$getstring());
            } catch (e) {
              js = null;
            }
            if (((js != null) && ($type(js) === "roAssociativeArray"))) {
              okn = (okn + 1);
              m.oknames.$push(rq.lg.n);
              logo = "";
              if ((($type(js.leagues) === "roArray") && (js.leagues.$count() > 0))) {
                l0 = $ix(js.leagues, 0);
                if (((($type(l0) === "roAssociativeArray") && ($type(l0.logos) === "roArray")) && (l0.logos.$count() > 0))) {
                  for (lg0 of $iter(l0.logos)) {
                    if (($type(lg0) === "roAssociativeArray")) {
                      if ((logo === "")) {
                        logo = mts(lg0.href);
                      }
                      if (($type(lg0.rel) === "roArray")) {
                        for (rl of $iter(lg0.rel)) {
                          if ((mts(rl) === "dark")) {
                            logo = mts(lg0.href);
                          }
                        }
                      }
                    }
                  }
                }
              }
              if (($type(js.events) === "roArray")) {
                before = evs.$count();
                mtaddevents(js.events, evs, seen);
                for (k = before, $e1 = (evs.$count() - 1); k <= $e1; k++) {
                  $ix(evs, k).league = rq.lg.n;
                  $ix(evs, k).lglogo = logo;
                  $ix(evs, k).prio = rq.p;
                  $ix(evs, k).lid = rq.lg.id;
                }
              }
            }
          }
        }
      }
    }
    for (id of $iter(reqs)) {
      if ((!$ix(reqs, id).done)) {
        $ix(reqs, id).h.$asynccancel();
      }
    }
  }
  console.log("[MT] ESPN: ", okn, " ligas respondieron, ", evs.$count(), " partidos");
  return evs;
}

function mtlistmode(parsed, tzoff, midutc) {
  let defoff, bykey, order, p, lm, start, key, lab, chitem, lgn, out, k;
  defoff = $int((tzoff / 60));
  bykey = {__proto__: $AAP};
  order = [];
  for (p of $iter(parsed)) {
    if (((p.sport !== "soccer") || (p.mins < 0))) {
      continue;
    }
    if (((p.mon > 0) && (!(((p.mon === m.mtmon) && (p.day === m.mtday)))))) {
      continue;
    }
    lm = p.mins;
    start = (midutc + (lm * 60));
    key = ("t" + p.pair);
    if ((p.pair === "")) {
      key = ("x" + p.t);
    }
    lab = p.chan;
    if ((lab === "")) {
      lab = p.it.g;
    }
    chitem = {__proto__: $AAP, "t": p.it.t, "u": p.it.u, "f": p.it.f, "l": p.it.l, "lab": lab};
    if (bykey.$doesexist(key)) {
      $ix(bykey, key).ch.$push(chitem);
    } else {
      lgn = p.league;
      if ((lgn === "")) {
        lgn = "De tu lista";
      }
      $six(bykey, key, {__proto__: $AAP, "k": key, "start": start, "est": true, "sport": "soccer", "league": lgn, "lglogo": "", "prio": 99, "lid": "", "h": p.home, "a": p.away, "hl": "", "al": "", "hsc": "", "asc": "", "state": "", "detail": "", "full": p.rest, "ch": [chitem]});
      order.$push(key);
    }
  }
  out = [];
  for (k of $iter(order)) {
    out.$push($ix(bykey, k));
  }
  return out;
}

function mtrx() {
  if ((m.rx == null)) {
    m.rx = {__proto__: $AAP, "c": $createobject("roRegex", "^(\\d{1,2})/(\\d{1,2})\\s+(\\S+)\\s+(\\d{1,2}):(\\d{2})\\s*([AaPp][Mm])\\s+(.+?)\\s*=\\s*(.+)$", ""), "b": $createobject("roRegex", "^(.+?)\\s*\\|\\s*(\\d{1,2}):(\\d{2})\\s*([AaPp][Mm])?\\s*\\|\\s*(.+)$", ""), "a": $createobject("roRegex", "^(\\d{1,2})[:\\.](\\d{2})\\s*([AaPp][Mm])?\\s*[-|:]?\\s*(.+)$", ""), "any": $createobject("roRegex", "(\\d{1,2}):(\\d{2})\\s*([AaPp][Mm])?", ""), "vs": $createobject("roRegex", "^(.*\\S)\\s+(?:vs\\.?|v\\.|x)\\s+(\\S.*)$", "i"), "dash": $createobject("roRegex", "^(.*\\S)\\s+-\\s+(\\S.*)$", "")};
  }
  return m.rx;
}

function mtminutes(h, mi, ap) {
  let hh, mm, a;
  if (((h == null) || (mi == null))) {
    return (-1);
  }
  hh = $val(h);
  mm = $val(mi);
  if (((hh > 23) || (mm > 59))) {
    return (-1);
  }
  a = "";
  if ((ap != null)) {
    a = $lcase(ap);
  }
  if (((a === "pm") && (hh < 12))) {
    hh = (hh + 12);
  }
  if (((a === "am") && (hh === 12))) {
    hh = 0;
  }
  return ((hh * 60) + mm);
}

function mtparse(t, grp) {
  let rx, p, r, sp3, ll, txt, w, hw, aw, hk, ak;
  rx = mtrx();
  p = {__proto__: $AAP, "mins": (-1), "mon": 0, "day": 0, "league": "", "rest": "", "chan": "", "sport": "soccer", "home": "", "away": "", "pair": ""};
  r = rx.c.$match(t);
  if ((r.$count() >= 9)) {
    p.mon = $val($ix(r, 1));
    p.day = $val($ix(r, 2));
    p.league = mts($ix(r, 3));
    p.mins = mtminutes($ix(r, 4), $ix(r, 5), $ix(r, 6));
    p.rest = mts($ix(r, 7));
    p.chan = mts($ix(r, 8)).$replace("*", "").$trim();
    sp3 = $lcase(p.league);
    if ((((sp3 !== "soccer") && (sp3 !== "futbol")) && (sp3 !== "football"))) {
      p.sport = "other";
    }
  } else {
    r = rx.b.$match(t);
    if ((r.$count() >= 6)) {
      p.league = mts($ix(r, 1)).$trim();
      p.mins = mtminutes($ix(r, 2), $ix(r, 3), $ix(r, 4));
      p.rest = mts($ix(r, 5));
    } else {
      r = rx.a.$match(t);
      if ((r.$count() >= 5)) {
        p.mins = mtminutes($ix(r, 1), $ix(r, 2), $ix(r, 3));
        p.rest = mts($ix(r, 4));
      } else {
        r = rx.any.$match(t);
        if ((r.$count() < 3)) {
          return null;
        }
        p.mins = mtminutes($ix(r, 1), $ix(r, 2), $ix(r, 3));
        p.rest = t.$replace(mts($ix(r, 0)), " ").$trim();
      }
    }
  }
  if ((p.mins < 0)) {
    return null;
  }
  ll = $lcase(p.league);
  if ((ll === "epl")) {
    p.league = "Premier League";
  }
  if ((ll === "les")) {
    p.league = "LaLiga";
  }
  if ((ll === "arg")) {
    p.league = "Liga Argentina";
  }
  txt = $lcase(((((p.league + " ") + p.rest) + " | ") + grp));
  for (w of $iter(["basket", "nba", "wnba", "nfl", "cfl", "americano", "nhl", "hockey", "mlb", "beisbol", "béisbol", "baseball", "tenis", "tennis", "atp ", "wta", "ufc", "boxing", "boxeo", "box ", "f1 ", "formula", "fórmula", "motogp", "nascar", "golf", "freestyle", "balonmano", "handball", "volei", "voley", "volley", "rugby", "artística", "artistica", "pesaje", "matchroom", "wwe", "horse", "ciclismo", "baloncesto", "bkfc", "nascar", "ncaa", "lmp", "lmb"])) {
    if (($instr(1, txt, w) > 0)) {
      p.sport = "other";
      break;
    }
  }
  r = rx.vs.$match(p.rest);
  if ((r.$count() < 3)) {
    r = rx.dash.$match(p.rest);
  }
  if ((r.$count() >= 3)) {
    p.home = mts($ix(r, 1)).$trim();
    p.away = mts($ix(r, 2)).$trim();
    hw = mtnorm(p.home, true).$split(" ");
    aw = mtnorm(p.away, true).$split(" ");
    hk = mtsig(hw, (hw.$count() - 2), (hw.$count() - 1));
    ak = mtsig(aw, 0, 1);
    if (((hk !== "") && (ak !== ""))) {
      if ((hk < ak)) {
        p.pair = ((hk + "|") + ak);
      } else {
        p.pair = ((ak + "|") + hk);
      }
    }
  }
  return p;
}

function mtsig(w, i0, i1) {
  let x, best, anyw, i, $e2;
  if ((m.stopp == null)) {
    m.stopp = {__proto__: $AAP};
    for (x of $iter(["club", "real", "sporting", "atletico", "deportivo", "athletic", "sport", "sports", "football", "futbol", "calcio", "olympique", "borussia", "racing", "union", "town", "rovers", "wanderers", "county", "women", "femenino", "under", "esporte", "clube", "the", "city", "united", "u17", "u19", "u20", "u21", "u22", "u23", "sub17"])) {
      $six(m.stopp, x, true);
    }
  }
  if ((i0 < 0)) {
    i0 = 0;
  }
  if ((i1 > (w.$count() - 1))) {
    i1 = (w.$count() - 1);
  }
  best = "";
  anyw = "";
  for (i = i0, $e2 = i1; i <= $e2; i++) {
    x = $ix(w, i);
    if (($len(x) > $len(anyw))) {
      anyw = x;
    }
    if (((($len(x) >= 4) && (!m.stopp.$doesexist(x))) && ($len(x) > $len(best)))) {
      best = x;
    }
  }
  if ((best === "")) {
    best = anyw;
  }
  return best;
}

function mtlastwords(s, n) {
  let w, out, c, i;
  w = mtnorm(s, true).$split(" ");
  out = "";
  c = 0;
  i = (w.$count() - 1);
  while (((i >= 0) && (c < n))) {
    if (($ix(w, i) !== "")) {
      out = (($ix(w, i) + " ") + out);
      c = (c + 1);
    }
    i = (i - 1);
  }
  return out.$trim();
}

function mtlongest(s) {
  let best, w;
  best = "";
  for (w of $iter(mtnorm(s, true).$split(" "))) {
    if (($len(w) > $len(best))) {
      best = w;
    }
  }
  return best;
}

function mtnorm(s, spaces) {
  let t, out, lastsp, n, i, $e3, ch, a, k;
  if ((m.acca == null)) {
    m.acca = "áàäâãåéèëêíìïîóòöôõøúùüûñçýÁÀÄÂÃÅÉÈËÊÍÌÏÎÓÒÖÔÕØÚÙÜÛÑÇÝłŁšŠžŽćĆčČęĘąĄńŃśŚźŹżŻğĞıİşŞ";
    m.accb = "aaaaaaeeeeiiiioooooouuuuncyaaaaaaeeeeiiiioooooouuuuncyllsszzcccceeaannsszzzzggiiss";
  }
  t = $lcase(s);
  out = "";
  lastsp = true;
  n = $len(t);
  for (i = 1, $e3 = n; i <= $e3; i++) {
    ch = $mid(t, i, 1);
    a = $asc(ch);
    if (((((a >= 97) && (a <= 122))) || (((a >= 48) && (a <= 57))))) {
      out = (out + ch);
      lastsp = false;
    } else if ((a >= 128)) {
      k = $instr(1, m.acca, ch);
      if ((k > 0)) {
        out = (out + $mid(m.accb, k, 1));
        lastsp = false;
      } else if ((spaces && (!lastsp))) {
        out = (out + " ");
        lastsp = true;
      }
    } else if ((spaces && (!lastsp))) {
      out = (out + " ");
      lastsp = true;
    }
  }
  return out.$trim();
}

function mtwords(name) {
  let w, out, got, full, compact, k;
  if ((m.stopw == null)) {
    m.stopw = {__proto__: $AAP};
    for (w of $iter(["club", "real", "sporting", "atletico", "deportivo", "athletic", "sport", "sports", "football", "futbol", "calcio", "olympique", "borussia", "racing", "union", "town", "rovers", "wanderers", "county", "women", "femenino", "fem", "under", "esporte", "clube", "associazione", "societa", "amateur", "reserves", "the"])) {
      $six(m.stopw, w, true);
    }
  }
  out = [];
  got = {__proto__: $AAP};
  for (w of $iter(mtnorm(name, true).$split(" "))) {
    if (((($len(w) >= 4) && (!m.stopw.$doesexist(w))) && (!got.$doesexist(w)))) {
      $six(got, w, true);
      out.$push(w);
    }
  }
  if ((out.$count() === 0)) {
    full = mtnorm(name, false);
    if (($len(full) >= 3)) {
      out.$push(full);
    }
  }
  if ((m.alias == null)) {
    m.alias = {__proto__: $AAP, "guadalajara": ["chivas"], "monterrey": ["rayados"], "unam": ["pumas"], "uanl": ["tigres"], "america": ["aguilas"], "toluca": ["diablos"], "manchesterunited": ["manutd", "manunited"], "manchestercity": ["mancity"], "parissaintgermain": ["psg"], "parissg": ["psg"], "borussiadortmund": ["dortmund", "bvb"], "bayernmunich": ["bayern"], "internazionale": ["inter"], "intermilan": ["inter"], "atleticomadrid": ["atleticomadrid", "atleticodemadrid", "atleti"], "atleticodemadrid": ["atleticomadrid", "atleticodemadrid", "atleti"], "realmadrid": ["realmadrid"], "realsociedad": ["sociedad"], "realbetis": ["betis"], "tottenhamhotspur": ["tottenham", "spurs"], "wolverhamptonwanderers": ["wolves"], "nottinghamforest": ["nottingham", "forest"], "athleticclub": ["athletic", "bilbao"], "sportingcp": ["sporting"], "rbleipzig": ["leipzig"], "bayerleverkusen": ["leverkusen"], "barcelona": ["barca"], "juventus": ["juve"], "napoli": ["napoles"], "acmilan": ["milan"], "olympiquemarseille": ["marsella", "marseille"], "olympiquelyonnais": ["lyon"], "bayernmunchen": ["bayern"], "unitedstates": ["estadosunidos", "usa", "eeuu"], "spain": ["espana"], "germany": ["alemania"], "france": ["francia"], "brazil": ["brasil"], "england": ["inglaterra"], "netherlands": ["paisesbajos", "holanda"], "japan": ["japon"], "italy": ["italia"], "belgium": ["belgica"], "croatia": ["croacia"], "morocco": ["marruecos"], "southkorea": ["corea"], "korearepublic": ["corea"], "switzerland": ["suiza"], "poland": ["polonia"], "turkey": ["turquia"], "turkiye": ["turquia"], "saudiarabia": ["arabia"], "egypt": ["egipto"], "scotland": ["escocia"], "wales": ["gales"], "ireland": ["irlanda"], "norway": ["noruega"], "sweden": ["suecia"], "denmark": ["dinamarca"], "czechia": ["chequia"], "czechrepublic": ["chequia"], "newzealand": ["nuevazelanda"], "southafrica": ["sudafrica"], "cameroon": ["camerun"], "ivorycoast": ["costademarfil"], "algeria": ["argelia"], "tunisia": ["tunez"], "ivorycoast2": ["costademarfil"]};
  }
  compact = mtnorm(name, false);
  for (k of $iter(m.alias)) {
    if (($instr(1, compact, k) > 0)) {
      for (w of $iter($ix(m.alias, k))) {
        if ((!got.$doesexist(w))) {
          $six(got, w, true);
          out.$push(w);
        }
      }
    }
  }
  return out;
}

function mtfind(p, evs) {
  let best, bestscore, ev, sh, sa;
  best = null;
  bestscore = 0;
  for (ev of $iter(evs)) {
    sh = mtteamscore(ev.hw, p);
    if ((sh > 0)) {
      sa = mtteamscore(ev.aw, p);
      if (((sa > 0) && ((sh + sa) > bestscore))) {
        bestscore = (sh + sa);
        best = ev;
      }
    }
  }
  return best;
}

function mtteamscore(words, p) {
  let sc, w, tk;
  sc = 0;
  for (w of $iter(words)) {
    if (($instr(1, p.t, w) > 0)) {
      sc = (sc + 1);
    }
  }
  if ((sc > 0)) {
    return sc;
  }
  for (w of $iter(words)) {
    if (($len(w) >= 5)) {
      for (tk of $iter(p.w)) {
        if (mtnear(w, tk)) {
          sc = (sc + 1);
          break;
        }
      }
    }
  }
  return sc;
}

function mtnear(a, b) {
  let la, lb, i, j, ed;
  la = $len(a);
  lb = $len(b);
  if (((((la - lb) > 1) || ((lb - la) > 1)) || (lb < 4))) {
    return false;
  }
  if (($left(a, 1) !== $left(b, 1))) {
    return false;
  }
  i = 1;
  j = 1;
  ed = 0;
  while (((i <= la) && (j <= lb))) {
    if (($mid(a, i, 1) === $mid(b, j, 1))) {
      i = (i + 1);
      j = (j + 1);
    } else {
      ed = (ed + 1);
      if ((ed > 1)) {
        return false;
      }
      if ((la > lb)) {
        i = (i + 1);
      } else if ((lb > la)) {
        j = (j + 1);
      } else {
        i = (i + 1);
        j = (j + 1);
      }
    }
  }
  ed = ((ed + (((la - i) + 1))) + (((lb - j) + 1)));
  return (ed <= 1);
}

function mtdeleet(s) {
  let toks, out, tk, n, hasl, hasd, nd, i, $e4, a;
  toks = s.$split(" ");
  out = [];
  for (tk of $iter(toks)) {
    n = $len(tk);
    hasl = false;
    hasd = false;
    nd = 0;
    for (i = 1, $e4 = n; i <= $e4; i++) {
      a = $asc($mid(tk, i, 1));
      if (((a >= 97) && (a <= 122))) {
        hasl = true;
      }
      if (((a >= 48) && (a <= 57))) {
        hasd = true;
        nd = (nd + 1);
      }
    }
    if ((((hasl && hasd) && (n >= 4)) && ((nd * 2) <= n))) {
      tk = tk.$replace("0", "o").$replace("1", "i").$replace("3", "e").$replace("4", "a").$replace("5", "s").$replace("7", "t").$replace("8", "b");
    }
    out.$push(tk);
  }
  return out.$join(" ");
}

function mtymd(secs) {
  let d, y, mo, dd, ms, ds;
  d = $createobject("roDateTime");
  d.$fromseconds(secs);
  y = d.$getyear().$tostr();
  mo = d.$getmonth();
  dd = d.$getdayofmonth();
  ms = mo.$tostr();
  if ((mo < 10)) {
    ms = ("0" + ms);
  }
  ds = dd.$tostr();
  if ((dd < 10)) {
    ds = ("0" + ds);
  }
  return ((y + ms) + ds);
}

function mtespn(midlocal) {
  let base, dy, dt, dm, evs, seen, js, d;
  base = "https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard?dates=";
  dy = mtymd((midlocal - 43200));
  dt = mtymd((midlocal + 43200));
  dm = mtymd(((midlocal + 86400) + 43200));
  evs = [];
  seen = {__proto__: $AAP};
  js = mtget((((base + dy) + "-") + dm));
  if ((((js != null) && ($type(js.events) === "roArray")) && (js.events.$count() > 0))) {
    mtaddevents(js.events, evs, seen);
  } else {
    for (d of $iter([dy, dt, dm])) {
      js = mtget((base + d));
      if (((js != null) && ($type(js.events) === "roArray"))) {
        mtaddevents(js.events, evs, seen);
      }
      js = null;
    }
  }
  console.log("[MT] ESPN: ", evs.$count(), " partidos");
  return evs;
}

function mtget(url) {
  let fs, path, http, port, msg, txt;
  fs = $createobject("roFileSystem");
  path = "cachefs:/mt_espn.json";
  if (fs.$exists(path)) {
    fs.$delete(path);
  }
  http = $createobject("roUrlTransfer");
  http.$setcertificatesfile("common:/certs/ca-bundle.crt");
  http.$initclientcertificates();
  http.$enableencodings(true);
  http.$seturl(url);
  port = $createobject("roMessagePort");
  http.$setmessageport(port);
  if ((!http.$asyncgettofile(path))) {
    return null;
  }
  msg = $wait(30000, port);
  if (($type(msg) !== "roUrlEvent")) {
    http.$asynccancel();
    console.log("[MT] ESPN sin respuesta");
    return null;
  }
  if ((msg.$getresponsecode() !== 200)) {
    console.log("[MT] ESPN codigo ", msg.$getresponsecode());
    if (fs.$exists(path)) {
      fs.$delete(path);
    }
    return null;
  }
  txt = $readasciifile(path);
  fs.$delete(path);
  if (((txt == null) || (txt === ""))) {
    return null;
  }
  return $parsejson(txt);
}

function mts(v) {
  let t;
  if ((v == null)) {
    return "";
  }
  t = $type(v);
  if (((t === "roString") || (t === "String"))) {
    return v;
  }
  if (((((((t === "roInteger") || (t === "Integer")) || (t === "roFloat")) || (t === "Float")) || (t === "LongInteger")) || (t === "Double"))) {
    return v.$tostr();
  }
  return "";
}

function mtiso(s) {
  let iso, d;
  if (($len(s) < 16)) {
    return 0;
  }
  iso = ($left(s, 16) + ":00Z");
  d = $createobject("roDateTime");
  d.$fromiso8601string(iso);
  return d.$asseconds();
}

function mtleaguename(e) {
  let n, mp, k;
  n = mtleagueraw(e);
  mp = {__proto__: $AAP, "english premier league": "Premier League", "spanish laliga": "LaLiga", "laliga": "LaLiga", "spanish la liga": "LaLiga", "italian serie a": "Serie A", "german bundesliga": "Bundesliga", "french ligue 1": "Ligue 1", "mexican liga bbva mx": "Liga MX", "liga bbva mx": "Liga MX", "mexican liga mx": "Liga MX", "uefa champions league": "Champions League", "uefa europa league": "Europa League", "english league championship": "Championship", "portuguese primeira liga": "Liga Portugal", "dutch eredivisie": "Eredivisie", "saudi pro league": "Liga Saudí", "argentine liga profesional de fútbol": "Liga Argentina", "brazilian serie a": "Brasileirão", "major league soccer": "MLS"};
  k = $lcase(n);
  if (mp.$doesexist(k)) {
    return $ix(mp, k);
  }
  return n;
}

function mtleagueraw(e) {
  let comp, n, sl, parts, out, w;
  comp = null;
  if ((($type(e.competitions) === "roArray") && (e.competitions.$count() > 0))) {
    comp = $ix(e.competitions, 0);
  }
  if ((comp != null)) {
    n = mts(comp.altgamenote);
    if ((n !== "")) {
      return n;
    }
  }
  if (($type(e.season) === "roAssociativeArray")) {
    sl = mts(e.season.slug);
    if ((sl !== "")) {
      parts = sl.$split("-");
      out = "";
      for (w of $iter(parts)) {
        if ((((w !== "") && ($val(w) === 0)) && (w !== "00"))) {
          out = (((out + $ucase($left(w, 1))) + $mid(w, 2)) + " ");
        }
      }
      return out.$trim();
    }
  }
  return "";
}

function mtaddevents(arr, evs, seen) {
  let e, id, comp, h, a, c, st, det, hn, an, hw, aw;
  for (e of $iter(arr)) {
    if (($type(e) === "roAssociativeArray")) {
      id = mts(e.id);
      if (((((id !== "") && (!seen.$doesexist(id))) && ($type(e.competitions) === "roArray")) && (e.competitions.$count() > 0))) {
        $six(seen, id, true);
        comp = $ix(e.competitions, 0);
        h = null;
        a = null;
        if (($type(comp.competitors) === "roArray")) {
          for (c of $iter(comp.competitors)) {
            if (($type(c) === "roAssociativeArray")) {
              if ((mts(c.homeaway) === "home")) {
                h = c;
              } else {
                a = c;
              }
            }
          }
        }
        if (((((h != null) && (a != null)) && ($type(h.team) === "roAssociativeArray")) && ($type(a.team) === "roAssociativeArray"))) {
          st = "";
          det = "";
          if ((($type(e.status) === "roAssociativeArray") && ($type(e.status.type) === "roAssociativeArray"))) {
            st = mts(e.status.type.state);
            det = mts(e.status.type.shortdetail);
          }
          hn = mts(h.team.shortdisplayname);
          if ((hn === "")) {
            hn = mts(h.team.displayname);
          }
          an = mts(a.team.shortdisplayname);
          if ((an === "")) {
            an = mts(a.team.displayname);
          }
          hw = mtwords(((mts(h.team.displayname) + " ") + mts(h.team.shortdisplayname)));
          aw = mtwords(((mts(a.team.displayname) + " ") + mts(a.team.shortdisplayname)));
          evs.$push({__proto__: $AAP, "id": id, "start": mtiso(mts(e.date)), "league": mtleaguename(e), "h": hn, "a": an, "hl": mts(h.team.logo), "al": mts(a.team.logo), "hsc": mts(h.score), "asc": mts(a.score), "state": st, "detail": det, "hw": hw, "aw": aw});
        }
      }
    }
  }
}
return {"init": init, "mtrun": mtrun, "mtruninner": mtruninner, "mtprio": mtprio, "mtleagues": mtleagues, "mtfetchleagues": mtfetchleagues, "mtlistmode": mtlistmode, "mtrx": mtrx, "mtminutes": mtminutes, "mtparse": mtparse, "mtsig": mtsig, "mtlastwords": mtlastwords, "mtlongest": mtlongest, "mtnorm": mtnorm, "mtwords": mtwords, "mtfind": mtfind, "mtteamscore": mtteamscore, "mtnear": mtnear, "mtdeleet": mtdeleet, "mtymd": mtymd, "mtespn": mtespn, "mtget": mtget, "mts": mts, "mtiso": mtiso, "mtleaguename": mtleaguename, "mtleagueraw": mtleagueraw, "mtaddevents": mtaddevents};
});

$defineComponent({"name":"QrServer","extends":"Task","fields":[{"id":"port","type":"integer","value":"8088"},{"id":"received","type":"assocarray"},{"id":"status","type":"string"}],"children":[]}, function (m) {
// ---- components/qrserver.brs ----
function init() {
  m.top.functionname = "serve";
}

function serve() {
  let mp, srv, bound, ports, pt, reuse, $e0, variant, $e1, cand, addr, okaddr, clients, clock, counter, msg, sid, c, k, cl, sock, s, now, old, key;
  mp = $createobject("roMessagePort");
  srv = null;
  bound = 0;
  ports = [m.top.port, 8090, 8099, 8123];
  for (pt of $iter(ports)) {
    for (reuse = 0, $e0 = 1; reuse <= $e0; reuse++) {
      for (variant = 0, $e1 = 2; variant <= $e1; variant++) {
        if ((srv == null)) {
          cand = $createobject("roStreamSocket");
          addr = $createobject("roSocketAddress");
          if ((variant === 0)) {
            addr.$setaddress(("0.0.0.0:" + pt.$tostr()));
          } else if ((variant === 1)) {
            addr.$sethostname("0.0.0.0");
            addr.$setport(pt);
          } else {
            addr.$setport(pt);
          }
          if ((reuse === 0)) {
            cand.$setreuseaddr(true);
          }
          okaddr = cand.$setaddress(addr);
          if (okaddr) {
            cand.$setmessageport(mp);
            cand.$notifyreadable(true);
            if (cand.$listen(5)) {
              srv = cand;
              bound = pt;
            }
          }
        }
      }
    }
  }
  if ((srv == null)) {
    m.top.status = ("error:" + tx("No se pudo abrir el servidor en la TV (puertos ocupados o bloqueados)"));
    return;
  }
  m.top.status = ("listo:" + bound.$tostr());
  clients = {__proto__: $AAP};
  clock = $createobject("roTimespan");
  counter = 0;
  while (true) {
    msg = $wait(1000, mp);
    if (($type(msg) === "roSocketEvent")) {
      sid = msg.$getsocketid();
      if ((sid === srv.$getid())) {
        if (srv.$isreadable()) {
          c = srv.$accept();
          if ((c != null)) {
            c.$setmessageport(mp);
            c.$notifyreadable(true);
            $six(clients, c.$getid().$tostr(), {__proto__: $AAP, "sock": c, "buf": "", "t": clock.$totalmilliseconds()});
          }
        }
      } else {
        k = sid.$tostr();
        cl = $ix(clients, k);
        if ((cl != null)) {
          sock = cl.sock;
          if (sock.$isreadable()) {
            s = sock.$receivestr(4096);
            if (((s == null) || (s === ""))) {
              sock.$close();
              clients.$delete(k);
            } else {
              cl.buf = (cl.buf + s);
              if ((($instr(1, cl.buf, ((($chr(13) + $chr(10)) + $chr(13)) + $chr(10))) > 0) || ($len(cl.buf) > 40000))) {
                counter = (counter + 1);
                handlerequest(sock, cl.buf, counter);
                sock.$close();
                clients.$delete(k);
              }
            }
          }
        }
      }
    }
    now = clock.$totalmilliseconds();
    old = [];
    for (key of $iter(clients)) {
      if (((now - $ix(clients, key).t) > 15000)) {
        old.$push(key);
      }
    }
    for (key of $iter(old)) {
      $ix(clients, key).sock.$close();
      clients.$delete(key);
    }
  }
}

function handlerequest(sock, req, counter) {
  let eol, line, sp1, rest, sp2, target, path, query, q, p, host, user, pass, full, err, it, items, total, i, $e2, url, epg, nm, lbl;
  eol = $instr(1, req, $chr(13));
  if ((eol === 0)) {
    eol = $instr(1, req, $chr(10));
  }
  if ((eol === 0)) {
    eol = ($len(req) + 1);
  }
  line = $left(req, (eol - 1));
  sp1 = $instr(1, line, " ");
  if ((sp1 === 0)) {
    sendpage(sock, "400 Bad Request", "Bad request");
    return;
  }
  rest = $mid(line, (sp1 + 1));
  sp2 = $instr(1, rest, " ");
  target = rest;
  if ((sp2 > 0)) {
    target = $left(rest, (sp2 - 1));
  }
  path = target;
  query = "";
  q = $instr(1, target, "?");
  if ((q > 0)) {
    path = $left(target, (q - 1));
    query = $mid(target, (q + 1));
  }
  if ((path === "/")) {
    sendpage(sock, "200 OK", noticepage());
  } else if ((path === "/form")) {
    p = parsequery(query);
    if ((p.ok === "1")) {
      sendpage(sock, "200 OK", formpage(""));
    } else {
      sendpage(sock, "200 OK", noticepage());
    }
  } else if ((path === "/xt")) {
    p = parsext(query);
    if ((p.ok === "1")) {
      sendpage(sock, "200 OK", xtformpage(""));
    } else {
      sendpage(sock, "200 OK", noticepage());
    }
  } else if ((path === "/addxt")) {
    p = parsext(query);
    if ((p.ok !== "1")) {
      sendpage(sock, "200 OK", noticepage());
      return;
    }
    host = p.host.$trim();
    user = p.user.$trim();
    pass = p.pass.$trim();
    full = xtfromurl(host);
    if ((full != null)) {
      host = full.host;
      user = full.user;
      pass = full.pass;
    }
    err = "";
    if ((host === "")) {
      err = tx("Escribe el servidor.");
    } else if ((user === "")) {
      err = tx("Falta el usuario.");
    } else if ((pass === "")) {
      err = tx("Falta la contraseña.");
    }
    if ((err !== "")) {
      sendpage(sock, "200 OK", xtformpage(err));
    } else {
      it = {__proto__: $AAP, "name": p.name.$trim(), "url": "", "epg": "", "xt": {__proto__: $AAP, "host": host, "user": user, "pass": pass}};
      m.top.received = {__proto__: $AAP, "id": counter, "items": [it]};
      sendpage(sock, "200 OK", donepage([it]));
    }
  } else if ((path === "/add")) {
    p = parsemulti(query);
    if ((p.ok !== "1")) {
      sendpage(sock, "200 OK", noticepage());
      return;
    }
    items = [];
    err = "";
    total = p.url.$count();
    if ((total > 10)) {
      err = tx("Solo puedes enviar hasta 10 listas a la vez.");
    }
    for (i = 0, $e2 = (total - 1); i <= $e2; i++) {
      url = $ix(p.url, i).$trim();
      epg = $ix(p.epg, i).$trim();
      nm = "";
      if ((i < p.name.$count())) {
        nm = $ix(p.name, i).$trim();
      }
      if (((url !== "") || (epg !== ""))) {
        lbl = "";
        if ((total > 1)) {
          lbl = ((tx("Lista ") + ((i + 1)).$tostr()) + ": ");
        }
        if (((url !== "") && ($lcase($left(url, 4)) !== "http"))) {
          err = (lbl + tx("el link de la lista debe empezar con http:// o https://"));
        } else if (((epg !== "") && ($lcase($left(epg, 4)) !== "http"))) {
          err = (lbl + tx("el link de la guía debe empezar con http:// o https://"));
        }
        items.$push({__proto__: $AAP, "name": nm, "url": url, "epg": epg});
      }
    }
    if (((err === "") && (items.$count() === 0))) {
      err = tx("Escribe el link de la lista M3U o el de la guía.");
    }
    if ((err !== "")) {
      sendpage(sock, "200 OK", formpage(err));
    } else {
      m.top.received = {__proto__: $AAP, "id": counter, "items": items};
      sendpage(sock, "200 OK", donepage(items));
    }
  } else {
    sendpage(sock, "404 Not Found", "Not found");
  }
}

function parsequery(q) {
  let res, xfer, p, total, amp, pair, eq, key, val;
  res = {__proto__: $AAP, "name": "", "url": "", "epg": "", "ok": ""};
  if ((q === "")) {
    return res;
  }
  xfer = $createobject("roUrlTransfer");
  p = 1;
  total = $len(q);
  while ((p <= total)) {
    amp = $instr(p, q, "&");
    if ((amp === 0)) {
      amp = (total + 1);
    }
    pair = $mid(q, p, (amp - p));
    eq = $instr(1, pair, "=");
    if ((eq > 0)) {
      key = $left(pair, (eq - 1));
      val = $mid(pair, (eq + 1));
      val = val.$replace("+", " ");
      val = xfer.$unescape(val);
      if (res.$doesexist(key)) {
        $six(res, key, val);
      }
    }
    p = (amp + 1);
  }
  return res;
}

function parsext(q) {
  let res, xfer, p, total, amp, pair, eq, key, val;
  res = {__proto__: $AAP, "name": "", "host": "", "user": "", "pass": "", "ok": ""};
  if ((q === "")) {
    return res;
  }
  xfer = $createobject("roUrlTransfer");
  p = 1;
  total = $len(q);
  while ((p <= total)) {
    amp = $instr(p, q, "&");
    if ((amp === 0)) {
      amp = (total + 1);
    }
    pair = $mid(q, p, (amp - p));
    eq = $instr(1, pair, "=");
    if ((eq > 0)) {
      key = $left(pair, (eq - 1));
      val = $mid(pair, (eq + 1));
      val = val.$replace("+", " ");
      val = xfer.$unescape(val);
      if (res.$doesexist(key)) {
        $six(res, key, val);
      }
    }
    p = (amp + 1);
  }
  return res;
}

function parsemulti(q) {
  let res, xfer, p, total, amp, pair, eq, key, val;
  res = {__proto__: $AAP, "name": [], "url": [], "epg": [], "ok": ""};
  if ((q === "")) {
    return res;
  }
  xfer = $createobject("roUrlTransfer");
  p = 1;
  total = $len(q);
  while ((p <= total)) {
    amp = $instr(p, q, "&");
    if ((amp === 0)) {
      amp = (total + 1);
    }
    pair = $mid(q, p, (amp - p));
    eq = $instr(1, pair, "=");
    if ((eq > 0)) {
      key = $left(pair, (eq - 1));
      val = $mid(pair, (eq + 1));
      val = val.$replace("+", " ");
      val = xfer.$unescape(val);
      if ((key === "ok")) {
        res.ok = val;
      } else if ((((key === "name") || (key === "url")) || (key === "epg"))) {
        $ix(res, key).$push(val);
      }
    }
    p = (amp + 1);
  }
  while ((res.name.$count() < res.url.$count())) {
    res.name.$push("");
  }
  while ((res.epg.$count() < res.url.$count())) {
    res.epg.$push("");
  }
  return res;
}

function htmlesc(s) {
  let out, i, $e3, c, a;
  out = "";
  for (i = 1, $e3 = $len(s); i <= $e3; i++) {
    c = $mid(s, i, 1);
    a = $asc(c);
    if ((c === "&")) {
      out = (out + "&amp;");
    } else if ((c === "<")) {
      out = (out + "&lt;");
    } else if ((c === ">")) {
      out = (out + "&gt;");
    } else if ((c === $chr(34))) {
      out = (out + "&quot;");
    } else if (((a > 126) || (a < 32))) {
      out = (((out + "&#") + a.$tostr()) + ";");
    } else {
      out = (out + c);
    }
  }
  return out;
}

function sendpage(sock, status, body) {
  let text, tries, n;
  text = ((("HTTP/1.1 " + status) + $chr(13)) + $chr(10));
  text = (((text + "Content-Type: text/html; charset=utf-8") + $chr(13)) + $chr(10));
  text = (((text + "Cache-Control: no-store") + $chr(13)) + $chr(10));
  text = (((((text + "Connection: close") + $chr(13)) + $chr(10)) + $chr(13)) + $chr(10));
  text = (text + body);
  tries = 0;
  while (((text !== "") && (tries < 300))) {
    n = sock.$sendstr(text);
    if ((n > 0)) {
      text = $mid(text, (n + 1));
    } else {
      tries = (tries + 1);
      $sleep(20);
    }
  }
}

function hx(t) {
  let o, i, $e4, c, a;
  o = "";
  for (i = 1, $e4 = $len(t); i <= $e4; i++) {
    c = $mid(t, i, 1);
    a = $asc(c);
    if (((((((a > 126) || (c === "'")) || (c === $chr(34))) || (c === "<")) || (c === ">")) || (c === "&"))) {
      o = (((o + "&#") + a.$tostr()) + ";");
    } else {
      o = (o + c);
    }
  }
  return o;
}

function jq(t) {
  let o, i, $e5, c, a, h;
  o = "";
  for (i = 1, $e5 = $len(t); i <= $e5; i++) {
    c = $mid(t, i, 1);
    a = $asc(c);
    if ((((((((a > 126) || (c === "'")) || (c === "\\")) || (c === $chr(34))) || (c === "<")) || (c === ">")) || (a < 32))) {
      h = $stri(a, 16);
      while (($len(h) < 4)) {
        h = ("0" + h);
      }
      o = ((o + "\\u") + h);
    } else {
      o = (o + c);
    }
  }
  return o;
}

function noticepage() {
  let s;
  s = "";
  s = (s + "<!DOCTYPE html><html lang='");
  s = (s + i18nlang());
  s = (s + "'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'><meta name='theme-color' content='#07070a'><title>Smart IPTV MX<");
  s = (s + "/title><style>*{box-sizing:border-box}html{-webkit-text-size-adjust:100%;background:#07070a}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,'SF Pro Text','Segoe UI',Robo");
  s = (s + "to,sans-serif;background:#07070a;color:#fff;min-height:100vh;background-image:radial-gradient(120% 60% at 10% -10%,rgba(255,122,26,.28),transparent 60%),radial-gradient(80% 50% at ");
  s = (s + "100% 0%,rgba(255,61,42,.12),transparent 60%)}.wrap{max-width:520px;margin:0 auto;padding:22px 18px 40px}.brand{display:flex;align-items:center;gap:12px;margin-bottom:22px}.logo{wid");
  s = (s + "th:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#ff9a3c,#ff5a1f);display:flex;align-items:center;justify-content:center;box-shadow:0 8px 24px rgba(255,106,");
  s = (s + "0,.35)}.bname{font-weight:800;letter-spacing:.3px;font-size:17px}.bsub{color:#8a8f98;font-size:13px;margin-top:2px}.steps{display:flex;gap:6px;margin:0 0 20px}.st{flex:1;height:4px");
  s = (s + ";border-radius:4px;background:rgba(255,255,255,.12)}.st.on{background:#ff8a24}.kick{color:#ff8a24;font-weight:800;font-size:12px;letter-spacing:1.2px;text-transform:uppercase;margi");
  s = (s + "n:0 0 6px}h1{font-size:28px;line-height:1.15;margin:0 0 8px;font-weight:800}.lead{color:#a8adb5;margin:0 0 20px;font-size:15px;line-height:1.5}.tabs{display:flex;background:rgba(25");
  s = (s + "5,255,255,.06);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:4px;margin-bottom:18px}.tab{flex:1;text-align:center;padding:11px 8px;border-radius:10px;color:#c8c");
  s = (s + "cd2;text-decoration:none;font-weight:700;font-size:15px}.tab.on{background:#fff;color:#0a0a0f}.card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-r");
  s = (s + "adius:18px;padding:18px;margin-bottom:14px}.card p{color:#d0d4da;font-size:15px;line-height:1.55;margin:0 0 10px}.card p:last-child{margin:0}label.f{display:block;font-weight:700;f");
  s = (s + "ont-size:14px;margin:14px 0 7px;color:#e6e8eb}label.f:first-child{margin-top:0}.opt{color:#7e838c;font-weight:500}.inp{position:relative}input.t{width:100%;padding:15px 14px;border");
  s = (s + "-radius:13px;border:1.5px solid rgba(255,255,255,.12);background:rgba(0,0,0,.35);color:#fff;font-size:16px;outline:none;transition:border-color .2s,box-shadow .2s}input.t:focus{bor");
  s = (s + "der-color:#ff8a24;box-shadow:0 0 0 4px rgba(255,138,36,.18)}input.t.bad{border-color:#ff5a4f}input.t.good{border-color:#34c759}.help{color:#7e838c;font-size:13px;margin-top:6px;lin");
  s = (s + "e-height:1.4}.msg{font-size:13px;margin-top:6px;font-weight:600}.msg.e{color:#ff6b61}.msg.o{color:#34c759}.eye{position:absolute;right:8px;top:50%;transform:translateY(-50%);backgr");
  s = (s + "ound:rgba(255,255,255,.08);border:0;color:#c8ccd2;border-radius:9px;padding:8px 10px;font-size:13px;font-weight:700}.btn{display:flex;align-items:center;justify-content:center;gap:");
  s = (s + "10px;width:100%;margin-top:18px;padding:17px;border:0;border-radius:15px;background:linear-gradient(135deg,#ff9a3c,#ff6a00);color:#0a0a0f;font-size:17px;font-weight:800;box-shadow:");
  s = (s + "0 10px 28px rgba(255,106,0,.3);text-decoration:none}.btn:disabled{opacity:.4;box-shadow:none}.btn.sec{background:rgba(255,255,255,.07);color:#fff;border:1px solid rgba(255,255,255,");
  s = (s + ".12);box-shadow:none;font-weight:700;font-size:15px;padding:14px}.btn.rm{background:transparent;border:1px solid rgba(255,255,255,.12);color:#a8adb5;box-shadow:none;font-size:14px;");
  s = (s + "padding:11px;margin-top:12px}.spin{width:18px;height:18px;border:3px solid rgba(0,0,0,.25);border-top-color:#0a0a0f;border-radius:50%;animation:sp .8s linear infinite;display:none}");
  s = (s + ".busy .spin{display:inline-block}@keyframes sp{to{transform:rotate(360deg)}}.err{background:rgba(255,90,79,.12);border:1px solid rgba(255,90,79,.35);color:#ffd2ce;border-radius:14p");
  s = (s + "x;padding:13px 14px;margin-bottom:14px;font-size:14px;font-weight:600}.chk{display:flex;align-items:flex-start;gap:12px;color:#fff;font-weight:700;font-size:15px;line-height:1.4}.c");
  s = (s + "hk input{width:24px;height:24px;flex:none;margin:0;accent-color:#ff8a24}.bt{font-weight:800;font-size:15px;margin-bottom:4px;display:flex;align-items:center;gap:8px}.num{background");
  s = (s + ":#ff8a24;color:#0a0a0f;border-radius:8px;padding:2px 8px;font-size:13px}.hid{display:none!important}.small{color:#7e838c;font-size:13px;line-height:1.5}a.lnk{color:#ff8a24;font-wei");
  s = (s + "ght:700;text-decoration:none}.det{background:rgba(52,199,89,.12);border:1px solid rgba(52,199,89,.35);color:#b8f5c8;border-radius:12px;padding:10px 12px;font-size:13px;font-weight:");
  s = (s + "700;margin-top:10px}.done{text-align:center;padding-top:20px}.ring{width:120px;height:120px;margin:10px auto 18px}.ring circle{stroke:#34c759;stroke-width:6;fill:none;stroke-dashar");
  s = (s + "ray:340;stroke-dashoffset:340;animation:dr .7s ease-out forwards}.ring path{stroke:#34c759;stroke-width:7;fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:80;s");
  s = (s + "troke-dashoffset:80;animation:dr .4s .55s ease-out forwards}@keyframes dr{to{stroke-dashoffset:0}}.item{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);bord");
  s = (s + "er-radius:14px;padding:12px 14px;margin:8px 0;text-align:left;font-size:14px;color:#d0d4da;word-break:break-all}</style></head><body><div class='wrap'><div class='brand'><div class");
  s = (s + "='logo'><svg width='24' height='24' viewBox='0 0 24 24'><path d='M8 5v14l11-7z' fill='#0a0a0f'/></svg></div><div><div class='bname'>SMART IPTV MX</div><div class='bsub'>");
  s = (s + hx(tx("Conectado a tu TV")));
  s = (s + "</div></div></div><div class='steps'><div class='st on'></div><div class='st'></div><div class='st'></div></div><div class='kick'>");
  s = (s + hx(tx("Paso 1 de 3")));
  s = (s + "</div><h1>");
  s = (s + hx(tx("Antes de continuar")));
  s = (s + "</h1><p class='lead'>");
  s = (s + hx(tx("Aviso de responsabilidad")));
  s = (s + "</p><div class='card'><p><b>");
  s = (s + hx(tx("Smart IPTV MX es solo un reproductor.")));
  s = (s + "</b> ");
  s = (s + hx(tx("No incluye, no distribuye ni vende canales, películas ni listas de reproducción.")));
  s = (s + "</p><p>");
  s = (s + hx(tx("Para usarla tienes que cargar tus propias listas. Tú eres la única persona responsable de que ese contenido sea legal y de contar con la suscripción o el permiso para verlo.")));
  s = (s + "</p><p>");
  s = (s + hx(tx("Los creadores de la app no controlan ni respaldan lo que contengan tus listas, y no responden por el uso que se les dé.")));
  s = (s + "</p><p>");
  s = (s + hx(tx("Las listas que envíes se guardan en tu televisor.")));
  s = (s + "</p></div><form action='/form' method='get'><input type='hidden' name='ok' value='1'><div class='card'><label class='chk'><input type='checkbox' id='agree' required> <span>");
  s = (s + hx(tx("He leído este aviso y estoy de acuerdo")));
  s = (s + "</span></label></div><button class='btn' id='go' type='submit' disabled>");
  s = (s + hx(tx("Estoy de acuerdo, continuar")));
  s = (s + "</button></form><script>var a=document.getElementById('agree'),g=document.getElementById('go');a.onchange=function(){g.disabled=!a.checked;};</script></div></body></html>");
  return s;
}

function formpage(err) {
  let s;
  s = "";
  s = (s + "<!DOCTYPE html><html lang='");
  s = (s + i18nlang());
  s = (s + "'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'><meta name='theme-color' content='#07070a'><title>Smart IPTV MX<");
  s = (s + "/title><style>*{box-sizing:border-box}html{-webkit-text-size-adjust:100%;background:#07070a}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,'SF Pro Text','Segoe UI',Robo");
  s = (s + "to,sans-serif;background:#07070a;color:#fff;min-height:100vh;background-image:radial-gradient(120% 60% at 10% -10%,rgba(255,122,26,.28),transparent 60%),radial-gradient(80% 50% at ");
  s = (s + "100% 0%,rgba(255,61,42,.12),transparent 60%)}.wrap{max-width:520px;margin:0 auto;padding:22px 18px 40px}.brand{display:flex;align-items:center;gap:12px;margin-bottom:22px}.logo{wid");
  s = (s + "th:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#ff9a3c,#ff5a1f);display:flex;align-items:center;justify-content:center;box-shadow:0 8px 24px rgba(255,106,");
  s = (s + "0,.35)}.bname{font-weight:800;letter-spacing:.3px;font-size:17px}.bsub{color:#8a8f98;font-size:13px;margin-top:2px}.steps{display:flex;gap:6px;margin:0 0 20px}.st{flex:1;height:4px");
  s = (s + ";border-radius:4px;background:rgba(255,255,255,.12)}.st.on{background:#ff8a24}.kick{color:#ff8a24;font-weight:800;font-size:12px;letter-spacing:1.2px;text-transform:uppercase;margi");
  s = (s + "n:0 0 6px}h1{font-size:28px;line-height:1.15;margin:0 0 8px;font-weight:800}.lead{color:#a8adb5;margin:0 0 20px;font-size:15px;line-height:1.5}.tabs{display:flex;background:rgba(25");
  s = (s + "5,255,255,.06);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:4px;margin-bottom:18px}.tab{flex:1;text-align:center;padding:11px 8px;border-radius:10px;color:#c8c");
  s = (s + "cd2;text-decoration:none;font-weight:700;font-size:15px}.tab.on{background:#fff;color:#0a0a0f}.card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-r");
  s = (s + "adius:18px;padding:18px;margin-bottom:14px}.card p{color:#d0d4da;font-size:15px;line-height:1.55;margin:0 0 10px}.card p:last-child{margin:0}label.f{display:block;font-weight:700;f");
  s = (s + "ont-size:14px;margin:14px 0 7px;color:#e6e8eb}label.f:first-child{margin-top:0}.opt{color:#7e838c;font-weight:500}.inp{position:relative}input.t{width:100%;padding:15px 14px;border");
  s = (s + "-radius:13px;border:1.5px solid rgba(255,255,255,.12);background:rgba(0,0,0,.35);color:#fff;font-size:16px;outline:none;transition:border-color .2s,box-shadow .2s}input.t:focus{bor");
  s = (s + "der-color:#ff8a24;box-shadow:0 0 0 4px rgba(255,138,36,.18)}input.t.bad{border-color:#ff5a4f}input.t.good{border-color:#34c759}.help{color:#7e838c;font-size:13px;margin-top:6px;lin");
  s = (s + "e-height:1.4}.msg{font-size:13px;margin-top:6px;font-weight:600}.msg.e{color:#ff6b61}.msg.o{color:#34c759}.eye{position:absolute;right:8px;top:50%;transform:translateY(-50%);backgr");
  s = (s + "ound:rgba(255,255,255,.08);border:0;color:#c8ccd2;border-radius:9px;padding:8px 10px;font-size:13px;font-weight:700}.btn{display:flex;align-items:center;justify-content:center;gap:");
  s = (s + "10px;width:100%;margin-top:18px;padding:17px;border:0;border-radius:15px;background:linear-gradient(135deg,#ff9a3c,#ff6a00);color:#0a0a0f;font-size:17px;font-weight:800;box-shadow:");
  s = (s + "0 10px 28px rgba(255,106,0,.3);text-decoration:none}.btn:disabled{opacity:.4;box-shadow:none}.btn.sec{background:rgba(255,255,255,.07);color:#fff;border:1px solid rgba(255,255,255,");
  s = (s + ".12);box-shadow:none;font-weight:700;font-size:15px;padding:14px}.btn.rm{background:transparent;border:1px solid rgba(255,255,255,.12);color:#a8adb5;box-shadow:none;font-size:14px;");
  s = (s + "padding:11px;margin-top:12px}.spin{width:18px;height:18px;border:3px solid rgba(0,0,0,.25);border-top-color:#0a0a0f;border-radius:50%;animation:sp .8s linear infinite;display:none}");
  s = (s + ".busy .spin{display:inline-block}@keyframes sp{to{transform:rotate(360deg)}}.err{background:rgba(255,90,79,.12);border:1px solid rgba(255,90,79,.35);color:#ffd2ce;border-radius:14p");
  s = (s + "x;padding:13px 14px;margin-bottom:14px;font-size:14px;font-weight:600}.chk{display:flex;align-items:flex-start;gap:12px;color:#fff;font-weight:700;font-size:15px;line-height:1.4}.c");
  s = (s + "hk input{width:24px;height:24px;flex:none;margin:0;accent-color:#ff8a24}.bt{font-weight:800;font-size:15px;margin-bottom:4px;display:flex;align-items:center;gap:8px}.num{background");
  s = (s + ":#ff8a24;color:#0a0a0f;border-radius:8px;padding:2px 8px;font-size:13px}.hid{display:none!important}.small{color:#7e838c;font-size:13px;line-height:1.5}a.lnk{color:#ff8a24;font-wei");
  s = (s + "ght:700;text-decoration:none}.det{background:rgba(52,199,89,.12);border:1px solid rgba(52,199,89,.35);color:#b8f5c8;border-radius:12px;padding:10px 12px;font-size:13px;font-weight:");
  s = (s + "700;margin-top:10px}.done{text-align:center;padding-top:20px}.ring{width:120px;height:120px;margin:10px auto 18px}.ring circle{stroke:#34c759;stroke-width:6;fill:none;stroke-dashar");
  s = (s + "ray:340;stroke-dashoffset:340;animation:dr .7s ease-out forwards}.ring path{stroke:#34c759;stroke-width:7;fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:80;s");
  s = (s + "troke-dashoffset:80;animation:dr .4s .55s ease-out forwards}@keyframes dr{to{stroke-dashoffset:0}}.item{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);bord");
  s = (s + "er-radius:14px;padding:12px 14px;margin:8px 0;text-align:left;font-size:14px;color:#d0d4da;word-break:break-all}</style></head><body><div class='wrap'><div class='brand'><div class");
  s = (s + "='logo'><svg width='24' height='24' viewBox='0 0 24 24'><path d='M8 5v14l11-7z' fill='#0a0a0f'/></svg></div><div><div class='bname'>SMART IPTV MX</div><div class='bsub'>");
  s = (s + hx(tx("Conectado a tu TV")));
  s = (s + "</div></div></div><div class='steps'><div class='st on'></div><div class='st on'></div><div class='st'></div></div><div class='kick'>");
  s = (s + hx(tx("Paso 2 de 3")));
  s = (s + "</div><h1>");
  s = (s + hx(tx("Envía tu lista a la TV")));
  s = (s + "</h1><p class='lead'>");
  s = (s + hx(tx("Pega el link de tu lista M3U. La guía es opcional.")));
  s = (s + "</p><div class='tabs'><a class='tab on' href='/form?ok=1'>");
  s = (s + hx(tx("Lista M3U")));
  s = (s + "</a><a class='tab ' href='/xt?ok=1'>");
  s = (s + hx(tx("Cuenta Xtream")));
  s = (s + "</a></div>");
  s = (s + errbox(err));
  s = (s + "<form action='/add' method='get' id='frm'><input type='hidden' name='ok' value='1'><div class='card'><label class='chk'><input type='checkbox' id='multi'> <span>");
  s = (s + hx(tx("Agregar varias listas (hasta 10)")));
  s = (s + "</span></label></div><div id='blocks'></div><button type='button' class='btn sec hid' id='more'>");
  s = (s + hx(tx("+ Agregar otra lista")));
  s = (s + "</button><p class='small hid' id='cnt' style='margin:8px 0 0'></p><button type='submit' class='btn' id='send' disabled><span class='spin'></span><span id='sendt'>");
  s = (s + hx(tx("Enviar a la TV")));
  s = (s + "</span></button></form><p class='small' style='margin-top:16px'>");
  s = (s + hx(tx("Si dejas la lista vacía y pones solo la guía, se agrega a la primera lista activa.")));
  s = (s + "</p><template id='tpl'><div class='card blk'><div class='bt'><span class='num'>1</span><span>");
  s = (s + hx(tx("Lista ")));
  s = (s + "</span></div><label class='f'>");
  s = (s + hx(tx("Nombre")));
  s = (s + " <span class='opt'>(");
  s = (s + hx(tx("opcional")));
  s = (s + ")</span></label><input class='t' name='name' autocomplete='off' placeholder='");
  s = (s + hx(tx("Mi lista")));
  s = (s + "'><label class='f'>");
  s = (s + hx(tx("Link de la lista M3U")));
  s = (s + "</label><input class='t u' name='url' type='url' inputmode='url' autocapitalize='off' autocorrect='off' spellcheck='false' placeholder='http://...'><div class='msg'></div><label cl");
  s = (s + "ass='f'>");
  s = (s + hx(tx("Link de la guía XMLTV")));
  s = (s + " <span class='opt'>(");
  s = (s + hx(tx("opcional")));
  s = (s + ")</span></label><input class='t g' name='epg' type='url' inputmode='url' autocapitalize='off' autocorrect='off' spellcheck='false' placeholder='http://...  (.xml / .xml.gz)'><div c");
  s = (s + "lass='msg'></div><button type='button' class='btn rm hid'>");
  s = (s + hx(tx("Quitar esta lista")));
  s = (s + "</button></div></template><script>var TOF='");
  s = (s + jq(tx("de")));
  s = (s + "',TLI='");
  s = (s + jq(tx("listas")));
  s = (s + "',TS1='");
  s = (s + jq(tx("Enviar a la TV")));
  s = (s + "',TSN='");
  s = (s + jq(tx("Enviar {n} listas a la TV")));
  s = (s + "',TBAD='");
  s = (s + jq(tx("Debe empezar con http:// o https://")));
  s = (s + "',TOK='");
  s = (s + jq(tx("Link válido")));
  s = (s + "',TSEND='");
  s = (s + jq(tx("Enviando a tu TV...")));
  s = (s + "';var MAX=10,box=document.getElementById('blocks'),tpl=document.getElementById('tpl'),chk=document.getElementById('multi'),more=document.getElementById('more'),cnt=document.getElem");
  s = (s + "entById('cnt'),send=document.getElementById('send'),sendt=document.getElementById('sendt');function okUrl(v){return /^https?:\\/\\/\\S+\\.\\S+/i.test(v);}function check(){var any=false,");
  s = (s + "bad=false;var bl=box.children;for(var i=0;i<bl.length;i++){var u=bl[i].querySelector('.u'),g=bl[i].querySelector('.g');[u,g].forEach(function(el){var m=el.nextElementSibling,v=el.v");
  s = (s + "alue.trim();el.classList.remove('bad','good');m.className='msg';m.textContent='';if(v){if(okUrl(v)){el.classList.add('good');if(el===u){m.className='msg o';m.textContent=TOK;}}else");
  s = (s + "{el.classList.add('bad');m.className='msg e';m.textContent=TBAD;bad=true;}any=true;}});}send.disabled=!any||bad;}function renum(){var b=box.children;for(var i=0;i<b.length;i++){b[i");
  s = (s + "].querySelector('.num').textContent=i+1;b[i].querySelector('.bt').style.display=chk.checked?'flex':'none';b[i].querySelector('.rm').classList.toggle('hid',!(chk.checked&&b.length>1");
  s = (s + "));}more.classList.toggle('hid',!(chk.checked&&b.length<MAX));cnt.classList.toggle('hid',!chk.checked);cnt.textContent=b.length+' '+TOF+' '+MAX+' '+TLI;sendt.textContent=chk.checke");
  s = (s + "d&&b.length>1?TSN.replace('{n}',b.length):TS1;check();}function add(){if(box.children.length>=MAX)return;var n=tpl.content.cloneNode(true);var el=n.firstElementChild;el.querySelect");
  s = (s + "or('.rm').onclick=function(){box.removeChild(el);renum();};el.querySelectorAll('input').forEach(function(i){i.addEventListener('input',check);});box.appendChild(n);renum();return e");
  s = (s + "l;}chk.onchange=function(){if(!chk.checked){while(box.children.length>1)box.removeChild(box.lastChild);}renum();};more.onclick=function(){var el=add();if(el){el.scrollIntoView({beh");
  s = (s + "avior:'smooth',block:'center'});}};document.getElementById('frm').onsubmit=function(){send.classList.add('busy');sendt.textContent=TSEND;setTimeout(function(){send.disabled=true;},");
  s = (s + "10);};add();</script></div></body></html>");
  return s;
}

function xtformpage(err) {
  let s;
  s = "";
  s = (s + "<!DOCTYPE html><html lang='");
  s = (s + i18nlang());
  s = (s + "'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'><meta name='theme-color' content='#07070a'><title>Smart IPTV MX<");
  s = (s + "/title><style>*{box-sizing:border-box}html{-webkit-text-size-adjust:100%;background:#07070a}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,'SF Pro Text','Segoe UI',Robo");
  s = (s + "to,sans-serif;background:#07070a;color:#fff;min-height:100vh;background-image:radial-gradient(120% 60% at 10% -10%,rgba(255,122,26,.28),transparent 60%),radial-gradient(80% 50% at ");
  s = (s + "100% 0%,rgba(255,61,42,.12),transparent 60%)}.wrap{max-width:520px;margin:0 auto;padding:22px 18px 40px}.brand{display:flex;align-items:center;gap:12px;margin-bottom:22px}.logo{wid");
  s = (s + "th:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#ff9a3c,#ff5a1f);display:flex;align-items:center;justify-content:center;box-shadow:0 8px 24px rgba(255,106,");
  s = (s + "0,.35)}.bname{font-weight:800;letter-spacing:.3px;font-size:17px}.bsub{color:#8a8f98;font-size:13px;margin-top:2px}.steps{display:flex;gap:6px;margin:0 0 20px}.st{flex:1;height:4px");
  s = (s + ";border-radius:4px;background:rgba(255,255,255,.12)}.st.on{background:#ff8a24}.kick{color:#ff8a24;font-weight:800;font-size:12px;letter-spacing:1.2px;text-transform:uppercase;margi");
  s = (s + "n:0 0 6px}h1{font-size:28px;line-height:1.15;margin:0 0 8px;font-weight:800}.lead{color:#a8adb5;margin:0 0 20px;font-size:15px;line-height:1.5}.tabs{display:flex;background:rgba(25");
  s = (s + "5,255,255,.06);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:4px;margin-bottom:18px}.tab{flex:1;text-align:center;padding:11px 8px;border-radius:10px;color:#c8c");
  s = (s + "cd2;text-decoration:none;font-weight:700;font-size:15px}.tab.on{background:#fff;color:#0a0a0f}.card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-r");
  s = (s + "adius:18px;padding:18px;margin-bottom:14px}.card p{color:#d0d4da;font-size:15px;line-height:1.55;margin:0 0 10px}.card p:last-child{margin:0}label.f{display:block;font-weight:700;f");
  s = (s + "ont-size:14px;margin:14px 0 7px;color:#e6e8eb}label.f:first-child{margin-top:0}.opt{color:#7e838c;font-weight:500}.inp{position:relative}input.t{width:100%;padding:15px 14px;border");
  s = (s + "-radius:13px;border:1.5px solid rgba(255,255,255,.12);background:rgba(0,0,0,.35);color:#fff;font-size:16px;outline:none;transition:border-color .2s,box-shadow .2s}input.t:focus{bor");
  s = (s + "der-color:#ff8a24;box-shadow:0 0 0 4px rgba(255,138,36,.18)}input.t.bad{border-color:#ff5a4f}input.t.good{border-color:#34c759}.help{color:#7e838c;font-size:13px;margin-top:6px;lin");
  s = (s + "e-height:1.4}.msg{font-size:13px;margin-top:6px;font-weight:600}.msg.e{color:#ff6b61}.msg.o{color:#34c759}.eye{position:absolute;right:8px;top:50%;transform:translateY(-50%);backgr");
  s = (s + "ound:rgba(255,255,255,.08);border:0;color:#c8ccd2;border-radius:9px;padding:8px 10px;font-size:13px;font-weight:700}.btn{display:flex;align-items:center;justify-content:center;gap:");
  s = (s + "10px;width:100%;margin-top:18px;padding:17px;border:0;border-radius:15px;background:linear-gradient(135deg,#ff9a3c,#ff6a00);color:#0a0a0f;font-size:17px;font-weight:800;box-shadow:");
  s = (s + "0 10px 28px rgba(255,106,0,.3);text-decoration:none}.btn:disabled{opacity:.4;box-shadow:none}.btn.sec{background:rgba(255,255,255,.07);color:#fff;border:1px solid rgba(255,255,255,");
  s = (s + ".12);box-shadow:none;font-weight:700;font-size:15px;padding:14px}.btn.rm{background:transparent;border:1px solid rgba(255,255,255,.12);color:#a8adb5;box-shadow:none;font-size:14px;");
  s = (s + "padding:11px;margin-top:12px}.spin{width:18px;height:18px;border:3px solid rgba(0,0,0,.25);border-top-color:#0a0a0f;border-radius:50%;animation:sp .8s linear infinite;display:none}");
  s = (s + ".busy .spin{display:inline-block}@keyframes sp{to{transform:rotate(360deg)}}.err{background:rgba(255,90,79,.12);border:1px solid rgba(255,90,79,.35);color:#ffd2ce;border-radius:14p");
  s = (s + "x;padding:13px 14px;margin-bottom:14px;font-size:14px;font-weight:600}.chk{display:flex;align-items:flex-start;gap:12px;color:#fff;font-weight:700;font-size:15px;line-height:1.4}.c");
  s = (s + "hk input{width:24px;height:24px;flex:none;margin:0;accent-color:#ff8a24}.bt{font-weight:800;font-size:15px;margin-bottom:4px;display:flex;align-items:center;gap:8px}.num{background");
  s = (s + ":#ff8a24;color:#0a0a0f;border-radius:8px;padding:2px 8px;font-size:13px}.hid{display:none!important}.small{color:#7e838c;font-size:13px;line-height:1.5}a.lnk{color:#ff8a24;font-wei");
  s = (s + "ght:700;text-decoration:none}.det{background:rgba(52,199,89,.12);border:1px solid rgba(52,199,89,.35);color:#b8f5c8;border-radius:12px;padding:10px 12px;font-size:13px;font-weight:");
  s = (s + "700;margin-top:10px}.done{text-align:center;padding-top:20px}.ring{width:120px;height:120px;margin:10px auto 18px}.ring circle{stroke:#34c759;stroke-width:6;fill:none;stroke-dashar");
  s = (s + "ray:340;stroke-dashoffset:340;animation:dr .7s ease-out forwards}.ring path{stroke:#34c759;stroke-width:7;fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:80;s");
  s = (s + "troke-dashoffset:80;animation:dr .4s .55s ease-out forwards}@keyframes dr{to{stroke-dashoffset:0}}.item{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);bord");
  s = (s + "er-radius:14px;padding:12px 14px;margin:8px 0;text-align:left;font-size:14px;color:#d0d4da;word-break:break-all}</style></head><body><div class='wrap'><div class='brand'><div class");
  s = (s + "='logo'><svg width='24' height='24' viewBox='0 0 24 24'><path d='M8 5v14l11-7z' fill='#0a0a0f'/></svg></div><div><div class='bname'>SMART IPTV MX</div><div class='bsub'>");
  s = (s + hx(tx("Conectado a tu TV")));
  s = (s + "</div></div></div><div class='steps'><div class='st on'></div><div class='st on'></div><div class='st'></div></div><div class='kick'>");
  s = (s + hx(tx("Paso 2 de 3")));
  s = (s + "</div><h1>");
  s = (s + hx(tx("Agrega tu cuenta Xtream")));
  s = (s + "</h1><p class='lead'>");
  s = (s + hx(tx("Escribe los 3 datos que te dio tu proveedor, o pega tu link completo y se llenan solos.")));
  s = (s + "</p><div class='tabs'><a class='tab ' href='/form?ok=1'>");
  s = (s + hx(tx("Lista M3U")));
  s = (s + "</a><a class='tab on' href='/xt?ok=1'>");
  s = (s + hx(tx("Cuenta Xtream")));
  s = (s + "</a></div>");
  s = (s + errbox(err));
  s = (s + "<form action='/addxt' method='get' id='frm'><input type='hidden' name='ok' value='1'><div class='card'><label class='f'>");
  s = (s + hx(tx("¿Tienes un link completo?")));
  s = (s + " <span class='opt'>(");
  s = (s + hx(tx("opcional")));
  s = (s + ")</span></label><input class='t' id='full' type='url' inputmode='url' autocapitalize='off' autocorrect='off' spellcheck='false' placeholder='http://servidor.com:8080/get.php?userna");
  s = (s + "me=...'><div class='help'>");
  s = (s + hx(tx("Pega un link que tenga username y password: separamos los datos por ti.")));
  s = (s + "</div><div id='det' class='det hid'></div></div><div class='card'><label class='f'>");
  s = (s + hx(tx("Servidor")));
  s = (s + "</label><input class='t' name='host' id='host' type='url' inputmode='url' autocapitalize='off' autocorrect='off' spellcheck='false' placeholder='http://servidor.com:8080'><div clas");
  s = (s + "s='msg' id='hm'></div><label class='f'>");
  s = (s + hx(tx("Usuario")));
  s = (s + "</label><input class='t' name='user' id='user' type='text' autocapitalize='off' autocorrect='off' spellcheck='false' autocomplete='off'><label class='f'>");
  s = (s + hx(tx("Contraseña")));
  s = (s + "</label><div class='inp'><input class='t' name='pass' id='pass' type='password' autocapitalize='off' autocorrect='off' spellcheck='false' autocomplete='off' style='padding-right:84");
  s = (s + "px'><button type='button' class='eye' id='eye'>");
  s = (s + hx(tx("Ver")));
  s = (s + "</button></div><label class='f'>");
  s = (s + hx(tx("Nombre")));
  s = (s + " <span class='opt'>(");
  s = (s + hx(tx("opcional")));
  s = (s + ")</span></label><input class='t' name='name' autocomplete='off' placeholder='Xtream'></div><button type='submit' class='btn' id='send' disabled><span class='spin'></span><span id='");
  s = (s + "sendt'>");
  s = (s + hx(tx("Enviar a la TV")));
  s = (s + "</span></button></form><script>var TDET='");
  s = (s + jq(tx("Datos detectados: servidor, usuario y contraseña")));
  s = (s + "',TBAD='");
  s = (s + jq(tx("Debe empezar con http:// o https://")));
  s = (s + "',TSEND='");
  s = (s + jq(tx("Enviando a tu TV...")));
  s = (s + "',TV='");
  s = (s + jq(tx("Ver")));
  s = (s + "',TH='");
  s = (s + jq(tx("Ocultar")));
  s = (s + "';var f=document.getElementById('full'),h=document.getElementById('host'),u=document.getElementById('user'),p=document.getElementById('pass'),s=document.getElementById('send'),d=do");
  s = (s + "cument.getElementById('det'),hm=document.getElementById('hm'),e=document.getElementById('eye');function v(){var hv=h.value.trim();h.classList.remove('bad','good');hm.textContent=''");
  s = (s + ";hm.className='msg';if(hv){if(/^https?:\\/\\/[^\\s\\/]+/i.test(hv)){h.classList.add('good');}else{h.classList.add('bad');hm.className='msg e';hm.textContent=TBAD;}}s.disabled=!(/^https");
  s = (s + "?:\\/\\/[^\\s\\/]+/i.test(hv)&&u.value.trim()&&p.value.trim());}f.addEventListener('input',function(){var t=f.value.trim();d.classList.add('hid');try{var x=new URL(t);var us=x.searchPa");
  s = (s + "rams.get('username'),pw=x.searchParams.get('password');if(!us){var m=x.pathname.match(/^\\/(?:live|movie|series)\\/([^\\/]+)\\/([^\\/]+)\\//);if(m){us=decodeURIComponent(m[1]);pw=decodeU");
  s = (s + "RIComponent(m[2]);}}if(us&&pw){h.value=x.protocol+'//'+x.host;u.value=us;p.value=pw;d.textContent='\\u2713 '+TDET;d.classList.remove('hid');v();}}catch(err){}});h.addEventListener('");
  s = (s + "blur',function(){var hv=h.value.trim();if(hv&&!/^https?:\\/\\//i.test(hv)){h.value='http://'+hv;}v();});[h,u,p].forEach(function(i){i.addEventListener('input',v);});e.onclick=functio");
  s = (s + "n(){var sh=p.type==='password';p.type=sh?'text':'password';e.textContent=sh?TH:TV;};document.getElementById('frm').onsubmit=function(){s.classList.add('busy');document.getElementBy");
  s = (s + "Id('sendt').textContent=TSEND;};v();</script></div></body></html>");
  return s;
}

function donepage(items) {
  let s;
  s = "";
  s = (s + "<!DOCTYPE html><html lang='");
  s = (s + i18nlang());
  s = (s + "'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'><meta name='theme-color' content='#07070a'><title>Smart IPTV MX<");
  s = (s + "/title><style>*{box-sizing:border-box}html{-webkit-text-size-adjust:100%;background:#07070a}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,'SF Pro Text','Segoe UI',Robo");
  s = (s + "to,sans-serif;background:#07070a;color:#fff;min-height:100vh;background-image:radial-gradient(120% 60% at 10% -10%,rgba(255,122,26,.28),transparent 60%),radial-gradient(80% 50% at ");
  s = (s + "100% 0%,rgba(255,61,42,.12),transparent 60%)}.wrap{max-width:520px;margin:0 auto;padding:22px 18px 40px}.brand{display:flex;align-items:center;gap:12px;margin-bottom:22px}.logo{wid");
  s = (s + "th:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#ff9a3c,#ff5a1f);display:flex;align-items:center;justify-content:center;box-shadow:0 8px 24px rgba(255,106,");
  s = (s + "0,.35)}.bname{font-weight:800;letter-spacing:.3px;font-size:17px}.bsub{color:#8a8f98;font-size:13px;margin-top:2px}.steps{display:flex;gap:6px;margin:0 0 20px}.st{flex:1;height:4px");
  s = (s + ";border-radius:4px;background:rgba(255,255,255,.12)}.st.on{background:#ff8a24}.kick{color:#ff8a24;font-weight:800;font-size:12px;letter-spacing:1.2px;text-transform:uppercase;margi");
  s = (s + "n:0 0 6px}h1{font-size:28px;line-height:1.15;margin:0 0 8px;font-weight:800}.lead{color:#a8adb5;margin:0 0 20px;font-size:15px;line-height:1.5}.tabs{display:flex;background:rgba(25");
  s = (s + "5,255,255,.06);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:4px;margin-bottom:18px}.tab{flex:1;text-align:center;padding:11px 8px;border-radius:10px;color:#c8c");
  s = (s + "cd2;text-decoration:none;font-weight:700;font-size:15px}.tab.on{background:#fff;color:#0a0a0f}.card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-r");
  s = (s + "adius:18px;padding:18px;margin-bottom:14px}.card p{color:#d0d4da;font-size:15px;line-height:1.55;margin:0 0 10px}.card p:last-child{margin:0}label.f{display:block;font-weight:700;f");
  s = (s + "ont-size:14px;margin:14px 0 7px;color:#e6e8eb}label.f:first-child{margin-top:0}.opt{color:#7e838c;font-weight:500}.inp{position:relative}input.t{width:100%;padding:15px 14px;border");
  s = (s + "-radius:13px;border:1.5px solid rgba(255,255,255,.12);background:rgba(0,0,0,.35);color:#fff;font-size:16px;outline:none;transition:border-color .2s,box-shadow .2s}input.t:focus{bor");
  s = (s + "der-color:#ff8a24;box-shadow:0 0 0 4px rgba(255,138,36,.18)}input.t.bad{border-color:#ff5a4f}input.t.good{border-color:#34c759}.help{color:#7e838c;font-size:13px;margin-top:6px;lin");
  s = (s + "e-height:1.4}.msg{font-size:13px;margin-top:6px;font-weight:600}.msg.e{color:#ff6b61}.msg.o{color:#34c759}.eye{position:absolute;right:8px;top:50%;transform:translateY(-50%);backgr");
  s = (s + "ound:rgba(255,255,255,.08);border:0;color:#c8ccd2;border-radius:9px;padding:8px 10px;font-size:13px;font-weight:700}.btn{display:flex;align-items:center;justify-content:center;gap:");
  s = (s + "10px;width:100%;margin-top:18px;padding:17px;border:0;border-radius:15px;background:linear-gradient(135deg,#ff9a3c,#ff6a00);color:#0a0a0f;font-size:17px;font-weight:800;box-shadow:");
  s = (s + "0 10px 28px rgba(255,106,0,.3);text-decoration:none}.btn:disabled{opacity:.4;box-shadow:none}.btn.sec{background:rgba(255,255,255,.07);color:#fff;border:1px solid rgba(255,255,255,");
  s = (s + ".12);box-shadow:none;font-weight:700;font-size:15px;padding:14px}.btn.rm{background:transparent;border:1px solid rgba(255,255,255,.12);color:#a8adb5;box-shadow:none;font-size:14px;");
  s = (s + "padding:11px;margin-top:12px}.spin{width:18px;height:18px;border:3px solid rgba(0,0,0,.25);border-top-color:#0a0a0f;border-radius:50%;animation:sp .8s linear infinite;display:none}");
  s = (s + ".busy .spin{display:inline-block}@keyframes sp{to{transform:rotate(360deg)}}.err{background:rgba(255,90,79,.12);border:1px solid rgba(255,90,79,.35);color:#ffd2ce;border-radius:14p");
  s = (s + "x;padding:13px 14px;margin-bottom:14px;font-size:14px;font-weight:600}.chk{display:flex;align-items:flex-start;gap:12px;color:#fff;font-weight:700;font-size:15px;line-height:1.4}.c");
  s = (s + "hk input{width:24px;height:24px;flex:none;margin:0;accent-color:#ff8a24}.bt{font-weight:800;font-size:15px;margin-bottom:4px;display:flex;align-items:center;gap:8px}.num{background");
  s = (s + ":#ff8a24;color:#0a0a0f;border-radius:8px;padding:2px 8px;font-size:13px}.hid{display:none!important}.small{color:#7e838c;font-size:13px;line-height:1.5}a.lnk{color:#ff8a24;font-wei");
  s = (s + "ght:700;text-decoration:none}.det{background:rgba(52,199,89,.12);border:1px solid rgba(52,199,89,.35);color:#b8f5c8;border-radius:12px;padding:10px 12px;font-size:13px;font-weight:");
  s = (s + "700;margin-top:10px}.done{text-align:center;padding-top:20px}.ring{width:120px;height:120px;margin:10px auto 18px}.ring circle{stroke:#34c759;stroke-width:6;fill:none;stroke-dashar");
  s = (s + "ray:340;stroke-dashoffset:340;animation:dr .7s ease-out forwards}.ring path{stroke:#34c759;stroke-width:7;fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:80;s");
  s = (s + "troke-dashoffset:80;animation:dr .4s .55s ease-out forwards}@keyframes dr{to{stroke-dashoffset:0}}.item{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);bord");
  s = (s + "er-radius:14px;padding:12px 14px;margin:8px 0;text-align:left;font-size:14px;color:#d0d4da;word-break:break-all}</style></head><body><div class='wrap'><div class='brand'><div class");
  s = (s + "='logo'><svg width='24' height='24' viewBox='0 0 24 24'><path d='M8 5v14l11-7z' fill='#0a0a0f'/></svg></div><div><div class='bname'>SMART IPTV MX</div><div class='bsub'>");
  s = (s + hx(tx("Conectado a tu TV")));
  s = (s + "</div></div></div><div class='steps'><div class='st on'></div><div class='st on'></div><div class='st on'></div></div><div class='done'><svg class='ring' viewBox='0 0 120 120'><cir");
  s = (s + "cle cx='60' cy='60' r='54'/><path d='M36 62 l16 16 l32 -34'/></svg><h1>");
  s = (s + donetitle(items));
  s = (s + "</h1><p class='lead'>");
  s = (s + hx(tx("Mira tu televisión: ya se está cargando.")));
  s = (s + "</p>");
  s = (s + doneitems(items));
  s = (s + "<a class='btn' href='/form?ok=1' style='margin-top:22px'>");
  s = (s + hx(tx("Enviar otra lista")));
  s = (s + "</a><a class='btn sec' href='/xt?ok=1'>");
  s = (s + hx(tx("Agregar cuenta Xtream")));
  s = (s + "</a></div></div></body></html>");
  return s;
}

function errbox(err) {
  if ((err === "")) {
    return "";
  }
  return (("<div class='err'>" + hx(err)) + "</div>");
}

function donetitle(items) {
  if ((items.$count() === 1)) {
    return hx(tx("¡Listo! Ya está en tu TV"));
  }
  return hx(tx("¡{n} listas recibidas en tu TV!").$replace("{n}", items.$count().$tostr()));
}

function doneitems(items) {
  let s, it, shown;
  s = "";
  for (it of $iter(items)) {
    shown = it.name;
    if ((shown === "")) {
      shown = it.url;
    }
    if ((shown === "")) {
      shown = it.epg;
    }
    if (((shown === "") && it.$doesexist("xt"))) {
      shown = it.xt.host;
    }
    s = (((s + "<div class='item'>") + htmlesc(shown)) + "</div>");
  }
  return s;
}
// ---- components/i18n.brs ----
function i18nlangs() {
  return [{__proto__: $AAP, "code": "es", "name": "Español", "flag": "pkg:/images/flag_es.png"}, {__proto__: $AAP, "code": "en", "name": "English", "flag": "pkg:/images/flag_en.png"}, {__proto__: $AAP, "code": "pt", "name": "Português", "flag": "pkg:/images/flag_pt.png"}, {__proto__: $AAP, "code": "fr", "name": "Français", "flag": "pkg:/images/flag_fr.png"}, {__proto__: $AAP, "code": "de", "name": "Deutsch", "flag": "pkg:/images/flag_de.png"}, {__proto__: $AAP, "code": "it", "name": "Italiano", "flag": "pkg:/images/flag_it.png"}];
}

function i18nvalid(code) {
  let l;
  for (l of $iter(i18nlangs())) {
    if ((l.code === code)) {
      return true;
    }
  }
  return false;
}

function i18ndetect() {
  let code, di, loc, c;
  code = "en";
  di = $createobject("roDeviceInfo");
  if ((di != null)) {
    loc = di.$getcurrentlocale();
    if (((loc != null) && ($len(loc) >= 2))) {
      c = $lcase($left(loc, 2));
      if (i18nvalid(c)) {
        code = c;
      }
    }
  }
  return code;
}

function i18nload(lang) {
  let d, txt, arr, p;
  d = $createobject("roAssociativeArray");
  d.$setmodecasesensitive();
  txt = $readasciifile((("pkg:/locale/" + lang) + ".json"));
  if (((txt != null) && (txt !== ""))) {
    arr = $parsejson(txt);
    if ((arr != null)) {
      for (p of $iter(arr)) {
        $six(d, $ix(p, 0), $ix(p, 1));
      }
    }
  }
  m.i18nd = d;
  m.i18nlang = lang;
}

function tx(s) {
  let lang, v;
  lang = m.global.lang;
  if ((lang == null)) {
    return s;
  }
  if ((lang === "es")) {
    return s;
  }
  if ((m.i18nlang == null)) {
    i18nload(lang);
  } else if ((m.i18nlang !== lang)) {
    i18nload(lang);
  }
  v = m.i18nd.$lookup(s);
  if ((v == null)) {
    return s;
  }
  return v;
}

function i18nlang() {
  let l;
  l = m.global.lang;
  if ((l == null)) {
    return "es";
  }
  return l;
}

function i18n24h() {
  let l;
  l = i18nlang();
  return (((l !== "es") && (l !== "en")));
}

function i18ndow3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  }
  if ((l === "pt")) {
    return ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
  }
  if ((l === "fr")) {
    return ["dim.", "lun.", "mar.", "mer.", "jeu.", "ven.", "sam."];
  }
  if ((l === "de")) {
    return ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
  }
  if ((l === "it")) {
    return ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
  }
  return ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
}

function i18nmon3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  }
  if ((l === "pt")) {
    return ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
  }
  if ((l === "fr")) {
    return ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
  }
  if ((l === "de")) {
    return ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];
  }
  if ((l === "it")) {
    return ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"];
  }
  return ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
}

function i18ndowfull() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  }
  if ((l === "pt")) {
    return ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
  }
  if ((l === "fr")) {
    return ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  }
  if ((l === "de")) {
    return ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
  }
  if ((l === "it")) {
    return ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"];
  }
  return ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
}

function i18ncompass() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  }
  if ((l === "pt")) {
    return ["N", "NE", "L", "SE", "S", "SO", "O", "NO"];
  }
  if ((l === "de")) {
    return ["N", "NO", "O", "SO", "S", "SW", "W", "NW"];
  }
  if ((l === "it")) {
    return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
  }
  return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
}

function i18nhm(h, mm, longfmt) {
  let hs, h12, l, suf;
  if (i18n24h()) {
    hs = h.$tostr();
    if ((h < 10)) {
      hs = ("0" + hs);
    }
    return ((hs + ":") + mm);
  }
  h12 = (h % 12);
  if ((h12 === 0)) {
    h12 = 12;
  }
  l = i18nlang();
  if ((l === "en")) {
    suf = " AM";
    if ((h >= 12)) {
      suf = " PM";
    }
    if ((!longfmt)) {
      suf = "a";
      if ((h >= 12)) {
        suf = "p";
      }
    }
    return (((h12.$tostr() + ":") + mm) + suf);
  }
  if (longfmt) {
    suf = " a. m.";
    if ((h >= 12)) {
      suf = " p. m.";
    }
  } else {
    suf = "a";
    if ((h >= 12)) {
      suf = "p";
    }
  }
  return (((h12.$tostr() + ":") + mm) + suf);
}
// ---- components/xtcommon.brs ----
function dstr(v) {
  let t;
  t = $type(v);
  if (((t === "roString") || (t === "String"))) {
    return v;
  }
  if (((((((((((t === "roInt") || (t === "Integer")) || (t === "roLongInteger")) || (t === "LongInteger")) || (t === "roFloat")) || (t === "Float")) || (t === "roDouble")) || (t === "Double")) || (t === "roBoolean")) || (t === "Boolean"))) {
    return v.$tostr();
  }
  return "";
}

function xtesc(s) {
  let ba, hex, out, i, $e0, b;
  ba = $createobject("roByteArray");
  ba.$fromasciistring(s);
  hex = "0123456789ABCDEF";
  out = "";
  for (i = 0, $e0 = (ba.$count() - 1); i <= $e0; i++) {
    b = $ix(ba, i);
    if ((((((((((b >= 48) && (b <= 57))) || (((b >= 65) && (b <= 90)))) || (((b >= 97) && (b <= 122)))) || (b === 45)) || (b === 46)) || (b === 95)) || (b === 126))) {
      out = (out + $chr(b));
    } else {
      out = (((out + "%") + $mid(hex, (($idiv(b, 16)) + 1), 1)) + $mid(hex, (((b % 16)) + 1), 1));
    }
  }
  return out;
}

function xthexval(c) {
  if (((c >= 48) && (c <= 57))) {
    return (c - 48);
  }
  if (((c >= 65) && (c <= 70))) {
    return (c - 55);
  }
  if (((c >= 97) && (c <= 102))) {
    return (c - 87);
  }
  return (-1);
}

function xtunesc(s) {
  let src, dst, n, i, b, used, hi, lo;
  src = $createobject("roByteArray");
  src.$fromasciistring(s);
  dst = $createobject("roByteArray");
  n = src.$count();
  i = 0;
  while ((i < n)) {
    b = $ix(src, i);
    used = false;
    if ((b === 37)) {
      if (((i + 2) < n)) {
        hi = xthexval($ix(src, (i + 1)));
        lo = xthexval($ix(src, (i + 2)));
        if (((hi >= 0) && (lo >= 0))) {
          dst.$push(((hi * 16) + lo));
          i = (i + 3);
          used = true;
        }
      }
    }
    if ((!used)) {
      dst.$push(b);
      i = (i + 1);
    }
  }
  return dst.$toasciistring();
}

function xtbase(h) {
  let s, low, q, done, tail;
  s = h.$trim();
  if ((s === "")) {
    return "";
  }
  low = $lcase(s);
  if ((($left(low, 7) !== "http://") && ($left(low, 8) !== "https://"))) {
    s = ("http://" + s);
  }
  q = $instr(1, s, "?");
  if ((q > 0)) {
    s = $left(s, (q - 1));
  }
  done = false;
  while ((!done)) {
    done = true;
    while ((($right(s, 1) === "/") && ($len(s) > 8))) {
      s = $left(s, ($len(s) - 1));
      done = false;
    }
    for (tail of $iter(["/player_api.php", "/get.php", "/xmltv.php", "/panel_api.php", "/c"])) {
      if (((($len(s) - $len(tail)) > 8) && ($lcase($right(s, $len(tail))) === tail))) {
        s = $left(s, ($len(s) - $len(tail)));
        done = false;
      }
    }
  }
  return s;
}

function xtparam(s, key) {
  let low, sep, p, st, en;
  low = $lcase(s);
  for (sep of $iter(["?", "&"])) {
    p = $instr(1, low, ((sep + $lcase(key)) + "="));
    if ((p > 0)) {
      st = ((p + $len(key)) + 2);
      en = $instr(st, s, "&");
      if ((en === 0)) {
        en = ($len(s) + 1);
      }
      return xtunesc($mid(s, st, (en - st)));
    }
  }
  return "";
}

function xtfromurl(s) {
  let u, p;
  u = xtparam(s, "username");
  p = xtparam(s, "password");
  if (((u === "") || (p === ""))) {
    return null;
  }
  return {__proto__: $AAP, "host": xtbase(s), "user": u, "pass": p};
}
return {"init": init, "serve": serve, "handlerequest": handlerequest, "parsequery": parsequery, "parsext": parsext, "parsemulti": parsemulti, "htmlesc": htmlesc, "sendpage": sendpage, "hx": hx, "jq": jq, "noticepage": noticepage, "formpage": formpage, "xtformpage": xtformpage, "donepage": donepage, "errbox": errbox, "donetitle": donetitle, "doneitems": doneitems, "i18nlangs": i18nlangs, "i18nvalid": i18nvalid, "i18ndetect": i18ndetect, "i18nload": i18nload, "tx": tx, "i18nlang": i18nlang, "i18n24h": i18n24h, "i18ndow3": i18ndow3, "i18nmon3": i18nmon3, "i18ndowfull": i18ndowfull, "i18ncompass": i18ncompass, "i18nhm": i18nhm, "dstr": dstr, "xtesc": xtesc, "xthexval": xthexval, "xtunesc": xtunesc, "xtbase": xtbase, "xtparam": xtparam, "xtfromurl": xtfromurl};
});

$defineComponent({"name":"WeatherTask","extends":"Task","fields":[{"id":"op","type":"string"},{"id":"query","type":"string"},{"id":"lat","type":"string"},{"id":"lon","type":"string"},{"id":"unit","type":"string"},{"id":"result","type":"assocarray"}],"children":[]}, function (m) {
// ---- components/weathertask.brs ----
function init() {
  m.top.functionname = "runWeather";
}

function runweather() {
  if ((m.top.op === "geo")) {
    dogeo();
  } else {
    doload();
  }
}

function getjson(url) {
  let port, http, msg, s;
  port = $createobject("roMessagePort");
  http = $createobject("roUrlTransfer");
  http.$setmessageport(port);
  http.$setcertificatesfile("common:/certs/ca-bundle.crt");
  http.$initclientcertificates();
  http.$enableencodings(true);
  http.$seturl(url);
  if ((!http.$asyncgettostring())) {
    return null;
  }
  msg = $wait(15000, port);
  if (($type(msg) !== "roUrlEvent")) {
    http.$asynccancel();
    return null;
  }
  if ((msg.$getresponsecode() !== 200)) {
    return null;
  }
  s = msg.$getstring();
  if (((s == null) || (s === ""))) {
    return null;
  }
  return $parsejson(s);
}

function num(v, d) {
  let t;
  t = $type(v);
  if (((((((((t === "Integer") || (t === "roInt")) || (t === "Float")) || (t === "roFloat")) || (t === "Double")) || (t === "roDouble")) || (t === "LongInteger")) || (t === "roLongInteger"))) {
    return v;
  }
  return d;
}

function pick(arr, i, d) {
  if ((arr == null)) {
    return d;
  }
  if (($type(arr) !== "roArray")) {
    return d;
  }
  if (((i < 0) || (i >= arr.$count()))) {
    return d;
  }
  return num($ix(arr, i), d);
}

function pickstr(arr, i) {
  let v;
  if ((arr == null)) {
    return "";
  }
  if (($type(arr) !== "roArray")) {
    return "";
  }
  if (((i < 0) || (i >= arr.$count()))) {
    return "";
  }
  v = $ix(arr, i);
  if ((($type(v) === "roString") || ($type(v) === "String"))) {
    return v;
  }
  return "";
}

function dogeo() {
  let http, url, j, list, r, label, region, country, full;
  http = $createobject("roUrlTransfer");
  url = (((("https://geocoding-api.open-meteo.com/v1/search?name=" + http.$escape(m.top.query)) + "&count=8&language=") + wxlang()) + "&format=json");
  j = getjson(url);
  if ((j == null)) {
    m.top.result = {__proto__: $AAP, "ok": false, "list": []};
    return;
  }
  list = [];
  if ((j.results != null)) {
    for (r of $iter(j.results)) {
      if ((((r.latitude != null) && (r.longitude != null)) && (r.name != null))) {
        label = r.name;
        region = "";
        if (((r.admin1 != null) && (r.admin1 !== r.name))) {
          region = r.admin1;
        }
        country = "";
        if ((r.country != null)) {
          country = r.country;
        }
        full = label;
        if ((region !== "")) {
          full = ((full + ", ") + region);
        }
        if ((country !== "")) {
          full = ((full + ", ") + country);
        }
        list.$push({__proto__: $AAP, "label": full, "name": label, "lat": r.latitude.$tostr(), "lon": r.longitude.$tostr()});
      }
    }
  }
  m.top.result = {__proto__: $AAP, "ok": true, "list": list};
}

function doload() {
  let lat, lon, tu, ws, pu, url, fx, c, cur, hours, h, prefix, start, i, $e0, $e1, hh, days, d, $e2, aq, aqj, a;
  lat = m.top.lat;
  lon = m.top.lon;
  tu = "celsius";
  ws = "kmh";
  pu = "mm";
  if ((m.top.unit === "f")) {
    tu = "fahrenheit";
    ws = "mph";
    pu = "inch";
  }
  url = ((("https://api.open-meteo.com/v1/forecast?latitude=" + lat) + "&longitude=") + lon);
  url = (url + "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m,surface_pressure,cloud_cover");
  url = (url + "&hourly=temperature_2m,precipitation_probability,weather_code,is_day");
  url = (url + "&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_sum,precipitation_probability_max");
  url = ((((((url + "&timezone=auto&forecast_days=7&temperature_unit=") + tu) + "&wind_speed_unit=") + ws) + "&precipitation_unit=") + pu);
  fx = getjson(url);
  if (((((fx == null) || (fx.current == null)) || (fx.daily == null)) || (fx.hourly == null))) {
    m.top.result = {__proto__: $AAP, "ok": false};
    return;
  }
  c = fx.current;
  cur = {__proto__: $AAP, "t": num(c.temperature_2m, 0), "feel": num(c.apparent_temperature, 0), "hum": num(c.relative_humidity_2m, (-1)), "code": num(c.weather_code, 0), "isday": num(c.is_day, 1), "precip": num(c.precipitation, 0), "wind": num(c.wind_speed_10m, 0), "dir": num(c.wind_direction_10m, (-1)), "gust": num(c.wind_gusts_10m, 0), "pres": num(c.surface_pressure, 0), "cloud": num(c.cloud_cover, 0)};
  hours = [];
  h = fx.hourly;
  prefix = "";
  if ((c.time != null)) {
    prefix = $left(c.time, 13);
  }
  start = 0;
  if ((h.time != null)) {
    for (i = 0, $e0 = (h.time.$count() - 1); i <= $e0; i++) {
      if (($left($ix(h.time, i), 13) >= prefix)) {
        start = i;
        break;
      }
    }
    for (i = start, $e1 = (h.time.$count() - 1); i <= $e1; i++) {
      if ((hours.$count() >= 12)) {
        break;
      }
      hh = $int($val($mid($ix(h.time, i), 12, 2)));
      hours.$push({__proto__: $AAP, "h": hh, "t": pick(h.temperature_2m, i, 0), "code": pick(h.weather_code, i, 0), "pop": pick(h.precipitation_probability, i, 0), "day": pick(h.is_day, i, 1)});
    }
  }
  days = [];
  d = fx.daily;
  if ((d.time != null)) {
    for (i = 0, $e2 = (d.time.$count() - 1); i <= $e2; i++) {
      days.$push({__proto__: $AAP, "date": $ix(d.time, i), "code": pick(d.weather_code, i, 0), "max": pick(d.temperature_2m_max, i, 0), "min": pick(d.temperature_2m_min, i, 0), "pop": pick(d.precipitation_probability_max, i, 0), "psum": pick(d.precipitation_sum, i, 0), "uv": pick(d.uv_index_max, i, 0), "sunrise": pickstr(d.sunrise, i), "sunset": pickstr(d.sunset, i)});
    }
  }
  aq = null;
  aqj = getjson((((("https://air-quality-api.open-meteo.com/v1/air-quality?latitude=" + lat) + "&longitude=") + lon) + "&current=us_aqi,pm2_5,pm10&timezone=auto"));
  if (((aqj != null) && (aqj.current != null))) {
    a = aqj.current;
    aq = {__proto__: $AAP, "aqi": num(a.us_aqi, (-1)), "pm25": num(a.pm2_5, (-1)), "pm10": num(a.pm10, (-1))};
  }
  m.top.result = {__proto__: $AAP, "ok": true, "ts": $createobject("roDateTime").$asseconds(), "unit": m.top.unit, "cur": cur, "hours": hours, "days": days, "aq": aq};
}

function wxlang() {
  let l;
  l = m.global.lang;
  if (((l == null) || (l === ""))) {
    return "es";
  }
  return l;
}
return {"init": init, "runweather": runweather, "getjson": getjson, "num": num, "pick": pick, "pickstr": pickstr, "dogeo": dogeo, "doload": doload, "wxlang": wxlang};
});

$defineComponent({"name":"XtreamReader","extends":"Task","fields":[{"id":"host","type":"string"},{"id":"user","type":"string"},{"id":"pass","type":"string"},{"id":"op","type":"string","value":"catalog"},{"id":"serid","type":"string"},{"id":"favs","type":"assocarray"},{"id":"listepg","type":"string"},{"id":"direct","type":"boolean","value":"false"},{"id":"progress","type":"integer","value":"0"},{"id":"status","type":"string"},{"id":"content","type":"node"},{"id":"movies","type":"node"},{"id":"series","type":"node"},{"id":"adult","type":"node"},{"id":"wanted","type":"assocarray"},{"id":"epgurl","type":"string"},{"id":"result","type":"assocarray"}],"children":[]}, function (m) {
// ---- components/xtreamreader.brs ----
function init() {
  m.top.functionname = "xtRun";
}

function xtrun() {
  m.xtbig = false;
  if ((m.top.op === "series")) {
    xtrunseries();
  } else if ((m.top.op === "vodinfo")) {
    xtrunvodinfo();
  } else {
    xtruncatalog();
  }
}

function xthttp(url) {
  let http;
  http = $createobject("roUrlTransfer");
  http.$setcertificatesfile("common:/certs/ca-bundle.crt");
  http.$initclientcertificates();
  http.$enableencodings(true);
  http.$addheader("User-Agent", "Mozilla/5.0 (Linux; Roku) SmartIPTVMX");
  http.$seturl(url);
  return http;
}

function xtjson(url, maxbytes, waitms = 90000) {
  let lbl, fs, path, port, http, msg, code, st, txt, js, rx;
  m.xtbig = false;
  m.xttimeout = false;
  m.xtsmall = false;
  lbl = xtlabel(url);
  fs = $createobject("roFileSystem");
  path = "cachefs:/xt_resp.json";
  if (fs.$exists(path)) {
    fs.$delete(path);
  }
  port = $createobject("roMessagePort");
  http = xthttp(url);
  http.$setmessageport(port);
  if ((!http.$asyncgettofile(path))) {
    console.log("[XT] ", lbl, ": no se pudo iniciar la descarga");
    return null;
  }
  msg = $wait(waitms, port);
  if (($type(msg) !== "roUrlEvent")) {
    console.log("[XT] ", lbl, ": sin respuesta en ", $int((waitms / 1000)), " s");
    m.xttimeout = true;
    http.$asynccancel();
    if (fs.$exists(path)) {
      fs.$delete(path);
    }
    return null;
  }
  code = msg.$getresponsecode();
  if ((code !== 200)) {
    console.log("[XT] ", lbl, ": codigo ", code, " ", msg.$getfailurereason());
    if (fs.$exists(path)) {
      fs.$delete(path);
    }
    return null;
  }
  st = fs.$stat(path);
  if ((st == null)) {
    console.log("[XT] ", lbl, ": respuesta sin archivo");
    return null;
  }
  if (((maxbytes > 0) && (st.size > maxbytes))) {
    console.log("[XT] ", lbl, ": ", st.size, " bytes, muy grande, se pide por categoria");
    m.xtbig = true;
    fs.$delete(path);
    return null;
  }
  if ((st.size < 64)) {
    m.xtsmall = true;
  }
  txt = $readasciifile(path);
  fs.$delete(path);
  if (((txt == null) || (txt === ""))) {
    console.log("[XT] ", lbl, ": respuesta vacia (", st.size, " bytes)");
    return null;
  }
  if (($asc($left(txt, 1)) === 65279)) {
    txt = $mid(txt, 2);
  }
  js = $parsejson(txt);
  if ((js == null)) {
    rx = $createobject("roRegex", "[\\x01-\\x1F]", "");
    js = $parsejson(rx.$replaceall(txt, " "));
    if ((js == null)) {
      console.log("[XT] ", lbl, ": JSON invalido (", st.size, " bytes). Inicio: ", $left(txt, 100));
    } else {
      console.log("[XT] ", lbl, ": JSON reparado (", st.size, " bytes)");
    }
  } else if (($type(js) === "roArray")) {
    console.log("[XT] ", lbl, ": ", js.$count(), " elementos (", st.size, " bytes)");
  }
  txt = "";
  return js;
}

function xtlabel(url) {
  let a;
  a = $instr(1, url, "action=");
  if ((a > 0)) {
    return $mid(url, (a + 7));
  }
  return "login";
}

function xtfail(msg) {
  m.top.status = ("error:" + msg);
  m.top.content = $createobject("roSGNode", "ContentNode");
}

function xtadult(s) {
  let t, w;
  t = $lcase(s);
  if (($instr(1, t, "adult swim") > 0)) {
    return false;
  }
  for (w of $iter(["xxx", "adult", "porn", "erotic", "erotik", "erot", "erót", "playboy", "sexy", "hentai", "18+", "+18"])) {
    if (($instr(1, t, w) > 0)) {
      return true;
    }
  }
  return false;
}

function xtruncatalog() {
  let base, user, pass, ue, pe, api, auth, ui, st, liveext, af, hasm3, f, livefmt, favs, ctx, live, vod, ser, total;
  base = xtbase(m.top.host);
  user = m.top.user;
  pass = m.top.pass;
  if ((((base === "") || (user === "")) || (pass === ""))) {
    xtfail(tx("Faltan datos de la cuenta Xtream."));
    return;
  }
  ue = xtesc(user);
  pe = xtesc(pass);
  api = ((((base + "/player_api.php?username=") + ue) + "&password=") + pe);
  m.top.progress = 1;
  auth = xtjson(api, 0);
  if (($type(auth) !== "roAssociativeArray")) {
    xtfail(tx("No se pudo conectar con el servidor. Revisa la dirección y tu internet."));
    return;
  }
  ui = auth.user_info;
  if (($type(ui) !== "roAssociativeArray")) {
    xtfail(tx("Usuario o contraseña incorrectos."));
    return;
  }
  if ((dstr(ui.auth) === "0")) {
    xtfail(tx("Usuario o contraseña incorrectos."));
    return;
  }
  st = $lcase(dstr(ui.status));
  if (((st !== "") && (st !== "active"))) {
    xtfail((tx("La cuenta no está activa: ") + st));
    return;
  }
  liveext = "m3u8";
  af = ui.allowed_output_formats;
  if ((($type(af) === "roArray") && (af.$count() > 0))) {
    hasm3 = false;
    for (f of $iter(af)) {
      if (($lcase(dstr(f)) === "m3u8")) {
        hasm3 = true;
      }
    }
    if ((!hasm3)) {
      liveext = "ts";
    }
  }
  livefmt = "hls";
  if ((liveext === "ts")) {
    livefmt = "ts";
  }
  favs = m.top.favs;
  if ((favs == null)) {
    favs = {__proto__: $AAP};
  }
  ctx = {__proto__: $AAP, "base": base, "ue": ue, "pe": pe, "api": api, "liveext": liveext, "livefmt": livefmt, "favs": favs, "adultroot": $createobject("roSGNode", "ContentNode")};
  live = xtsection("live", ctx, 4, 40);
  vod = xtsection("vod", ctx, 40, 72);
  ser = xtsection("series", ctx, 72, 96);
  total = ((live.$getchildcount() + vod.$getchildcount()) + ser.$getchildcount());
  if ((total === 0)) {
    xtfail(tx("El servidor no devolvió canales, películas ni series."));
    return;
  }
  m.top.progress = 99;
  m.top.epgurl = ((((base + "/xmltv.php?username=") + ue) + "&password=") + pe);
  m.top.movies = vod;
  m.top.series = ser;
  m.top.adult = ctx.adultroot;
  m.top.wanted = epgwantedof(live);
  m.top.content = live;
}

function xtsection(kind, ctx, p0, p1) {
  let root, cata, stra, catname, order, cats, c, id, groups, adg, all, okn, failn, seq, n, i, $e0, u, part, pre;
  root = $createobject("roSGNode", "ContentNode");
  cata = "get_live_categories";
  stra = "get_live_streams";
  if ((kind === "vod")) {
    cata = "get_vod_categories";
    stra = "get_vod_streams";
  } else if ((kind === "series")) {
    cata = "get_series_categories";
    stra = "get_series";
  }
  catname = {__proto__: $AAP};
  $six(catname, "_", "Otros");
  order = [];
  cats = xtjson(((ctx.api + "&action=") + cata), 0);
  if (($type(cats) !== "roArray")) {
    $sleep(1500);
    cats = xtjson(((ctx.api + "&action=") + cata), 0);
  }
  if (($type(cats) === "roArray")) {
    for (c of $iter(cats)) {
      if (($type(c) === "roAssociativeArray")) {
        id = dstr(c.category_id);
        if (((id !== "") && (!catname.$doesexist(id)))) {
          $six(catname, id, dstr(c.category_name));
          order.$push(id);
        }
      }
    }
  }
  order.$push("_");
  m.top.progress = (p0 + $int((((p1 - p0)) * 0.2)));
  groups = {__proto__: $AAP};
  adg = {__proto__: $AAP};
  all = xtjson(((ctx.api + "&action=") + stra), 20000000, 180000);
  if (((($type(all) !== "roArray") && (!m.xtbig)) && (!m.xttimeout))) {
    $sleep(2000);
    all = xtjson(((ctx.api + "&action=") + stra), 20000000, 180000);
  }
  if (($type(all) === "roArray")) {
    xtadd(kind, all, groups, ctx, catname, adg);
    all = null;
  } else if ((order.$count() > 1)) {
    all = null;
    okn = 0;
    failn = 0;
    seq = 0;
    n = (order.$count() - 1);
    for (i = 0, $e0 = (n - 1); i <= $e0; i++) {
      u = ((((ctx.api + "&action=") + stra) + "&category_id=") + xtesc($ix(order, i)));
      part = xtjson(u, 0);
      if ((($type(part) !== "roArray") && (!m.xtsmall))) {
        $sleep(1500);
        part = xtjson(u, 0);
      }
      if ((($type(part) !== "roArray") && m.xtsmall)) {
        okn = (okn + 1);
        seq = 0;
      } else if (($type(part) === "roArray")) {
        xtadd(kind, part, groups, ctx, catname, adg);
        okn = (okn + 1);
        seq = 0;
      } else {
        failn = (failn + 1);
        seq = (seq + 1);
        if (((okn === 0) && (seq >= 3))) {
          break;
        }
        if ((seq >= 8)) {
          break;
        }
        $sleep(2500);
      }
      part = null;
      $sleep(150);
      m.top.progress = (p0 + $int((((p1 - p0)) * ((0.2 + ((0.7 * ((i + 1))) / n))))));
    }
    console.log("[XT] ", kind, " por categoria: ", okn, " bien, ", failn, " fallaron, de ", n);
  }
  xtfill(kind, root, groups, order, catname, ctx);
  pre = tx("TV en vivo");
  if ((kind === "vod")) {
    pre = tx("Películas");
  }
  if ((kind === "series")) {
    pre = tx("Series");
  }
  xtfill(kind, ctx.adultroot, adg, order, catname, ctx, (pre + " · "));
  m.top.progress = p1;
  return root;
}

function xtadd(kind, items, groups, ctx, catname, adg) {
  let it, cid, name, skip, e, sid, ext, f, dest;
  for (it of $iter(items)) {
    if (($type(it) === "roAssociativeArray")) {
      cid = dstr(it.category_id);
      if (((cid === "") || (!catname.$doesexist(cid)))) {
        cid = "_";
      }
      name = dstr(it.name);
      skip = xtadult($ix(catname, cid));
      if ((((kind === "live") && (!skip)) && xtadult(name))) {
        skip = true;
      }
      if (true) {
        e = null;
        sid = "";
        if ((kind === "series")) {
          sid = dstr(it.series_id);
          if ((name === "")) {
            name = tx("Sin titulo");
          }
          if ((sid !== "")) {
            e = {__proto__: $AAP, "t": name, "sid": sid, "l": cleanlogo(dstr(it.cover)), "k": sortkey(name)};
          }
        } else if ((kind === "vod")) {
          sid = dstr(it.stream_id);
          if ((name === "")) {
            name = tx("Sin titulo");
          }
          if ((sid !== "")) {
            ext = $lcase(dstr(it.container_extension));
            if ((ext === "")) {
              ext = "mp4";
            }
            f = "mp4";
            if ((ext === "mkv")) {
              f = "mkv";
            }
            e = {__proto__: $AAP, "t": name, "u": ((((((((ctx.base + "/movie/") + ctx.ue) + "/") + ctx.pe) + "/") + sid) + ".") + ext), "i": "", "l": cleanlogo(dstr(it.stream_icon)), "n": "", "f": f, "k": sortkey(name)};
          }
        } else {
          sid = dstr(it.stream_id);
          if ((name === "")) {
            name = tx("Canal sin nombre");
          }
          if ((sid !== "")) {
            e = {__proto__: $AAP, "t": name, "u": ((((((((ctx.base + "/live/") + ctx.ue) + "/") + ctx.pe) + "/") + sid) + ".") + ctx.liveext), "i": $lcase(dstr(it.epg_channel_id)), "l": cleanlogo(dstr(it.stream_icon)), "n": dstr(it.num), "f": ctx.livefmt, "k": ""};
          }
        }
        if ((e != null)) {
          dest = groups;
          if (skip) {
            dest = adg;
          }
          if ((!dest.$doesexist(cid))) {
            $six(dest, cid, []);
          }
          $ix(dest, cid).$push(e);
        }
      }
    }
  }
}

function xtfill(kind, root, groups, order, catname, ctx, prefix = "") {
  let cid, arr, name, cat, d, e, item, sr;
  for (cid of $iter(order)) {
    arr = $ix(groups, cid);
    groups.$delete(cid);
    if (((arr != null) && (arr.$count() > 0))) {
      if ((kind !== "live")) {
        arr.$sortby("k");
      }
      name = (prefix + $ix(catname, cid));
      cat = root.$createchild("ContentNode");
      cat.id = name;
      d = "movie";
      if ((kind === "live")) {
        d = "live";
      }
      for (e of $iter(arr)) {
        item = cat.$createchild("ContentNode");
        if ((kind === "series")) {
          item.$setfields({__proto__: $AAP, "title": e.t, "id": ("xt:" + e.sid), "hdposterurl": e.l, "description": "series", "shortdescriptionline1": ("xt:" + e.sid)});
        } else {
          sr = 0;
          if (ctx.favs.$doesexist(e.u)) {
            sr = 100;
          }
          item.$setfields({__proto__: $AAP, "title": e.t, "url": e.u, "id": e.i, "streamformat": e.f, "hdposterurl": e.l, "shortdescriptionline1": e.n, "description": d, "starrating": sr});
        }
      }
      cat.title = (((name + "  (") + cat.$getchildcount().$tostr()) + ")");
    }
  }
}

function xtrunseries() {
  let base, ue, pe, res, j, cover, inf, bd, raw, eps, key, arr, i, sr, list, ep, eid, ext, f, num, poster, eplot, edur, secs, et, pr;
  base = xtbase(m.top.host);
  ue = xtesc(m.top.user);
  pe = xtesc(m.top.pass);
  res = {__proto__: $AAP, "ok": false, "seasons": [], "info": {__proto__: $AAP}};
  j = xtjson(((((((base + "/player_api.php?username=") + ue) + "&password=") + pe) + "&action=get_series_info&series_id=") + xtesc(m.top.serid)), 0);
  if (($type(j) === "roAssociativeArray")) {
    cover = "";
    if (($type(j.info) === "roAssociativeArray")) {
      inf = j.info;
      cover = cleanlogo(dstr(inf.cover));
      bd = inf.backdrop_path;
      if (($type(bd) === "roArray")) {
        if ((bd.$count() > 0)) {
          bd = $ix(bd, 0);
        } else {
          bd = "";
        }
      }
      res.info = {__proto__: $AAP, "plot": xtfirst(inf, ["plot", "description"]), "cast": xtfirst(inf, ["cast", "actors"]), "director": xtfirst(inf, ["director"]), "genre": xtfirst(inf, ["genre"]), "date": xtfirst(inf, ["releaseDate", "releasedate", "release_date"]), "rating": xtfirst(inf, ["rating"]), "backdrop": cleanlogo(dstr(bd)), "cover": cover};
    }
    raw = [];
    eps = j.episodes;
    if (($type(eps) === "roAssociativeArray")) {
      for (key of $iter(eps)) {
        arr = $ix(eps, key);
        if (($type(arr) === "roArray")) {
          raw.$push({__proto__: $AAP, "s": $int($val(key)), "arr": arr});
        }
      }
    } else if (($type(eps) === "roArray")) {
      i = 0;
      for (arr of $iter(eps)) {
        i = (i + 1);
        if (($type(arr) === "roArray")) {
          raw.$push({__proto__: $AAP, "s": i, "arr": arr});
        }
      }
    }
    for (sr of $iter(raw)) {
      list = [];
      for (ep of $iter(sr.arr)) {
        if (($type(ep) === "roAssociativeArray")) {
          eid = dstr(ep.id);
          if ((eid !== "")) {
            ext = $lcase(dstr(ep.container_extension));
            if ((ext === "")) {
              ext = "mp4";
            }
            f = "mp4";
            if ((ext === "mkv")) {
              f = "mkv";
            }
            num = $int($val(dstr(ep.episode_num)));
            if ((num <= 0)) {
              num = (list.$count() + 1);
            }
            poster = "";
            eplot = "";
            edur = "";
            if (($type(ep.info) === "roAssociativeArray")) {
              poster = cleanlogo(dstr(ep.info.movie_image));
              eplot = xtfirst(ep.info, ["plot", "overview"]);
              edur = xtfirst(ep.info, ["duration"]);
              if ((edur === "")) {
                secs = $int($val(xtfirst(ep.info, ["duration_secs"])));
                if ((secs > 0)) {
                  edur = ((($idiv(secs, 3600)).$tostr() + ":") + ($idiv(((secs % 3600)), 60)).$tostr());
                }
              }
            }
            if ((poster === "")) {
              poster = cover;
            }
            et = dstr(ep.title);
            if (($instr(1, et, "&") > 0)) {
              et = decodeentities(et);
            }
            pr = epparse(et);
            if ((pr != null)) {
              et = pr.t;
            }
            list.$push({__proto__: $AAP, "e": num, "t": et, "u": ((((((((base + "/series/") + ue) + "/") + pe) + "/") + eid) + ".") + ext), "f": f, "l": poster, "p": eplot, "d": edur});
          }
        }
      }
      if ((list.$count() > 0)) {
        list.$sortby("e");
        res.seasons.$push({__proto__: $AAP, "s": sr.s, "eps": list});
      }
    }
    res.seasons.$sortby("s");
    if ((res.seasons.$count() > 0)) {
      res.ok = true;
    }
  }
  m.top.result = res;
}

function xtrunvodinfo() {
  let res, ut, user, pass, url, port, http, msg, j, inf, bd;
  res = {__proto__: $AAP, "ok": false};
  ut = $createobject("roUrlTransfer");
  user = ut.$unescape(m.top.user);
  pass = ut.$unescape(m.top.pass);
  if ((user == null)) {
    user = m.top.user;
  }
  if ((pass == null)) {
    pass = m.top.pass;
  }
  url = ((((((xtbase(m.top.host) + "/player_api.php?username=") + xtesc(user)) + "&password=") + xtesc(pass)) + "&action=get_vod_info&vod_id=") + xtesc(m.top.serid));
  port = $createobject("roMessagePort");
  http = xthttp(url);
  http.$setmessageport(port);
  if (http.$asyncgettostring()) {
    msg = $wait(20000, port);
    if (($type(msg) === "roUrlEvent")) {
      if ((msg.$getresponsecode() === 200)) {
        j = $parsejson(msg.$getstring());
        if (($type(j) === "roAssociativeArray")) {
          if (($type(j.info) === "roAssociativeArray")) {
            inf = j.info;
            res.plot = xtfirst(inf, ["plot", "description"]);
            res.cast = xtfirst(inf, ["cast", "actors"]);
            res.director = xtfirst(inf, ["director"]);
            res.genre = xtfirst(inf, ["genre"]);
            res.date = xtfirst(inf, ["releasedate", "release_date", "releaseDate"]);
            res.duration = xtfirst(inf, ["duration"]);
            res.rating = xtfirst(inf, ["rating"]);
            bd = inf.backdrop_path;
            if (($type(bd) === "roArray")) {
              if ((bd.$count() > 0)) {
                bd = $ix(bd, 0);
              } else {
                bd = "";
              }
            }
            res.backdrop = cleanlogo(dstr(bd));
            res.poster = cleanlogo(xtfirst(inf, ["movie_image", "cover_big"]));
            res.ok = true;
          }
        }
      }
    } else {
      http.$asynccancel();
    }
  }
  m.top.result = res;
}

function xtfirst(inf, keys) {
  let k, v;
  for (k of $iter(keys)) {
    v = dstr($ix(inf, k)).$trim();
    if ((((v !== "") && (v !== "0")) && ($lcase(v) !== "null"))) {
      if (($instr(1, v, "&") > 0)) {
        v = decodeentities(decodeentities(v));
      }
      return v;
    }
  }
  return "";
}
// ---- components/xtcommon.brs ----
function dstr(v) {
  let t;
  t = $type(v);
  if (((t === "roString") || (t === "String"))) {
    return v;
  }
  if (((((((((((t === "roInt") || (t === "Integer")) || (t === "roLongInteger")) || (t === "LongInteger")) || (t === "roFloat")) || (t === "Float")) || (t === "roDouble")) || (t === "Double")) || (t === "roBoolean")) || (t === "Boolean"))) {
    return v.$tostr();
  }
  return "";
}

function xtesc(s) {
  let ba, hex, out, i, $e0, b;
  ba = $createobject("roByteArray");
  ba.$fromasciistring(s);
  hex = "0123456789ABCDEF";
  out = "";
  for (i = 0, $e0 = (ba.$count() - 1); i <= $e0; i++) {
    b = $ix(ba, i);
    if ((((((((((b >= 48) && (b <= 57))) || (((b >= 65) && (b <= 90)))) || (((b >= 97) && (b <= 122)))) || (b === 45)) || (b === 46)) || (b === 95)) || (b === 126))) {
      out = (out + $chr(b));
    } else {
      out = (((out + "%") + $mid(hex, (($idiv(b, 16)) + 1), 1)) + $mid(hex, (((b % 16)) + 1), 1));
    }
  }
  return out;
}

function xthexval(c) {
  if (((c >= 48) && (c <= 57))) {
    return (c - 48);
  }
  if (((c >= 65) && (c <= 70))) {
    return (c - 55);
  }
  if (((c >= 97) && (c <= 102))) {
    return (c - 87);
  }
  return (-1);
}

function xtunesc(s) {
  let src, dst, n, i, b, used, hi, lo;
  src = $createobject("roByteArray");
  src.$fromasciistring(s);
  dst = $createobject("roByteArray");
  n = src.$count();
  i = 0;
  while ((i < n)) {
    b = $ix(src, i);
    used = false;
    if ((b === 37)) {
      if (((i + 2) < n)) {
        hi = xthexval($ix(src, (i + 1)));
        lo = xthexval($ix(src, (i + 2)));
        if (((hi >= 0) && (lo >= 0))) {
          dst.$push(((hi * 16) + lo));
          i = (i + 3);
          used = true;
        }
      }
    }
    if ((!used)) {
      dst.$push(b);
      i = (i + 1);
    }
  }
  return dst.$toasciistring();
}

function xtbase(h) {
  let s, low, q, done, tail;
  s = h.$trim();
  if ((s === "")) {
    return "";
  }
  low = $lcase(s);
  if ((($left(low, 7) !== "http://") && ($left(low, 8) !== "https://"))) {
    s = ("http://" + s);
  }
  q = $instr(1, s, "?");
  if ((q > 0)) {
    s = $left(s, (q - 1));
  }
  done = false;
  while ((!done)) {
    done = true;
    while ((($right(s, 1) === "/") && ($len(s) > 8))) {
      s = $left(s, ($len(s) - 1));
      done = false;
    }
    for (tail of $iter(["/player_api.php", "/get.php", "/xmltv.php", "/panel_api.php", "/c"])) {
      if (((($len(s) - $len(tail)) > 8) && ($lcase($right(s, $len(tail))) === tail))) {
        s = $left(s, ($len(s) - $len(tail)));
        done = false;
      }
    }
  }
  return s;
}

function xtparam(s, key) {
  let low, sep, p, st, en;
  low = $lcase(s);
  for (sep of $iter(["?", "&"])) {
    p = $instr(1, low, ((sep + $lcase(key)) + "="));
    if ((p > 0)) {
      st = ((p + $len(key)) + 2);
      en = $instr(st, s, "&");
      if ((en === 0)) {
        en = ($len(s) + 1);
      }
      return xtunesc($mid(s, st, (en - st)));
    }
  }
  return "";
}

function xtfromurl(s) {
  let u, p;
  u = xtparam(s, "username");
  p = xtparam(s, "password");
  if (((u === "") || (p === ""))) {
    return null;
  }
  return {__proto__: $AAP, "host": xtbase(s), "user": u, "pass": p};
}
// ---- components/utils.brs ----
function getattr(s, key) {
  let pat, p, okp, vstart, q, e, total, c;
  pat = (key + "=");
  p = $instr(1, s, pat);
  while ((p > 0)) {
    okp = false;
    if ((p === 1)) {
      okp = true;
    } else {
      okp = (($mid(s, (p - 1), 1) === " "));
    }
    if (okp) {
      break;
    }
    p = $instr((p + 1), s, pat);
  }
  if ((p === 0)) {
    return "";
  }
  vstart = (p + $len(pat));
  q = $mid(s, vstart, 1);
  if (((q === $chr(34)) || (q === "'"))) {
    e = $instr((vstart + 1), s, q);
    if ((e === 0)) {
      return "";
    }
    return $mid(s, (vstart + 1), ((e - vstart) - 1));
  }
  total = $len(s);
  e = vstart;
  while ((e <= total)) {
    c = $mid(s, e, 1);
    if (((c === " ") || (c === ","))) {
      break;
    }
    e = (e + 1);
  }
  return $mid(s, vstart, (e - vstart));
}

function normname(s) {
  let out, i, $e0, c, a;
  s = $lcase(s);
  out = "";
  for (i = 1, $e0 = $len(s); i <= $e0; i++) {
    c = $mid(s, i, 1);
    a = $asc(c);
    if (((((a >= 97) && (a <= 122))) || (((a >= 48) && (a <= 57))))) {
      out = (out + c);
    }
  }
  return out;
}

function decodeentities(s) {
  let p, semi, numstr, code, repl;
  p = $instr(1, s, "&#");
  while ((p > 0)) {
    semi = $instr(p, s, ";");
    if (((semi === 0) || ((semi - p) > 8))) {
      break;
    }
    numstr = $mid(s, (p + 2), ((semi - p) - 2));
    code = 0;
    if ((($left(numstr, 1) === "x") || ($left(numstr, 1) === "X"))) {
      code = $val($mid(numstr, 2), 16);
    } else {
      code = $val(numstr, 10);
    }
    repl = "";
    if ((code > 0)) {
      repl = $chr(code);
    }
    s = (($left(s, (p - 1)) + repl) + $mid(s, (semi + 1)));
    p = $instr((p + 1), s, "&#");
  }
  s = s.$replace("&lt;", "<");
  s = s.$replace("&gt;", ">");
  s = s.$replace("&quot;", $chr(34));
  s = s.$replace("&apos;", "'");
  s = s.$replace("&#39;", "'");
  s = s.$replace("&amp;", "&");
  return s;
}

function pad2(n) {
  if ((n < 10)) {
    return ("0" + n.$tostr());
  }
  return n.$tostr();
}

function fmttime(secs) {
  let dt;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  return i18nhm(dt.$gethours(), pad2(dt.$getminutes()), false);
}

function fmttimelong(secs) {
  let dt;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  return i18nhm(dt.$gethours(), pad2(dt.$getminutes()), true);
}

function fmtday(secs) {
  let dt, days, months;
  dt = $createobject("roDateTime");
  dt.$fromseconds(secs);
  dt.$tolocaltime();
  days = i18ndow3();
  months = i18nmon3();
  return (((($ix(days, dt.$getdayofweek()) + " ") + dt.$getdayofmonth().$tostr()) + " ") + $ix(months, (dt.$getmonth() - 1)));
}

function cleanlogo(u) {
  let low, base, q;
  u = u.$trim();
  if (((u === "") || ($len(u) > 2000))) {
    return "";
  }
  low = $lcase(u);
  if (($left(low, 4) !== "http")) {
    return "";
  }
  base = low;
  q = $instr(1, low, "?");
  if ((q > 0)) {
    base = $left(low, (q - 1));
  }
  if (($right(base, 4) === ".svg")) {
    return "";
  }
  return u;
}

function epgwantedof(root) {
  let wanted, i, $e1, cat, j, $e2, ch, cid, nk;
  wanted = {__proto__: $AAP};
  if ((root == null)) {
    return wanted;
  }
  for (i = 0, $e1 = (root.$getchildcount() - 1); i <= $e1; i++) {
    cat = root.$getchild(i);
    for (j = 0, $e2 = (cat.$getchildcount() - 1); j <= $e2; j++) {
      ch = cat.$getchild(j);
      cid = ch.id;
      if (((cid != null) && (cid !== ""))) {
        $six(wanted, $lcase(cid), true);
      }
      nk = normname(ch.title);
      if ((nk !== "")) {
        $six(wanted, nk, true);
      }
    }
  }
  return wanted;
}
// ---- components/series.brs ----
function epregexes() {
  let b;
  if ((m.eprx == null)) {
    b = "(?:^|[\\s\\.\\-_\\[\\(])";
    m.eprx = [{__proto__: $AAP, "rx": $createobject("roRegex", (b + "S(\\d{1,2})[\\s\\.\\-_]*E(\\d{1,3})(?!\\d)"), "i"), "strong": true}, {__proto__: $AAP, "rx": $createobject("roRegex", (b + "(?:(?:Season|Temporada|Temp)\\.?\\s*|T)(\\d{1,2})[\\s\\.\\-_,]*(?:Episode|Episodio|Cap\\w*|Ep|E)\\.?\\s*(\\d{1,3})(?!\\d)"), "i"), "strong": true}, {__proto__: $AAP, "rx": $createobject("roRegex", (b + "(\\d{1,2})x(\\d{1,3})(?![\\dp])"), "i"), "strong": false}];
  }
  return m.eprx;
}

function epparse(title) {
  let p, r, full, at, nm, rest;
  for (p of $iter(epregexes())) {
    r = p.rx.$match(title);
    if ((r.$count() >= 3)) {
      full = $ix(r, 0);
      at = $instr(1, title, full);
      if ((at > 0)) {
        nm = eptrim($left(title, (at - 1)));
        rest = eptrim($mid(title, (at + $len(full))));
        return {__proto__: $AAP, "name": nm, "s": $val($ix(r, 1)), "e": $val($ix(r, 2)), "t": rest, "strong": p.strong};
      }
    }
  }
  return null;
}

function eptrim(s) {
  let seps;
  s = s.$trim();
  seps = "-:|.,([_ ";
  while ((($len(s) > 0) && ($instr(1, seps, $left(s, 1)) > 0))) {
    s = $mid(s, 2).$trim();
  }
  while ((($len(s) > 0) && ($instr(1, seps, $right(s, 1)) > 0))) {
    s = $left(s, ($len(s) - 1)).$trim();
  }
  return s;
}

function sortkey(t) {
  let s, ff, tt, i, $e0, a;
  s = $lcase(t);
  ff = ["á", "é", "í", "ó", "ú", "ü", "ñ", "Á", "É", "Í", "Ó", "Ú", "Ü", "Ñ"];
  tt = ["a", "e", "i", "o", "u", "u", "n", "a", "e", "i", "o", "u", "u", "n"];
  for (i = 0, $e0 = (ff.$count() - 1); i <= $e0; i++) {
    s = s.$replace($ix(ff, i), $ix(tt, i));
  }
  while (($len(s) > 1)) {
    a = $asc($left(s, 1));
    if (((((a >= 48) && (a <= 57))) || (((a >= 97) && (a <= 122))))) {
      break;
    }
    s = $mid(s, 2);
  }
  return s;
}

function seradd(sd, order, gname, ep, entry) {
  let g, key, rec, sk, num;
  if ((!sd.$doesexist(gname))) {
    $six(sd, gname, {__proto__: $AAP, "order": [], "map": {__proto__: $AAP}});
    order.$push(gname);
  }
  g = $ix(sd, gname);
  key = $lcase(ep.name);
  if ((!g.map.$doesexist(key))) {
    $six(g.map, key, {__proto__: $AAP, "name": ep.name, "poster": "", "seasons": {__proto__: $AAP}, "snums": []});
    g.order.$push(key);
  }
  rec = $ix(g.map, key);
  if (((rec.poster === "") && (entry.l !== ""))) {
    rec.poster = entry.l;
  }
  sk = ep.s.$tostr();
  if ((!rec.seasons.$doesexist(sk))) {
    $six(rec.seasons, sk, []);
    rec.snums.$push(ep.s);
  }
  num = ep.e;
  if ((num <= 0)) {
    num = ($ix(rec.seasons, sk).$count() + 1);
  }
  $ix(rec.seasons, sk).$push({__proto__: $AAP, "e": num, "t": ep.t, "u": entry.u, "f": entry.f, "l": entry.l});
}

function serfill(root, sd, order) {
  let gname, g, arr, key, rec, cat, a, sn, s, season, eps, ep, item;
  for (gname of $iter(order)) {
    g = $ix(sd, gname);
    arr = [];
    for (key of $iter(g.order)) {
      rec = $ix(g.map, key);
      arr.$push({__proto__: $AAP, "k": sortkey(rec.name), "r": rec});
    }
    arr.$sortby("k");
    cat = root.$createchild("ContentNode");
    cat.id = gname;
    cat.title = (((gname + "  (") + arr.$count().$tostr()) + ")");
    for (a of $iter(arr)) {
      rec = a.r;
      sn = cat.$createchild("ContentNode");
      sn.title = rec.name;
      sn.id = $lcase(rec.name);
      sn.hdposterurl = rec.poster;
      sn.description = "series";
      rec.snums.$sort();
      for (s of $iter(rec.snums)) {
        season = sn.$createchild("ContentNode");
        season.id = s.$tostr();
        season.title = (tx("Temporada ") + s.$tostr());
        eps = $ix(rec.seasons, s.$tostr());
        eps.$sortby("e");
        for (ep of $iter(eps)) {
          item = season.$createchild("ContentNode");
          item.title = sereptitle(rec.name, s, ep);
          item.shortdescriptionline2 = ep.t;
          item.url = ep.u;
          item.streamformat = ep.f;
          item.hdposterurl = ep.l;
          item.shortdescriptionline1 = ep.e.$tostr();
          item.description = "movie";
        }
      }
    }
  }
}

function serfilldirect(root, sd, order, seen, favs) {
  let gname, g, arr, key, rec, cat, a, sn, s, eps, season, ep, u, sr, item;
  for (gname of $iter(order)) {
    g = $ix(sd, gname);
    sd.$delete(gname);
    if (((g == null) || ($lcase(gname) === "adultos"))) {
      continue;
    }
    arr = [];
    for (key of $iter(g.order)) {
      rec = $ix(g.map, key);
      arr.$push({__proto__: $AAP, "k": sortkey(rec.name), "r": rec});
    }
    arr.$sortby("k");
    cat = null;
    for (a of $iter(arr)) {
      rec = a.r;
      sn = null;
      rec.snums.$sort();
      for (s of $iter(rec.snums)) {
        eps = $ix(rec.seasons, s.$tostr());
        eps.$sortby("e");
        season = null;
        for (ep of $iter(eps)) {
          u = ep.u;
          if (((u !== "") && (!seen.$doesexist(u)))) {
            $six(seen, u, true);
            if ((cat == null)) {
              cat = root.$createchild("ContentNode");
              cat.id = gname;
            }
            if ((sn == null)) {
              sn = cat.$createchild("ContentNode");
              sn.$setfields({__proto__: $AAP, "title": rec.name, "id": $lcase(rec.name), "hdposterurl": rec.poster, "description": "series"});
            }
            if ((season == null)) {
              season = sn.$createchild("ContentNode");
              season.id = s.$tostr();
              season.title = (tx("Temporada ") + s.$tostr());
            }
            sr = 0;
            if (favs.$doesexist(u)) {
              sr = 100;
            }
            item = season.$createchild("ContentNode");
            item.$setfields({__proto__: $AAP, "title": sereptitle(rec.name, s, ep), "shortdescriptionline2": ep.t, "url": u, "streamformat": ep.f, "hdposterurl": ep.l, "shortdescriptionline1": ep.e.$tostr(), "description": "movie", "starrating": sr});
          }
        }
      }
    }
    if ((cat != null)) {
      cat.title = (((gname + "  (") + cat.$getchildcount().$tostr()) + ")");
    }
  }
}

function sereptitle(name, s, ep) {
  let t;
  t = ((((name + "  T") + s.$tostr()) + " E") + ep.e.$tostr());
  if ((ep.t !== "")) {
    t = ((t + " - ") + ep.t);
  }
  return t;
}
// ---- components/i18n.brs ----
function i18nlangs() {
  return [{__proto__: $AAP, "code": "es", "name": "Español", "flag": "pkg:/images/flag_es.png"}, {__proto__: $AAP, "code": "en", "name": "English", "flag": "pkg:/images/flag_en.png"}, {__proto__: $AAP, "code": "pt", "name": "Português", "flag": "pkg:/images/flag_pt.png"}, {__proto__: $AAP, "code": "fr", "name": "Français", "flag": "pkg:/images/flag_fr.png"}, {__proto__: $AAP, "code": "de", "name": "Deutsch", "flag": "pkg:/images/flag_de.png"}, {__proto__: $AAP, "code": "it", "name": "Italiano", "flag": "pkg:/images/flag_it.png"}];
}

function i18nvalid(code) {
  let l;
  for (l of $iter(i18nlangs())) {
    if ((l.code === code)) {
      return true;
    }
  }
  return false;
}

function i18ndetect() {
  let code, di, loc, c;
  code = "en";
  di = $createobject("roDeviceInfo");
  if ((di != null)) {
    loc = di.$getcurrentlocale();
    if (((loc != null) && ($len(loc) >= 2))) {
      c = $lcase($left(loc, 2));
      if (i18nvalid(c)) {
        code = c;
      }
    }
  }
  return code;
}

function i18nload(lang) {
  let d, txt, arr, p;
  d = $createobject("roAssociativeArray");
  d.$setmodecasesensitive();
  txt = $readasciifile((("pkg:/locale/" + lang) + ".json"));
  if (((txt != null) && (txt !== ""))) {
    arr = $parsejson(txt);
    if ((arr != null)) {
      for (p of $iter(arr)) {
        $six(d, $ix(p, 0), $ix(p, 1));
      }
    }
  }
  m.i18nd = d;
  m.i18nlang = lang;
}

function tx(s) {
  let lang, v;
  lang = m.global.lang;
  if ((lang == null)) {
    return s;
  }
  if ((lang === "es")) {
    return s;
  }
  if ((m.i18nlang == null)) {
    i18nload(lang);
  } else if ((m.i18nlang !== lang)) {
    i18nload(lang);
  }
  v = m.i18nd.$lookup(s);
  if ((v == null)) {
    return s;
  }
  return v;
}

function i18nlang() {
  let l;
  l = m.global.lang;
  if ((l == null)) {
    return "es";
  }
  return l;
}

function i18n24h() {
  let l;
  l = i18nlang();
  return (((l !== "es") && (l !== "en")));
}

function i18ndow3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  }
  if ((l === "pt")) {
    return ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
  }
  if ((l === "fr")) {
    return ["dim.", "lun.", "mar.", "mer.", "jeu.", "ven.", "sam."];
  }
  if ((l === "de")) {
    return ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
  }
  if ((l === "it")) {
    return ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
  }
  return ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
}

function i18nmon3() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  }
  if ((l === "pt")) {
    return ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
  }
  if ((l === "fr")) {
    return ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
  }
  if ((l === "de")) {
    return ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];
  }
  if ((l === "it")) {
    return ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"];
  }
  return ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
}

function i18ndowfull() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  }
  if ((l === "pt")) {
    return ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
  }
  if ((l === "fr")) {
    return ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  }
  if ((l === "de")) {
    return ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
  }
  if ((l === "it")) {
    return ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"];
  }
  return ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
}

function i18ncompass() {
  let l;
  l = i18nlang();
  if ((l === "en")) {
    return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  }
  if ((l === "pt")) {
    return ["N", "NE", "L", "SE", "S", "SO", "O", "NO"];
  }
  if ((l === "de")) {
    return ["N", "NO", "O", "SO", "S", "SW", "W", "NW"];
  }
  if ((l === "it")) {
    return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
  }
  return ["N", "NE", "E", "SE", "S", "SO", "O", "NO"];
}

function i18nhm(h, mm, longfmt) {
  let hs, h12, l, suf;
  if (i18n24h()) {
    hs = h.$tostr();
    if ((h < 10)) {
      hs = ("0" + hs);
    }
    return ((hs + ":") + mm);
  }
  h12 = (h % 12);
  if ((h12 === 0)) {
    h12 = 12;
  }
  l = i18nlang();
  if ((l === "en")) {
    suf = " AM";
    if ((h >= 12)) {
      suf = " PM";
    }
    if ((!longfmt)) {
      suf = "a";
      if ((h >= 12)) {
        suf = "p";
      }
    }
    return (((h12.$tostr() + ":") + mm) + suf);
  }
  if (longfmt) {
    suf = " a. m.";
    if ((h >= 12)) {
      suf = " p. m.";
    }
  } else {
    suf = "a";
    if ((h >= 12)) {
      suf = "p";
    }
  }
  return (((h12.$tostr() + ":") + mm) + suf);
}
return {"init": init, "xtrun": xtrun, "xthttp": xthttp, "xtjson": xtjson, "xtlabel": xtlabel, "xtfail": xtfail, "xtadult": xtadult, "xtruncatalog": xtruncatalog, "xtsection": xtsection, "xtadd": xtadd, "xtfill": xtfill, "xtrunseries": xtrunseries, "xtrunvodinfo": xtrunvodinfo, "xtfirst": xtfirst, "dstr": dstr, "xtesc": xtesc, "xthexval": xthexval, "xtunesc": xtunesc, "xtbase": xtbase, "xtparam": xtparam, "xtfromurl": xtfromurl, "getattr": getattr, "normname": normname, "decodeentities": decodeentities, "pad2": pad2, "fmttime": fmttime, "fmttimelong": fmttimelong, "fmtday": fmtday, "cleanlogo": cleanlogo, "epgwantedof": epgwantedof, "epregexes": epregexes, "epparse": epparse, "eptrim": eptrim, "sortkey": sortkey, "seradd": seradd, "serfill": serfill, "serfilldirect": serfilldirect, "sereptitle": sereptitle, "i18nlangs": i18nlangs, "i18nvalid": i18nvalid, "i18ndetect": i18ndetect, "i18nload": i18nload, "tx": tx, "i18nlang": i18nlang, "i18n24h": i18n24h, "i18ndow3": i18ndow3, "i18nmon3": i18nmon3, "i18ndowfull": i18ndowfull, "i18ncompass": i18ncompass, "i18nhm": i18nhm};
});

$defineComponent({"name":"MosFeedTask","extends":"Task","fields":[{"id":"leagues","type":"array"},{"id":"ymd","type":"string"},{"id":"result","type":"assocarray"}],"children":[]}, function (m) {
// ---- components/mosfeedtask.brs ----
function init() {
  m.top.functionname = "mfRun";
}

function mfrun() {
  let out;
  out = {__proto__: $AAP, "ok": false, "evs": [], "lids": []};
  try {
    out = mffetch(m.top.leagues, m.top.ymd);
  } catch (e) {
    console.log("[MF] error: ", e.message);
  }
  m.top.result = out;
}

function mfleagues() {
  return [{__proto__: $AAP, "id": "mex.1", "n": "Liga MX"}, {__proto__: $AAP, "id": "uefa.champions", "n": "Champions League"}, {__proto__: $AAP, "id": "eng.1", "n": "Premier League"}, {__proto__: $AAP, "id": "esp.1", "n": "LaLiga"}, {__proto__: $AAP, "id": "ita.1", "n": "Serie A"}, {__proto__: $AAP, "id": "ger.1", "n": "Bundesliga"}, {__proto__: $AAP, "id": "fra.1", "n": "Ligue 1"}, {__proto__: $AAP, "id": "ned.1", "n": "Eredivisie"}, {__proto__: $AAP, "id": "por.1", "n": "Liga Portugal"}, {__proto__: $AAP, "id": "uefa.europa", "n": "Europa League"}, {__proto__: $AAP, "id": "uefa.europa.conf", "n": "Conference League"}, {__proto__: $AAP, "id": "usa.1", "n": "MLS"}, {__proto__: $AAP, "id": "concacaf.champions", "n": "Concacaf Champions Cup"}, {__proto__: $AAP, "id": "concacaf.leagues.cup", "n": "Leagues Cup"}, {__proto__: $AAP, "id": "conmebol.libertadores", "n": "Copa Libertadores"}, {__proto__: $AAP, "id": "conmebol.sudamericana", "n": "Copa Sudamericana"}, {__proto__: $AAP, "id": "arg.1", "n": "Liga Argentina"}, {__proto__: $AAP, "id": "bra.1", "n": "Brasileirão"}, {__proto__: $AAP, "id": "mex.2", "n": "Liga de Expansión MX"}, {__proto__: $AAP, "id": "mex.w.1", "n": "Liga MX Femenil"}, {__proto__: $AAP, "id": "eng.2", "n": "Championship"}, {__proto__: $AAP, "id": "esp.copa_del_rey", "n": "Copa del Rey"}, {__proto__: $AAP, "id": "eng.fa", "n": "FA Cup"}, {__proto__: $AAP, "id": "fifa.world", "n": "Mundial 2026"}, {__proto__: $AAP, "id": "fifa.worldq.concacaf", "n": "Eliminatorias Concacaf"}, {__proto__: $AAP, "id": "fifa.worldq.conmebol", "n": "Eliminatorias Conmebol"}, {__proto__: $AAP, "id": "fifa.worldq.uefa", "n": "Eliminatorias UEFA"}, {__proto__: $AAP, "id": "uefa.nations", "n": "Nations League"}, {__proto__: $AAP, "id": "concacaf.nations.league", "n": "Nations League Concacaf"}, {__proto__: $AAP, "id": "fifa.friendly", "n": "Amistosos"}];
}

function mffetch(lids, ymd) {
  let out, all, info, i, $e0, want, lg, id, base, seen, port, reqs, n, h, u, pending, clock, msg, rq, js, li, e, ev, k;
  out = {__proto__: $AAP, "ok": false, "evs": [], "lids": []};
  all = mfleagues();
  info = {__proto__: $AAP};
  for (i = 0, $e0 = (all.$count() - 1); i <= $e0; i++) {
    $six(info, $ix(all, i).id, {__proto__: $AAP, "n": $ix(all, i).n, "p": (i + 1)});
  }
  want = [];
  if (((lids == null) || (lids.$count() === 0))) {
    for (lg of $iter(all)) {
      want.$push(lg.id);
    }
  } else {
    for (id of $iter(lids)) {
      if (info.$doesexist(id)) {
        want.$push(id);
      }
    }
  }
  base = "https://site.api.espn.com/apis/site/v2/sports/soccer/";
  seen = {__proto__: $AAP};
  i = 0;
  while ((i < want.$count())) {
    port = $createobject("roMessagePort");
    reqs = {__proto__: $AAP};
    n = 0;
    while (((i < want.$count()) && (n < 8))) {
      id = $ix(want, i);
      h = $createobject("roUrlTransfer");
      h.$setcertificatesfile("common:/certs/ca-bundle.crt");
      h.$initclientcertificates();
      h.$enableencodings(true);
      h.$setmessageport(port);
      u = ((base + id) + "/scoreboard");
      if ((ymd !== "")) {
        u = ((u + "?dates=") + ymd);
      }
      h.$seturl(u);
      if (h.$asyncgettostring()) {
        $six(reqs, h.$getidentity().$tostr(), {__proto__: $AAP, "h": h, "id": id, "done": false});
        n = (n + 1);
      }
      i = (i + 1);
    }
    pending = n;
    clock = $createobject("roTimespan");
    while (((pending > 0) && (clock.$totalmilliseconds() < 15000))) {
      msg = $wait(1000, port);
      if (($type(msg) === "roUrlEvent")) {
        rq = $ix(reqs, msg.$getsourceidentity().$tostr());
        if (((rq != null) && (!rq.done))) {
          rq.done = true;
          pending = (pending - 1);
          if ((msg.$getresponsecode() === 200)) {
            js = null;
            try {
              js = $parsejson(msg.$getstring());
            } catch (e) {
              js = null;
            }
            if (((js != null) && ($type(js) === "roAssociativeArray"))) {
              out.ok = true;
              out.lids.$push(rq.id);
              if (($type(js.events) === "roArray")) {
                li = $ix(info, rq.id);
                for (e of $iter(js.events)) {
                  ev = mfevent(e);
                  if (((ev != null) && (!seen.$doesexist(ev.id)))) {
                    $six(seen, ev.id, true);
                    ev.lid = rq.id;
                    ev.lg = li.n;
                    ev.prio = li.p;
                    out.evs.$push(ev);
                  }
                }
              }
            }
          }
        }
      }
    }
    for (k of $iter(reqs)) {
      if ((!$ix(reqs, k).done)) {
        $ix(reqs, k).h.$asynccancel();
      }
    }
  }
  console.log("[MF] ESPN: ", out.lids.$count(), " ligas, ", out.evs.$count(), " partidos");
  return out;
}

function mfs(v) {
  let t;
  if ((v == null)) {
    return "";
  }
  t = $type(v);
  if (((t === "roString") || (t === "String"))) {
    return v;
  }
  if (((((((t === "roInteger") || (t === "Integer")) || (t === "roFloat")) || (t === "Float")) || (t === "LongInteger")) || (t === "Double"))) {
    return v.$tostr();
  }
  return "";
}

function mfb(v) {
  let t;
  t = $type(v);
  if (((t === "roBoolean") || (t === "Boolean"))) {
    return v;
  }
  return false;
}

function mfn(v) {
  let t;
  t = $type(v);
  if (((((((t === "roInteger") || (t === "Integer")) || (t === "roFloat")) || (t === "Float")) || (t === "LongInteger")) || (t === "Double"))) {
    return v;
  }
  return 0;
}

function mfiso(s) {
  let d;
  if (($len(s) < 16)) {
    return 0;
  }
  d = $createobject("roDateTime");
  d.$fromiso8601string(($left(s, 16) + ":00Z"));
  return d.$asseconds();
}

function mfevent(e) {
  let comp, h, a, c, stt, st, sn, det, ck, hid, aid, hn, an, ha, aa, plays, d, k, who, at, side, tid, pck, pv;
  if (($type(e) !== "roAssociativeArray")) {
    return null;
  }
  if ((($type(e.competitions) !== "roArray") || (e.competitions.$count() === 0))) {
    return null;
  }
  comp = $ix(e.competitions, 0);
  if ((($type(comp) !== "roAssociativeArray") || ($type(comp.competitors) !== "roArray"))) {
    return null;
  }
  h = null;
  a = null;
  for (c of $iter(comp.competitors)) {
    if ((($type(c) === "roAssociativeArray") && ($type(c.team) === "roAssociativeArray"))) {
      if ((mfs(c.homeaway) === "home")) {
        h = c;
      } else {
        a = c;
      }
    }
  }
  if (((h == null) || (a == null))) {
    return null;
  }
  stt = e.status;
  if (($type(stt) !== "roAssociativeArray")) {
    stt = comp.status;
  }
  st = "";
  sn = "";
  det = "";
  ck = "";
  if (($type(stt) === "roAssociativeArray")) {
    ck = mfs(stt.displayclock);
    if (($type(stt.type) === "roAssociativeArray")) {
      st = mfs(stt.type.state);
      sn = mfs(stt.type.name);
      det = mfs(stt.type.shortdetail);
    }
  }
  hid = mfs(h.team.id);
  aid = mfs(a.team.id);
  hn = mfs(h.team.shortdisplayname);
  if ((hn === "")) {
    hn = mfs(h.team.displayname);
  }
  an = mfs(a.team.shortdisplayname);
  if ((an === "")) {
    an = mfs(a.team.displayname);
  }
  ha = mfs(h.team.abbreviation);
  if ((ha === "")) {
    ha = $ucase($left(hn, 3));
  }
  aa = mfs(a.team.abbreviation);
  if ((aa === "")) {
    aa = $ucase($left(an, 3));
  }
  plays = [];
  if (($type(comp.details) === "roArray")) {
    for (d of $iter(comp.details)) {
      if ((($type(d) === "roAssociativeArray") && (!mfb(d.shootout)))) {
        k = "";
        if (mfb(d.scoringplay)) {
          k = "goal";
          if (mfb(d.owngoal)) {
            k = "og";
          }
          if (mfb(d.penaltykick)) {
            k = "pen";
          }
        } else if (mfb(d.redcard)) {
          k = "red";
        }
        if ((k !== "")) {
          who = "";
          if ((($type(d.athletesinvolved) === "roArray") && (d.athletesinvolved.$count() > 0))) {
            at = $ix(d.athletesinvolved, 0);
            if (($type(at) === "roAssociativeArray")) {
              who = mfs(at.shortname);
              if ((who === "")) {
                who = mfs(at.displayname);
              }
              if ((who === "")) {
                who = mfs(at.fullname);
              }
            }
          }
          side = "";
          if (($type(d.team) === "roAssociativeArray")) {
            tid = mfs(d.team.id);
            if (((tid !== "") && (tid === hid))) {
              side = "h";
            }
            if (((tid !== "") && (tid === aid))) {
              side = "a";
            }
          }
          pck = "";
          pv = 0;
          if (($type(d.clock) === "roAssociativeArray")) {
            pck = mfs(d.clock.displayvalue);
            pv = mfn(d.clock.value);
          }
          plays.$push({__proto__: $AAP, "k": k, "ck": pck, "v": pv, "side": side, "who": who});
        }
      }
    }
  }
  return {__proto__: $AAP, "id": mfs(e.id), "start": mfiso(mfs(e.date)), "h": hn, "a": an, "ha": ha, "aa": aa, "hid": hid, "aid": aid, "hsc": mfs(h.score), "asc": mfs(a.score), "hl": mfs(h.team.logo), "al": mfs(a.team.logo), "st": st, "sn": sn, "ck": ck, "det": det, "plays": plays};
}
return {"init": init, "mfrun": mfrun, "mfleagues": mfleagues, "mffetch": mffetch, "mfs": mfs, "mfb": mfb, "mfn": mfn, "mfiso": mfiso, "mfevent": mfevent};
});


// Reemplazos especificos para el hilo de tareas (vacio por ahora)

// Hilo de tareas (equivalente a los nodos Task de Roku)
'use strict';

self.onmessage = function (e) {
  const d = e.data;
  if (d.type !== 'run') return;
  $SRV = d.srv;
  if (d.manifest) $MANIFEST = d.manifest;
  const comp = $COMPONENTS[d.comp];
  if (!comp) { postMessage({ type: 'error', msg: 'componente no encontrado ' + d.comp }); postMessage({ type: 'done' }); return; }
  const spec = comp.spec;
  // nodo de la tarea: cada campo que se escribe se manda al hilo principal
  const t = new $NodeBase(d.comp);
  t.ftypes = Object.create(null);
  for (const fd of spec.fields) t.ftypes[fd.id.toLowerCase()] = (fd.type || 'string').toLowerCase();
  for (const k in d.fields) t.f[k] = $hydrate(d.fields[k], false);
  const baseSet = t.set.bind(t);
  t.set = function (k, v, quiet) {
    baseSet(k, v, true);
    try { postMessage({ type: 'set', k, v: $toWire(t.f[k]) }); } catch (err) { postMessage({ type: 'error', msg: 'no se pudo enviar ' + k + ': ' + err.message }); }
  };
  const g = new $NodeBase('Node');
  for (const k in d.global) g.f[k] = $hydrate(d.global[k], false);
  const m = $newAA();
  m.top = t.proxy;
  m.global = g.proxy;
  $G.$curM = m;
  const scope = { m, fns: null, node: t };
  t.scope = scope;
  try {
    scope.fns = comp.factory(m);
    const fname = String(t.f.functionname || '').toLowerCase();
    const fn = scope.fns[fname];
    if (!fn) throw new Error('funcion de la tarea no encontrada: ' + fname);
    $curScope = scope;
    fn();
  } catch (err) {
    postMessage({ type: 'error', msg: (err && err.stack) || String(err) });
  }
  postMessage({ type: 'done' });
};

$G.$onBrsError = function (e) { postMessage({ type: 'error', msg: (e && e.stack) || String(e) }); };
console.log = function () { try { postMessage({ type: 'log', msg: Array.from(arguments).map(String).join(' ') }); } catch (e) { } };
