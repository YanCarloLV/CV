package com.smartiptv.mx

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.widget.FrameLayout
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import org.json.JSONObject

/**
 * Mosaico: hasta 4 canales a la vez, cada uno con su propio ExoPlayer.
 *
 * Pensado para que la TV aguante los 4 juntos:
 *  - Calidad reducida y FIJA en todos los cuadros (hasta 480p, ~2.5 Mbps, 30 cuadros/s cuando
 *    el canal ofrece varias calidades). Cambiar de cuadro solo mueve el sonido: antes tambien
 *    cambiaba la calidad y eso obligaba a recargar el canal.
 *  - Los canales arrancan escalonados (no los 4 en el mismo instante).
 *  - Buffer mas holgado, velocidad siempre normal (sin acelerar/frenar el video en vivo),
 *    recuperacion silenciosa cuando el canal se queda atras de la transmision en vivo y
 *    reintentos con espera creciente.
 *  - Si el proveedor rechaza la conexion mientras otros cuadros si reproducen, avisa que la
 *    lista no permite mas pantallas a la vez (estado "limit") en lugar de reintentar sin fin.
 *  - Al salir del mosaico los reproductores se detienen sin bloquear la interfaz y se liberan
 *    un minuto despues si no se vuelven a usar.
 * Usa la extension FFmpeg, igual que el reproductor principal, para el audio que la
 * Chromecast no decodifica sola (MPEG-L2, AC3, E-AC3, DTS...).
 */
class TilePlayers(
    private val ctx: Context,
    private val root: FrameLayout,
    private val insertAt: () -> Int,
    private val emit: (String) -> Unit
) {

    private val main = Handler(Looper.getMainLooper())
    private val tiles = HashMap<Int, Tile>()
    private var nextStartAt = 0L
    var onActive: ((Boolean) -> Unit)? = null

    companion object {
        private const val STAGGER_MS = 700L
        private const val STALL_MS = 18000L
        private const val IDLE_RELEASE_MS = 60000L
        private const val MAX_RETRIES = 8
        private const val MAX_LIMIT_TRIES = 6
        // respuestas tipicas de un proveedor que ya no acepta otra conexion de la misma cuenta
        private val LIMIT_CODES = setOf(401, 403, 406, 429, 456, 458, 509, 551)
    }

    private inner class Tile(val pid: Int) : Player.Listener {
        val view = PlayerView(ctx)
        var exo: ExoPlayer? = null
        var url = ""
        var format = ""
        var altTried = false
        var retries = 0
        var limitTries = 0
        var lastState = ""
        var mute = true
        var active = false
        private val startRun = Runnable { load() }
        private val retryRun = Runnable { load() }
        private val stallRun = Runnable { onStall() }
        val idleRun = Runnable { releasePlayer() }

        init {
            view.useController = false
            view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            view.setShutterBackgroundColor(android.graphics.Color.BLACK)
            view.isFocusable = false
            view.visibility = View.GONE
            root.addView(view, insertAt(), FrameLayout.LayoutParams(1, 1))
        }

        fun play(u: String, f: String, delay: Long) {
            main.removeCallbacks(idleRun)
            cancelTimers()
            active = true
            url = u
            format = f.lowercase()
            altTried = false
            retries = 0
            limitTries = 0
            lastState = ""
            send("buffering")
            if (delay > 0) main.postDelayed(startRun, delay) else load()
        }

        private fun cancelTimers() {
            main.removeCallbacks(startRun)
            main.removeCallbacks(retryRun)
            main.removeCallbacks(stallRun)
        }

        private fun build(): ExoPlayer {
            val rf = DefaultRenderersFactory(ctx)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
                .setEnableDecoderFallback(true)
            val http = DefaultHttpDataSource.Factory()
                .setUserAgent(LocalServer.USER_AGENT)
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(12000)
                .setReadTimeoutMs(15000)
            val load = DefaultLoadControl.Builder()
                .setBufferDurationsMs(5000, 20000, 1500, 3000)
                .setTargetBufferBytes(16 * 1024 * 1024)
                .setPrioritizeTimeOverSizeThresholds(false)
                .build()
            val p = ExoPlayer.Builder(ctx, rf)
                .setMediaSourceFactory(DefaultMediaSourceFactory(http))
                .setLoadControl(load)
                .build()
            // calidad fija para todos los cuadros (no se cambia al mover el foco)
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                .setMaxVideoSize(854, 480)
                .setMaxVideoBitrate(2_500_000)
                .setMaxVideoFrameRate(30)
                .build()
            p.addListener(this)
            view.player = p
            return p
        }

        private fun load() {
            if (url.isEmpty() || !active) return
            main.removeCallbacks(stallRun)
            val p = exo ?: build().also { exo = it }
            p.stop()
            p.clearMediaItems()
            val b = MediaItem.Builder().setUri(Uri.parse(url))
                // en vivo a velocidad normal siempre: acelerar o frenar el video se nota como tirones
                .setLiveConfiguration(
                    MediaItem.LiveConfiguration.Builder().setMinPlaybackSpeed(1f).setMaxPlaybackSpeed(1f).build()
                )
            val path = Uri.parse(url).path?.lowercase() ?: ""
            if (path.endsWith(".mpd")) b.setMimeType(MimeTypes.APPLICATION_MPD)
            else when (format) {
                "hls" -> b.setMimeType(MimeTypes.APPLICATION_M3U8)
                "ts" -> b.setMimeType(MimeTypes.VIDEO_MP2T)
            }
            p.setMediaItem(b.build())
            p.volume = if (mute) 0f else 1f
            p.playWhenReady = true
            p.prepare()
            main.postDelayed(stallRun, STALL_MS)
        }

        fun applyAudio() {
            exo?.volume = if (mute) 0f else 1f
        }

        override fun onPlaybackStateChanged(state: Int) {
            if (!active) return
            when (state) {
                Player.STATE_READY -> {
                    main.removeCallbacks(stallRun)
                    retries = 0
                    limitTries = 0
                    send("playing")
                }
                Player.STATE_BUFFERING -> {
                    // una pausa corta para llenar el buffer no es "reconectar"; solo si se queda trabado
                    main.removeCallbacks(stallRun)
                    main.postDelayed(stallRun, STALL_MS)
                    if (lastState != "playing") send("buffering")
                }
                Player.STATE_ENDED -> scheduleRetry(1000L)
            }
        }

        private fun onStall() {
            if (!active) return
            val p = exo ?: return
            if (p.playbackState == Player.STATE_READY) return
            scheduleRetry(0L)
        }

        override fun onPlayerError(error: PlaybackException) {
            if (!active) return
            main.removeCallbacks(stallRun)
            // se quedo atras de la transmision en vivo: volver al punto en vivo sin avisar
            if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                exo?.let {
                    it.seekToDefaultPosition()
                    it.prepare()
                }
                main.postDelayed(stallRun, STALL_MS)
                return
            }
            val code = httpCode(error)
            if (code in LIMIT_CODES && othersPlaying()) {
                // el proveedor no acepta mas conexiones a la vez de esta cuenta
                limitTries++
                send("limit")
                if (limitTries < MAX_LIMIT_TRIES) {
                    main.removeCallbacks(retryRun)
                    main.postDelayed(retryRun, 10000L * limitTries.coerceAtMost(3))
                }
                return
            }
            // Igual que en el canal: un enlace sin extension que falla como HLS se prueba como TS y al reves
            if (!altTried && (format == "hls" || format == "ts" || format.isEmpty())) {
                altTried = true
                val low = url.lowercase()
                if (format == "hls" && low.contains("/live/") && low.endsWith(".m3u8")) url = url.dropLast(5) + ".ts"
                else if (format == "ts" && low.contains("/live/") && low.endsWith(".ts")) url = url.dropLast(3) + ".m3u8"
                format = if (format == "hls") "ts" else "hls"
                load()
                return
            }
            scheduleRetry(-1L)
        }

        private fun scheduleRetry(fixed: Long) {
            main.removeCallbacks(stallRun)
            if (retries < MAX_RETRIES) {
                retries++
                send("retry")
                val d = if (fixed >= 0) fixed else (2000L * retries).coerceAtMost(10000L)
                main.removeCallbacks(retryRun)
                main.postDelayed(retryRun, d)
            } else {
                exo?.stop()
                send("error")
            }
        }

        fun send(st: String) {
            if (st == lastState) return
            lastState = st
            val o = JSONObject()
            o.put("pid", pid)
            o.put("state", st)
            emit(o.toString())
        }

        /** Detiene sin bloquear la interfaz (stop() es asincrono; release() espera al reproductor). */
        fun stopPlayback() {
            active = false
            cancelTimers()
            url = ""
            lastState = ""
            exo?.let {
                it.stop()
                it.clearMediaItems()
            }
            view.visibility = View.GONE
            main.removeCallbacks(idleRun)
            main.postDelayed(idleRun, IDLE_RELEASE_MS)
        }

        fun releasePlayer() {
            main.removeCallbacks(idleRun)
            exo?.release()
            exo = null
            view.player = null
        }

        fun destroy() {
            active = false
            cancelTimers()
            releasePlayer()
            root.removeView(view)
        }
    }

    private fun httpCode(e: Throwable?): Int {
        var c = e
        var n = 0
        while (c != null && n < 8) {
            if (c is HttpDataSource.InvalidResponseCodeException) return c.responseCode
            c = c.cause
            n++
        }
        return 0
    }

    private fun othersPlaying(): Boolean = tiles.values.count { it.active && it.lastState == "playing" } > 0

    private fun anyActive(): Boolean = tiles.values.any { it.active }

    fun command(c: JSONObject) {
        val pid = c.optInt("pid")
        if (pid <= 0) return
        when (c.optString("op")) {
            "play" -> {
                val t = tiles.getOrPut(pid) { Tile(pid) }
                t.mute = c.optBoolean("mute", true)
                // arranques escalonados: la TV abre un canal a la vez
                val now = SystemClock.uptimeMillis()
                val start = maxOf(now, nextStartAt)
                nextStartAt = start + STAGGER_MS
                t.play(c.optString("url"), c.optString("format"), start - now)
                onActive?.invoke(true)
            }
            "stop" -> {
                tiles[pid]?.stopPlayback()
                if (!anyActive()) onActive?.invoke(false)
            }
            "audio" -> tiles[pid]?.let {
                it.mute = c.optBoolean("mute", true)
                it.applyAudio()
            }
            "rect" -> tiles[pid]?.let { t ->
                val lp = t.view.layoutParams as FrameLayout.LayoutParams
                val w = c.optInt("w").coerceAtLeast(1)
                val h = c.optInt("h").coerceAtLeast(1)
                if (lp.width != w || lp.height != h || lp.leftMargin != c.optInt("x") || lp.topMargin != c.optInt("y")) {
                    lp.width = w
                    lp.height = h
                    lp.leftMargin = c.optInt("x")
                    lp.topMargin = c.optInt("y")
                    t.view.layoutParams = lp
                }
                val vis = if (c.optBoolean("visible") && t.active) View.VISIBLE else View.GONE
                if (t.view.visibility != vis) t.view.visibility = vis
            }
        }
    }

    fun pauseAll() {
        for (t in tiles.values) t.exo?.pause()
    }

    fun resumeAll() {
        for (t in tiles.values) if (t.active) t.exo?.play()
    }

    fun releaseAll() {
        for (t in tiles.values) t.destroy()
        tiles.clear()
        nextStartAt = 0L
    }
}
