package com.smartiptv.mx

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Playlist(
    val id: String,
    var name: String,
    var url: String,
    var epg: String,
    var active: Boolean
)

/** Guarda en el equipo: listas, favoritos y el punto donde ibas en cada pelicula. */
class Store(ctx: Context) {

    private val sp = ctx.getSharedPreferences("iptv", Context.MODE_PRIVATE)

    fun playlists(): ArrayList<Playlist> {
        val out = ArrayList<Playlist>()
        try {
            val a = JSONArray(sp.getString("lists", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(
                    Playlist(
                        o.getString("id"),
                        o.optString("name"),
                        o.getString("url"),
                        o.optString("epg"),
                        o.optBoolean("active", true)
                    )
                )
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun savePlaylists(list: List<Playlist>) {
        val a = JSONArray()
        for (p in list) {
            val o = JSONObject()
            o.put("id", p.id)
            o.put("name", p.name)
            o.put("url", p.url)
            o.put("epg", p.epg)
            o.put("active", p.active)
            a.put(o)
        }
        sp.edit().putString("lists", a.toString()).apply()
    }

    fun favorites(): ArrayList<Channel> {
        val out = ArrayList<Channel>()
        try {
            val a = JSONArray(sp.getString("favs", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(
                    Channel(
                        o.getString("n"),
                        o.optString("g"),
                        o.getString("u"),
                        o.optString("l"),
                        o.optString("i"),
                        "",
                        o.optBoolean("v", false),
                        ""
                    )
                )
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun saveFavorites(list: List<Channel>) {
        val a = JSONArray()
        for (c in list) {
            val o = JSONObject()
            o.put("n", c.name)
            o.put("g", c.group)
            o.put("u", c.url)
            o.put("l", c.logo)
            o.put("i", c.id)
            o.put("v", c.vod)
            a.put(o)
        }
        sp.edit().putString("favs", a.toString()).apply()
    }

    fun bookmark(url: String): Long = sp.getLong("bm_" + url.hashCode(), 0L)

    fun setBookmark(url: String, ms: Long) {
        sp.edit().putLong("bm_" + url.hashCode(), ms).apply()
    }

    fun clearBookmark(url: String) {
        sp.edit().remove("bm_" + url.hashCode()).apply()
    }
}
