# Smart IPTV MX para Google TV / Android TV (v1.91)

Es el mismo canal de Roku (versión 1.90), migrado a Android TV.

## Cómo está hecho

- **Interfaz**: es el código BrightScript del canal de Roku, convertido automáticamente a
  JavaScript, más un motor pequeño que reproduce el SceneGraph de Roku en HTML a 1280x720.
  Por eso las pantallas, posiciones, colores, textos, idiomas, animaciones y la lógica
  (listas M3U, Xtream, guía EPG, QR, clima, partidos, control parental, favoritos,
  continuar viendo, reconexión automática...) son las mismas que en Roku.
- **Video**: ExoPlayer (Media3), con decodificadores de audio FFmpeg (AC3, E-AC3, DTS...).
  Va detrás de la interfaz, en el recuadro que la interfaz pide (pantalla completa, guía o
  miniatura en el menú de canales).
- **Servidor local** (`LocalServer.kt`): hace lo que en Roku hace el sistema: descargas
  (roUrlTransfer), archivos tmp:/ y cachefs:/, el registro y el servidor para el celular (QR).

## Mosaico (solo Google TV)

Hasta 4 canales a la vez, cada uno con su propio reproductor (`TilePlayers.kt`).
El sonido sigue al cuadro enfocado; los demás van en silencio y a 480p para que la TV
aguante los 4 videos. Usa la misma extensión FFmpeg que el reproductor principal, así que
también suena el audio MPEG-L2 / AC3 / E-AC3 / DTS que la Chromecast no decodifica sola.

- Inicio → tarjeta **Mosaico**.
- En vivo: mantener **Atrás** (o Menú / *) sobre un canal lo agrega o lo quita.
- Partidos de hoy: mantener **OK** (o Play) sobre un partido lo agrega.
- Dentro del mosaico: flechas = mover (el audio cambia de cuadro), OK = pantalla completa,
  mantener OK = cambiar diseño (Cuadrícula / Enfoque), mantener Atrás = opciones
  (cambiar canal, quitar, vaciar), « » = canal anterior/siguiente en ese cuadro.
- Si no hay canales: botón para llenarlo con los **partidos en vivo** que tengan canal en tu lista.
- El mosaico se guarda y aparece igual la próxima vez.

El código del mosaico está en `tools/extra/components/mosaic.brs` (kit de migración) y los
cambios al canal de Roku en `tools/patches.js`.

## Control remoto

| Roku | Google TV / Android TV |
|------|------------------------|
| Flechas, OK, Atrás | Flechas, OK, Atrás |
| Play/Pausa | Play/Pausa, o **mantener OK** medio segundo |
| * (opciones) | Menú, o **mantener Atrás** medio segundo |
| « » (rew / ff) | Rebobinar / Adelantar (o Anterior / Siguiente) |
| Repetición instantánea | Canal anterior (si el control lo tiene) |
| Canal + / – | Canal + / – (cambian de canal como Arriba/Abajo) |

## Compilar

El flujo de GitHub Actions (`.github/workflows/build.yml`) descomprime
`smart-iptv-tv.zip` y genera `smart-iptv-mx.apk` en Releases. El APK se firma con la misma
llave de siempre (`app/debug.keystore`), así que se instala encima de la versión anterior.

## Actualizar la interfaz desde el canal de Roku

La carpeta `assets/web` se genera con las herramientas del proyecto de migración
(`tools/package.sh <carpeta_del_canal_roku>`): convierte los `.brs`/`.xml` del canal y
copia imágenes, fuentes, sonidos y traducciones.
