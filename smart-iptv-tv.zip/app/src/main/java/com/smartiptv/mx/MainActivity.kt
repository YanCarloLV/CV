package com.smartiptv.mx

import android.app.Activity
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.UnrecognizedInputFormatException
import androidx.media3.ui.PlayerView
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    private val cBg = 0xFF090A0C.toInt()
    private val cCard = 0xFF17191D.toInt()
    private val cLine = 0xFF2A2D33.toInt()
    private val cOrange = 0xFFFF6A00.toInt()
    private val cOrangeLight = 0xFFFFB067.toInt()
    private val cText = 0xFFF4F5F7.toInt()
    private val cMuted = 0xFF9CA0A8.toInt()

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout

    private var allChannels: List<Channel> = emptyList()
    private var shown: List<Channel> = emptyList()
    private var groups: List<String> = emptyList()
    private var groupSel = 0
    private val picks = ArrayList<Channel>()
    private var pickMode = false

    private var screen = "setup"
    private var backTo = "browse"
    private var resumeBrowse = false
    private var server: LocalServer? = null
    private var statusView: TextView? = null

    private var single: ExoPlayer? = null
    private var singleStream: Stream? = null
    private var playList: List<Channel> = emptyList()
    private var playIndex = 0
    private var infoView: TextView? = null
    private val hideInfo = Runnable { infoView?.visibility = View.GONE }
    private val tileStreams = ArrayList<Stream>()

    // ------------------------------------------------------------------
    // Ciclo de vida
    // ------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        root = FrameLayout(this)
        root.setBackgroundColor(cBg)
        setContentView(root)

        val cached = File(filesDir, "list.m3u")
        if (cached.exists()) {
            Thread {
                val list = try {
                    M3u.parse(cached.readText())
                } catch (e: Exception) {
                    emptyList()
                }
                ui.post {
                    if (list.isNotEmpty()) {
                        allChannels = list
                        showBrowse()
                    } else {
                        showSetup()
                    }
                }
            }.start()
        } else {
            showSetup()
        }
    }

    override fun onStop() {
        super.onStop()
        if (screen == "player" || screen == "mosaic") {
            stopAll()
            resumeBrowse = true
        }
    }

    override fun onStart() {
        super.onStart()
        if (resumeBrowse) {
            resumeBrowse = false
            showBrowse()
        }
    }

    override fun onDestroy() {
        stopAll()
        server?.stop()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (screen) {
            "player" -> if (backTo == "mosaic") showMosaic() else showBrowse()
            "mosaic" -> showBrowse()
            "setup" -> if (allChannels.isNotEmpty()) showBrowse() else super.onBackPressed()
            else -> super.onBackPressed()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (screen == "player" && single != null) {
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> {
                    zap(1)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                    zap(-1)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    showInfo()
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ------------------------------------------------------------------
    // Utilidades de interfaz
    // ------------------------------------------------------------------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun setScreen(v: View) {
        root.removeAllViews()
        root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    private fun button(text: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 18f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(24), dp(12), dp(24), dp(12))
        t.isFocusable = true
        t.isClickable = true
        fun paint(focused: Boolean) {
            val g = GradientDrawable()
            g.cornerRadius = dp(30).toFloat()
            g.setColor(if (focused) cOrange else cCard)
            g.setStroke(dp(2), if (focused) cOrangeLight else cLine)
            t.background = g
            t.setTextColor(if (focused) cBg else cText)
        }
        paint(false)
        t.setOnFocusChangeListener { _, f -> paint(f) }
        t.setOnClickListener { onClick() }
        return t
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun listAdapter(items: List<String>, mark: (Int) -> Boolean): ArrayAdapter<String> {
        val ctx = this
        return object : ArrayAdapter<String>(ctx, android.R.layout.simple_list_item_1, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                val marked = mark(position)
                v.text = (if (marked) "★  " else "") + (getItem(position) ?: "")
                v.setTextColor(if (marked) cOrangeLight else cText)
                v.textSize = 20f
                v.maxLines = 1
                v.ellipsize = TextUtils.TruncateAt.END
                v.setPadding(dp(18), dp(12), dp(18), dp(12))
                return v
            }
        }
    }

    private fun styleList(lv: ListView) {
        lv.divider = null
        lv.selector = ColorDrawable(0x66FF6A00)
        lv.isFocusable = true
        lv.itemsCanFocus = false
        lv.setBackgroundColor(cCard)
    }

    // ------------------------------------------------------------------
    // Pantalla 1: cargar lista
    // ------------------------------------------------------------------

    private fun showSetup() {
        stopAll()
        screen = "setup"

        if (server == null) {
            val s = LocalServer { url -> ui.post { loadFromUrl(url) } }
            if (s.start()) server = s
        }
        val srv = server
        val addr = if (srv != null) "http://" + LocalServer.localIp() + ":" + srv.port
        else "No se pudo iniciar el servidor"

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.setPadding(dp(60), dp(24), dp(60), dp(24))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo_mark)
        col.addView(logo, LinearLayout.LayoutParams(dp(150), dp(95)))

        col.addView(label("SMART IPTV MX", 30f, cText, true))

        val step = label("Desde tu celular (misma red Wi-Fi) abre esta dirección:", 20f, cMuted)
        step.gravity = Gravity.CENTER
        step.setPadding(0, dp(18), 0, dp(6))
        col.addView(step)

        col.addView(label(addr, 34f, cOrangeLight, true))

        val orLbl = label("o escribe el enlace aquí:", 18f, cMuted)
        orLbl.setPadding(0, dp(22), 0, dp(8))
        col.addView(orLbl)

        val input = EditText(this)
        input.hint = "https://..."
        input.setSingleLine()
        input.textSize = 20f
        input.setTextColor(cText)
        input.setHintTextColor(cMuted)
        input.imeOptions = EditorInfo.IME_ACTION_DONE
        val bg = GradientDrawable()
        bg.cornerRadius = dp(14).toFloat()
        bg.setColor(cCard)
        bg.setStroke(dp(2), cLine)
        input.background = bg
        input.setPadding(dp(20), dp(12), dp(20), dp(12))
        input.setOnEditorActionListener { _, _, _ ->
            loadFromUrl(input.text.toString().trim())
            true
        }
        col.addView(input, LinearLayout.LayoutParams(dp(640), WRAP))

        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER
        row.setPadding(0, dp(14), 0, dp(10))
        row.addView(button("Cargar lista") { loadFromUrl(input.text.toString().trim()) })
        if (allChannels.isNotEmpty()) {
            val back = button("Volver") { showBrowse() }
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.leftMargin = dp(16)
            row.addView(back, lp)
        }
        col.addView(row)

        val st = label("", 18f, cOrangeLight, true)
        st.gravity = Gravity.CENTER
        statusView = st
        col.addView(st)

        setScreen(col)
    }

    private fun download(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        if (c.responseCode !in 200..299) throw Exception("HTTP " + c.responseCode)
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun loadFromUrl(url: String) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            statusView?.text = "El enlace debe empezar con http:// o https://"
            return
        }
        statusView?.text = "Descargando lista..."
        Thread {
            try {
                val text = download(url)
                val list = M3u.parse(text)
                if (list.isEmpty()) throw Exception("La lista no tiene canales")
                File(filesDir, "list.m3u").writeText(text)
                ui.post {
                    allChannels = list
                    picks.clear()
                    groupSel = 0
                    showBrowse()
                }
            } catch (e: Exception) {
                ui.post { statusView?.text = "No se pudo cargar: " + (e.message ?: "error") }
            }
        }.start()
    }

    // ------------------------------------------------------------------
    // Pantalla 2: categorias y canales
    // ------------------------------------------------------------------

    private fun modeLabel(): String = if (pickMode) "Elegir para mosaico: SÍ" else "Elegir para mosaico: NO"

    private fun mosaicLabel(): String = "Abrir mosaico (" + picks.size + "/4)"

    private fun showBrowse() {
        stopAll()
        screen = "browse"
        groups = listOf("Todos") + allChannels.map { it.group }.distinct()
        if (groupSel >= groups.size) groupSel = 0

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(48), dp(22), dp(48), dp(18))

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo_mark)
        top.addView(logo, LinearLayout.LayoutParams(dp(84), dp(53)))
        val title = label("Smart IPTV MX  ·  " + allChannels.size + " canales", 22f, cText, true)
        title.setPadding(dp(16), 0, 0, 0)
        top.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))

        val modeBtn = button(modeLabel()) { }
        val openBtn = button(mosaicLabel()) { openMosaic() }
        val listBtn = button("Cambiar lista") { showSetup() }
        modeBtn.setOnClickListener {
            pickMode = !pickMode
            modeBtn.text = modeLabel()
        }
        top.addView(modeBtn)
        val lp2 = LinearLayout.LayoutParams(WRAP, WRAP)
        lp2.leftMargin = dp(12)
        top.addView(openBtn, lp2)
        val lp3 = LinearLayout.LayoutParams(WRAP, WRAP)
        lp3.leftMargin = dp(12)
        top.addView(listBtn, lp3)

        val gv = ListView(this)
        val cv = ListView(this)
        styleList(gv)
        styleList(cv)

        val body = LinearLayout(this)
        body.addView(gv, LinearLayout.LayoutParams(0, MATCH, 1f))
        val cvLp = LinearLayout.LayoutParams(0, MATCH, 2f)
        cvLp.leftMargin = dp(20)
        body.addView(cv, cvLp)

        val hint = label(
            "OK: ver canal   ·   Para mosaico: activa \"Elegir para mosaico\" y pulsa OK en 2 a 4 canales",
            16f, cMuted
        )
        hint.setPadding(0, dp(10), 0, 0)

        val topLp = LinearLayout.LayoutParams(MATCH, WRAP)
        topLp.bottomMargin = dp(14)
        col.addView(top, topLp)
        col.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))
        col.addView(hint)
        setScreen(col)

        gv.adapter = listAdapter(groups) { false }

        fun showGroup(i: Int) {
            groupSel = i
            shown = if (i == 0) allChannels else allChannels.filter { it.group == groups[i] }
            cv.adapter = listAdapter(shown.map { it.name }) { pos -> picks.contains(shown[pos]) }
        }
        showGroup(groupSel)
        gv.setSelection(groupSel)

        gv.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != groupSel) showGroup(pos)
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        fun refreshMarks() {
            (cv.adapter as ArrayAdapter<*>).notifyDataSetChanged()
            openBtn.text = mosaicLabel()
        }

        cv.onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ ->
            if (pickMode) {
                togglePick(shown[pos])
                refreshMarks()
            } else {
                showPlayer(shown, pos, "browse")
            }
        }
        cv.onItemLongClickListener = AdapterView.OnItemLongClickListener { _, _, pos, _ ->
            togglePick(shown[pos])
            refreshMarks()
            true
        }

        cv.requestFocus()
    }

    private fun togglePick(ch: Channel) {
        if (picks.contains(ch)) {
            picks.remove(ch)
        } else if (picks.size < 4) {
            picks.add(ch)
        } else {
            toast("Máximo 4 canales en el mosaico")
        }
    }

    private fun openMosaic() {
        if (picks.size < 2) {
            toast("Elige de 2 a 4 canales: activa \"Elegir para mosaico\" y pulsa OK sobre cada uno")
            return
        }
        showMosaic()
    }

    // ------------------------------------------------------------------
    // Reproductores
    // ------------------------------------------------------------------

    private fun buildPlayer(multi: Boolean): ExoPlayer {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(20000)
        val load = if (multi) {
            DefaultLoadControl.Builder().setBufferDurationsMs(2500, 8000, 1000, 2000).build()
        } else {
            DefaultLoadControl.Builder().setBufferDurationsMs(8000, 30000, 2000, 4000).build()
        }
        val renderers = DefaultRenderersFactory(this).setEnableDecoderFallback(true)
        return ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(http))
            .setLoadControl(load)
            .build()
    }

    private fun capQuality(p: ExoPlayer, w: Int, h: Int) {
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setMaxVideoSize(w, h)
            .build()
    }

    /** Controla un reproductor: carga el canal, prueba HLS si hace falta y reintenta si se cae. */
    private inner class Stream(val p: ExoPlayer, val status: TextView?) : Player.Listener {
        var ch: Channel? = null
        var triedHls = false
        var retries = 0
        private val retry = Runnable { load(triedHls) }

        init {
            p.addListener(this)
        }

        fun play(c: Channel) {
            ch = c
            triedHls = false
            retries = 0
            ui.removeCallbacks(retry)
            load(false)
        }

        private fun load(hls: Boolean) {
            val c = ch ?: return
            status?.text = "Cargando..."
            status?.visibility = View.VISIBLE
            val b = MediaItem.Builder().setUri(c.url)
            if (hls) b.setMimeType(MimeTypes.APPLICATION_M3U8)
            p.setMediaItem(b.build())
            p.prepare()
            p.playWhenReady = true
        }

        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_READY) {
                status?.visibility = View.GONE
                retries = 0
            } else if (state == Player.STATE_BUFFERING) {
                status?.text = "Cargando..."
                status?.visibility = View.VISIBLE
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            if (error.cause is UnrecognizedInputFormatException && !triedHls) {
                triedHls = true
                load(true)
                return
            }
            if (retries < 3) {
                retries++
                status?.text = "Sin señal, reintentando ($retries/3)..."
                status?.visibility = View.VISIBLE
                ui.postDelayed(retry, 4000)
            } else {
                status?.text = "Canal no disponible"
                status?.visibility = View.VISIBLE
            }
        }

        fun stop() {
            ui.removeCallbacks(retry)
        }
    }

    private fun stopAll() {
        ui.removeCallbacks(hideInfo)
        singleStream?.stop()
        single?.release()
        single = null
        singleStream = null
        for (s in tileStreams) {
            s.stop()
            s.p.release()
        }
        tileStreams.clear()
        infoView = null
    }

    // ------------------------------------------------------------------
    // Pantalla 3: un canal a pantalla completa
    // ------------------------------------------------------------------

    private fun showPlayer(list: List<Channel>, index: Int, back: String) {
        stopAll()
        screen = "player"
        backTo = back
        playList = list
        playIndex = index

        val frame = FrameLayout(this)
        val pv = PlayerView(this)
        pv.useController = false
        pv.isFocusable = false
        frame.addView(pv, FrameLayout.LayoutParams(MATCH, MATCH))

        val info = label("", 24f, cText, true)
        info.setPadding(dp(18), dp(10), dp(18), dp(10))
        val ib = GradientDrawable()
        ib.cornerRadius = dp(14).toFloat()
        ib.setColor(0xCC090A0C.toInt())
        info.background = ib
        val ilp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START)
        ilp.setMargins(dp(40), dp(32), 0, 0)
        frame.addView(info, ilp)
        infoView = info

        val status = label("", 26f, cText, true)
        status.setPadding(dp(22), dp(12), dp(22), dp(12))
        status.background = ib
        frame.addView(status, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        setScreen(frame)

        val p = buildPlayer(false)
        capQuality(p, 1920, 1080)
        pv.player = p
        single = p
        singleStream = Stream(p, status)
        startChannel()
    }

    private fun startChannel() {
        val ch = playList[playIndex]
        showInfo()
        singleStream?.play(ch)
    }

    private fun showInfo() {
        val iv = infoView ?: return
        iv.text = (playIndex + 1).toString() + "/" + playList.size + "   " + playList[playIndex].name
        iv.visibility = View.VISIBLE
        ui.removeCallbacks(hideInfo)
        ui.postDelayed(hideInfo, 3500)
    }

    private fun zap(dir: Int) {
        if (playList.isEmpty()) return
        playIndex = (playIndex + dir + playList.size) % playList.size
        startChannel()
    }

    // ------------------------------------------------------------------
    // Pantalla 4: mosaico de 2 a 4 canales
    // ------------------------------------------------------------------

    private fun showMosaic() {
        stopAll()
        screen = "mosaic"
        val n = picks.size

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(18), dp(18), dp(18))

        val tiles = ArrayList<View>()
        val rows = (n + 1) / 2
        var idx = 0
        for (r in 0 until rows) {
            val row = LinearLayout(this)
            val inRow = if (r == rows - 1 && n % 2 == 1) 1 else 2
            for (k in 0 until inRow) {
                val tile = makeTile(idx)
                val lp = LinearLayout.LayoutParams(0, MATCH, 1f)
                lp.setMargins(dp(6), dp(6), dp(6), dp(6))
                row.addView(tile, lp)
                tiles.add(tile)
                idx++
            }
            col.addView(row, LinearLayout.LayoutParams(MATCH, 0, 1f))
        }
        setScreen(col)

        for (s in tileStreams) capQuality(s.p, 854, 480)
        tiles[0].requestFocus()
    }

    private fun giveAudio(i: Int) {
        for (k in tileStreams.indices) {
            val p = tileStreams[k].p
            if (k == i) {
                p.volume = 1f
                capQuality(p, 1280, 720)
            } else {
                p.volume = 0f
                capQuality(p, 854, 480)
            }
        }
    }

    private fun makeTile(i: Int): FrameLayout {
        val ch = picks[i]
        val tile = FrameLayout(this)
        tile.isFocusable = true
        tile.isClickable = true

        val pv = PlayerView(this)
        pv.useController = false
        pv.isFocusable = false
        val inset = dp(4)
        val pvLp = FrameLayout.LayoutParams(MATCH, MATCH)
        pvLp.setMargins(inset, inset, inset, inset)
        tile.addView(pv, pvLp)

        val shade = GradientDrawable()
        shade.cornerRadius = dp(10).toFloat()
        shade.setColor(0xCC090A0C.toInt())

        val name = label(ch.name, 18f, cText, true)
        name.setPadding(dp(12), dp(6), dp(12), dp(6))
        name.background = shade
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        val nlp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START)
        nlp.setMargins(dp(14), 0, 0, dp(14))
        tile.addView(name, nlp)

        val badge = label("AUDIO", 14f, cBg, true)
        badge.setPadding(dp(12), dp(5), dp(12), dp(5))
        val bb = GradientDrawable()
        bb.cornerRadius = dp(10).toFloat()
        bb.setColor(cOrange)
        badge.background = bb
        badge.visibility = View.GONE
        val blp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END)
        blp.setMargins(0, dp(14), dp(14), 0)
        tile.addView(badge, blp)

        val status = label("", 20f, cText, true)
        status.setPadding(dp(16), dp(8), dp(16), dp(8))
        status.background = shade
        tile.addView(status, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        val p = buildPlayer(true)
        p.volume = 0f
        pv.player = p
        val stream = Stream(p, status)
        tileStreams.add(stream)

        fun paint(f: Boolean) {
            val g = GradientDrawable()
            g.cornerRadius = dp(16).toFloat()
            g.setColor(cCard)
            g.setStroke(dp(4), if (f) cOrange else cLine)
            tile.background = g
        }
        paint(false)
        tile.setOnFocusChangeListener { _, f ->
            paint(f)
            badge.visibility = if (f) View.VISIBLE else View.GONE
            if (f) giveAudio(i)
        }
        tile.setOnClickListener { showPlayer(ArrayList(picks), i, "mosaic") }

        stream.play(ch)
        return tile
    }

    companion object {
        const val UA = "Mozilla/5.0 (Linux; Android 14; Chromecast) SmartIPTVMX/0.1"
    }
}
