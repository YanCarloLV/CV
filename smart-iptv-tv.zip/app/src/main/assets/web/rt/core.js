// Runtime BrightScript compartido (pantalla principal y tareas en segundo plano).
/* eslint-disable no-unused-vars */
'use strict';

var $G = (typeof self !== 'undefined') ? self : globalThis;
var $IS_WORKER = (typeof WorkerGlobalScope !== 'undefined') && (self instanceof WorkerGlobalScope);

// ---------------------------------------------------------------
// Arreglos asociativos (roAssociativeArray): claves sin distinguir mayusculas
// ---------------------------------------------------------------
var $AAP = Object.create(null);
function $defm(proto, name, fn) {
  Object.defineProperty(proto, name, { value: fn, enumerable: false, writable: true, configurable: true });
}
function $isAA(o) { return o !== null && typeof o === 'object' && Object.getPrototypeOf(o) === $AAP; }
function $newAA(src) {
  const o = Object.create($AAP);
  if (src) for (const k in src) o[k] = src[k];
  return o;
}
function $akey(o, k) { return (typeof k === 'string' && !o.$cs) ? k.toLowerCase() : k; }
$defm($AAP, '$count', function () { let n = 0; for (const k in this) n++; return n; });
$defm($AAP, '$doesexist', function (k) { return $akey(this, k) in this; });
$defm($AAP, '$delete', function (k) { k = $akey(this, k); const had = k in this; delete this[k]; return had; });
$defm($AAP, '$keys', function () { return Object.keys(this).sort(); });
$defm($AAP, '$items', function () { return Object.keys(this).sort().map(k => $newAA({ key: k, value: this[k] })); });
$defm($AAP, '$lookup', function (k) { return this[$akey(this, k)]; });
$defm($AAP, '$lookupci', function (k) { return this[$akey(this, k)]; });
$defm($AAP, '$addreplace', function (k, v) { this[$akey(this, k)] = v; });
$defm($AAP, '$append', function (o) { if (o) for (const k in o) this[k] = o[k]; });
$defm($AAP, '$clear', function () { for (const k in this) delete this[k]; });
$defm($AAP, '$isempty', function () { for (const k in this) return false; return true; });
$defm($AAP, '$setmodecasesensitive', function () { Object.defineProperty(this, '$cs', { value: true, enumerable: false }); });
$defm($AAP, '$ifassociativearray', function () { return this; });
$defm($AAP, '$isnext', function () { return false; });
$defm($AAP, 'toString', function () { return '<Component: roAssociativeArray>'; });

// Convierte objetos planos (JSON, mensajes entre hilos) a AA de forma recursiva
function $hydrate(v, lower) {
  if (v === null || typeof v !== 'object') return v;
  if (Array.isArray(v)) { for (let i = 0; i < v.length; i++) v[i] = $hydrate(v[i], lower); return v; }
  if (v.__node) return $Node.fromWire(v);
  if (v instanceof Uint8Array || v instanceof ArrayBuffer) return v;
  const o = Object.create($AAP);
  for (const k in v) o[lower ? k.toLowerCase() : k] = $hydrate(v[k], lower);
  return o;
}

// ---------------------------------------------------------------
// Acceso con indice: a[i], aa["clave"], nodo["campo"]
// ---------------------------------------------------------------
function $ix(o, k) {
  if (typeof k === 'string') {
    if (o == null) throw new TypeError('indice sobre invalid: ' + k);
    if (!o.$cs) k = k.toLowerCase();
    return o[k];
  }
  if (o instanceof $ByteArray) return o.a[k];
  if (typeof k === 'number' && Array.isArray(o)) return o[k];
  return o[k];
}
function $six(o, k, v) {
  if (typeof k === 'string' && !o.$cs) k = k.toLowerCase();
  if (o instanceof $ByteArray) { o.$set(k, v); return; }
  o[k] = v;
}
function $iter(o) {
  if (o == null) return [];
  if (Array.isArray(o)) return o.slice();
  if (o instanceof $ByteArray) return Array.from(o.a.subarray(0, o.n));
  if ($isAA(o)) return Object.keys(o);
  if (o.$isnode) return o.$getchildren(-1, 0);
  if (typeof o === 'string') return [o];
  if (o.$iterate) return o.$iterate();
  return Object.keys(o);
}
function $callv(f, args) {
  if (typeof f !== 'function') throw new TypeError('no es una funcion');
  return f.apply(null, args);
}
function $idiv(a, b) { return Math.trunc(a / b); }
function $and(a, b) { return (typeof a === 'number' && typeof b === 'number') ? (a & b) : (a && b); }
function $or(a, b) { return (typeof a === 'number' && typeof b === 'number') ? (a | b) : (a || b); }
function $not(a) { return typeof a === 'number' ? ~a : !a; }
function $err(v) { if (v instanceof Error) return v; const e = new Error(typeof v === 'string' ? v : (v && v.message) || 'error'); return e; }
function $dim() {
  const dims = Array.from(arguments);
  const mk = (d) => { const a = []; if (d < dims.length - 1) for (let i = 0; i <= dims[d]; i++) a.push(mk(d + 1)); return a; };
  return mk(0);
}
function $attr(o, a) { return o && o.$getattributes ? o.$getattributes()[a] : undefined; }

// ---------------------------------------------------------------
// Metodos de String / Number / Boolean / Array
// ---------------------------------------------------------------
const SP = String.prototype, NP = Number.prototype, BP = Boolean.prototype, AP = Array.prototype;
$defm(SP, '$len', function () { return this.length; });
$defm(SP, '$tostr', function () { return String(this); });
$defm(SP, '$getstring', function () { return String(this); });
$defm(SP, '$trim', function () { return this.replace(/^[\s\u0000- ]+|[\s\u0000- ]+$/g, ''); });
$defm(SP, '$replace', function (a, b) { if (a === '') return String(this); return this.split(a).join(b); });
$defm(SP, '$split', function (sep) {
  const s = String(this);
  if (s === '') return [];
  if (sep === '') return Array.from(s);
  return s.split(sep);
});
$defm(SP, '$tokenize', function (delims) {
  const out = []; let cur = '';
  for (const ch of String(this)) { if (delims.indexOf(ch) >= 0) { if (cur !== '') out.push(cur); cur = ''; } else cur += ch; }
  if (cur !== '') out.push(cur);
  return out;
});
$defm(SP, '$instr', function (a, b) {
  if (b === undefined) return this.indexOf(a);
  return this.indexOf(b, a);
});
$defm(SP, '$left', function (n) { return n <= 0 ? '' : this.substr(0, n); });
$defm(SP, '$right', function (n) { return n <= 0 ? '' : this.substr(Math.max(0, this.length - n)); });
$defm(SP, '$mid', function (s, n) { if (s < 0) s = 0; return n === undefined ? this.substr(s) : (n <= 0 ? '' : this.substr(s, n)); });
$defm(SP, '$lcase', function () { return this.toLowerCase(); });
$defm(SP, '$ucase', function () { return this.toUpperCase(); });
$defm(SP, '$toint', function () { const v = parseInt(this, 10); return isNaN(v) ? 0 : v; });
$defm(SP, '$tofloat', function () { const v = parseFloat(this); return isNaN(v) ? 0 : v; });
$defm(SP, '$startswith', function (s, p) { return this.startsWith(s, p || 0); });
$defm(SP, '$endswith', function (s) { return this.endsWith(s); });
$defm(SP, '$isempty', function () { return this.length === 0; });
$defm(SP, '$escape', function () { return $urlEscape(String(this)); });
$defm(SP, '$encodeuri', function () { return encodeURI(String(this)); });
$defm(SP, '$encodeuricomponent', function () { return encodeURIComponent(String(this)); });
$defm(SP, '$decodeuri', function () { try { return decodeURI(String(this)); } catch (e) { return String(this); } });
$defm(SP, '$decodeuricomponent', function () { try { return decodeURIComponent(String(this)); } catch (e) { return String(this); } });
$defm(SP, '$unescape', function () { try { return decodeURIComponent(String(this).replace(/\+/g, ' ')); } catch (e) { return String(this); } });
$defm(SP, '$getentityencode', function () { return String(this).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;'); });
$defm(SP, '$ifstring', function () { return this; });
$defm(SP, '$arg', function () { return String(this); });
$defm(NP, '$tostr', function (fmt) {
  if (fmt) return $sprintf(fmt, Number(this));
  return $numStr(Number(this));
});
$defm(NP, '$getint', function () { return Math.trunc(this); });
$defm(BP, '$tostr', function () { return this.valueOf() ? 'true' : 'false'; });
$defm(AP, '$count', function () { return this.length; });
$defm(AP, '$push', function (v) { this.push(v); });
$defm(AP, '$pop', function () { return this.length ? this.pop() : null; });
$defm(AP, '$shift', function () { return this.length ? this.shift() : null; });
$defm(AP, '$unshift', function (v) { this.unshift(v); });
$defm(AP, '$peek', function () { return this.length ? this[this.length - 1] : null; });
$defm(AP, '$delete', function (i) { if (i < 0 || i >= this.length) return false; this.splice(i, 1); return true; });
$defm(AP, '$clear', function () { this.length = 0; });
$defm(AP, '$append', function (o) { if (o) for (const v of o) this.push(v); });
$defm(AP, '$isempty', function () { return this.length === 0; });
$defm(AP, '$getentry', function (i) { return this[i]; });
$defm(AP, '$setentry', function (i, v) { this[i] = v; });
$defm(AP, '$join', function (s) { return this.join(s); });
$defm(AP, '$reverse', function () { this.reverse(); });
$defm(AP, '$addtail', function (v) { this.push(v); });
$defm(AP, '$addhead', function (v) { this.unshift(v); });
$defm(AP, '$removehead', function () { return this.length ? this.shift() : null; });
$defm(AP, '$removetail', function () { return this.length ? this.pop() : null; });
$defm(AP, '$gethead', function () { return this.length ? this[0] : null; });
$defm(AP, '$gettail', function () { return this.length ? this[this.length - 1] : null; });
$defm(AP, '$slice', function (a, b) { return this.slice(a, b); });
function $cmpBrs(a, b, ci) {
  const ta = typeof a, tb = typeof b;
  const rank = (t) => t === 'number' ? 0 : (t === 'string' ? 1 : 2);
  if (rank(ta) !== rank(tb)) return rank(ta) - rank(tb);
  if (ta === 'string') {
    if (ci) { a = a.toLowerCase(); b = b.toLowerCase(); }
    return a < b ? -1 : (a > b ? 1 : 0);
  }
  if (ta === 'number') return a - b;
  return 0;
}
$defm(AP, '$sort', function (flags) {
  flags = (flags || '').toLowerCase();
  const ci = flags.indexOf('i') >= 0, rev = flags.indexOf('r') >= 0;
  const idx = this.map((v, i) => [v, i]);
  idx.sort((x, y) => $cmpBrs(x[0], y[0], ci) || (x[1] - y[1]));
  for (let i = 0; i < idx.length; i++) this[i] = idx[i][0];
  if (rev) this.reverse();
});
$defm(AP, '$sortby', function (field, flags) {
  flags = (flags || '').toLowerCase();
  const ci = flags.indexOf('i') >= 0, rev = flags.indexOf('r') >= 0;
  field = String(field).toLowerCase();
  const get = (o) => (o != null && typeof o === 'object') ? o[field] : undefined;
  const idx = this.map((v, i) => [v, i, get(v)]);
  idx.sort((x, y) => {
    const ax = x[2], ay = y[2];
    if (ax === undefined && ay !== undefined) return 1;
    if (ay === undefined && ax !== undefined) return -1;
    return $cmpBrs(ax, ay, ci) || (x[1] - y[1]);
  });
  for (let i = 0; i < idx.length; i++) this[i] = idx[i][0];
  if (rev) this.reverse();
});
$defm(AP, '$ifarray', function () { return this; });

function $numStr(n) {
  if (Number.isInteger(n)) return String(n);
  if (!isFinite(n)) return n > 0 ? 'inf' : (n < 0 ? '-inf' : 'nan');
  // BrightScript Float: ~7 cifras significativas
  let s = String(parseFloat(n.toPrecision(7)));
  if (s.indexOf('e') >= 0) s = n.toPrecision(7);
  return s;
}
function $sprintf(fmt, v) {
  return fmt.replace(/%(0?)(\d*)(?:\.(\d+))?([dfsxX])/g, (all, z, w, p, t) => {
    let s;
    if (t === 'd') s = String(Math.trunc(v));
    else if (t === 'f') s = Number(v).toFixed(p === undefined ? 6 : Number(p));
    else if (t === 'x') s = (v >>> 0).toString(16);
    else if (t === 'X') s = (v >>> 0).toString(16).toUpperCase();
    else s = String(v);
    const width = Number(w || 0);
    while (s.length < width) s = (z ? '0' : ' ') + s;
    return s;
  });
}

// ---------------------------------------------------------------
// Funciones globales
// ---------------------------------------------------------------
function $len(s) { return s == null ? 0 : String(s).length; }
function $left(s, n) { return n <= 0 ? '' : String(s).substr(0, n); }
function $right(s, n) { s = String(s); return n <= 0 ? '' : s.substr(Math.max(0, s.length - n)); }
function $mid(s, start, n) {
  s = String(s);
  let st = start - 1;
  if (st < 0) st = 0;
  if (n === undefined) return s.substr(st);
  if (n <= 0) return '';
  return s.substr(st, n);
}
function $instr(start, s, sub) {
  if (sub === undefined) { sub = s; s = start; start = 1; }
  if (s == null) return 0;
  s = String(s);
  if (start < 1) start = 1;
  if (sub === '') return start <= s.length + 1 ? start : 0;
  return s.indexOf(sub, start - 1) + 1;
}
function $lcase(s) { return String(s).toLowerCase(); }
function $ucase(s) { return String(s).toUpperCase(); }
function $str(n) { const s = $numStr(n); return n >= 0 ? ' ' + s : s; }
function $stri(n, radix) { return radix ? Math.trunc(n).toString(radix) : String(Math.trunc(n)); }
function $val(s, radix) {
  if (s == null) return 0;
  s = String(s).trim();
  if (radix) { const v = parseInt(s, radix); return isNaN(v) ? 0 : v; }
  if (/^&h/i.test(s)) return parseInt(s.slice(2), 16) || 0;
  const m = /^[+\-]?(\d+\.?\d*|\.\d+)([eE][+\-]?\d+)?/.exec(s);
  return m ? Number(m[0]) : 0;
}
function $strtoi(s, radix) { const v = parseInt(String(s).trim(), radix || 10); return isNaN(v) ? 0 : v; }
function $int(x) { return Math.floor(x); }
function $fix(x) { return Math.trunc(x); }
function $cint(x) { return Math.round(x); }
function $cdbl(x) { return Number(x); }
function $csng(x) { return Number(x); }
function $abs(x) { return Math.abs(x); }
function $sqr(x) { return Math.sqrt(x); }
function $exp(x) { return Math.exp(x); }
function $log(x) { return Math.log(x); }
function $atn(x) { return Math.atan(x); }
function $cos(x) { return Math.cos(x); }
function $sin(x) { return Math.sin(x); }
function $tan(x) { return Math.tan(x); }
function $sgn(x) { return x > 0 ? 1 : (x < 0 ? -1 : 0); }
function $rnd(n) { if (!n) return Math.random(); return 1 + Math.floor(Math.random() * n); }
function $chr(c) { return String.fromCodePoint(c); }
function $asc(s) { s = String(s); if (s === '') return 0; return s.codePointAt(0); }
function $string(n, ch) { if (typeof ch === 'number') ch = String.fromCharCode(ch); return n > 0 ? ch.charAt(0).repeat(n) : ''; }
function $stringi(n, c) { return $string(n, String.fromCharCode(c)); }
function $substitute(fmt) { const a = Array.from(arguments).slice(1); return String(fmt).replace(/\{(\d)\}/g, (x, i) => a[i] == null ? '' : String(a[i])); }
function $tr(s) { return s; }
function $box(v) { return v; }
function $isvalid(v) { return v != null; }
function $rungarbagecollector() { return $newAA(); }
function $getglobalaa() { return $G.$curM || $newAA(); }
function $getinterface(o, name) { return o; }
function $sleep(ms) { const end = Date.now() + ms; if ($IS_WORKER) { try { const x = new XMLHttpRequest(); x.open('GET', $SRV + '/sleep?ms=' + ms, false); x.send(); } catch (e) { } } while (Date.now() < end) { /* espera */ } }
var $T0 = Date.now();
function $uptime() { return (Date.now() - $T0) / 1000; }

function $type(v, ver) {
  if (v === undefined) return ver === 3 ? '<uninitialized>' : 'Invalid';
  if (v === null) return ver === 3 ? 'Invalid' : 'roInvalid';
  if (typeof v === 'string') return 'roString';
  if (typeof v === 'number') return Number.isInteger(v) ? 'roInt' : 'roFloat';
  if (typeof v === 'boolean') return 'roBoolean';
  if (typeof v === 'function') return 'roFunction';
  if (Array.isArray(v)) return 'roArray';
  if ($isAA(v)) return 'roAssociativeArray';
  if (v.$isnode) return 'roSGNode';
  if (v.$brsType) return v.$brsType;
  return 'roAssociativeArray';
}

function $formatjson(v) {
  const conv = (x) => {
    if (x === undefined || x === null) return null;
    if (typeof x !== 'object') return x;
    if (Array.isArray(x)) return x.map(conv);
    if (x.$isnode) return null;
    const o = {};
    for (const k in x) o[k] = conv(x[k]);
    return o;
  };
  try { return JSON.stringify(conv(v)); } catch (e) { return ''; }
}
function $parsejson(s, flags) {
  if (s == null || s === '') return null;
  let v;
  try { v = JSON.parse(String(s)); } catch (e) { return null; }
  return $hydrate(v, true);
}

function $urlEscape(s) {
  return encodeURIComponent(s).replace(/[!'()*]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase());
}

// ---------------------------------------------------------------
// roDateTime / roTimespan
// ---------------------------------------------------------------
class $DateTime {
  constructor() { this.$brsType = 'roDateTime'; this.ms = Date.now(); this.local = false; }
  _d() { return new Date(this.ms + (this.local ? -new Date(this.ms).getTimezoneOffset() * 60000 : 0)); }
  $mark() { this.ms = Date.now(); this.local = false; }
  $asseconds() { return Math.floor(this.ms / 1000); }
  $assecondslong() { return Math.floor(this.ms / 1000); }
  $fromseconds(s) { this.ms = s * 1000; this.local = false; }
  $fromsecondslong(s) { this.ms = s * 1000; this.local = false; }
  $tolocaltime() { if (!this.local) { this.ms += -new Date(this.ms).getTimezoneOffset() * 60000; } this.local = true; }
  $getyear() { return new Date(this.ms).getUTCFullYear(); }
  $getmonth() { return new Date(this.ms).getUTCMonth() + 1; }
  $getdayofmonth() { return new Date(this.ms).getUTCDate(); }
  $gethours() { return new Date(this.ms).getUTCHours(); }
  $getminutes() { return new Date(this.ms).getUTCMinutes(); }
  $getseconds() { return new Date(this.ms).getUTCSeconds(); }
  $getmilliseconds() { return new Date(this.ms).getUTCMilliseconds(); }
  $getdayofweek() { return new Date(this.ms).getUTCDay(); }
  $getweekday() { return ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][new Date(this.ms).getUTCDay()]; }
  $getlastdayofmonth() { const d = new Date(this.ms); return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate(); }
  $gettimezoneoffset() { return new Date().getTimezoneOffset(); }
  $fromiso8601string(s) {
    s = String(s || '').trim();
    let t = Date.parse(/[zZ]|[+\-]\d\d:?\d\d$/.test(s) ? s : s + 'Z');
    if (isNaN(t)) t = 0;
    this.ms = t; this.local = false;
  }
  $toisostring() { return new Date(this.ms).toISOString().replace(/\.\d{3}Z$/, 'Z'); }
  $asdatestring(fmt) {
    const d = new Date(this.ms);
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    if (fmt === 'short-date') return (d.getUTCMonth() + 1) + '/' + d.getUTCDate() + '/' + String(d.getUTCFullYear()).slice(2);
    return days[d.getUTCDay()] + ' ' + months[d.getUTCMonth()] + ' ' + d.getUTCDate() + ', ' + d.getUTCFullYear();
  }
  $asdatestringnolocale(fmt) { return this.$asdatestring(fmt); }
}
class $Timespan {
  constructor() { this.$brsType = 'roTimespan'; this.t = performance.now(); }
  $mark() { this.t = performance.now(); }
  $totalmilliseconds() { return Math.floor(performance.now() - this.t); }
  $totalseconds() { return Math.floor((performance.now() - this.t) / 1000); }
  $getsecondstoiso8601date(s) { return Math.floor((Date.parse(s) - Date.now()) / 1000); }
}

// ---------------------------------------------------------------
// roRegex
// ---------------------------------------------------------------
class $Regex {
  constructor(pat, flags) {
    this.$brsType = 'roRegex';
    flags = String(flags || '');
    let f = '';
    if (flags.indexOf('i') >= 0) f += 'i';
    if (flags.indexOf('m') >= 0) f += 'm';
    if (flags.indexOf('s') >= 0) f += 's';
    // PCRE -> JS: \x{..} no se usa; (?i) no se usa
    this.src = String(pat);
    this.f = f;
    this.re = new RegExp(this.src, f);
    this.reg = new RegExp(this.src, f + 'g');
  }
  $ismatch(s) { this.re.lastIndex = 0; return this.re.test(String(s)); }
  $match(s) {
    const r = this.re.exec(String(s));
    if (!r) return [];
    return Array.from(r, x => x === undefined ? '' : x);
  }
  $matchall(s) {
    const out = [];
    for (const r of String(s).matchAll(this.reg)) out.push(Array.from(r, x => x === undefined ? '' : x));
    return out;
  }
  _repl(r) { return String(r).replace(/\$/g, '$$$$').replace(/\\(\d)/g, '$$$1'); }
  $replace(s, r) { return String(s).replace(this.re, this._repl(r)); }
  $replaceall(s, r) { return String(s).replace(this.reg, this._repl(r)); }
  $split(s) { return String(s).split(this.re); }
}

// ---------------------------------------------------------------
// roByteArray
// ---------------------------------------------------------------
class $ByteArray {
  constructor() { this.$brsType = 'roByteArray'; this.a = new Uint8Array(64); this.n = 0; }
  _ensure(n) { if (n > this.a.length) { let c = this.a.length; while (c < n) c *= 2; const b = new Uint8Array(c); b.set(this.a.subarray(0, this.n)); this.a = b; } }
  _setBytes(u8) { this.a = u8.length ? u8 : new Uint8Array(64); this.n = u8.length; }
  $set(i, v) { this._ensure(i + 1); this.a[i] = v & 255; if (i >= this.n) this.n = i + 1; }
  $count() { return this.n; }
  $push(v) { this._ensure(this.n + 1); this.a[this.n++] = v & 255; }
  $pop() { return this.n ? this.a[--this.n] : null; }
  $clear() { this.n = 0; }
  $getentry(i) { return this.a[i]; }
  $setresize(n) { this._ensure(n); }
  $fromasciistring(s) { this._setBytes(new TextEncoder().encode(String(s))); }
  $toasciistring() { return new TextDecoder('utf-8').decode(this.a.subarray(0, this.n)); }
  $tohexstring() { let s = ''; for (let i = 0; i < this.n; i++) s += (this.a[i] < 16 ? '0' : '') + this.a[i].toString(16).toUpperCase(); return s; }
  $fromhexstring(h) { h = String(h); const u = new Uint8Array(h.length >> 1); for (let i = 0; i < u.length; i++) u[i] = parseInt(h.substr(i * 2, 2), 16); this._setBytes(u); }
  $tobase64string() { let s = ''; for (let i = 0; i < this.n; i++) s += String.fromCharCode(this.a[i]); return btoa(s); }
  $frombase64string(b) { let s; try { s = atob(String(b)); } catch (e) { s = ''; } const u = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); this._setBytes(u); }
  $getsignedbyte(i) { const v = this.a[i]; return v > 127 ? v - 256 : v; }
  $getcrc32(start, len) {
    start = start || 0; len = len === undefined ? this.n - start : len;
    let c, crc = 0xFFFFFFFF;
    for (let i = start; i < start + len; i++) {
      c = (crc ^ this.a[i]) & 0xFF;
      for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xEDB88320 : c >>> 1;
      crc = (crc >>> 8) ^ c;
    }
    return (crc ^ 0xFFFFFFFF) | 0;
  }
  $readfile(path, offset, len) {
    const r = $fsRead(path, offset || 0, len === undefined ? -1 : len);
    if (r == null) return false;
    this._setBytes(r);
    return true;
  }
  $writefile(path, start, len) { start = start || 0; len = len === undefined ? this.n - start : len; return $fsWrite(path, this.a.subarray(start, start + len), false); }
  $appendfile(path, start, len) { start = start || 0; len = len === undefined ? this.n - start : len; return $fsWrite(path, this.a.subarray(start, start + len), true); }
  $iterate() { return Array.from(this.a.subarray(0, this.n)); }
}

// ---------------------------------------------------------------
// roEVPDigest (md5 / sha1 / sha256 simplificado: solo md5)
// ---------------------------------------------------------------
function $md5(bytes) {
  function add(x, y) { const l = (x & 0xFFFF) + (y & 0xFFFF); return (((x >> 16) + (y >> 16) + (l >> 16)) << 16) | (l & 0xFFFF); }
  function rol(n, c) { return (n << c) | (n >>> (32 - c)); }
  function cmn(q, a, b, x, s, t) { return add(rol(add(add(a, q), add(x, t)), s), b); }
  function ff(a, b, c, d, x, s, t) { return cmn((b & c) | ((~b) & d), a, b, x, s, t); }
  function gg(a, b, c, d, x, s, t) { return cmn((b & d) | (c & (~d)), a, b, x, s, t); }
  function hh(a, b, c, d, x, s, t) { return cmn(b ^ c ^ d, a, b, x, s, t); }
  function ii(a, b, c, d, x, s, t) { return cmn(c ^ (b | (~d)), a, b, x, s, t); }
  const n = bytes.length;
  const nblk = ((n + 8) >> 6) + 1;
  const x = new Array(nblk * 16).fill(0);
  for (let i = 0; i < n; i++) x[i >> 2] |= bytes[i] << ((i % 4) * 8);
  x[n >> 2] |= 0x80 << ((n % 4) * 8);
  x[nblk * 16 - 2] = n * 8;
  let a = 1732584193, b = -271733879, c = -1732584194, d = 271733878;
  for (let i = 0; i < x.length; i += 16) {
    const oa = a, ob = b, oc = c, od = d;
    a = ff(a, b, c, d, x[i], 7, -680876936); d = ff(d, a, b, c, x[i + 1], 12, -389564586); c = ff(c, d, a, b, x[i + 2], 17, 606105819); b = ff(b, c, d, a, x[i + 3], 22, -1044525330);
    a = ff(a, b, c, d, x[i + 4], 7, -176418897); d = ff(d, a, b, c, x[i + 5], 12, 1200080426); c = ff(c, d, a, b, x[i + 6], 17, -1473231341); b = ff(b, c, d, a, x[i + 7], 22, -45705983);
    a = ff(a, b, c, d, x[i + 8], 7, 1770035416); d = ff(d, a, b, c, x[i + 9], 12, -1958414417); c = ff(c, d, a, b, x[i + 10], 17, -42063); b = ff(b, c, d, a, x[i + 11], 22, -1990404162);
    a = ff(a, b, c, d, x[i + 12], 7, 1804603682); d = ff(d, a, b, c, x[i + 13], 12, -40341101); c = ff(c, d, a, b, x[i + 14], 17, -1502002290); b = ff(b, c, d, a, x[i + 15], 22, 1236535329);
    a = gg(a, b, c, d, x[i + 1], 5, -165796510); d = gg(d, a, b, c, x[i + 6], 9, -1069501632); c = gg(c, d, a, b, x[i + 11], 14, 643717713); b = gg(b, c, d, a, x[i], 20, -373897302);
    a = gg(a, b, c, d, x[i + 5], 5, -701558691); d = gg(d, a, b, c, x[i + 10], 9, 38016083); c = gg(c, d, a, b, x[i + 15], 14, -660478335); b = gg(b, c, d, a, x[i + 4], 20, -405537848);
    a = gg(a, b, c, d, x[i + 9], 5, 568446438); d = gg(d, a, b, c, x[i + 14], 9, -1019803690); c = gg(c, d, a, b, x[i + 3], 14, -187363961); b = gg(b, c, d, a, x[i + 8], 20, 1163531501);
    a = gg(a, b, c, d, x[i + 13], 5, -1444681467); d = gg(d, a, b, c, x[i + 2], 9, -51403784); c = gg(c, d, a, b, x[i + 7], 14, 1735328473); b = gg(b, c, d, a, x[i + 12], 20, -1926607734);
    a = hh(a, b, c, d, x[i + 5], 4, -378558); d = hh(d, a, b, c, x[i + 8], 11, -2022574463); c = hh(c, d, a, b, x[i + 11], 16, 1839030562); b = hh(b, c, d, a, x[i + 14], 23, -35309556);
    a = hh(a, b, c, d, x[i + 1], 4, -1530992060); d = hh(d, a, b, c, x[i + 4], 11, 1272893353); c = hh(c, d, a, b, x[i + 7], 16, -155497632); b = hh(b, c, d, a, x[i + 10], 23, -1094730640);
    a = hh(a, b, c, d, x[i + 13], 4, 681279174); d = hh(d, a, b, c, x[i], 11, -358537222); c = hh(c, d, a, b, x[i + 3], 16, -722521979); b = hh(b, c, d, a, x[i + 6], 23, 76029189);
    a = hh(a, b, c, d, x[i + 9], 4, -640364487); d = hh(d, a, b, c, x[i + 12], 11, -421815835); c = hh(c, d, a, b, x[i + 15], 16, 530742520); b = hh(b, c, d, a, x[i + 2], 23, -995338651);
    a = ii(a, b, c, d, x[i], 6, -198630844); d = ii(d, a, b, c, x[i + 7], 10, 1126891415); c = ii(c, d, a, b, x[i + 14], 15, -1416354905); b = ii(b, c, d, a, x[i + 5], 21, -57434055);
    a = ii(a, b, c, d, x[i + 12], 6, 1700485571); d = ii(d, a, b, c, x[i + 3], 10, -1894986606); c = ii(c, d, a, b, x[i + 10], 15, -1051523); b = ii(b, c, d, a, x[i + 1], 21, -2054922799);
    a = ii(a, b, c, d, x[i + 8], 6, 1873313359); d = ii(d, a, b, c, x[i + 15], 10, -30611744); c = ii(c, d, a, b, x[i + 6], 15, -1560198380); b = ii(b, c, d, a, x[i + 13], 21, 1309151649);
    a = ii(a, b, c, d, x[i + 4], 6, -145523070); d = ii(d, a, b, c, x[i + 11], 10, -1120210379); c = ii(c, d, a, b, x[i + 2], 15, 718787259); b = ii(b, c, d, a, x[i + 9], 21, -343485551);
    a = add(a, oa); b = add(b, ob); c = add(c, oc); d = add(d, od);
  }
  let s = '';
  for (const w of [a, b, c, d]) for (let j = 0; j < 4; j++) s += ((w >> (j * 8)) & 255).toString(16).padStart(2, '0');
  return s;
}
class $EVPDigest {
  constructor() { this.$brsType = 'roEVPDigest'; this.buf = []; }
  $setup(alg) { this.buf = []; return 0; }
  $reinit() { this.buf = []; return 0; }
  $update(ba) { for (let i = 0; i < ba.n; i++) this.buf.push(ba.a[i]); }
  $final() { const r = $md5(this.buf); this.buf = []; return r; }
  $process(ba) { return $md5(Array.from(ba.a.subarray(0, ba.n))); }
}

// ---------------------------------------------------------------
// Servidor local de la app (en Android lo da la app nativa)
// ---------------------------------------------------------------
var $SRV = (typeof location !== 'undefined') ? location.origin : '';

function $xhr(method, path, body, binary, timeoutMs) {
  const x = new XMLHttpRequest();
  x.open(method, $SRV + path, false);
  if (binary && $IS_WORKER) x.responseType = 'arraybuffer';
  if (binary && !$IS_WORKER) x.overrideMimeType('text/plain; charset=x-user-defined');
  if ($IS_WORKER && timeoutMs) { try { x.timeout = timeoutMs; } catch (e) { } }
  try { x.send(body === undefined ? null : body); } catch (e) { return { status: 0, text: '', bytes: null, headers: '', timedout: !!(e && e.name === 'TimeoutError') }; }
  let bytes = null, text = '';
  if (binary) {
    if ($IS_WORKER) bytes = new Uint8Array(x.response || new ArrayBuffer(0));
    else { const t = x.responseText || ''; bytes = new Uint8Array(t.length); for (let i = 0; i < t.length; i++) bytes[i] = t.charCodeAt(i) & 255; }
  } else text = x.responseText;
  return { status: x.status, text, bytes, headers: x.getAllResponseHeaders ? x.getAllResponseHeaders() : '' };
}

// Sistema de archivos virtual (tmp:/, cachefs:/) guardado por la app nativa
function $isPkg(p) { return /^pkg:\//i.test(String(p || '')); }
function $pkgUrl(p) { return '/' + String(p).replace(/^pkg:\/+/i, ''); }
function $fsRead(path, offset, len) {
  if ($isPkg(path)) {
    const r = $xhr('GET', $pkgUrl(path), undefined, true);
    if (r.status !== 200) return null;
    const o = offset || 0;
    return r.bytes.subarray(o, len == null || len < 0 ? r.bytes.length : Math.min(r.bytes.length, o + len));
  }
  const r = $xhr('GET', '/fs/read?p=' + encodeURIComponent(path) + '&o=' + (offset || 0) + '&n=' + (len == null ? -1 : len), undefined, true);
  if (r.status !== 200) return null;
  return r.bytes;
}
function $fsWrite(path, u8, append) {
  const r = $xhr('POST', '/fs/write?p=' + encodeURIComponent(path) + (append ? '&a=1' : ''), u8);
  return r.status === 200;
}
function $readasciifile(path) {
  if ($isPkg(path)) {
    if (!$IS_WORKER && $G.Android && $G.Android.asset) { try { return $G.Android.asset(String(path).replace(/^pkg:\/+/i, '')) || ''; } catch (e) { return ''; } }
    const rp = $xhr('GET', $pkgUrl(path)); return rp.status === 200 ? rp.text : '';
  }
  const r = $xhr('GET', '/fs/read?p=' + encodeURIComponent(path) + '&o=0&n=-1');
  return r.status === 200 ? r.text : '';
}
function $writeasciifile(path, text) { return $fsWrite(path, new TextEncoder().encode(String(text)), false); }
function $deletefile(path) { return $xhr('GET', '/fs/delete?p=' + encodeURIComponent(path)).status === 200; }
function $copyfile(a, b) { const d = $fsRead(a, 0, -1); return d ? $fsWrite(b, d, false) : false; }
function $movefile(a, b) { const ok = $copyfile(a, b); if (ok) $deletefile(a); return ok; }
function $listdir(p) { const r = $xhr('GET', '/fs/list?p=' + encodeURIComponent(p)); try { return JSON.parse(r.text); } catch (e) { return []; } }
function $createdirectory() { return true; }
class $FileSystem {
  constructor() { this.$brsType = 'roFileSystem'; }
  $exists(p) { if ($isPkg(p)) return $xhr('GET', $pkgUrl(p)).status === 200; return $xhr('GET', '/fs/stat?p=' + encodeURIComponent(p)).status === 200; }
  $delete(p) { return $deletefile(p); }
  $stat(p) {
    const r = $xhr('GET', '/fs/stat?p=' + encodeURIComponent(p));
    if (r.status !== 200) return null;
    try { const o = JSON.parse(r.text); return $newAA({ size: o.size, type: 'file', permissions: 'rw' }); } catch (e) { return null; }
  }
  $getdirectorylisting(p) { return $listdir(p); }
  $createdirectory() { return true; }
  $getvolumelist() { return ['tmp:', 'cachefs:']; }
  $getvolumeinfo() { return $newAA({ freespace: 1e9 }); }
  $copyfile(a, b) { return $copyfile(a, b); }
  $rename(a, b) { return $movefile(a, b); }
}

// ---------------------------------------------------------------
// roMessagePort / roUrlTransfer (solo en tareas)
// ---------------------------------------------------------------
class $MessagePort {
  constructor() { this.$brsType = 'roMessagePort'; this.q = []; this.jobs = null; }
  $getmessage() { return this.q.length ? this.q.shift() : null; }
  $peekmessage() { return this.q.length ? this.q[0] : null; }
  $waitmessage(ms) { return $wait(ms, this); }
}
var $xferId = 1;
class $UrlEvent {
  constructor(xfer, r) { this.$brsType = 'roUrlEvent'; this.x = xfer; this.r = r; }
  $getresponsecode() { return this.r.status !== 0 ? this.r.status : -28; }
  $getstring() { return this.r.text || ''; }
  $getfailurereason() { return this.r.status > 0 ? (this.r.status >= 400 ? 'HTTP ' + this.r.status : '') : 'Timeout was reached'; }
  $getsourceidentity() { return this.x.id; }
  $getint() { return 1; }
  $getresponseheaders() { return $newAA(); }
  $gettargetipaddress() { return ''; }
}
class $UrlTransfer {
  constructor() { this.$brsType = 'roUrlTransfer'; this.url = ''; this.headers = {}; this.port = null; this.id = $xferId++; this.method = 'GET'; this.timeout = 0; }
  $seturl(u) { this.url = String(u); }
  $geturl() { return this.url; }
  $setcertificatesfile() { }
  $initclientcertificates() { }
  $enableencodings() { }
  $enablepeerverification() { }
  $enablehostverification() { }
  $retainbodyonerror() { }
  $enablecookies() { }
  $setminimumtransferrate() { }
  $setconnectiontimeout(s) { this.timeout = s * 1000; }
  $addheader(k, v) { this.headers[k] = v; }
  $setheaders(h) { for (const k in h) this.headers[k] = h[k]; }
  $setrequest(m) { this.method = String(m || 'GET').toUpperCase(); }
  $getrequest() { return this.method; }
  $setmessageport(p) { this.port = p; }
  $setport(p) { this.port = p; }
  $getidentity() { return this.id; }
  $escape(s) { return $urlEscape(String(s)); }
  $unescape(s) { try { return decodeURIComponent(String(s).replace(/\+/g, ' ')); } catch (e) { return String(s); } }
  $urlencode(s) { return $urlEscape(String(s)); }
  _q(extra) {
    let q = '/net?u=' + encodeURIComponent(this.url);
    const hk = Object.keys(this.headers);
    if (hk.length) q += '&h=' + encodeURIComponent(JSON.stringify(this.headers));
    if (this.method !== 'GET') q += '&m=' + this.method;
    if (extra) q += extra;
    return q;
  }
  _do(toFile, body, tmo) {
    const r = $xhr(body !== undefined && body !== null ? 'POST' : 'GET', this._q(toFile ? '&to=' + encodeURIComponent(toFile) : ''), body === null ? undefined : body, false, tmo > 0 ? tmo : (this.timeout || 0));
    if (r.timedout) return { status: 0, text: '', timedout: true };
    if (toFile && r.status === 200) { /* el archivo quedo guardado del lado nativo */ }
    let st = r.status;
    const hs = /x-net-status:\s*(-?\d+)/i.exec(r.headers || '');
    if (hs) st = Number(hs[1]);
    return { status: st, text: toFile ? '' : r.text };
  }
  $gettostring() { const r = this._do(null); return r.status >= 200 && r.status < 300 ? r.text : (r.status > 0 ? r.text : ''); }
  $gettofile(path) { return this._do(path).status; }
  $postfromstring(s) { return this._do(null, String(s)).status; }
  // Las descargas "async" las hace la app nativa en paralelo (igual que Roku)
  _start(kind, path, body) {
    if (!this.port) return false;
    const q = this._q(path ? '&to=' + encodeURIComponent(path) : '').replace('/net?', '/net/start?');
    const r = $xhr(body !== undefined ? 'POST' : 'GET', q, body);
    if (r.status !== 200 || !r.text) return false;
    const id = String(r.text).trim();
    if (!this.port.jobs) this.port.jobs = new Map();
    this.port.jobs.set(id, { x: this, kind });
    this.job = id;
    return true;
  }
  $asyncgettostring() { return this._start('str'); }
  $asyncgettofile(path) { return this._start('file', path); }
  $asyncpostfromstring(s) { return this._start('str', null, String(s)); }
  $asynccancel() {
    if (this.job && this.port && this.port.jobs) { this.port.jobs.delete(this.job); $xhr('GET', '/net/cancel?id=' + this.job); }
    this.job = null;
    return true;
  }
  $asynchead() { return this.$asyncgettostring(); }
}
// wait(ms, port): espera el siguiente evento (descarga terminada, socket, campo...)
function $wait(ms, port) {
  if (port == null) { if (ms > 0) $sleep(ms); return null; }
  if (port.q.length) return port.q.shift();
  if (port.jobs && port.jobs.size) {
    const ids = Array.from(port.jobs.keys()).join(',');
    const r = $xhr('GET', '/net/wait?ids=' + ids + '&ms=' + (ms > 0 ? ms : 600000));
    if (r.status !== 200 || !r.text) return null;
    let d;
    try { d = JSON.parse(r.text); } catch (e) { return null; }
    const job = port.jobs.get(String(d.id));
    if (!job) return null;
    port.jobs.delete(String(d.id));
    job.x.job = null;
    let text = '';
    if (job.kind === 'str') { const b = $xhr('GET', '/net/result?id=' + d.id); text = b.text; }
    else $xhr('GET', '/net/cancel?id=' + d.id);
    return new $UrlEvent(job.x, { status: d.status, text });
  }
  if (port.$poll) { const m = port.$poll(ms); if (m) return m; return null; }
  if (ms > 0) $sleep(Math.min(ms, 50));
  return null;
}

// ---------------------------------------------------------------
// roRegistrySection / roDeviceInfo / roAppInfo
// ---------------------------------------------------------------
var $REG = null;
function $regLoad() {
  if ($REG) return $REG;
  $REG = {};
  try {
    if (!$IS_WORKER && $G.Android && $G.Android.regAll) $REG = JSON.parse($G.Android.regAll()) || {};
    else { const r = $xhr('GET', '/reg/all'); $REG = JSON.parse(r.text || '{}'); }
  } catch (e) { $REG = {}; }
  return $REG;
}
function $regSave() {
  const js = JSON.stringify($REG || {});
  try {
    if (!$IS_WORKER && $G.Android && $G.Android.regSave) $G.Android.regSave(js);
    else $xhr('POST', '/reg/save', js);
  } catch (e) { }
}
class $RegistrySection {
  constructor(name) { this.$brsType = 'roRegistrySection'; this.name = String(name); }
  _s() { const r = $regLoad(); if (!r[this.name]) r[this.name] = {}; return r[this.name]; }
  $read(k) { const s = this._s(); return Object.prototype.hasOwnProperty.call(s, k) ? s[k] : ''; }
  $write(k, v) { this._s()[k] = String(v); return true; }
  $delete(k) { const s = this._s(); const had = Object.prototype.hasOwnProperty.call(s, k); delete s[k]; return had; }
  $exists(k) { return Object.prototype.hasOwnProperty.call(this._s(), k); }
  $flush() { $regSave(); return true; }
  $getkeylist() { return Object.keys(this._s()); }
  $readmulti(keys) { const o = $newAA(); for (const k of keys) if (this.$exists(k)) o[k.toLowerCase()] = this.$read(k); return o; }
  $writemulti(aa) { for (const k in aa) this.$write(k, aa[k]); return true; }
}
class $Registry {
  constructor() { this.$brsType = 'roRegistry'; }
  $getsectionlist() { return Object.keys($regLoad()); }
  $delete(sec) { delete $regLoad()[sec]; $regSave(); return true; }
  $flush() { $regSave(); return true; }
}
var $DEV = null;
function $devInfo() {
  if ($DEV) return $DEV;
  let d = {};
  try {
    if (!$IS_WORKER && $G.Android && $G.Android.deviceInfo) d = JSON.parse($G.Android.deviceInfo());
    else { const r = $xhr('GET', '/device'); d = JSON.parse(r.text || '{}'); }
  } catch (e) { d = {}; }
  const nav = (typeof navigator !== 'undefined') ? navigator : {};
  const lang = (nav.language || 'es-MX').replace('-', '_');
  $DEV = Object.assign({ locale: lang, country: (lang.split('_')[1] || 'MX'), ip: '127.0.0.1', model: 'Google TV', uuid: '0000', tz: (Intl.DateTimeFormat().resolvedOptions().timeZone || 'America/Mexico_City'), w: 1920, h: 1080 }, d);
  return $DEV;
}
class $DeviceInfo {
  constructor() { this.$brsType = 'roDeviceInfo'; }
  $getcurrentlocale() { return $devInfo().locale; }
  $getpreferredcaptionlanguage() { return $devInfo().locale.slice(0, 2); }
  $getcountrycode() { return $devInfo().country; }
  $getusercountrycode() { return $devInfo().country; }
  $getipaddrs() { return $newAA({ eth0: $devInfo().ip }); }
  $getexternalip() { return ''; }
  $getmodel() { return $devInfo().model; }
  $getmodeldisplayname() { return $devInfo().model; }
  $getmodeldetails() { return $newAA({ vendorname: 'Android', modelnumber: $devInfo().model }); }
  $getfriendlyname() { return $devInfo().model; }
  $getversion() { return '13.0.0'; }
  $getosversion() { return $newAA({ major: '13', minor: '0', revision: '0', build: '0' }); }
  $getchannelclientid() { return $devInfo().uuid; }
  $getrandomuuid() { return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c => (c ^ Math.random() * 16 >> c / 4).toString(16)); }
  $getdisplaysize() { return $newAA({ w: 1280, h: 720 }); }
  $getuiresolution() { return $newAA({ width: 1280, height: 720, name: 'HD' }); }
  $getdisplaymode() { return '720p'; }
  $getvideomode() { return '1080p'; }
  $getdisplaytype() { return 'HDTV'; }
  $gettimezone() { return $devInfo().tz; }
  $getclockformat() { return '12h'; }
  $getlinkstatus() { return true; }
  $getinternetstatus() { return true; }
  $getconnectiontype() { return 'WiFiConnection'; }
  $getconnectioninfo() { return $newAA({ type: 'WiFiConnection', name: 'wlan0', ip: $devInfo().ip, ssid: '', gateway: '' }); }
  $getgeneralmemorylevel() { return 'normal'; }
  $isrideenabled() { return false; }
  $setmessageport() { }
  $enablelinkstatusevent() { }
  $enableinternetstatusevent() { }
  $getaudiooutputchannel() { return 'Stereo'; }
  $getfeatures() { return []; }
  $hasfeature() { return false; }
  $getcaptionsmode() { return 'Off'; }
  $getcaptionsoption() { return ''; }
  $getdrmInfo() { return $newAA(); }
  $isautoplayenabled() { return true; }
  $getuidevice() { return 'tv'; }
}
var $MANIFEST = $G.$MANIFEST || { title: 'Smart IPTV MX', major_version: '1', minor_version: '90', build_version: '00000' };
class $AppInfo {
  constructor() { this.$brsType = 'roAppInfo'; }
  $getid() { return 'dev'; }
  $isdev() { return false; }
  $getversion() { return $MANIFEST.major_version + '.' + $MANIFEST.minor_version + '.' + $MANIFEST.build_version; }
  $gettitle() { return $MANIFEST.title; }
  $getsubtitle() { return $MANIFEST.subtitle || ''; }
  $getvalue(k) { return $MANIFEST[String(k).toLowerCase()] || ''; }
  $getdevid() { return 'dev'; }
}

// ---------------------------------------------------------------
// Nodos (base sin dibujo): ContentNode y compania
// ---------------------------------------------------------------
var $NODE_DEFAULTS = {
  Node: { id: '', focusable: false, focusedchild: null, change: null },
  ContentNode: {
    title: '', url: '', description: '', hdposterurl: '', sdposterurl: '', fhdposterurl: '', shortdescriptionline1: '',
    shortdescriptionline2: '', starrating: 0, streamformat: '', releasedate: '', rating: '', playstart: 0,
    length: 0, contenttype: '', live: false, categories: '', actors: '', director: '', titleseason: '',
    episodenumber: '', hdbackgroundimageurl: '', textoverlayul: '', textoverlayur: '', textoverlaybody: ''
  }
};
var $FIELD_TYPES = {};
var $curScope = null;

class $NodeBase {
  constructor(type) {
    this.type = type;
    this.f = Object.create(null);
    this.kids = [];
    this.parent = null;
    this.obs = null;
    this.ftypes = null;     // tipos declarados por interfaz/addFields
    this.always = null;     // campos alwaysNotify
    this.proxy = new Proxy(this, $NodeHandler);
  }
  defaults() { return $NODE_DEFAULTS[this.type] || $NODE_DEFAULTS[$nodeBaseType(this.type)] || {}; }
  get(k) {
    if (k in this.f) return this.f[k];
    const d = this.defaults();
    if (k in d) { const v = d[k]; return Array.isArray(v) ? v.slice() : v; }
    const nd = $NODE_DEFAULTS.Node;
    if (k in nd) return nd[k];
    return undefined;
  }
  set(k, v, quiet) {
    v = this.coerce(k, v);
    const old = this.f[k];
    this.f[k] = v;
    this.applyField(k, v, old);
    if (quiet) return;
    if (old !== v || (this.always && this.always[k]) || (typeof v === 'object' && v !== null)) this.notify(k, v);
  }
  coerce(k, v) {
    const t = this.ftypes && this.ftypes[k];
    if (!t) return v;
    switch (t) {
      case 'string': case 'str': return v == null ? '' : (typeof v === 'string' ? v : String(v));
      case 'integer': case 'int': return typeof v === 'number' ? Math.trunc(v) : (typeof v === 'string' ? $val(v) | 0 : (v ? 1 : 0));
      case 'float': return typeof v === 'number' ? v : Number(v) || 0;
      case 'boolean': case 'bool': return typeof v === 'string' ? v.toLowerCase() === 'true' : !!v;
      default: return v;
    }
  }
  applyField() { }
  notify(k, v) {
    if (!this.obs) return;
    const list = this.obs[k];
    if (!list || !list.length) return;
    for (const o of list.slice()) {
      if (o.dead) continue;
      $dispatchObserver(o, this.proxy, k, v);
    }
  }
  addObserver(k, handler, scope, scoped, infoFields) {
    k = String(k).toLowerCase();
    if (!this.obs) this.obs = Object.create(null);
    if (!this.obs[k]) this.obs[k] = [];
    this.obs[k].push({ handler, scope, scoped, info: infoFields });
    return true;
  }
  removeObservers(k, scope, onlyScoped) {
    k = String(k).toLowerCase();
    if (!this.obs || !this.obs[k]) return;
    this.obs[k] = this.obs[k].filter(o => {
      const kill = onlyScoped ? (o.scope === scope) : true;
      if (kill) o.dead = true;
      return !kill;
    });
  }
  // ---- arbol ----
  appendChild(c) {
    if (!c) return false;
    const n = c.$t;
    if (n.parent) n.parent.removeChildImpl(n);
    n.parent = this;
    this.kids.push(n);
    this.childAdded(n, this.kids.length - 1);
    return true;
  }
  insertChildImpl(n, idx) {
    if (n.parent) n.parent.removeChildImpl(n);
    n.parent = this;
    if (idx < 0) idx = 0;
    if (idx > this.kids.length) idx = this.kids.length;
    this.kids.splice(idx, 0, n);
    this.childAdded(n, idx);
  }
  removeChildImpl(n) {
    const i = this.kids.indexOf(n);
    if (i < 0) return false;
    this.kids.splice(i, 1);
    n.parent = null;
    this.childRemoved(n, i);
    return true;
  }
  childAdded() { this.contentChanged(); }
  childRemoved() { this.contentChanged(); }
  contentChanged() { let p = this; while (p) { if (p.onContentChange) p.onContentChange(); p = p.parent; } }
  findById(id) {
    const low = String(id).toLowerCase();
    const stack = [this];
    while (stack.length) {
      const n = stack.shift();
      const nid = n.f.id;
      if (nid !== undefined && nid !== '' && String(nid).toLowerCase() === low) return n;
      for (const c of n.kids) stack.push(c);
    }
    return null;
  }
  toWire() {
    const f = {};
    for (const k in this.f) {
      const v = this.f[k];
      f[k] = $toWire(v);
    }
    return { __node: 1, type: this.type, f, ft: this.ftypes, k: this.kids.map(c => c.toWire()) };
  }
}
function $toWire(v) {
  if (v === null || typeof v !== 'object') return v;
  if (v.$isnode) return v.$t.toWire();
  if (Array.isArray(v)) return v.map($toWire);
  if (v instanceof Uint8Array) return v;
  if (v.$brsType) return null;
  const o = {};
  for (const k in v) o[k] = $toWire(v[k]);
  return o;
}
function $nodeBaseType(t) { return ($G.$COMP_EXTENDS && $G.$COMP_EXTENDS[t]) || t; }

// Metodos de nodo que ve el codigo BrightScript (node.$metodo)
var $NodeMethods = {
  $findnode(id) { const n = this.findById(id); return n ? n.proxy : null; },
  $getchild(i) { const n = this.kids[i]; return n ? n.proxy : null; },
  $getchildcount() { return this.kids.length; },
  $getchildren(count, start) { start = start || 0; const end = (count == null || count < 0) ? this.kids.length : start + count; return this.kids.slice(start, end).map(n => n.proxy); },
  $appendchild(c) { return this.appendChild(c); },
  $appendchildren(arr) { for (const c of arr) this.appendChild(c); return true; },
  $insertchild(c, i) { if (!c) return false; this.insertChildImpl(c.$t, i); return true; },
  $insertchildren(arr, i) { for (const c of arr) this.insertChildImpl(c.$t, i++); return true; },
  $removechild(c) { return c ? this.removeChildImpl(c.$t) : false; },
  $removechildren(arr) { for (const c of arr) if (c) this.removeChildImpl(c.$t); return true; },
  $removechildindex(i) { const n = this.kids[i]; return n ? this.removeChildImpl(n) : false; },
  $removechildrenindex(count, i) { for (let k = 0; k < count && this.kids[i]; k++) this.removeChildImpl(this.kids[i]); return true; },
  $replacechild(c, i) { const old = this.kids[i]; if (old) this.removeChildImpl(old); this.insertChildImpl(c.$t, i); return true; },
  $createchild(type) { const c = $createNode(type); if (!c) return null; this.appendChild(c); return c; },
  $getparent() { return this.parent ? this.parent.proxy : null; },
  $getscene() { let p = this; while (p.parent) p = p.parent; return p.proxy; },
  $clone(deep) { return $cloneNode(this, deep); },
  $clonenode(deep) { return $cloneNode(this, deep); },
  $issamenode(o) { return o != null && o.$isnode && o.$t === this; },
  $subtype() { return this.type; },
  $getid() { return this.get('id'); },
  $hasfield(k) { k = String(k).toLowerCase(); return (k in this.f) || (k in this.defaults()) || (this.ftypes && k in this.ftypes); },
  $getfield(k) { return this.proxy[String(k).toLowerCase()]; },
  $setfield(k, v) { this.proxy[String(k).toLowerCase()] = v; return true; },
  $getfields() { const o = $newAA(); for (const k in this.defaults()) o[k] = this.get(k); for (const k in this.f) o[k] = this.f[k]; return o; },
  $setfields(aa) { if (!aa) return true; for (const k in aa) this.proxy[k.toLowerCase()] = aa[k]; return true; },
  $addfield(k, type, always) { k = String(k).toLowerCase(); if (!this.ftypes) this.ftypes = Object.create(null); this.ftypes[k] = String(type).toLowerCase(); if (always) { if (!this.always) this.always = Object.create(null); this.always[k] = true; } if (!(k in this.f)) this.f[k] = $fieldDefault(type); return true; },
  $addfields(aa) {
    if (!aa) return true;
    for (const k in aa) {
      const v = aa[k];
      if (!this.ftypes) this.ftypes = Object.create(null);
      if (!(k in this.ftypes)) this.ftypes[k] = $guessType(v);
      this.set(k, v, true);
    }
    return true;
  },
  $removefield(k) { delete this.f[String(k).toLowerCase()]; return true; },
  $observefield(k, h, info) { return this.addObserver(k, h, $curScope, false, info); },
  $observefieldscoped(k, h, info) { return this.addObserver(k, h, $curScope, true, info); },
  $unobservefield(k) { this.removeObservers(k, $curScope, false); return true; },
  $unobservefieldscoped(k) { this.removeObservers(k, $curScope, true); return true; },
  $callfunc(name) {
    const args = Array.from(arguments).slice(1);
    const sc = this.scope;
    if (!sc) return null;
    const fn = sc.fns[String(name).toLowerCase()];
    if (!fn) return null;
    return $runInScope(sc, () => fn.apply(null, args));
  },
  $signalbeacon() { },
  $update(aa, add) { this.proxy.$setfields(aa); return true; },
  $count() { return this.kids.length; },
  $getall() { return this.kids.map(n => n.proxy); },
  $ifsgnodechildren() { return this.proxy; },
  $isinfocuschain() { return $isInFocusChain(this); },
  $hasfocus() { return $focusedNode === this; },
  $setfocus(on) { $setFocus(this, on); return true; },
  $getfocusednode() { return null; },
  $boundingrect() { return this.boundingRect ? this.boundingRect(false) : $newAA({ x: 0, y: 0, width: 0, height: 0 }); },
  $localboundingrect() { return this.boundingRect ? this.boundingRect(true) : $newAA({ x: 0, y: 0, width: 0, height: 0 }); },
  $sceneboundingrect() { return this.boundingRect ? this.boundingRect(false) : $newAA({ x: 0, y: 0, width: 0, height: 0 }); },
  $isnode: true
};
function $fieldDefault(type) {
  switch (String(type).toLowerCase()) {
    case 'string': case 'str': case 'uri': return '';
    case 'integer': case 'int': case 'float': case 'time': return 0;
    case 'boolean': case 'bool': return false;
    case 'array': case 'intarray': case 'floatarray': case 'stringarray': case 'boolarray': case 'nodearray': case 'vector2d': return [];
    case 'assocarray': return $newAA();
    default: return null;
  }
}
function $guessType(v) {
  if (typeof v === 'string') return 'string';
  if (typeof v === 'number') return Number.isInteger(v) ? 'integer' : 'float';
  if (typeof v === 'boolean') return 'boolean';
  if (Array.isArray(v)) return 'array';
  if (v && v.$isnode) return 'node';
  return 'assocarray';
}

var $focusedNode = null;
function $setFocus(n, on) { if ($G.$sceneSetFocus) return $G.$sceneSetFocus(n, on); if (on) $focusedNode = n; else if ($focusedNode === n) $focusedNode = null; }
function $isInFocusChain(n) { let f = $focusedNode; while (f) { if (f === n) return true; f = f.parent; } return false; }

var $NodeHandler = {
  get(t, k) {
    if (typeof k !== 'string') return undefined;
    if (k === '$t') return t;
    if (k.charCodeAt(0) === 36) { // '$'
      const fn = $NodeMethods[k] || (t.methods && t.methods[k]);
      if (fn) return typeof fn === 'function' ? fn.bind(t) : fn;
      return undefined;
    }
    if (k === 'toString') return () => '<Component: roSGNode:' + t.type + '>';
    return t.get(k.toLowerCase());
  },
  set(t, k, v) {
    if (typeof k !== 'string') return false;
    t.set(k.toLowerCase(), v);
    return true;
  },
  has(t, k) { return typeof k === 'string' && (k in t.f || k in t.defaults()); },
  ownKeys(t) { return Object.keys(t.f); },
  getOwnPropertyDescriptor(t, k) { if (k in t.f) return { value: t.f[k], enumerable: true, configurable: true, writable: true }; return undefined; }
};

function $cloneNode(n, deep) {
  const c = $createNode(n.type);
  const t = c.$t;
  if (n.ftypes) t.ftypes = Object.assign(Object.create(null), n.ftypes);
  for (const k in n.f) t.set(k, n.f[k], true);
  if (deep) for (const k of n.kids) t.appendChild($cloneNode(k, true));
  return c;
}

// Nodo creado desde el "cable" (mensaje de una tarea)
var $Node = {
  fromWire(w) {
    const p = $createNode(w.type);
    const t = p.$t;
    if (w.ft) t.ftypes = Object.assign(Object.create(null), w.ft);
    for (const k in w.f) t.f[k] = $hydrate(w.f[k], false);
    for (const k of w.k) { const cp = $Node.fromWire(k); const ct = cp.$t; ct.parent = t; t.kids.push(ct); }
    if (t.afterWire) t.afterWire();
    return p;
  }
};

function $dispatchObserver(o, nodeProxy, field, value) {
  if (typeof o.handler === 'function') { try { o.handler(value, nodeProxy, field); } catch (e) { $reportError(e); } return; }
  if (typeof o.handler === 'string') {
    const sc = o.scope;
    if (!sc) return;
    const fn = sc.fns[o.handler.toLowerCase()];
    if (!fn) { console.warn('observer sin funcion: ' + o.handler); return; }
    const ev = new $NodeEvent(nodeProxy, field, value, o.info);
    $runInScope(sc, () => (fn.length > 0 ? fn(ev) : fn()));
  } else if (o.handler && o.handler.$brsType === 'roMessagePort') {
    o.handler.q.push(new $NodeEvent(nodeProxy, field, value, o.info));
    if (o.handler.$wake) o.handler.$wake();
  }
}
class $NodeEvent {
  constructor(node, field, data, info) { this.$brsType = 'roSGNodeEvent'; this.n = node; this.fld = field; this.d = data; this.info = info; }
  $getdata() { return this.d; }
  $getfield() { return this.fld; }
  $getrosgnode() { return this.n; }
  $getnode() { return this.n ? this.n.id : ''; }
  $getinfo() { const o = $newAA(); if (this.info && this.n) for (const k of this.info) o[k.toLowerCase()] = this.n[k.toLowerCase()]; return o; }
}

function $runInScope(sc, f) {
  const prev = $curScope;
  $curScope = sc;
  try { return f(); } catch (e) { $reportError(e); return undefined; } finally { $curScope = prev; }
}
function $reportError(e) {
  console.error('[BRS] ' + (e && e.stack ? e.stack : e));
  if ($G.$onBrsError) $G.$onBrsError(e);
}

// Registro de componentes (XML) y fabricas
var $COMPONENTS = {};
var $COMP_EXTENDS = {};
$G.$COMP_EXTENDS = $COMP_EXTENDS;
function $defineComponent(spec, factory) {
  $COMPONENTS[spec.name] = { spec, factory };
  $COMP_EXTENDS[spec.name] = spec.extends;
}

// En el hilo principal scene.js reemplaza $createNode por uno que dibuja.
function $createNodeBase(type) {
  const n = new $NodeBase(type);
  return n.proxy;
}
var $createNode = function (type) { return $createNodeBase(type); };

function $createobject(kind, a, b) {
  switch (String(kind).toLowerCase()) {
    case 'rosgnode': return $createNode(a);
    case 'roassociativearray': return $newAA();
    case 'roarray': case 'rolist': return [];
    case 'rodatetime': return new $DateTime();
    case 'rotimespan': return new $Timespan();
    case 'roregex': return new $Regex(a, b);
    case 'robytearray': return new $ByteArray();
    case 'roevpdigest': return new $EVPDigest();
    case 'rofilesystem': return new $FileSystem();
    case 'rourltransfer': return new $UrlTransfer();
    case 'romessageport': return new $MessagePort();
    case 'roregistrysection': return new $RegistrySection(a);
    case 'roregistry': return new $Registry();
    case 'rodeviceinfo': return new $DeviceInfo();
    case 'roappinfo': return new $AppInfo();
    case 'rostring': return '';
    case 'roint': case 'rointeger': return 0;
    case 'rostreamsocket': case 'rosocketaddress': return $G.$createSocket ? $G.$createSocket(kind) : null;
    case 'roinput': return { $brsType: 'roInput', $setmessageport() { } };
    default:
      console.warn('CreateObject no soportado: ' + kind);
      return null;
  }
}
